package p004io.kodular.anshsingh2006_1.COV_AID_2;

import android.support.p000v4.app.FragmentTransaction;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.ListView;
import com.google.appinventor.components.runtime.MakeroidCircularProgress;
import com.google.appinventor.components.runtime.MakeroidListViewImageText;
import com.google.appinventor.components.runtime.MakeroidSnackbar;
import com.google.appinventor.components.runtime.MakeroidViewPager;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1241runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.C1271lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import org.jose4j.jws.AlgorithmIdentifiers;
import p012yt.DeepHost.InApp_PDFViewer.C1691InApp_PDFViewer;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen2 */
/* compiled from: Screen2.yail */
public class Screen2 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final SimpleSymbol Lit100;
    static final FString Lit101;
    static final FString Lit102;
    static final SimpleSymbol Lit103;
    static final SimpleSymbol Lit104;
    static final IntNum Lit105;
    static final FString Lit106;
    static final FString Lit107;
    static final IntNum Lit108;
    static final SimpleSymbol Lit109;
    static final SimpleSymbol Lit11;
    static final SimpleSymbol Lit110;
    static final IntNum Lit111;
    static final SimpleSymbol Lit112;
    static final IntNum Lit113;
    static final FString Lit114;
    static final SimpleSymbol Lit115;
    static final SimpleSymbol Lit116;
    static final SimpleSymbol Lit117;
    static final PairWithPosition Lit118 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 626885), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 626879);
    static final PairWithPosition Lit119 = PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 626915);
    static final IntNum Lit12;
    static final SimpleSymbol Lit120;
    static final SimpleSymbol Lit121;
    static final FString Lit122;
    static final IntNum Lit123;
    static final SimpleSymbol Lit124;
    static final IntNum Lit125;
    static final SimpleSymbol Lit126;
    static final IntNum Lit127;
    static final FString Lit128;
    static final SimpleSymbol Lit129;
    static final SimpleSymbol Lit13;
    static final SimpleSymbol Lit130;
    static final FString Lit131;
    static final SimpleSymbol Lit132;
    static final FString Lit133;
    static final FString Lit134;
    static final FString Lit135;
    static final SimpleSymbol Lit136;
    static final PairWithPosition Lit137 = PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737478);
    static final SimpleSymbol Lit138;
    static final PairWithPosition Lit139 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737710), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737704);
    static final SimpleSymbol Lit14;
    static final PairWithPosition Lit140 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit233, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737747), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737741);
    static final IntNum Lit141 = IntNum.make(2);
    static final PairWithPosition Lit142 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737950), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737944);
    static final PairWithPosition Lit143 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit233, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737987), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 737981);
    static final SimpleSymbol Lit144;
    static final SimpleSymbol Lit145;
    static final SimpleSymbol Lit146;
    static final SimpleSymbol Lit147;
    static final PairWithPosition Lit148 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738353), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738347);
    static final PairWithPosition Lit149 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738495), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738489);
    static final IntNum Lit15 = IntNum.make(3);
    static final PairWithPosition Lit150 = PairWithPosition.make(Lit17, PairWithPosition.make(Lit17, PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738536), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738531), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738525);
    static final PairWithPosition Lit151 = PairWithPosition.make(Lit145, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 738629);
    static final SimpleSymbol Lit152;
    static final SimpleSymbol Lit153;
    static final FString Lit154;
    static final SimpleSymbol Lit155;
    static final FString Lit156;
    static final FString Lit157;
    static final IntNum Lit158;
    static final FString Lit159;
    static final SimpleSymbol Lit16;
    static final FString Lit160;
    static final SimpleSymbol Lit161;
    static final IntNum Lit162 = IntNum.make(16777215);
    static final FString Lit163;
    static final FString Lit164;
    static final SimpleSymbol Lit165;
    static final IntNum Lit166;
    static final FString Lit167;
    static final PairWithPosition Lit168 = PairWithPosition.make(Lit233, PairWithPosition.make(Lit233, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 909415), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 909410);
    static final SimpleSymbol Lit169;
    static final SimpleSymbol Lit17;
    static final SimpleSymbol Lit170;
    static final SimpleSymbol Lit171;
    static final FString Lit172;
    static final SimpleSymbol Lit173;
    static final IntNum Lit174;
    static final FString Lit175;
    static final FString Lit176;
    static final SimpleSymbol Lit177;
    static final IntNum Lit178;
    static final IntNum Lit179;
    static final SimpleSymbol Lit18;
    static final FString Lit180;
    static final PairWithPosition Lit181 = PairWithPosition.make(Lit234, PairWithPosition.make(Lit17, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1040594), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1040589), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1040578);
    static final SimpleSymbol Lit182;
    static final FString Lit183;
    static final FString Lit184;
    static final FString Lit185;
    static final IntNum Lit186;
    static final IntNum Lit187;
    static final IntNum Lit188;
    static final FString Lit189;
    static final SimpleSymbol Lit19;
    static final PairWithPosition Lit190 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1163466), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1163460);
    static final PairWithPosition Lit191 = PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1163496);
    static final SimpleSymbol Lit192;
    static final FString Lit193;
    static final IntNum Lit194;
    static final FString Lit195;
    static final FString Lit196;
    static final SimpleSymbol Lit197;
    static final FString Lit198;
    static final FString Lit199;
    static final SimpleSymbol Lit2;
    static final IntNum Lit20;
    static final FString Lit200;
    static final PairWithPosition Lit201 = PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1257599);
    static final PairWithPosition Lit202 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1257831), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1257825);
    static final PairWithPosition Lit203 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit233, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1257868), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1257862);
    static final PairWithPosition Lit204 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258071), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258065);
    static final PairWithPosition Lit205 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit233, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258108), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258102);
    static final PairWithPosition Lit206 = PairWithPosition.make(Lit145, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258475), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258469);
    static final PairWithPosition Lit207;
    static final PairWithPosition Lit208;
    static final PairWithPosition Lit209;
    static final SimpleSymbol Lit21;
    static final SimpleSymbol Lit210;
    static final FString Lit211;
    static final SimpleSymbol Lit212;
    static final FString Lit213;
    static final FString Lit214;
    static final FString Lit215;
    static final FString Lit216;
    static final FString Lit217;
    static final SimpleSymbol Lit218;
    static final SimpleSymbol Lit219;
    static final IntNum Lit22;
    static final SimpleSymbol Lit220;
    static final SimpleSymbol Lit221;
    static final SimpleSymbol Lit222;
    static final SimpleSymbol Lit223;
    static final SimpleSymbol Lit224;
    static final SimpleSymbol Lit225;
    static final SimpleSymbol Lit226;
    static final SimpleSymbol Lit227;
    static final SimpleSymbol Lit228;
    static final SimpleSymbol Lit229;
    static final SimpleSymbol Lit23;
    static final SimpleSymbol Lit230;
    static final SimpleSymbol Lit231;
    static final SimpleSymbol Lit232;
    static final SimpleSymbol Lit233;
    static final SimpleSymbol Lit234;
    static final SimpleSymbol Lit24;
    static final SimpleSymbol Lit25;
    static final SimpleSymbol Lit26;
    static final SimpleSymbol Lit27;
    static final SimpleSymbol Lit28;
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit3;
    static final PairWithPosition Lit30 = PairWithPosition.make(Lit234, PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123035), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123024);
    static final SimpleSymbol Lit31;
    static final PairWithPosition Lit32 = PairWithPosition.make(Lit234, PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123192), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123181);
    static final SimpleSymbol Lit33;
    static final SimpleSymbol Lit34;
    static final SimpleSymbol Lit35;
    static final SimpleSymbol Lit36;
    static final SimpleSymbol Lit37;
    static final SimpleSymbol Lit38;
    static final SimpleSymbol Lit39;
    static final SimpleSymbol Lit4;
    static final PairWithPosition Lit40;
    static final SimpleSymbol Lit41;
    static final SimpleSymbol Lit42;
    static final PairWithPosition Lit43 = PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 131147);
    static final SimpleSymbol Lit44;
    static final SimpleSymbol Lit45;
    static final FString Lit46;
    static final SimpleSymbol Lit47;
    static final IntNum Lit48 = IntNum.make(-2);
    static final SimpleSymbol Lit49;
    static final SimpleSymbol Lit5;
    static final SimpleSymbol Lit50;
    static final IntNum Lit51;
    static final SimpleSymbol Lit52;
    static final IntNum Lit53;
    static final FString Lit54;
    static final FString Lit55;
    static final SimpleSymbol Lit56;
    static final IntNum Lit57;
    static final FString Lit58;
    static final FString Lit59;
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final IntNum Lit61 = IntNum.make(16777215);
    static final FString Lit62;
    static final FString Lit63;
    static final SimpleSymbol Lit64;
    static final IntNum Lit65;
    static final SimpleSymbol Lit66;
    static final IntNum Lit67 = IntNum.make(20);
    static final SimpleSymbol Lit68;
    static final IntNum Lit69 = IntNum.make(7);
    static final SimpleSymbol Lit7;
    static final IntNum Lit70 = IntNum.make(30);
    static final SimpleSymbol Lit71;
    static final FString Lit72;
    static final PairWithPosition Lit73 = PairWithPosition.make(Lit233, PairWithPosition.make(Lit233, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 344166), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 344161);
    static final SimpleSymbol Lit74;
    static final SimpleSymbol Lit75;
    static final SimpleSymbol Lit76;
    static final SimpleSymbol Lit77;
    static final SimpleSymbol Lit78;
    static final FString Lit79;
    static final SimpleSymbol Lit8;
    static final SimpleSymbol Lit80;
    static final SimpleSymbol Lit81;
    static final IntNum Lit82 = IntNum.make(25);
    static final SimpleSymbol Lit83;
    static final IntNum Lit84 = IntNum.make(1);
    static final SimpleSymbol Lit85;
    static final IntNum Lit86;
    static final FString Lit87;
    static final FString Lit88;
    static final SimpleSymbol Lit89;
    static final SimpleSymbol Lit9;
    static final IntNum Lit90;
    static final IntNum Lit91;
    static final FString Lit92;
    static final SimpleSymbol Lit93;
    static final SimpleSymbol Lit94;
    static final SimpleSymbol Lit95;
    static final PairWithPosition Lit96 = PairWithPosition.make(Lit234, PairWithPosition.make(Lit17, PairWithPosition.make(Lit13, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 475346), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 475341), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 475330);
    static final SimpleSymbol Lit97;
    static final SimpleSymbol Lit98;
    static final FString Lit99;
    public static Screen2 Screen2;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn32 = null;
    static final ModuleMethod lambda$Fn33 = null;
    static final ModuleMethod lambda$Fn34 = null;
    static final ModuleMethod lambda$Fn35 = null;
    static final ModuleMethod lambda$Fn36 = null;
    static final ModuleMethod lambda$Fn37 = null;
    static final ModuleMethod lambda$Fn38 = null;
    static final ModuleMethod lambda$Fn39 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn40 = null;
    static final ModuleMethod lambda$Fn41 = null;
    static final ModuleMethod lambda$Fn42 = null;
    static final ModuleMethod lambda$Fn43 = null;
    static final ModuleMethod lambda$Fn44 = null;
    static final ModuleMethod lambda$Fn45 = null;
    static final ModuleMethod lambda$Fn46 = null;
    static final ModuleMethod lambda$Fn47 = null;
    static final ModuleMethod lambda$Fn48 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn50 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn9 = null;
    static final ModuleMethod proc$Fn31 = null;
    static final ModuleMethod proc$Fn49 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public Button Button1;
    public final ModuleMethod Button1$Click;
    public Button Button1_copy;
    public final ModuleMethod Button1_copy$Click;
    public Button Button2;
    public final ModuleMethod Button2$Click;
    public Button Button3;
    public final ModuleMethod Button3$Click;
    public MakeroidCircularProgress Circular_Progress1;
    public Web Get_data_web;
    public final ModuleMethod Get_data_web$GotText;
    public HorizontalArrangement Horizontal_Arrangement1;
    public HorizontalArrangement Horizontal_Arrangement2;
    public C1691InApp_PDFViewer InApp_PDFViewer1;
    public C1691InApp_PDFViewer InApp_PDFViewer2;
    public Label Label1;
    public Label Label1_copy;
    public ListView List_View1;
    public final ModuleMethod List_View1$AfterPicking;
    public ListView List_View1_copy;
    public final ModuleMethod List_View1_copy$AfterPicking;
    public MakeroidListViewImageText List_View_Image_and_Text1;
    public MakeroidListViewImageText List_View_Image_and_Text2;
    public Notifier Notifier1;
    public Notifier Notifier2;
    public final ModuleMethod Screen2$BackPressed;
    public final ModuleMethod Screen2$Initialize;
    public Web Send_data_web;
    public MakeroidSnackbar Snackbar1;
    public final ModuleMethod Snackbar1$Click;
    public VerticalArrangement Vertical_Arrangement1;
    public VerticalArrangement Vertical_Arrangement1_copy;
    public VerticalArrangement Vertical_Arrangement2;
    public MakeroidViewPager View_Pager1;
    public Web Web1;
    public final ModuleMethod Web1$GotText;
    public Web Web2;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        SimpleSymbol simpleSymbol15;
        SimpleSymbol simpleSymbol16;
        SimpleSymbol simpleSymbol17;
        FString fString;
        FString fString2;
        FString fString3;
        FString fString4;
        FString fString5;
        SimpleSymbol simpleSymbol18;
        FString fString6;
        SimpleSymbol simpleSymbol19;
        SimpleSymbol simpleSymbol20;
        SimpleSymbol simpleSymbol21;
        SimpleSymbol simpleSymbol22;
        FString fString7;
        FString fString8;
        FString fString9;
        SimpleSymbol simpleSymbol23;
        FString fString10;
        FString fString11;
        FString fString12;
        SimpleSymbol simpleSymbol24;
        FString fString13;
        FString fString14;
        FString fString15;
        FString fString16;
        SimpleSymbol simpleSymbol25;
        FString fString17;
        SimpleSymbol simpleSymbol26;
        FString fString18;
        FString fString19;
        SimpleSymbol simpleSymbol27;
        FString fString20;
        SimpleSymbol simpleSymbol28;
        SimpleSymbol simpleSymbol29;
        SimpleSymbol simpleSymbol30;
        FString fString21;
        SimpleSymbol simpleSymbol31;
        FString fString22;
        FString fString23;
        SimpleSymbol simpleSymbol32;
        FString fString24;
        FString fString25;
        FString fString26;
        FString fString27;
        SimpleSymbol simpleSymbol33;
        FString fString28;
        SimpleSymbol simpleSymbol34;
        SimpleSymbol simpleSymbol35;
        SimpleSymbol simpleSymbol36;
        SimpleSymbol simpleSymbol37;
        SimpleSymbol simpleSymbol38;
        SimpleSymbol simpleSymbol39;
        SimpleSymbol simpleSymbol40;
        FString fString29;
        FString fString30;
        FString fString31;
        SimpleSymbol simpleSymbol41;
        FString fString32;
        SimpleSymbol simpleSymbol42;
        SimpleSymbol simpleSymbol43;
        FString fString33;
        SimpleSymbol simpleSymbol44;
        SimpleSymbol simpleSymbol45;
        FString fString34;
        SimpleSymbol simpleSymbol46;
        SimpleSymbol simpleSymbol47;
        SimpleSymbol simpleSymbol48;
        SimpleSymbol simpleSymbol49;
        SimpleSymbol simpleSymbol50;
        FString fString35;
        SimpleSymbol simpleSymbol51;
        SimpleSymbol simpleSymbol52;
        SimpleSymbol simpleSymbol53;
        FString fString36;
        FString fString37;
        SimpleSymbol simpleSymbol54;
        SimpleSymbol simpleSymbol55;
        FString fString38;
        FString fString39;
        SimpleSymbol simpleSymbol56;
        FString fString40;
        SimpleSymbol simpleSymbol57;
        SimpleSymbol simpleSymbol58;
        SimpleSymbol simpleSymbol59;
        SimpleSymbol simpleSymbol60;
        SimpleSymbol simpleSymbol61;
        FString fString41;
        SimpleSymbol simpleSymbol62;
        FString fString42;
        FString fString43;
        SimpleSymbol simpleSymbol63;
        SimpleSymbol simpleSymbol64;
        SimpleSymbol simpleSymbol65;
        SimpleSymbol simpleSymbol66;
        FString fString44;
        SimpleSymbol simpleSymbol67;
        SimpleSymbol simpleSymbol68;
        SimpleSymbol simpleSymbol69;
        SimpleSymbol simpleSymbol70;
        SimpleSymbol simpleSymbol71;
        FString fString45;
        SimpleSymbol simpleSymbol72;
        SimpleSymbol simpleSymbol73;
        SimpleSymbol simpleSymbol74;
        SimpleSymbol simpleSymbol75;
        FString fString46;
        FString fString47;
        SimpleSymbol simpleSymbol76;
        FString fString48;
        FString fString49;
        SimpleSymbol simpleSymbol77;
        FString fString50;
        FString fString51;
        SimpleSymbol simpleSymbol78;
        SimpleSymbol simpleSymbol79;
        SimpleSymbol simpleSymbol80;
        SimpleSymbol simpleSymbol81;
        FString fString52;
        SimpleSymbol simpleSymbol82;
        SimpleSymbol simpleSymbol83;
        SimpleSymbol simpleSymbol84;
        SimpleSymbol simpleSymbol85;
        SimpleSymbol simpleSymbol86;
        SimpleSymbol simpleSymbol87;
        SimpleSymbol simpleSymbol88;
        SimpleSymbol simpleSymbol89;
        SimpleSymbol simpleSymbol90;
        SimpleSymbol simpleSymbol91;
        SimpleSymbol simpleSymbol92;
        SimpleSymbol simpleSymbol93;
        SimpleSymbol simpleSymbol94;
        SimpleSymbol simpleSymbol95;
        SimpleSymbol simpleSymbol96;
        SimpleSymbol simpleSymbol97;
        SimpleSymbol simpleSymbol98;
        SimpleSymbol simpleSymbol99;
        SimpleSymbol simpleSymbol100;
        SimpleSymbol simpleSymbol101;
        SimpleSymbol simpleSymbol102;
        SimpleSymbol simpleSymbol103;
        SimpleSymbol simpleSymbol104;
        SimpleSymbol simpleSymbol105;
        SimpleSymbol simpleSymbol106;
        SimpleSymbol simpleSymbol107;
        SimpleSymbol simpleSymbol108;
        SimpleSymbol simpleSymbol109;
        SimpleSymbol simpleSymbol110;
        SimpleSymbol simpleSymbol111;
        SimpleSymbol simpleSymbol112;
        SimpleSymbol simpleSymbol113;
        SimpleSymbol simpleSymbol114;
        SimpleSymbol simpleSymbol115;
        SimpleSymbol simpleSymbol116;
        SimpleSymbol simpleSymbol117;
        new SimpleSymbol("component");
        Lit234 = (SimpleSymbol) simpleSymbol.readResolve();
        new SimpleSymbol("any");
        Lit233 = (SimpleSymbol) simpleSymbol2.readResolve();
        new SimpleSymbol("proc");
        Lit232 = (SimpleSymbol) simpleSymbol3.readResolve();
        new SimpleSymbol("lookup-handler");
        Lit231 = (SimpleSymbol) simpleSymbol4.readResolve();
        new SimpleSymbol("dispatchGenericEvent");
        Lit230 = (SimpleSymbol) simpleSymbol5.readResolve();
        new SimpleSymbol("dispatchEvent");
        Lit229 = (SimpleSymbol) simpleSymbol6.readResolve();
        new SimpleSymbol("send-error");
        Lit228 = (SimpleSymbol) simpleSymbol7.readResolve();
        new SimpleSymbol("add-to-form-do-after-creation");
        Lit227 = (SimpleSymbol) simpleSymbol8.readResolve();
        new SimpleSymbol("add-to-global-vars");
        Lit226 = (SimpleSymbol) simpleSymbol9.readResolve();
        new SimpleSymbol("add-to-components");
        Lit225 = (SimpleSymbol) simpleSymbol10.readResolve();
        new SimpleSymbol("add-to-events");
        Lit224 = (SimpleSymbol) simpleSymbol11.readResolve();
        new SimpleSymbol("add-to-global-var-environment");
        Lit223 = (SimpleSymbol) simpleSymbol12.readResolve();
        new SimpleSymbol("is-bound-in-form-environment");
        Lit222 = (SimpleSymbol) simpleSymbol13.readResolve();
        new SimpleSymbol("lookup-in-form-environment");
        Lit221 = (SimpleSymbol) simpleSymbol14.readResolve();
        new SimpleSymbol("add-to-form-environment");
        Lit220 = (SimpleSymbol) simpleSymbol15.readResolve();
        new SimpleSymbol("android-log-form");
        Lit219 = (SimpleSymbol) simpleSymbol16.readResolve();
        new SimpleSymbol("get-simple-name");
        Lit218 = (SimpleSymbol) simpleSymbol17.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit217 = fString;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit216 = fString2;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit215 = fString3;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit214 = fString4;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit213 = fString5;
        new SimpleSymbol("Web2");
        Lit212 = (SimpleSymbol) simpleSymbol18.readResolve();
        new FString("com.google.appinventor.components.runtime.Web");
        Lit211 = fString6;
        new SimpleSymbol("Web1$GotText");
        Lit210 = (SimpleSymbol) simpleSymbol19.readResolve();
        new SimpleSymbol("list");
        SimpleSymbol simpleSymbol118 = (SimpleSymbol) simpleSymbol20.readResolve();
        Lit145 = simpleSymbol118;
        Lit209 = PairWithPosition.make(simpleSymbol118, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258751);
        new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol119 = (SimpleSymbol) simpleSymbol21.readResolve();
        Lit17 = simpleSymbol119;
        Lit208 = PairWithPosition.make(simpleSymbol119, PairWithPosition.make(Lit17, PairWithPosition.make(Lit17, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258658), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258653), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258647);
        SimpleSymbol simpleSymbol120 = Lit145;
        new SimpleSymbol("number");
        SimpleSymbol simpleSymbol121 = (SimpleSymbol) simpleSymbol22.readResolve();
        Lit13 = simpleSymbol121;
        Lit207 = PairWithPosition.make(simpleSymbol120, PairWithPosition.make(simpleSymbol121, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258617), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 1258611);
        new FString("com.google.appinventor.components.runtime.Web");
        Lit200 = fString7;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit199 = fString8;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit198 = fString9;
        new SimpleSymbol("InApp_PDFViewer1");
        Lit197 = (SimpleSymbol) simpleSymbol23.readResolve();
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit196 = fString10;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit195 = fString11;
        int[] iArr = new int[2];
        iArr[0] = -5138;
        Lit194 = IntNum.make(iArr);
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit193 = fString12;
        new SimpleSymbol("List_View1_copy$AfterPicking");
        Lit192 = (SimpleSymbol) simpleSymbol24.readResolve();
        new FString("com.google.appinventor.components.runtime.ListView");
        Lit189 = fString13;
        int[] iArr2 = new int[2];
        iArr2[0] = -5138;
        Lit188 = IntNum.make(iArr2);
        int[] iArr3 = new int[2];
        iArr3[0] = -16777216;
        Lit187 = IntNum.make(iArr3);
        int[] iArr4 = new int[2];
        iArr4[0] = -769226;
        Lit186 = IntNum.make(iArr4);
        new FString("com.google.appinventor.components.runtime.ListView");
        Lit185 = fString14;
        new FString("com.google.appinventor.components.runtime.MakeroidListViewImageText");
        Lit184 = fString15;
        new FString("com.google.appinventor.components.runtime.MakeroidListViewImageText");
        Lit183 = fString16;
        new SimpleSymbol("Button1_copy$Click");
        Lit182 = (SimpleSymbol) simpleSymbol25.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit180 = fString17;
        int[] iArr5 = new int[2];
        iArr5[0] = -5138;
        Lit179 = IntNum.make(iArr5);
        int[] iArr6 = new int[2];
        iArr6[0] = -769226;
        Lit178 = IntNum.make(iArr6);
        new SimpleSymbol("Button1_copy");
        Lit177 = (SimpleSymbol) simpleSymbol26.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit176 = fString18;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit175 = fString19;
        int[] iArr7 = new int[2];
        iArr7[0] = -769226;
        Lit174 = IntNum.make(iArr7);
        new SimpleSymbol("Label1_copy");
        Lit173 = (SimpleSymbol) simpleSymbol27.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit172 = fString20;
        new SimpleSymbol("Button3$Click");
        Lit171 = (SimpleSymbol) simpleSymbol28.readResolve();
        new SimpleSymbol("List_View1_copy");
        Lit170 = (SimpleSymbol) simpleSymbol29.readResolve();
        new SimpleSymbol("List_View_Image_and_Text2");
        Lit169 = (SimpleSymbol) simpleSymbol30.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit167 = fString21;
        int[] iArr8 = new int[2];
        iArr8[0] = -769226;
        Lit166 = IntNum.make(iArr8);
        new SimpleSymbol("Button3");
        Lit165 = (SimpleSymbol) simpleSymbol31.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit164 = fString22;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit163 = fString23;
        new SimpleSymbol("Horizontal_Arrangement2");
        Lit161 = (SimpleSymbol) simpleSymbol32.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit160 = fString24;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit159 = fString25;
        int[] iArr9 = new int[2];
        iArr9[0] = -5138;
        Lit158 = IntNum.make(iArr9);
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit157 = fString26;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit156 = fString27;
        new SimpleSymbol("Notifier1");
        Lit155 = (SimpleSymbol) simpleSymbol33.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit154 = fString28;
        new SimpleSymbol("GotText");
        Lit153 = (SimpleSymbol) simpleSymbol34.readResolve();
        new SimpleSymbol("Get_data_web$GotText");
        Lit152 = (SimpleSymbol) simpleSymbol35.readResolve();
        new SimpleSymbol("$number");
        Lit147 = (SimpleSymbol) simpleSymbol36.readResolve();
        new SimpleSymbol("AddItem");
        Lit146 = (SimpleSymbol) simpleSymbol37.readResolve();
        new SimpleSymbol("Elements");
        Lit144 = (SimpleSymbol) simpleSymbol38.readResolve();
        new SimpleSymbol("$item");
        Lit138 = (SimpleSymbol) simpleSymbol39.readResolve();
        new SimpleSymbol("$responseContent");
        Lit136 = (SimpleSymbol) simpleSymbol40.readResolve();
        new FString("com.google.appinventor.components.runtime.Web");
        Lit135 = fString29;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit134 = fString30;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit133 = fString31;
        new SimpleSymbol("Send_data_web");
        Lit132 = (SimpleSymbol) simpleSymbol41.readResolve();
        new FString("com.google.appinventor.components.runtime.Web");
        Lit131 = fString32;
        new SimpleSymbol("Snackbar1$Click");
        Lit130 = (SimpleSymbol) simpleSymbol42.readResolve();
        new SimpleSymbol("Dismiss");
        Lit129 = (SimpleSymbol) simpleSymbol43.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidSnackbar");
        Lit128 = fString33;
        int[] iArr10 = new int[2];
        iArr10[0] = -769226;
        Lit127 = IntNum.make(iArr10);
        new SimpleSymbol("Duration");
        Lit126 = (SimpleSymbol) simpleSymbol44.readResolve();
        int[] iArr11 = new int[2];
        iArr11[0] = -16777216;
        Lit125 = IntNum.make(iArr11);
        new SimpleSymbol("ButtonTextColor");
        Lit124 = (SimpleSymbol) simpleSymbol45.readResolve();
        int[] iArr12 = new int[2];
        iArr12[0] = -5138;
        Lit123 = IntNum.make(iArr12);
        new FString("com.google.appinventor.components.runtime.MakeroidSnackbar");
        Lit122 = fString34;
        new SimpleSymbol("AfterPicking");
        Lit121 = (SimpleSymbol) simpleSymbol46.readResolve();
        new SimpleSymbol("List_View1$AfterPicking");
        Lit120 = (SimpleSymbol) simpleSymbol47.readResolve();
        new SimpleSymbol("SelectionIndex");
        Lit117 = (SimpleSymbol) simpleSymbol48.readResolve();
        new SimpleSymbol("Show");
        Lit116 = (SimpleSymbol) simpleSymbol49.readResolve();
        new SimpleSymbol("Snackbar1");
        Lit115 = (SimpleSymbol) simpleSymbol50.readResolve();
        new FString("com.google.appinventor.components.runtime.ListView");
        Lit114 = fString35;
        int[] iArr13 = new int[2];
        iArr13[0] = -5138;
        Lit113 = IntNum.make(iArr13);
        new SimpleSymbol("ShowFilterBar");
        Lit112 = (SimpleSymbol) simpleSymbol51.readResolve();
        int[] iArr14 = new int[2];
        iArr14[0] = -16777216;
        Lit111 = IntNum.make(iArr14);
        new SimpleSymbol("SearchTextColor");
        Lit110 = (SimpleSymbol) simpleSymbol52.readResolve();
        new SimpleSymbol("FilterBarHint");
        Lit109 = (SimpleSymbol) simpleSymbol53.readResolve();
        int[] iArr15 = new int[2];
        iArr15[0] = -769226;
        Lit108 = IntNum.make(iArr15);
        new FString("com.google.appinventor.components.runtime.ListView");
        Lit107 = fString36;
        new FString("com.google.appinventor.components.runtime.MakeroidCircularProgress");
        Lit106 = fString37;
        int[] iArr16 = new int[2];
        iArr16[0] = -769226;
        Lit105 = IntNum.make(iArr16);
        new SimpleSymbol("Color");
        Lit104 = (SimpleSymbol) simpleSymbol54.readResolve();
        new SimpleSymbol("Circular_Progress1");
        Lit103 = (SimpleSymbol) simpleSymbol55.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidCircularProgress");
        Lit102 = fString38;
        new FString("com.google.appinventor.components.runtime.MakeroidListViewImageText");
        Lit101 = fString39;
        new SimpleSymbol("TitleBold");
        Lit100 = (SimpleSymbol) simpleSymbol56.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidListViewImageText");
        Lit99 = fString40;
        new SimpleSymbol("Button1$Click");
        Lit98 = (SimpleSymbol) simpleSymbol57.readResolve();
        new SimpleSymbol("ShowCustomDialog");
        Lit97 = (SimpleSymbol) simpleSymbol58.readResolve();
        new SimpleSymbol("HORIZONTAL");
        Lit95 = (SimpleSymbol) simpleSymbol59.readResolve();
        new SimpleSymbol("PDF_Load_From_Assest");
        Lit94 = (SimpleSymbol) simpleSymbol60.readResolve();
        new SimpleSymbol("InApp_PDFViewer2");
        Lit93 = (SimpleSymbol) simpleSymbol61.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit92 = fString41;
        int[] iArr17 = new int[2];
        iArr17[0] = -5138;
        Lit91 = IntNum.make(iArr17);
        int[] iArr18 = new int[2];
        iArr18[0] = -769226;
        Lit90 = IntNum.make(iArr18);
        new SimpleSymbol("Button1");
        Lit89 = (SimpleSymbol) simpleSymbol62.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit88 = fString42;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit87 = fString43;
        int[] iArr19 = new int[2];
        iArr19[0] = -769226;
        Lit86 = IntNum.make(iArr19);
        new SimpleSymbol("TextColor");
        Lit85 = (SimpleSymbol) simpleSymbol63.readResolve();
        new SimpleSymbol("TextAlignment");
        Lit83 = (SimpleSymbol) simpleSymbol64.readResolve();
        new SimpleSymbol("FontBold");
        Lit81 = (SimpleSymbol) simpleSymbol65.readResolve();
        new SimpleSymbol("Label1");
        Lit80 = (SimpleSymbol) simpleSymbol66.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit79 = fString44;
        new SimpleSymbol("Click");
        Lit78 = (SimpleSymbol) simpleSymbol67.readResolve();
        new SimpleSymbol("Button2$Click");
        Lit77 = (SimpleSymbol) simpleSymbol68.readResolve();
        new SimpleSymbol("List_View1");
        Lit76 = (SimpleSymbol) simpleSymbol69.readResolve();
        new SimpleSymbol("Visible");
        Lit75 = (SimpleSymbol) simpleSymbol70.readResolve();
        new SimpleSymbol("List_View_Image_and_Text1");
        Lit74 = (SimpleSymbol) simpleSymbol71.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit72 = fString45;
        new SimpleSymbol("Text");
        Lit71 = (SimpleSymbol) simpleSymbol72.readResolve();
        new SimpleSymbol("FontTypeface");
        Lit68 = (SimpleSymbol) simpleSymbol73.readResolve();
        new SimpleSymbol("FontSize");
        Lit66 = (SimpleSymbol) simpleSymbol74.readResolve();
        int[] iArr20 = new int[2];
        iArr20[0] = -769226;
        Lit65 = IntNum.make(iArr20);
        new SimpleSymbol("Button2");
        Lit64 = (SimpleSymbol) simpleSymbol75.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit63 = fString46;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit62 = fString47;
        new SimpleSymbol("Horizontal_Arrangement1");
        Lit60 = (SimpleSymbol) simpleSymbol76.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit59 = fString48;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit58 = fString49;
        int[] iArr21 = new int[2];
        iArr21[0] = -5138;
        Lit57 = IntNum.make(iArr21);
        new SimpleSymbol("BackgroundColor");
        Lit56 = (SimpleSymbol) simpleSymbol77.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit55 = fString50;
        new FString("com.google.appinventor.components.runtime.MakeroidViewPager");
        Lit54 = fString51;
        int[] iArr22 = new int[2];
        iArr22[0] = -769226;
        Lit53 = IntNum.make(iArr22);
        new SimpleSymbol("TabsBackgroundColor");
        Lit52 = (SimpleSymbol) simpleSymbol78.readResolve();
        int[] iArr23 = new int[2];
        iArr23[0] = -5138;
        Lit51 = IntNum.make(iArr23);
        new SimpleSymbol("TabsActiveTextColor");
        Lit50 = (SimpleSymbol) simpleSymbol79.readResolve();
        new SimpleSymbol("Width");
        Lit49 = (SimpleSymbol) simpleSymbol80.readResolve();
        new SimpleSymbol("Height");
        Lit47 = (SimpleSymbol) simpleSymbol81.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidViewPager");
        Lit46 = fString52;
        new SimpleSymbol("BackPressed");
        Lit45 = (SimpleSymbol) simpleSymbol82.readResolve();
        new SimpleSymbol("Screen2$BackPressed");
        Lit44 = (SimpleSymbol) simpleSymbol83.readResolve();
        new SimpleSymbol("Initialize");
        Lit42 = (SimpleSymbol) simpleSymbol84.readResolve();
        new SimpleSymbol("Screen2$Initialize");
        Lit41 = (SimpleSymbol) simpleSymbol85.readResolve();
        SimpleSymbol simpleSymbol122 = Lit234;
        SimpleSymbol simpleSymbol123 = Lit17;
        SimpleSymbol simpleSymbol124 = Lit17;
        SimpleSymbol simpleSymbol125 = Lit17;
        new SimpleSymbol("boolean");
        SimpleSymbol simpleSymbol126 = (SimpleSymbol) simpleSymbol86.readResolve();
        Lit26 = simpleSymbol126;
        Lit40 = PairWithPosition.make(simpleSymbol122, PairWithPosition.make(simpleSymbol123, PairWithPosition.make(simpleSymbol124, PairWithPosition.make(simpleSymbol125, PairWithPosition.make(simpleSymbol126, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123782), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123777), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123772), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123767), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen2.yail", 123756);
        new SimpleSymbol("Vertical_Arrangement2");
        Lit39 = (SimpleSymbol) simpleSymbol87.readResolve();
        new SimpleSymbol("CreateCustomDialog");
        Lit38 = (SimpleSymbol) simpleSymbol88.readResolve();
        new SimpleSymbol("Notifier2");
        Lit37 = (SimpleSymbol) simpleSymbol89.readResolve();
        new SimpleSymbol("Web1");
        Lit36 = (SimpleSymbol) simpleSymbol90.readResolve();
        new SimpleSymbol("Get");
        Lit35 = (SimpleSymbol) simpleSymbol91.readResolve();
        new SimpleSymbol("Url");
        Lit34 = (SimpleSymbol) simpleSymbol92.readResolve();
        new SimpleSymbol("Get_data_web");
        Lit33 = (SimpleSymbol) simpleSymbol93.readResolve();
        new SimpleSymbol("Vertical_Arrangement1_copy");
        Lit31 = (SimpleSymbol) simpleSymbol94.readResolve();
        new SimpleSymbol("Vertical_Arrangement1");
        Lit29 = (SimpleSymbol) simpleSymbol95.readResolve();
        new SimpleSymbol("AddComponentToView");
        Lit28 = (SimpleSymbol) simpleSymbol96.readResolve();
        new SimpleSymbol("View_Pager1");
        Lit27 = (SimpleSymbol) simpleSymbol97.readResolve();
        new SimpleSymbol("TitleVisible");
        Lit25 = (SimpleSymbol) simpleSymbol98.readResolve();
        new SimpleSymbol("Title");
        Lit24 = (SimpleSymbol) simpleSymbol99.readResolve();
        new SimpleSymbol("ReceiveSharedText");
        Lit23 = (SimpleSymbol) simpleSymbol100.readResolve();
        int[] iArr24 = new int[2];
        iArr24[0] = -769226;
        Lit22 = IntNum.make(iArr24);
        new SimpleSymbol("PrimaryColorDark");
        Lit21 = (SimpleSymbol) simpleSymbol101.readResolve();
        int[] iArr25 = new int[2];
        iArr25[0] = -769226;
        Lit20 = IntNum.make(iArr25);
        new SimpleSymbol("PrimaryColor");
        Lit19 = (SimpleSymbol) simpleSymbol102.readResolve();
        new SimpleSymbol("AppName");
        Lit18 = (SimpleSymbol) simpleSymbol103.readResolve();
        new SimpleSymbol("AppId");
        Lit16 = (SimpleSymbol) simpleSymbol104.readResolve();
        new SimpleSymbol("AlignHorizontal");
        Lit14 = (SimpleSymbol) simpleSymbol105.readResolve();
        int[] iArr26 = new int[2];
        iArr26[0] = -769226;
        Lit12 = IntNum.make(iArr26);
        new SimpleSymbol("AccentColor");
        Lit11 = (SimpleSymbol) simpleSymbol106.readResolve();
        new SimpleSymbol("g$v_centres");
        Lit10 = (SimpleSymbol) simpleSymbol107.readResolve();
        new SimpleSymbol("g$vaccination");
        Lit9 = (SimpleSymbol) simpleSymbol108.readResolve();
        new SimpleSymbol("g$v_states");
        Lit8 = (SimpleSymbol) simpleSymbol109.readResolve();
        new SimpleSymbol("g$t_centres");
        Lit7 = (SimpleSymbol) simpleSymbol110.readResolve();
        new SimpleSymbol("g$t_states");
        Lit6 = (SimpleSymbol) simpleSymbol111.readResolve();
        new SimpleSymbol("g$testing");
        Lit5 = (SimpleSymbol) simpleSymbol112.readResolve();
        new SimpleSymbol("g$list_format2");
        Lit4 = (SimpleSymbol) simpleSymbol113.readResolve();
        new SimpleSymbol("g$list_format");
        Lit3 = (SimpleSymbol) simpleSymbol114.readResolve();
        new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol115.readResolve();
        new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol116.readResolve();
        new SimpleSymbol("Screen2");
        Lit0 = (SimpleSymbol) simpleSymbol117.readResolve();
    }

    public Screen2() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleMethod moduleMethod29;
        ModuleMethod moduleMethod30;
        ModuleMethod moduleMethod31;
        ModuleMethod moduleMethod32;
        ModuleMethod moduleMethod33;
        ModuleMethod moduleMethod34;
        ModuleMethod moduleMethod35;
        ModuleMethod moduleMethod36;
        ModuleMethod moduleMethod37;
        ModuleMethod moduleMethod38;
        ModuleMethod moduleMethod39;
        ModuleMethod moduleMethod40;
        ModuleMethod moduleMethod41;
        ModuleMethod moduleMethod42;
        ModuleMethod moduleMethod43;
        ModuleMethod moduleMethod44;
        ModuleMethod moduleMethod45;
        ModuleMethod moduleMethod46;
        ModuleMethod moduleMethod47;
        ModuleMethod moduleMethod48;
        ModuleMethod moduleMethod49;
        ModuleMethod moduleMethod50;
        ModuleMethod moduleMethod51;
        ModuleMethod moduleMethod52;
        ModuleMethod moduleMethod53;
        ModuleMethod moduleMethod54;
        ModuleMethod moduleMethod55;
        ModuleMethod moduleMethod56;
        ModuleMethod moduleMethod57;
        ModuleMethod moduleMethod58;
        ModuleMethod moduleMethod59;
        ModuleMethod moduleMethod60;
        ModuleMethod moduleMethod61;
        ModuleMethod moduleMethod62;
        ModuleMethod moduleMethod63;
        ModuleMethod moduleMethod64;
        ModuleMethod moduleMethod65;
        ModuleMethod moduleMethod66;
        ModuleMethod moduleMethod67;
        ModuleMethod moduleMethod68;
        ModuleMethod moduleMethod69;
        ModuleMethod moduleMethod70;
        ModuleMethod moduleMethod71;
        ModuleMethod moduleMethod72;
        ModuleMethod moduleMethod73;
        ModuleMethod moduleMethod74;
        ModuleMethod moduleMethod75;
        ModuleMethod moduleMethod76;
        ModuleMethod moduleMethod77;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod78 = moduleMethod;
        new frame();
        frame frame3 = frame2;
        frame3.$main = this;
        frame frame4 = frame3;
        new ModuleMethod(frame4, 1, Lit218, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod78;
        new ModuleMethod(frame4, 2, Lit219, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod2;
        new ModuleMethod(frame4, 3, Lit220, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod3;
        new ModuleMethod(frame4, 4, Lit221, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod4;
        new ModuleMethod(frame4, 6, Lit222, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod5;
        new ModuleMethod(frame4, 7, Lit223, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod6;
        new ModuleMethod(frame4, 8, Lit224, 8194);
        this.add$Mnto$Mnevents = moduleMethod7;
        new ModuleMethod(frame4, 9, Lit225, 16388);
        this.add$Mnto$Mncomponents = moduleMethod8;
        new ModuleMethod(frame4, 10, Lit226, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod9;
        new ModuleMethod(frame4, 11, Lit227, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod10;
        new ModuleMethod(frame4, 12, Lit228, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod11;
        new ModuleMethod(frame4, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod12;
        new ModuleMethod(frame4, 14, Lit229, 16388);
        this.dispatchEvent = moduleMethod13;
        new ModuleMethod(frame4, 15, Lit230, 16388);
        this.dispatchGenericEvent = moduleMethod14;
        new ModuleMethod(frame4, 16, Lit231, 8194);
        this.lookup$Mnhandler = moduleMethod15;
        new ModuleMethod(frame4, 17, (Object) null, 0);
        ModuleMethod moduleMethod79 = moduleMethod16;
        moduleMethod79.setProperty("source-location", "/tmp/runtime7522387041397852836.scm:615");
        lambda$Fn1 = moduleMethod79;
        new ModuleMethod(frame4, 18, "$define", 0);
        this.$define = moduleMethod17;
        new ModuleMethod(frame4, 19, (Object) null, 0);
        lambda$Fn2 = moduleMethod18;
        new ModuleMethod(frame4, 20, (Object) null, 0);
        lambda$Fn3 = moduleMethod19;
        new ModuleMethod(frame4, 21, (Object) null, 0);
        lambda$Fn4 = moduleMethod20;
        new ModuleMethod(frame4, 22, (Object) null, 0);
        lambda$Fn5 = moduleMethod21;
        new ModuleMethod(frame4, 23, (Object) null, 0);
        lambda$Fn6 = moduleMethod22;
        new ModuleMethod(frame4, 24, (Object) null, 0);
        lambda$Fn7 = moduleMethod23;
        new ModuleMethod(frame4, 25, (Object) null, 0);
        lambda$Fn8 = moduleMethod24;
        new ModuleMethod(frame4, 26, (Object) null, 0);
        lambda$Fn9 = moduleMethod25;
        new ModuleMethod(frame4, 27, (Object) null, 0);
        lambda$Fn10 = moduleMethod26;
        new ModuleMethod(frame4, 28, Lit41, 0);
        this.Screen2$Initialize = moduleMethod27;
        new ModuleMethod(frame4, 29, Lit44, 0);
        this.Screen2$BackPressed = moduleMethod28;
        new ModuleMethod(frame4, 30, (Object) null, 0);
        lambda$Fn11 = moduleMethod29;
        new ModuleMethod(frame4, 31, (Object) null, 0);
        lambda$Fn12 = moduleMethod30;
        new ModuleMethod(frame4, 32, (Object) null, 0);
        lambda$Fn13 = moduleMethod31;
        new ModuleMethod(frame4, 33, (Object) null, 0);
        lambda$Fn14 = moduleMethod32;
        new ModuleMethod(frame4, 34, (Object) null, 0);
        lambda$Fn15 = moduleMethod33;
        new ModuleMethod(frame4, 35, (Object) null, 0);
        lambda$Fn16 = moduleMethod34;
        new ModuleMethod(frame4, 36, (Object) null, 0);
        lambda$Fn17 = moduleMethod35;
        new ModuleMethod(frame4, 37, (Object) null, 0);
        lambda$Fn18 = moduleMethod36;
        new ModuleMethod(frame4, 38, Lit77, 0);
        this.Button2$Click = moduleMethod37;
        new ModuleMethod(frame4, 39, (Object) null, 0);
        lambda$Fn19 = moduleMethod38;
        new ModuleMethod(frame4, 40, (Object) null, 0);
        lambda$Fn20 = moduleMethod39;
        new ModuleMethod(frame4, 41, (Object) null, 0);
        lambda$Fn21 = moduleMethod40;
        new ModuleMethod(frame4, 42, (Object) null, 0);
        lambda$Fn22 = moduleMethod41;
        new ModuleMethod(frame4, 43, Lit98, 0);
        this.Button1$Click = moduleMethod42;
        new ModuleMethod(frame4, 44, (Object) null, 0);
        lambda$Fn23 = moduleMethod43;
        new ModuleMethod(frame4, 45, (Object) null, 0);
        lambda$Fn24 = moduleMethod44;
        new ModuleMethod(frame4, 46, (Object) null, 0);
        lambda$Fn25 = moduleMethod45;
        new ModuleMethod(frame4, 47, (Object) null, 0);
        lambda$Fn26 = moduleMethod46;
        new ModuleMethod(frame4, 48, (Object) null, 0);
        lambda$Fn27 = moduleMethod47;
        new ModuleMethod(frame4, 49, (Object) null, 0);
        lambda$Fn28 = moduleMethod48;
        new ModuleMethod(frame4, 50, Lit120, 0);
        this.List_View1$AfterPicking = moduleMethod49;
        new ModuleMethod(frame4, 51, (Object) null, 0);
        lambda$Fn29 = moduleMethod50;
        new ModuleMethod(frame4, 52, (Object) null, 0);
        lambda$Fn30 = moduleMethod51;
        new ModuleMethod(frame4, 53, Lit130, 0);
        this.Snackbar1$Click = moduleMethod52;
        new ModuleMethod(frame4, 54, Lit232, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        proc$Fn31 = moduleMethod53;
        new ModuleMethod(frame4, 55, (Object) null, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        lambda$Fn32 = moduleMethod54;
        new ModuleMethod(frame4, 56, Lit152, 16388);
        this.Get_data_web$GotText = moduleMethod55;
        new ModuleMethod(frame4, 57, (Object) null, 0);
        lambda$Fn33 = moduleMethod56;
        new ModuleMethod(frame4, 58, (Object) null, 0);
        lambda$Fn34 = moduleMethod57;
        new ModuleMethod(frame4, 59, (Object) null, 0);
        lambda$Fn35 = moduleMethod58;
        new ModuleMethod(frame4, 60, (Object) null, 0);
        lambda$Fn36 = moduleMethod59;
        new ModuleMethod(frame4, 61, (Object) null, 0);
        lambda$Fn37 = moduleMethod60;
        new ModuleMethod(frame4, 62, (Object) null, 0);
        lambda$Fn38 = moduleMethod61;
        new ModuleMethod(frame4, 63, Lit171, 0);
        this.Button3$Click = moduleMethod62;
        new ModuleMethod(frame4, 64, (Object) null, 0);
        lambda$Fn39 = moduleMethod63;
        new ModuleMethod(frame4, 65, (Object) null, 0);
        lambda$Fn40 = moduleMethod64;
        new ModuleMethod(frame4, 66, (Object) null, 0);
        lambda$Fn41 = moduleMethod65;
        new ModuleMethod(frame4, 67, (Object) null, 0);
        lambda$Fn42 = moduleMethod66;
        new ModuleMethod(frame4, 68, Lit182, 0);
        this.Button1_copy$Click = moduleMethod67;
        new ModuleMethod(frame4, 69, (Object) null, 0);
        lambda$Fn43 = moduleMethod68;
        new ModuleMethod(frame4, 70, (Object) null, 0);
        lambda$Fn44 = moduleMethod69;
        new ModuleMethod(frame4, 71, (Object) null, 0);
        lambda$Fn45 = moduleMethod70;
        new ModuleMethod(frame4, 72, (Object) null, 0);
        lambda$Fn46 = moduleMethod71;
        new ModuleMethod(frame4, 73, Lit192, 0);
        this.List_View1_copy$AfterPicking = moduleMethod72;
        new ModuleMethod(frame4, 74, (Object) null, 0);
        lambda$Fn47 = moduleMethod73;
        new ModuleMethod(frame4, 75, (Object) null, 0);
        lambda$Fn48 = moduleMethod74;
        new ModuleMethod(frame4, 76, Lit232, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        proc$Fn49 = moduleMethod75;
        new ModuleMethod(frame4, 77, (Object) null, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        lambda$Fn50 = moduleMethod76;
        new ModuleMethod(frame4, 78, Lit210, 16388);
        this.Web1$GotText = moduleMethod77;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        String obj;
        Object obj2;
        Consumer $result = $ctx.consumer;
        C1241runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
        Object[] objArr = new Object[2];
        objArr[0] = misc.symbol$To$String(Lit0);
        Object[] objArr2 = objArr;
        objArr2[1] = "-global-vars";
        FString stringAppend = strings.stringAppend(objArr2);
        FString fString = stringAppend;
        if (stringAppend == null) {
            obj = null;
        } else {
            obj = fString.toString();
        }
        this.global$Mnvar$Mnenvironment = Environment.make(obj);
        Screen2 = null;
        this.form$Mnname$Mnsymbol = Lit0;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        C1241runtime.$instance.run();
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit3, ""), $result);
        } else {
            addToGlobalVars(Lit3, lambda$Fn2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit4, ""), $result);
        } else {
            addToGlobalVars(Lit4, lambda$Fn3);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit5, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit5, lambda$Fn4);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit6, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit6, lambda$Fn5);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit7, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit7, lambda$Fn6);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit8, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit8, lambda$Fn7);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit9, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit9, lambda$Fn8);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit10, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit10, lambda$Fn9);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit13);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, Lit15, Lit13);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit16, "6193580781600768", Lit17);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, "COVID19ANALYZER", Lit17);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, Lit20, Lit13);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, Lit22, Lit13);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit23, AlgorithmIdentifiers.NONE, Lit17);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, "Screen2", Lit17);
            Values.writeValues(C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit25, Boolean.FALSE, Lit26), $result);
        } else {
            new Promise(lambda$Fn10);
            addToFormDoAfterCreation(obj2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment = C1241runtime.addToCurrentFormEnvironment(Lit41, this.Screen2$Initialize);
        } else {
            addToFormEnvironment(Lit41, this.Screen2$Initialize);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Screen2", "Initialize");
        } else {
            addToEvents(Lit0, Lit42);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment2 = C1241runtime.addToCurrentFormEnvironment(Lit44, this.Screen2$BackPressed);
        } else {
            addToFormEnvironment(Lit44, this.Screen2$BackPressed);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Screen2", "BackPressed");
        } else {
            addToEvents(Lit0, Lit45);
        }
        this.View_Pager1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit46, Lit27, lambda$Fn11), $result);
        } else {
            addToComponents(Lit0, Lit54, Lit27, lambda$Fn12);
        }
        this.Vertical_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit55, Lit29, lambda$Fn13), $result);
        } else {
            addToComponents(Lit0, Lit58, Lit29, lambda$Fn14);
        }
        this.Horizontal_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit29, Lit59, Lit60, lambda$Fn15), $result);
        } else {
            addToComponents(Lit29, Lit62, Lit60, lambda$Fn16);
        }
        this.Button2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit60, Lit63, Lit64, lambda$Fn17), $result);
        } else {
            addToComponents(Lit60, Lit72, Lit64, lambda$Fn18);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment3 = C1241runtime.addToCurrentFormEnvironment(Lit77, this.Button2$Click);
        } else {
            addToFormEnvironment(Lit77, this.Button2$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button2", "Click");
        } else {
            addToEvents(Lit64, Lit78);
        }
        this.Label1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit60, Lit79, Lit80, lambda$Fn19), $result);
        } else {
            addToComponents(Lit60, Lit87, Lit80, lambda$Fn20);
        }
        this.Button1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit60, Lit88, Lit89, lambda$Fn21), $result);
        } else {
            addToComponents(Lit60, Lit92, Lit89, lambda$Fn22);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment4 = C1241runtime.addToCurrentFormEnvironment(Lit98, this.Button1$Click);
        } else {
            addToFormEnvironment(Lit98, this.Button1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button1", "Click");
        } else {
            addToEvents(Lit89, Lit78);
        }
        this.List_View_Image_and_Text1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit29, Lit99, Lit74, lambda$Fn23), $result);
        } else {
            addToComponents(Lit29, Lit101, Lit74, lambda$Fn24);
        }
        this.Circular_Progress1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit29, Lit102, Lit103, lambda$Fn25), $result);
        } else {
            addToComponents(Lit29, Lit106, Lit103, lambda$Fn26);
        }
        this.List_View1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit29, Lit107, Lit76, lambda$Fn27), $result);
        } else {
            addToComponents(Lit29, Lit114, Lit76, lambda$Fn28);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment5 = C1241runtime.addToCurrentFormEnvironment(Lit120, this.List_View1$AfterPicking);
        } else {
            addToFormEnvironment(Lit120, this.List_View1$AfterPicking);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "List_View1", "AfterPicking");
        } else {
            addToEvents(Lit76, Lit121);
        }
        this.Snackbar1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit122, Lit115, lambda$Fn29), $result);
        } else {
            addToComponents(Lit0, Lit128, Lit115, lambda$Fn30);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment6 = C1241runtime.addToCurrentFormEnvironment(Lit130, this.Snackbar1$Click);
        } else {
            addToFormEnvironment(Lit130, this.Snackbar1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Snackbar1", "Click");
        } else {
            addToEvents(Lit115, Lit78);
        }
        this.Send_data_web = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit131, Lit132, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit133, Lit132, Boolean.FALSE);
        }
        this.Get_data_web = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit134, Lit33, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit135, Lit33, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment7 = C1241runtime.addToCurrentFormEnvironment(Lit152, this.Get_data_web$GotText);
        } else {
            addToFormEnvironment(Lit152, this.Get_data_web$GotText);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Get_data_web", "GotText");
        } else {
            addToEvents(Lit33, Lit153);
        }
        this.Notifier1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit154, Lit155, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit156, Lit155, Boolean.FALSE);
        }
        this.Vertical_Arrangement1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit157, Lit31, lambda$Fn33), $result);
        } else {
            addToComponents(Lit0, Lit159, Lit31, lambda$Fn34);
        }
        this.Horizontal_Arrangement2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit31, Lit160, Lit161, lambda$Fn35), $result);
        } else {
            addToComponents(Lit31, Lit163, Lit161, lambda$Fn36);
        }
        this.Button3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit161, Lit164, Lit165, lambda$Fn37), $result);
        } else {
            addToComponents(Lit161, Lit167, Lit165, lambda$Fn38);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment8 = C1241runtime.addToCurrentFormEnvironment(Lit171, this.Button3$Click);
        } else {
            addToFormEnvironment(Lit171, this.Button3$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button3", "Click");
        } else {
            addToEvents(Lit165, Lit78);
        }
        this.Label1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit161, Lit172, Lit173, lambda$Fn39), $result);
        } else {
            addToComponents(Lit161, Lit175, Lit173, lambda$Fn40);
        }
        this.Button1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit161, Lit176, Lit177, lambda$Fn41), $result);
        } else {
            addToComponents(Lit161, Lit180, Lit177, lambda$Fn42);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment9 = C1241runtime.addToCurrentFormEnvironment(Lit182, this.Button1_copy$Click);
        } else {
            addToFormEnvironment(Lit182, this.Button1_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button1_copy", "Click");
        } else {
            addToEvents(Lit177, Lit78);
        }
        this.List_View_Image_and_Text2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit31, Lit183, Lit169, lambda$Fn43), $result);
        } else {
            addToComponents(Lit31, Lit184, Lit169, lambda$Fn44);
        }
        this.List_View1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit31, Lit185, Lit170, lambda$Fn45), $result);
        } else {
            addToComponents(Lit31, Lit189, Lit170, lambda$Fn46);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment10 = C1241runtime.addToCurrentFormEnvironment(Lit192, this.List_View1_copy$AfterPicking);
        } else {
            addToFormEnvironment(Lit192, this.List_View1_copy$AfterPicking);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "List_View1_copy", "AfterPicking");
        } else {
            addToEvents(Lit170, Lit121);
        }
        this.Vertical_Arrangement2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit193, Lit39, lambda$Fn47), $result);
        } else {
            addToComponents(Lit0, Lit195, Lit39, lambda$Fn48);
        }
        this.InApp_PDFViewer1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit196, Lit197, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit198, Lit197, Boolean.FALSE);
        }
        this.Web1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit199, Lit36, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit200, Lit36, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment11 = C1241runtime.addToCurrentFormEnvironment(Lit210, this.Web1$GotText);
        } else {
            addToFormEnvironment(Lit210, this.Web1$GotText);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Web1", "GotText");
        } else {
            addToEvents(Lit36, Lit153);
        }
        this.Web2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit211, Lit212, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit213, Lit212, Boolean.FALSE);
        }
        this.InApp_PDFViewer2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit214, Lit93, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit215, Lit93, Boolean.FALSE);
        }
        this.Notifier2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit216, Lit37, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit217, Lit37, Boolean.FALSE);
        }
        C1241runtime.initRuntime();
    }

    static String lambda3() {
        return "";
    }

    static String lambda4() {
        return "";
    }

    static Object lambda5() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda6() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda7() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda8() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda9() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda10() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda11() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, Lit15, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit16, "6193580781600768", Lit17);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, "COVID19ANALYZER", Lit17);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, Lit20, Lit13);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, Lit22, Lit13);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit23, AlgorithmIdentifiers.NONE, Lit17);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, "Screen2", Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit25, Boolean.FALSE, Lit26);
    }

    public Object Screen2$Initialize() {
        C1241runtime.setThisForm();
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit27, Lit28, LList.list2(C1241runtime.lookupInCurrentFormEnvironment(Lit29), "Vaccination Centres"), Lit30);
        Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit27, Lit28, LList.list2(C1241runtime.lookupInCurrentFormEnvironment(Lit31), "Testing Centres"), Lit32);
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit33, Lit34, "https://docs.google.com/spreadsheets/d/15irlwwyV8LTaNOvWvxQq8XNGFtubrBaTbNcQkqXshNY/export?format=csv", Lit17);
        Object callComponentMethod3 = C1241runtime.callComponentMethod(Lit33, Lit35, LList.Empty, LList.Empty);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit36, Lit34, "https://docs.google.com/spreadsheets/d/14XIA4QpnoxP8pKFvxaekC3IsZ3ISPfz8bO_UA-xW0VE/export?format=csv", Lit17);
        Object callComponentMethod4 = C1241runtime.callComponentMethod(Lit36, Lit35, LList.Empty, LList.Empty);
        SimpleSymbol simpleSymbol = Lit37;
        SimpleSymbol simpleSymbol2 = Lit38;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit39));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.TRUE);
        return C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit40);
    }

    public Object Screen2$BackPressed() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("home"), Lit43, "open another screen");
    }

    static Object lambda12() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit47, Lit48, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit50, Lit51, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit52, Lit53, Lit13);
    }

    static Object lambda13() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit47, Lit48, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit50, Lit51, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit52, Lit53, Lit13);
    }

    static Object lambda14() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit14, Lit15, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit56, Lit57, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit47, Lit48, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit49, Lit48, Lit13);
    }

    static Object lambda15() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit14, Lit15, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit56, Lit57, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit47, Lit48, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit29, Lit49, Lit48, Lit13);
    }

    static Object lambda16() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit56, Lit61, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit49, Lit48, Lit13);
    }

    static Object lambda17() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit56, Lit61, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit49, Lit48, Lit13);
    }

    static Object lambda18() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit56, Lit65, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit66, Lit67, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit68, Lit69, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit49, Lit70, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit71, "format_list_bulleted", Lit17);
    }

    static Object lambda19() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit56, Lit65, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit66, Lit67, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit68, Lit69, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit49, Lit70, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit71, "format_list_bulleted", Lit17);
    }

    public Object Button2$Click() {
        Object addGlobalVarToCurrentFormEnvironment;
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, C1241runtime.$Stthe$Mnnull$Mnvalue$St), "ballot"), Lit73, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit74, Lit75, Boolean.TRUE, Lit26);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit75, Boolean.FALSE, Lit26);
            addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit3, "xyz");
        } else {
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit74, Lit75, Boolean.FALSE, Lit26);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit75, Boolean.TRUE, Lit26);
            addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit3, "ballot");
        }
        return addGlobalVarToCurrentFormEnvironment;
    }

    static Object lambda20() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit66, Lit82, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit71, "Vaccination Centres", Lit17);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit83, Lit84, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit85, Lit86, Lit13);
    }

    static Object lambda21() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit66, Lit82, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit71, "Vaccination Centres", Lit17);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit83, Lit84, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit80, Lit85, Lit86, Lit13);
    }

    static Object lambda22() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit56, Lit90, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit71, "Full List", Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit85, Lit91, Lit13);
    }

    static Object lambda23() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit56, Lit90, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit71, "Full List", Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit85, Lit91, Lit13);
    }

    public Object Button1$Click() {
        C1241runtime.setThisForm();
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit93, Lit94, LList.list3(C1241runtime.lookupInCurrentFormEnvironment(Lit39), "vaccine-data.pdf", C1241runtime.get$Mnproperty.apply2(Lit93, Lit95)), Lit96);
        return C1241runtime.callComponentMethod(Lit37, Lit97, LList.Empty, LList.Empty);
    }

    static Object lambda24() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit74, Lit100, Boolean.TRUE, Lit26);
    }

    static Object lambda25() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit74, Lit100, Boolean.TRUE, Lit26);
    }

    static Object lambda26() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit104, Lit105, Lit13);
    }

    static Object lambda27() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit104, Lit105, Lit13);
    }

    static Object lambda28() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit56, Lit108, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit109, "Search hospitals...", Lit17);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit47, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit110, Lit111, Lit13);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit112, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit85, Lit113, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit75, Boolean.FALSE, Lit26);
    }

    static Object lambda29() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit56, Lit108, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit109, "Search hospitals...", Lit17);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit47, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit110, Lit111, Lit13);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit112, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit85, Lit113, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit75, Boolean.FALSE, Lit26);
    }

    public Object List_View1$AfterPicking() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit115, Lit116, LList.list1(C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit76, Lit117)), Lit118, "select list item")), Lit119);
    }

    static Object lambda30() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit56, Lit123, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit124, Lit125, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit126, Lit48, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit85, Lit127, Lit13);
    }

    static Object lambda31() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit56, Lit123, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit124, Lit125, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit126, Lit48, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit85, Lit127, Lit13);
    }

    public Object Snackbar1$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit115, Lit129, LList.Empty, LList.Empty);
    }

    public Object Get_data_web$GotText(Object $url, Object $responseCode, Object $responseType, Object $responseContent) {
        Object obj;
        Object sanitizeComponentData = C1241runtime.sanitizeComponentData($url);
        Object sanitizeComponentData2 = C1241runtime.sanitizeComponentData($responseCode);
        Object sanitizeComponentData3 = C1241runtime.sanitizeComponentData($responseType);
        Object $responseContent2 = C1241runtime.sanitizeComponentData($responseContent);
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit75, Boolean.FALSE, Lit26);
        SimpleSymbol simpleSymbol = Lit9;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnfrom$Mncsv$Mntable;
        if ($responseContent2 instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit136);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj = $responseContent2;
        }
        Object addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(simpleSymbol, C1241runtime.callYailPrimitive(moduleMethod, LList.list1(obj), Lit137, "list from csv table"));
        ModuleMethod moduleMethod2 = proc$Fn31;
        Object yailForEach = C1241runtime.yailForEach(proc$Fn31, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit9, C1241runtime.$Stthe$Mnnull$Mnvalue$St));
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit144, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit10, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit145);
        return C1241runtime.yailForRange(lambda$Fn32, Lit84, C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnlength, LList.list1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit10, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit151, "length of list"), Lit84);
    }

    public static Object lambda32proc(Object obj) {
        Object obj2;
        Object obj3;
        Object $item = obj;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit10, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod2 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit138);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj2 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj2 = $item;
        }
        Object callYailPrimitive = C1241runtime.callYailPrimitive(moduleMethod, LList.list2(lookupGlobalVarInCurrentFormEnvironment, C1241runtime.callYailPrimitive(moduleMethod2, LList.list2(obj2, Lit84), Lit139, "select list item")), Lit140, "add items to list");
        ModuleMethod moduleMethod3 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment2 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod4 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr4 = new Object[3];
            objArr4[0] = "The variable ";
            Object[] objArr5 = objArr4;
            objArr5[1] = C1241runtime.getDisplayRepresentation(Lit138);
            Object[] objArr6 = objArr5;
            objArr6[2] = " is not bound in the current context";
            obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
        } else {
            obj3 = $item;
        }
        return C1241runtime.callYailPrimitive(moduleMethod3, LList.list2(lookupGlobalVarInCurrentFormEnvironment2, C1241runtime.callYailPrimitive(moduleMethod4, LList.list2(obj3, Lit141), Lit142, "select list item")), Lit143, "add items to list");
    }

    static Object lambda33(Object obj) {
        Object obj2;
        Object obj3;
        Object $number = obj;
        SimpleSymbol simpleSymbol = Lit74;
        SimpleSymbol simpleSymbol2 = Lit146;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        Object lookupGlobalVarInCurrentFormEnvironment = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit10, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        if ($number instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit147);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj2 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj2 = $number;
        }
        Object callYailPrimitive = C1241runtime.callYailPrimitive(moduleMethod, LList.list2(lookupGlobalVarInCurrentFormEnvironment, obj2), Lit148, "select list item");
        ModuleMethod moduleMethod2 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        Object lookupGlobalVarInCurrentFormEnvironment2 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        if ($number instanceof Package) {
            Object[] objArr4 = new Object[3];
            objArr4[0] = "The variable ";
            Object[] objArr5 = objArr4;
            objArr5[1] = C1241runtime.getDisplayRepresentation(Lit147);
            Object[] objArr6 = objArr5;
            objArr6[2] = " is not bound in the current context";
            obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
        } else {
            obj3 = $number;
        }
        return C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, LList.list3("assetdbvac.png", callYailPrimitive, C1241runtime.callYailPrimitive(moduleMethod2, LList.list2(lookupGlobalVarInCurrentFormEnvironment2, obj3), Lit149, "select list item")), Lit150);
    }

    static Object lambda34() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit31, Lit56, Lit158, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit31, Lit47, Lit48, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit31, Lit49, Lit48, Lit13);
    }

    static Object lambda35() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit31, Lit56, Lit158, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit31, Lit47, Lit48, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit31, Lit49, Lit48, Lit13);
    }

    static Object lambda36() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit161, Lit56, Lit162, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit161, Lit49, Lit48, Lit13);
    }

    static Object lambda37() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit161, Lit56, Lit162, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit161, Lit49, Lit48, Lit13);
    }

    static Object lambda38() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit56, Lit166, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit66, Lit67, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit68, Lit69, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit49, Lit70, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit71, "format_list_bulleted", Lit17);
    }

    static Object lambda39() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit56, Lit166, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit66, Lit67, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit68, Lit69, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit49, Lit70, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit71, "format_list_bulleted", Lit17);
    }

    public Object Button3$Click() {
        Object addGlobalVarToCurrentFormEnvironment;
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, C1241runtime.$Stthe$Mnnull$Mnvalue$St), "ballot"), Lit168, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit75, Boolean.TRUE, Lit26);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit75, Boolean.FALSE, Lit26);
            addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit4, "xyz");
        } else {
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit75, Boolean.FALSE, Lit26);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit75, Boolean.TRUE, Lit26);
            addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit4, "ballot");
        }
        return addGlobalVarToCurrentFormEnvironment;
    }

    static Object lambda40() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit66, Lit82, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit71, "Testing Centres", Lit17);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit83, Lit84, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit85, Lit174, Lit13);
    }

    static Object lambda41() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit66, Lit82, Lit13);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit71, "Testing Centres", Lit17);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit83, Lit84, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit85, Lit174, Lit13);
    }

    static Object lambda42() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit56, Lit178, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit71, "Full List", Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit85, Lit179, Lit13);
    }

    static Object lambda43() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit56, Lit178, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit81, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit71, "Full List", Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit85, Lit179, Lit13);
    }

    public Object Button1_copy$Click() {
        C1241runtime.setThisForm();
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit93, Lit94, LList.list3(C1241runtime.lookupInCurrentFormEnvironment(Lit39), "testing-data.pdf", C1241runtime.get$Mnproperty.apply2(Lit93, Lit95)), Lit181);
        return C1241runtime.callComponentMethod(Lit37, Lit97, LList.Empty, LList.Empty);
    }

    static Object lambda44() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit100, Boolean.TRUE, Lit26);
    }

    static Object lambda45() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit100, Boolean.TRUE, Lit26);
    }

    static Object lambda46() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit56, Lit186, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit109, "Search hospitals...", Lit17);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit47, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit110, Lit187, Lit13);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit112, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit85, Lit188, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit75, Boolean.FALSE, Lit26);
    }

    static Object lambda47() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit56, Lit186, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit109, "Search hospitals...", Lit17);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit47, Lit48, Lit13);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit49, Lit48, Lit13);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit110, Lit187, Lit13);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit112, Boolean.TRUE, Lit26);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit85, Lit188, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit75, Boolean.FALSE, Lit26);
    }

    public Object List_View1_copy$AfterPicking() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit115, Lit116, LList.list1(C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit170, Lit117)), Lit190, "select list item")), Lit191);
    }

    static Object lambda48() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit14, Lit15, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit56, Lit194, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit49, Lit48, Lit13);
    }

    static Object lambda49() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit14, Lit15, Lit13);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit56, Lit194, Lit13);
        return C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit49, Lit48, Lit13);
    }

    public Object Web1$GotText(Object $url, Object $responseCode, Object $responseType, Object $responseContent) {
        Object obj;
        Object sanitizeComponentData = C1241runtime.sanitizeComponentData($url);
        Object sanitizeComponentData2 = C1241runtime.sanitizeComponentData($responseCode);
        Object sanitizeComponentData3 = C1241runtime.sanitizeComponentData($responseType);
        Object $responseContent2 = C1241runtime.sanitizeComponentData($responseContent);
        C1241runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit5;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnfrom$Mncsv$Mntable;
        if ($responseContent2 instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit136);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj = $responseContent2;
        }
        Object addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(simpleSymbol, C1241runtime.callYailPrimitive(moduleMethod, LList.list1(obj), Lit201, "list from csv table"));
        ModuleMethod moduleMethod2 = proc$Fn49;
        Object yailForEach = C1241runtime.yailForEach(proc$Fn49, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit5, C1241runtime.$Stthe$Mnnull$Mnvalue$St));
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit170, Lit144, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit145);
        return C1241runtime.yailForRange(lambda$Fn50, Lit84, C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnlength, LList.list1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit209, "length of list"), Lit84);
    }

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen2$frame */
    /* compiled from: Screen2.yail */
    public class frame extends ModuleBody {
        Screen2 $main;

        public frame() {
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Screen2)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 54:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 55:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 76:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 77:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Screen2)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof Screen2)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 56:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 78:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            Throwable th;
            Throwable th2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th3 = th2;
                        new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw th3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th4 = th;
                        new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw th4;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                case 54:
                    return Screen2.lambda32proc(obj2);
                case 55:
                    return Screen2.lambda33(obj2);
                case 76:
                    return Screen2.lambda50proc(obj2);
                case 77:
                    return Screen2.lambda51(obj2);
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            Throwable th6;
            Throwable th7;
            Throwable th8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    Throwable th9 = th8;
                                    new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw th9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                Throwable th10 = th7;
                                new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw th10;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            Throwable th11 = th6;
                            new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw th11;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        Throwable th12 = th5;
                        new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw th12;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    Throwable th13 = th4;
                                    new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw th13;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                Throwable th14 = th3;
                                new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw th14;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            Throwable th15 = th2;
                            new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw th15;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        Throwable th16 = th;
                        new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw th16;
                    }
                case 56:
                    return this.$main.Get_data_web$GotText(obj5, obj6, obj7, obj8);
                case 78:
                    return this.$main.Web1$GotText(obj5, obj6, obj7, obj8);
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th4 = th3;
                        new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw th4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th2;
                        new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw th5;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        Throwable th6 = th;
                        new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw th6;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return Screen2.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return Screen2.lambda3();
                case 20:
                    return Screen2.lambda4();
                case 21:
                    return Screen2.lambda5();
                case 22:
                    return Screen2.lambda6();
                case 23:
                    return Screen2.lambda7();
                case 24:
                    return Screen2.lambda8();
                case 25:
                    return Screen2.lambda9();
                case 26:
                    return Screen2.lambda10();
                case 27:
                    return Screen2.lambda11();
                case 28:
                    return this.$main.Screen2$Initialize();
                case 29:
                    return this.$main.Screen2$BackPressed();
                case 30:
                    return Screen2.lambda12();
                case 31:
                    return Screen2.lambda13();
                case 32:
                    return Screen2.lambda14();
                case 33:
                    return Screen2.lambda15();
                case 34:
                    return Screen2.lambda16();
                case 35:
                    return Screen2.lambda17();
                case 36:
                    return Screen2.lambda18();
                case 37:
                    return Screen2.lambda19();
                case 38:
                    return this.$main.Button2$Click();
                case 39:
                    return Screen2.lambda20();
                case 40:
                    return Screen2.lambda21();
                case 41:
                    return Screen2.lambda22();
                case 42:
                    return Screen2.lambda23();
                case 43:
                    return this.$main.Button1$Click();
                case 44:
                    return Screen2.lambda24();
                case 45:
                    return Screen2.lambda25();
                case 46:
                    return Screen2.lambda26();
                case 47:
                    return Screen2.lambda27();
                case 48:
                    return Screen2.lambda28();
                case 49:
                    return Screen2.lambda29();
                case 50:
                    return this.$main.List_View1$AfterPicking();
                case 51:
                    return Screen2.lambda30();
                case 52:
                    return Screen2.lambda31();
                case 53:
                    return this.$main.Snackbar1$Click();
                case 57:
                    return Screen2.lambda34();
                case 58:
                    return Screen2.lambda35();
                case 59:
                    return Screen2.lambda36();
                case 60:
                    return Screen2.lambda37();
                case 61:
                    return Screen2.lambda38();
                case 62:
                    return Screen2.lambda39();
                case 63:
                    return this.$main.Button3$Click();
                case 64:
                    return Screen2.lambda40();
                case 65:
                    return Screen2.lambda41();
                case 66:
                    return Screen2.lambda42();
                case 67:
                    return Screen2.lambda43();
                case 68:
                    return this.$main.Button1_copy$Click();
                case 69:
                    return Screen2.lambda44();
                case 70:
                    return Screen2.lambda45();
                case 71:
                    return Screen2.lambda46();
                case 72:
                    return Screen2.lambda47();
                case 73:
                    return this.$main.List_View1_copy$AfterPicking();
                case 74:
                    return Screen2.lambda48();
                case 75:
                    return Screen2.lambda49();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 20:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 23:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 24:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 30:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 31:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 32:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 33:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 34:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 35:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 36:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 37:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 38:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 39:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 40:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 41:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 42:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 43:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 44:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 45:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 46:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 47:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 48:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 49:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 50:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 51:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 52:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 53:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 57:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 58:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 59:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 60:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 61:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 62:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 63:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 64:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 65:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 66:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 67:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 68:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 69:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 70:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 71:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 72:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 73:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 74:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 75:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }
    }

    public static Object lambda50proc(Object obj) {
        Object obj2;
        Object obj3;
        Object $item = obj;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod2 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit138);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj2 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj2 = $item;
        }
        Object callYailPrimitive = C1241runtime.callYailPrimitive(moduleMethod, LList.list2(lookupGlobalVarInCurrentFormEnvironment, C1241runtime.callYailPrimitive(moduleMethod2, LList.list2(obj2, Lit84), Lit202, "select list item")), Lit203, "add items to list");
        ModuleMethod moduleMethod3 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment2 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod4 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr4 = new Object[3];
            objArr4[0] = "The variable ";
            Object[] objArr5 = objArr4;
            objArr5[1] = C1241runtime.getDisplayRepresentation(Lit138);
            Object[] objArr6 = objArr5;
            objArr6[2] = " is not bound in the current context";
            obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
        } else {
            obj3 = $item;
        }
        return C1241runtime.callYailPrimitive(moduleMethod3, LList.list2(lookupGlobalVarInCurrentFormEnvironment2, C1241runtime.callYailPrimitive(moduleMethod4, LList.list2(obj3, Lit141), Lit204, "select list item")), Lit205, "add items to list");
    }

    static Object lambda51(Object obj) {
        Object obj2;
        Object obj3;
        Object $number = obj;
        SimpleSymbol simpleSymbol = Lit169;
        SimpleSymbol simpleSymbol2 = Lit146;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        Object lookupGlobalVarInCurrentFormEnvironment = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        if ($number instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit147);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj2 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj2 = $number;
        }
        Object callYailPrimitive = C1241runtime.callYailPrimitive(moduleMethod, LList.list2(lookupGlobalVarInCurrentFormEnvironment, obj2), Lit206, "select list item");
        ModuleMethod moduleMethod2 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        Object lookupGlobalVarInCurrentFormEnvironment2 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        if ($number instanceof Package) {
            Object[] objArr4 = new Object[3];
            objArr4[0] = "The variable ";
            Object[] objArr5 = objArr4;
            objArr5[1] = C1241runtime.getDisplayRepresentation(Lit147);
            Object[] objArr6 = objArr5;
            objArr6[2] = " is not bound in the current context";
            obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
        } else {
            obj3 = $number;
        }
        return C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, LList.list3("assetdbtub.png", callYailPrimitive, C1241runtime.callYailPrimitive(moduleMethod2, LList.list2(lookupGlobalVarInCurrentFormEnvironment2, obj3), Lit207, "select list item")), Lit208);
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.form$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name = symbol;
        Object default$Mnvalue = obj;
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & true;
        if (!x ? !x : !this.form$Mnenvironment.isBound(name)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = C1271lists.cons(C1271lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = C1271lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = C1271lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = C1271lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        Object obj = error;
        RetValManager.sendError(obj == null ? null : obj.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        objArr2[0] = "any$";
        Object[] objArr3 = objArr2;
        objArr3[1] = getSimpleName(componentObject);
        Object[] objArr4 = objArr3;
        objArr4[2] = "$";
        Object[] objArr5 = objArr4;
        objArr5[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr5)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1271lists.cons(component2, C1271lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object componentName, Object obj) {
        Object eventName = obj;
        Object obj2 = componentName;
        String obj3 = obj2 == null ? null : obj2.toString();
        Object obj4 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj3, obj4 == null ? null : obj4.toString())));
    }

    public void $define() {
        Object obj;
        Throwable th;
        Object obj2;
        Throwable th2;
        Object obj3;
        Throwable th3;
        Object obj4;
        Throwable th4;
        Object obj5;
        Throwable th5;
        Object obj6;
        Throwable th6;
        Object obj7;
        Throwable th7;
        Object obj8;
        Throwable th8;
        Throwable th9;
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception e) {
            Exception exception = e;
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        Screen2 = this;
        addToFormEnvironment(Lit0, this);
        Object obj9 = this.events$Mnto$Mnregister;
        while (true) {
            Object obj10 = obj9;
            if (obj10 == LList.Empty) {
                break;
            }
            Object obj11 = obj10;
            Object obj12 = obj11;
            try {
                Pair arg0 = (Pair) obj11;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = C1271lists.car.apply1(event$Mninfo);
                String obj13 = apply1 == null ? null : apply1.toString();
                Object apply12 = C1271lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj13, apply12 == null ? null : apply12.toString());
                obj9 = arg0.getCdr();
            } catch (ClassCastException e2) {
                ClassCastException classCastException = e2;
                Throwable th10 = th9;
                new WrongType(classCastException, "arg0", -2, obj12);
                throw th10;
            }
        }
        try {
            LList components = C1271lists.reverse(this.components$Mnto$Mncreate);
            addToGlobalVars(Lit2, lambda$Fn1);
            LList event$Mninfo2 = components;
            while (event$Mninfo2 != LList.Empty) {
                Object obj14 = event$Mninfo2;
                obj6 = obj14;
                Pair arg02 = (Pair) obj14;
                Object component$Mninfo = arg02.getCar();
                Object apply13 = C1271lists.caddr.apply1(component$Mninfo);
                Object apply14 = C1271lists.cadddr.apply1(component$Mninfo);
                Object component$Mntype = C1271lists.cadr.apply1(component$Mninfo);
                Object apply15 = C1271lists.car.apply1(component$Mninfo);
                obj7 = apply15;
                Object component$Mnname = apply13;
                Object component$Mnobject = Invoke.make.apply2(component$Mntype, lookupInFormEnvironment((Symbol) apply15));
                Object apply3 = SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
                Object obj15 = component$Mnname;
                obj8 = obj15;
                addToFormEnvironment((Symbol) obj15, component$Mnobject);
                event$Mninfo2 = arg02.getCdr();
            }
            LList reverse = C1271lists.reverse(this.global$Mnvars$Mnto$Mncreate);
            while (reverse != LList.Empty) {
                Object obj16 = reverse;
                obj4 = obj16;
                Pair arg03 = (Pair) obj16;
                Object var$Mnval = arg03.getCar();
                Object apply16 = C1271lists.car.apply1(var$Mnval);
                obj5 = apply16;
                addToGlobalVarEnvironment((Symbol) apply16, Scheme.applyToArgs.apply1(C1271lists.cadr.apply1(var$Mnval)));
                reverse = arg03.getCdr();
            }
            Object reverse2 = C1271lists.reverse(this.form$Mndo$Mnafter$Mncreation);
            while (reverse2 != LList.Empty) {
                Object obj17 = reverse2;
                obj3 = obj17;
                Pair arg04 = (Pair) obj17;
                Object force = misc.force(arg04.getCar());
                reverse2 = arg04.getCdr();
            }
            LList component$Mndescriptors = components;
            LList lList = component$Mndescriptors;
            while (lList != LList.Empty) {
                Object obj18 = lList;
                obj2 = obj18;
                Pair arg05 = (Pair) obj18;
                Object component$Mninfo2 = arg05.getCar();
                Object apply17 = C1271lists.caddr.apply1(component$Mninfo2);
                Object init$Mnthunk = C1271lists.cadddr.apply1(component$Mninfo2);
                if (init$Mnthunk != Boolean.FALSE) {
                    Object apply18 = Scheme.applyToArgs.apply1(init$Mnthunk);
                }
                lList = arg05.getCdr();
            }
            LList lList2 = component$Mndescriptors;
            while (lList2 != LList.Empty) {
                Object obj19 = lList2;
                obj = obj19;
                Pair arg06 = (Pair) obj19;
                Object component$Mninfo3 = arg06.getCar();
                Object component$Mnname2 = C1271lists.caddr.apply1(component$Mninfo3);
                Object apply19 = C1271lists.cadddr.apply1(component$Mninfo3);
                callInitialize(SlotGet.field.apply2(this, component$Mnname2));
                lList2 = arg06.getCdr();
            }
        } catch (ClassCastException e3) {
            ClassCastException classCastException2 = e3;
            Throwable th11 = th;
            new WrongType(classCastException2, "arg0", -2, obj);
            throw th11;
        } catch (ClassCastException e4) {
            ClassCastException classCastException3 = e4;
            Throwable th12 = th2;
            new WrongType(classCastException3, "arg0", -2, obj2);
            throw th12;
        } catch (ClassCastException e5) {
            ClassCastException classCastException4 = e5;
            Throwable th13 = th3;
            new WrongType(classCastException4, "arg0", -2, obj3);
            throw th13;
        } catch (ClassCastException e6) {
            ClassCastException classCastException5 = e6;
            Throwable th14 = th5;
            new WrongType(classCastException5, "add-to-global-var-environment", 0, obj5);
            throw th14;
        } catch (ClassCastException e7) {
            ClassCastException classCastException6 = e7;
            Throwable th15 = th4;
            new WrongType(classCastException6, "arg0", -2, obj4);
            throw th15;
        } catch (ClassCastException e8) {
            ClassCastException classCastException7 = e8;
            Throwable th16 = th8;
            new WrongType(classCastException7, "add-to-form-environment", 0, obj8);
            throw th16;
        } catch (ClassCastException e9) {
            ClassCastException classCastException8 = e9;
            Throwable th17 = th7;
            new WrongType(classCastException8, "lookup-in-form-environment", 0, obj7);
            throw th17;
        } catch (ClassCastException e10) {
            ClassCastException classCastException9 = e10;
            Throwable th18 = th6;
            new WrongType(classCastException9, "arg0", -2, obj6);
            throw th18;
        } catch (YailRuntimeError e11) {
            processException(e11);
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        LList symbols = LList.makeList(argsArray, 0);
        LList lList = symbols;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj = symbols;
        Object obj2 = LList.Empty;
        while (true) {
            Object obj3 = obj2;
            Object obj4 = obj;
            if (obj4 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj3));
                Object obj5 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    Throwable th4 = th;
                    new WrongType(classCastException, "string->symbol", 1, obj5);
                    throw th4;
                }
            } else {
                Object obj6 = obj4;
                Object obj7 = obj6;
                try {
                    Pair arg0 = (Pair) obj6;
                    obj = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj8 = car;
                    try {
                        obj2 = Pair.make(misc.symbol$To$String((Symbol) car), obj3);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th3;
                        new WrongType(classCastException2, "symbol->string", 1, obj8);
                        throw th5;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    Throwable th6 = th2;
                    new WrongType(classCastException3, "arg0", -2, obj7);
                    throw th6;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
