package p004io.kodular.anshsingh2006_1.COV_AID_2;

import android.support.p000v4.app.FragmentTransaction;
import com.google.appinventor.components.common.ComponentConstants;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.ActivityStarter;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.KodularFirebaseAuthentication;
import com.google.appinventor.components.runtime.KodularImageUtilities;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.MakeroidFab;
import com.google.appinventor.components.runtime.MakeroidViewFlipper;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.SpaceView;
import com.google.appinventor.components.runtime.TinyDB;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.FullScreenVideoUtil;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1241runtime;
import com.microsoft.appcenter.crashes.utils.ErrorLogHelper;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.Procedure;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.DFloNum;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.C1271lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.shaded.apache.http.HttpStatus;
import p012yt.DeepHost.HyperLinks.HiperLinks;
import p012yt.DeepHost.InApp_PDFViewer.C1691InApp_PDFViewer;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.home */
/* compiled from: home.yail */
public class home extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final PairWithPosition Lit10 = PairWithPosition.make(Lit57, PairWithPosition.make(Lit22, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 37103), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 37098), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 37087);
    static final IntNum Lit100 = IntNum.make(-1002);
    static final FString Lit101;
    static final FString Lit102;
    static final SimpleSymbol Lit103;
    static final IntNum Lit104;
    static final FString Lit105;
    static final FString Lit106;
    static final SimpleSymbol Lit107;
    static final IntNum Lit108 = IntNum.make(-1002);
    static final FString Lit109;
    static final SimpleSymbol Lit11;
    static final FString Lit110;
    static final SimpleSymbol Lit111;
    static final FString Lit112;
    static final FString Lit113;
    static final SimpleSymbol Lit114;
    static final IntNum Lit115;
    static final SimpleSymbol Lit116;
    static final IntNum Lit117 = IntNum.make(-1014);
    static final IntNum Lit118 = IntNum.make(-1028);
    static final SimpleSymbol Lit119;
    static final SimpleSymbol Lit12;
    static final FString Lit120;
    static final PairWithPosition Lit121 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 647246);
    static final SimpleSymbol Lit122;
    static final SimpleSymbol Lit123;
    static final FString Lit124;
    static final SimpleSymbol Lit125;
    static final IntNum Lit126 = IntNum.make(-1035);
    static final FString Lit127;
    static final FString Lit128;
    static final SimpleSymbol Lit129;
    static final PairWithPosition Lit13 = PairWithPosition.make(Lit57, PairWithPosition.make(Lit22, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 37103), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 37098), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 37087);
    static final IntNum Lit130;
    static final IntNum Lit131 = IntNum.make(-1014);
    static final IntNum Lit132 = IntNum.make(-1028);
    static final FString Lit133;
    static final PairWithPosition Lit134 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 745550);
    static final SimpleSymbol Lit135;
    static final FString Lit136;
    static final SimpleSymbol Lit137;
    static final IntNum Lit138 = IntNum.make(-1002);
    static final FString Lit139;
    static final SimpleSymbol Lit14;
    static final FString Lit140;
    static final SimpleSymbol Lit141;
    static final FString Lit142;
    static final FString Lit143;
    static final SimpleSymbol Lit144;
    static final FString Lit145;
    static final FString Lit146;
    static final SimpleSymbol Lit147;
    static final FString Lit148;
    static final FString Lit149;
    static final IntNum Lit15;
    static final SimpleSymbol Lit150;
    static final IntNum Lit151 = IntNum.make(-1050);
    static final FString Lit152;
    static final FString Lit153;
    static final SimpleSymbol Lit154;
    static final IntNum Lit155 = IntNum.make(50);
    static final FString Lit156;
    static final FString Lit157;
    static final SimpleSymbol Lit158;
    static final IntNum Lit159 = IntNum.make(-1005);
    static final SimpleSymbol Lit16;
    static final FString Lit160;
    static final FString Lit161;
    static final SimpleSymbol Lit162;
    static final FString Lit163;
    static final FString Lit164;
    static final SimpleSymbol Lit165;
    static final IntNum Lit166;
    static final IntNum Lit167 = IntNum.make(-1014);
    static final IntNum Lit168 = IntNum.make(-1028);
    static final FString Lit169;
    static final SimpleSymbol Lit17;
    static final PairWithPosition Lit170 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 1126478);
    static final SimpleSymbol Lit171;
    static final FString Lit172;
    static final SimpleSymbol Lit173;
    static final IntNum Lit174 = IntNum.make(-1035);
    static final FString Lit175;
    static final FString Lit176;
    static final SimpleSymbol Lit177;
    static final IntNum Lit178;
    static final IntNum Lit179 = IntNum.make(-1014);
    static final IntNum Lit18 = IntNum.make(3);
    static final IntNum Lit180 = IntNum.make(-1028);
    static final FString Lit181;
    static final PairWithPosition Lit182 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 1224782);
    static final SimpleSymbol Lit183;
    static final FString Lit184;
    static final SimpleSymbol Lit185;
    static final FString Lit186;
    static final FString Lit187;
    static final SimpleSymbol Lit188;
    static final FString Lit189;
    static final SimpleSymbol Lit19;
    static final FString Lit190;
    static final SimpleSymbol Lit191;
    static final IntNum Lit192 = IntNum.make(-1037);
    static final FString Lit193;
    static final FString Lit194;
    static final SimpleSymbol Lit195;
    static final DFloNum Lit196 = DFloNum.make(13.5d);
    static final FString Lit197;
    static final FString Lit198;
    static final SimpleSymbol Lit199;
    static final SimpleSymbol Lit2;
    static final IntNum Lit20 = IntNum.make(2);
    static final IntNum Lit200 = IntNum.make(-1002);
    static final FString Lit201;
    static final FString Lit202;
    static final SimpleSymbol Lit203;
    static final IntNum Lit204 = IntNum.make(-1002);
    static final FString Lit205;
    static final FString Lit206;
    static final SimpleSymbol Lit207;
    static final IntNum Lit208;
    static final FString Lit209;
    static final SimpleSymbol Lit21;
    static final FString Lit210;
    static final SimpleSymbol Lit211;
    static final DFloNum Lit212 = DFloNum.make(13.5d);
    static final FString Lit213;
    static final FString Lit214;
    static final SimpleSymbol Lit215;
    static final IntNum Lit216 = IntNum.make(-1001);
    static final FString Lit217;
    static final FString Lit218;
    static final SimpleSymbol Lit219;
    static final SimpleSymbol Lit22;
    static final IntNum Lit220;
    static final FString Lit221;
    static final FString Lit222;
    static final SimpleSymbol Lit223;
    static final IntNum Lit224;
    static final FString Lit225;
    static final FString Lit226;
    static final SimpleSymbol Lit227;
    static final IntNum Lit228;
    static final FString Lit229;
    static final SimpleSymbol Lit23;
    static final SimpleSymbol Lit230;
    static final FString Lit231;
    static final SimpleSymbol Lit232;
    static final IntNum Lit233 = IntNum.make(-1010);
    static final FString Lit234;
    static final FString Lit235;
    static final SimpleSymbol Lit236;
    static final IntNum Lit237;
    static final FString Lit238;
    static final FString Lit239;
    static final SimpleSymbol Lit24;
    static final SimpleSymbol Lit240;
    static final IntNum Lit241;
    static final FString Lit242;
    static final SimpleSymbol Lit243;
    static final FString Lit244;
    static final SimpleSymbol Lit245;
    static final IntNum Lit246 = IntNum.make(-1002);
    static final FString Lit247;
    static final FString Lit248;
    static final SimpleSymbol Lit249;
    static final IntNum Lit25;
    static final IntNum Lit250;
    static final IntNum Lit251 = IntNum.make(-1040);
    static final FString Lit252;
    static final FString Lit253;
    static final SimpleSymbol Lit254;
    static final FString Lit255;
    static final PairWithPosition Lit256 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 2175055);
    static final SimpleSymbol Lit257;
    static final FString Lit258;
    static final SimpleSymbol Lit259;
    static final SimpleSymbol Lit26;
    static final IntNum Lit260 = IntNum.make(-1002);
    static final FString Lit261;
    static final FString Lit262;
    static final FString Lit263;
    static final FString Lit264;
    static final SimpleSymbol Lit265;
    static final IntNum Lit266 = IntNum.make(18);
    static final FString Lit267;
    static final SimpleSymbol Lit268;
    static final SimpleSymbol Lit269;
    static final IntNum Lit27;
    static final FString Lit270;
    static final SimpleSymbol Lit271;
    static final IntNum Lit272 = IntNum.make(-1020);
    static final IntNum Lit273 = IntNum.make(-1030);
    static final SimpleSymbol Lit274;
    static final FString Lit275;
    static final FString Lit276;
    static final SimpleSymbol Lit277;
    static final IntNum Lit278 = IntNum.make(-1002);
    static final FString Lit279;
    static final SimpleSymbol Lit28;
    static final FString Lit280;
    static final SimpleSymbol Lit281;
    static final IntNum Lit282;
    static final IntNum Lit283 = IntNum.make(-1070);
    static final FString Lit284;
    static final FString Lit285;
    static final SimpleSymbol Lit286;
    static final IntNum Lit287;
    static final FString Lit288;
    static final PairWithPosition Lit289 = PairWithPosition.make(Lit491, PairWithPosition.make(Lit491, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 2580672), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 2580667);
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit290;
    static final SimpleSymbol Lit291;
    static final FString Lit292;
    static final SimpleSymbol Lit293;
    static final IntNum Lit294 = IntNum.make(-1002);
    static final FString Lit295;
    static final FString Lit296;
    static final FString Lit297;
    static final FString Lit298;
    static final FString Lit299;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final FString Lit300;
    static final SimpleSymbol Lit301;
    static final IntNum Lit302 = IntNum.make(21);
    static final FString Lit303;
    static final FString Lit304;
    static final SimpleSymbol Lit305;
    static final IntNum Lit306 = IntNum.make(-1002);
    static final FString Lit307;
    static final FString Lit308;
    static final SimpleSymbol Lit309;
    static final SimpleSymbol Lit31;
    static final IntNum Lit310;
    static final FString Lit311;
    static final FString Lit312;
    static final SimpleSymbol Lit313;
    static final IntNum Lit314 = IntNum.make(17);
    static final FString Lit315;
    static final FString Lit316;
    static final SimpleSymbol Lit317;
    static final IntNum Lit318 = IntNum.make(-1001);
    static final FString Lit319;
    static final SimpleSymbol Lit32;
    static final FString Lit320;
    static final SimpleSymbol Lit321;
    static final FString Lit322;
    static final FString Lit323;
    static final SimpleSymbol Lit324;
    static final IntNum Lit325 = IntNum.make(16);
    static final FString Lit326;
    static final FString Lit327;
    static final SimpleSymbol Lit328;
    static final FString Lit329;
    static final SimpleSymbol Lit33;
    static final FString Lit330;
    static final SimpleSymbol Lit331;
    static final IntNum Lit332 = IntNum.make(-1001);
    static final FString Lit333;
    static final FString Lit334;
    static final FString Lit335;
    static final FString Lit336;
    static final SimpleSymbol Lit337;
    static final IntNum Lit338 = IntNum.make(-1001);
    static final FString Lit339;
    static final SimpleSymbol Lit34;
    static final FString Lit340;
    static final FString Lit341;
    static final FString Lit342;
    static final SimpleSymbol Lit343;
    static final IntNum Lit344 = IntNum.make(13);
    static final FString Lit345;
    static final FString Lit346;
    static final SimpleSymbol Lit347;
    static final FString Lit348;
    static final FString Lit349;
    static final PairWithPosition Lit35 = PairWithPosition.make(Lit22, PairWithPosition.make(Lit491, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 106646), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 106640);
    static final SimpleSymbol Lit350;
    static final IntNum Lit351;
    static final FString Lit352;
    static final PairWithPosition Lit353 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 3342415);
    static final SimpleSymbol Lit354;
    static final FString Lit355;
    static final SimpleSymbol Lit356;
    static final IntNum Lit357;
    static final FString Lit358;
    static final PairWithPosition Lit359 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 3428431);
    static final IntNum Lit36 = IntNum.make(1);
    static final SimpleSymbol Lit360;
    static final FString Lit361;
    static final FString Lit362;
    static final FString Lit363;
    static final SimpleSymbol Lit364;
    static final IntNum Lit365 = IntNum.make(25);
    static final FString Lit366;
    static final FString Lit367;
    static final SimpleSymbol Lit368;
    static final IntNum Lit369 = IntNum.make(-1002);
    static final PairWithPosition Lit37 = PairWithPosition.make(Lit491, PairWithPosition.make(Lit491, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 106661), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 106656);
    static final FString Lit370;
    static final FString Lit371;
    static final SimpleSymbol Lit372;
    static final IntNum Lit373;
    static final FString Lit374;
    static final FString Lit375;
    static final SimpleSymbol Lit376;
    static final FString Lit377;
    static final FString Lit378;
    static final SimpleSymbol Lit379;
    static final SimpleSymbol Lit38;
    static final IntNum Lit380 = IntNum.make(-1001);
    static final FString Lit381;
    static final FString Lit382;
    static final SimpleSymbol Lit383;
    static final FString Lit384;
    static final FString Lit385;
    static final SimpleSymbol Lit386;
    static final FString Lit387;
    static final FString Lit388;
    static final SimpleSymbol Lit389;
    static final SimpleSymbol Lit39;
    static final FString Lit390;
    static final FString Lit391;
    static final SimpleSymbol Lit392;
    static final IntNum Lit393 = IntNum.make(-1001);
    static final FString Lit394;
    static final FString Lit395;
    static final FString Lit396;
    static final FString Lit397;
    static final SimpleSymbol Lit398;
    static final IntNum Lit399 = IntNum.make(-1001);
    static final IntNum Lit4 = IntNum.make(0);
    static final SimpleSymbol Lit40;
    static final FString Lit400;
    static final FString Lit401;
    static final FString Lit402;
    static final FString Lit403;
    static final SimpleSymbol Lit404;
    static final FString Lit405;
    static final FString Lit406;
    static final SimpleSymbol Lit407;
    static final FString Lit408;
    static final FString Lit409;
    static final PairWithPosition Lit41 = PairWithPosition.make(Lit22, PairWithPosition.make(Lit491, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 106857), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 106851);
    static final SimpleSymbol Lit410;
    static final IntNum Lit411;
    static final FString Lit412;
    static final PairWithPosition Lit413 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 4149327);
    static final SimpleSymbol Lit414;
    static final FString Lit415;
    static final SimpleSymbol Lit416;
    static final DFloNum Lit417 = DFloNum.make((double) 15);
    static final IntNum Lit418;
    static final FString Lit419;
    static final SimpleSymbol Lit42;
    static final PairWithPosition Lit420 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 4243535);
    static final SimpleSymbol Lit421;
    static final FString Lit422;
    static final IntNum Lit423;
    static final FString Lit424;
    static final FString Lit425;
    static final SimpleSymbol Lit426;
    static final SimpleSymbol Lit427;
    static final FString Lit428;
    static final SimpleSymbol Lit429;
    static final SimpleSymbol Lit43;
    static final FString Lit430;
    static final SimpleSymbol Lit431;
    static final IntNum Lit432 = IntNum.make(-1003);
    static final IntNum Lit433;
    static final FString Lit434;
    static final FString Lit435;
    static final SimpleSymbol Lit436;
    static final SimpleSymbol Lit437;
    static final SimpleSymbol Lit438;
    static final FString Lit439;
    static final SimpleSymbol Lit44;
    static final FString Lit440;
    static final FString Lit441;
    static final FString Lit442;
    static final SimpleSymbol Lit443;
    static final FString Lit444;
    static final FString Lit445;
    static final FString Lit446;
    static final FString Lit447;
    static final SimpleSymbol Lit448;
    static final FString Lit449;
    static final PairWithPosition Lit45 = PairWithPosition.make(Lit57, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107010);
    static final FString Lit450;
    static final SimpleSymbol Lit451;
    static final FString Lit452;
    static final FString Lit453;
    static final SimpleSymbol Lit454;
    static final FString Lit455;
    static final FString Lit456;
    static final SimpleSymbol Lit457;
    static final FString Lit458;
    static final FString Lit459;
    static final SimpleSymbol Lit46;
    static final SimpleSymbol Lit460;
    static final IntNum Lit461;
    static final SimpleSymbol Lit462;
    static final FString Lit463;
    static final PairWithPosition Lit464 = PairWithPosition.make(Lit22, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 4718671);
    static final SimpleSymbol Lit465;
    static final PairWithPosition Lit466;
    static final SimpleSymbol Lit467;
    static final SimpleSymbol Lit468;
    static final FString Lit469;
    static final PairWithPosition Lit47 = PairWithPosition.make(Lit57, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107162);
    static final FString Lit470;
    static final FString Lit471;
    static final FString Lit472;
    static final FString Lit473;
    static final FString Lit474;
    static final FString Lit475;
    static final FString Lit476;
    static final SimpleSymbol Lit477;
    static final SimpleSymbol Lit478;
    static final SimpleSymbol Lit479;
    static final SimpleSymbol Lit48;
    static final SimpleSymbol Lit480;
    static final SimpleSymbol Lit481;
    static final SimpleSymbol Lit482;
    static final SimpleSymbol Lit483;
    static final SimpleSymbol Lit484;
    static final SimpleSymbol Lit485;
    static final SimpleSymbol Lit486;
    static final SimpleSymbol Lit487;
    static final SimpleSymbol Lit488;
    static final SimpleSymbol Lit489;
    static final SimpleSymbol Lit49;
    static final SimpleSymbol Lit490;
    static final SimpleSymbol Lit491;
    static final SimpleSymbol Lit5;
    static final SimpleSymbol Lit50;
    static final PairWithPosition Lit51 = PairWithPosition.make(Lit57, PairWithPosition.make(Lit22, PairWithPosition.make(Lit22, PairWithPosition.make(Lit22, PairWithPosition.make(Lit30, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107348), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107343), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107338), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107333), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107322);
    static final PairWithPosition Lit52;
    static final SimpleSymbol Lit53;
    static final SimpleSymbol Lit54;
    static final SimpleSymbol Lit55;
    static final SimpleSymbol Lit56;
    static final SimpleSymbol Lit57;
    static final SimpleSymbol Lit58;
    static final SimpleSymbol Lit59;
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final SimpleSymbol Lit61;
    static final SimpleSymbol Lit62;
    static final SimpleSymbol Lit63;
    static final SimpleSymbol Lit64;
    static final FString Lit65;
    static final SimpleSymbol Lit66;
    static final SimpleSymbol Lit67;
    static final IntNum Lit68;
    static final SimpleSymbol Lit69;
    static final SimpleSymbol Lit7;
    static final IntNum Lit70 = IntNum.make(-1007);
    static final SimpleSymbol Lit71;
    static final IntNum Lit72 = IntNum.make(-2);
    static final SimpleSymbol Lit73;
    static final FString Lit74;
    static final FString Lit75;
    static final SimpleSymbol Lit76;
    static final SimpleSymbol Lit77;
    static final IntNum Lit78 = IntNum.make(20);
    static final SimpleSymbol Lit79;
    static final SimpleSymbol Lit8;
    static final SimpleSymbol Lit80;
    static final SimpleSymbol Lit81;
    static final FString Lit82;
    static final FString Lit83;
    static final SimpleSymbol Lit84;
    static final IntNum Lit85 = IntNum.make(-1002);
    static final FString Lit86;
    static final FString Lit87;
    static final SimpleSymbol Lit88;
    static final IntNum Lit89;
    static final SimpleSymbol Lit9;
    static final SimpleSymbol Lit90;
    static final FString Lit91;
    static final FString Lit92;
    static final SimpleSymbol Lit93;
    static final IntNum Lit94 = IntNum.make(12);
    static final SimpleSymbol Lit95;
    static final IntNum Lit96;
    static final FString Lit97;
    static final FString Lit98;
    static final SimpleSymbol Lit99;
    public static home home;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn100 = null;
    static final ModuleMethod lambda$Fn101 = null;
    static final ModuleMethod lambda$Fn102 = null;
    static final ModuleMethod lambda$Fn103 = null;
    static final ModuleMethod lambda$Fn104 = null;
    static final ModuleMethod lambda$Fn105 = null;
    static final ModuleMethod lambda$Fn106 = null;
    static final ModuleMethod lambda$Fn107 = null;
    static final ModuleMethod lambda$Fn108 = null;
    static final ModuleMethod lambda$Fn109 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn110 = null;
    static final ModuleMethod lambda$Fn111 = null;
    static final ModuleMethod lambda$Fn112 = null;
    static final ModuleMethod lambda$Fn113 = null;
    static final ModuleMethod lambda$Fn114 = null;
    static final ModuleMethod lambda$Fn115 = null;
    static final ModuleMethod lambda$Fn116 = null;
    static final ModuleMethod lambda$Fn117 = null;
    static final ModuleMethod lambda$Fn118 = null;
    static final ModuleMethod lambda$Fn119 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn120 = null;
    static final ModuleMethod lambda$Fn121 = null;
    static final ModuleMethod lambda$Fn122 = null;
    static final ModuleMethod lambda$Fn123 = null;
    static final ModuleMethod lambda$Fn124 = null;
    static final ModuleMethod lambda$Fn125 = null;
    static final ModuleMethod lambda$Fn126 = null;
    static final ModuleMethod lambda$Fn127 = null;
    static final ModuleMethod lambda$Fn128 = null;
    static final ModuleMethod lambda$Fn129 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn130 = null;
    static final ModuleMethod lambda$Fn131 = null;
    static final ModuleMethod lambda$Fn132 = null;
    static final ModuleMethod lambda$Fn133 = null;
    static final ModuleMethod lambda$Fn134 = null;
    static final ModuleMethod lambda$Fn135 = null;
    static final ModuleMethod lambda$Fn136 = null;
    static final ModuleMethod lambda$Fn137 = null;
    static final ModuleMethod lambda$Fn138 = null;
    static final ModuleMethod lambda$Fn139 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn140 = null;
    static final ModuleMethod lambda$Fn141 = null;
    static final ModuleMethod lambda$Fn142 = null;
    static final ModuleMethod lambda$Fn143 = null;
    static final ModuleMethod lambda$Fn144 = null;
    static final ModuleMethod lambda$Fn145 = null;
    static final ModuleMethod lambda$Fn146 = null;
    static final ModuleMethod lambda$Fn147 = null;
    static final ModuleMethod lambda$Fn148 = null;
    static final ModuleMethod lambda$Fn149 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn150 = null;
    static final ModuleMethod lambda$Fn151 = null;
    static final ModuleMethod lambda$Fn152 = null;
    static final ModuleMethod lambda$Fn153 = null;
    static final ModuleMethod lambda$Fn154 = null;
    static final ModuleMethod lambda$Fn155 = null;
    static final ModuleMethod lambda$Fn156 = null;
    static final ModuleMethod lambda$Fn157 = null;
    static final ModuleMethod lambda$Fn158 = null;
    static final ModuleMethod lambda$Fn159 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn160 = null;
    static final ModuleMethod lambda$Fn161 = null;
    static final ModuleMethod lambda$Fn162 = null;
    static final ModuleMethod lambda$Fn163 = null;
    static final ModuleMethod lambda$Fn164 = null;
    static final ModuleMethod lambda$Fn165 = null;
    static final ModuleMethod lambda$Fn166 = null;
    static final ModuleMethod lambda$Fn167 = null;
    static final ModuleMethod lambda$Fn168 = null;
    static final ModuleMethod lambda$Fn169 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn170 = null;
    static final ModuleMethod lambda$Fn171 = null;
    static final ModuleMethod lambda$Fn172 = null;
    static final ModuleMethod lambda$Fn173 = null;
    static final ModuleMethod lambda$Fn174 = null;
    static final ModuleMethod lambda$Fn175 = null;
    static final ModuleMethod lambda$Fn176 = null;
    static final ModuleMethod lambda$Fn177 = null;
    static final ModuleMethod lambda$Fn178 = null;
    static final ModuleMethod lambda$Fn179 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn180 = null;
    static final ModuleMethod lambda$Fn181 = null;
    static final ModuleMethod lambda$Fn182 = null;
    static final ModuleMethod lambda$Fn183 = null;
    static final ModuleMethod lambda$Fn184 = null;
    static final ModuleMethod lambda$Fn185 = null;
    static final ModuleMethod lambda$Fn186 = null;
    static final ModuleMethod lambda$Fn187 = null;
    static final ModuleMethod lambda$Fn188 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn31 = null;
    static final ModuleMethod lambda$Fn32 = null;
    static final ModuleMethod lambda$Fn33 = null;
    static final ModuleMethod lambda$Fn34 = null;
    static final ModuleMethod lambda$Fn35 = null;
    static final ModuleMethod lambda$Fn36 = null;
    static final ModuleMethod lambda$Fn37 = null;
    static final ModuleMethod lambda$Fn38 = null;
    static final ModuleMethod lambda$Fn39 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn40 = null;
    static final ModuleMethod lambda$Fn41 = null;
    static final ModuleMethod lambda$Fn42 = null;
    static final ModuleMethod lambda$Fn43 = null;
    static final ModuleMethod lambda$Fn44 = null;
    static final ModuleMethod lambda$Fn45 = null;
    static final ModuleMethod lambda$Fn46 = null;
    static final ModuleMethod lambda$Fn47 = null;
    static final ModuleMethod lambda$Fn48 = null;
    static final ModuleMethod lambda$Fn49 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn50 = null;
    static final ModuleMethod lambda$Fn51 = null;
    static final ModuleMethod lambda$Fn52 = null;
    static final ModuleMethod lambda$Fn53 = null;
    static final ModuleMethod lambda$Fn54 = null;
    static final ModuleMethod lambda$Fn55 = null;
    static final ModuleMethod lambda$Fn56 = null;
    static final ModuleMethod lambda$Fn57 = null;
    static final ModuleMethod lambda$Fn58 = null;
    static final ModuleMethod lambda$Fn59 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn60 = null;
    static final ModuleMethod lambda$Fn61 = null;
    static final ModuleMethod lambda$Fn62 = null;
    static final ModuleMethod lambda$Fn63 = null;
    static final ModuleMethod lambda$Fn64 = null;
    static final ModuleMethod lambda$Fn65 = null;
    static final ModuleMethod lambda$Fn66 = null;
    static final ModuleMethod lambda$Fn67 = null;
    static final ModuleMethod lambda$Fn68 = null;
    static final ModuleMethod lambda$Fn69 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn70 = null;
    static final ModuleMethod lambda$Fn71 = null;
    static final ModuleMethod lambda$Fn72 = null;
    static final ModuleMethod lambda$Fn73 = null;
    static final ModuleMethod lambda$Fn74 = null;
    static final ModuleMethod lambda$Fn75 = null;
    static final ModuleMethod lambda$Fn76 = null;
    static final ModuleMethod lambda$Fn77 = null;
    static final ModuleMethod lambda$Fn78 = null;
    static final ModuleMethod lambda$Fn79 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn80 = null;
    static final ModuleMethod lambda$Fn81 = null;
    static final ModuleMethod lambda$Fn82 = null;
    static final ModuleMethod lambda$Fn83 = null;
    static final ModuleMethod lambda$Fn84 = null;
    static final ModuleMethod lambda$Fn85 = null;
    static final ModuleMethod lambda$Fn86 = null;
    static final ModuleMethod lambda$Fn87 = null;
    static final ModuleMethod lambda$Fn88 = null;
    static final ModuleMethod lambda$Fn89 = null;
    static final ModuleMethod lambda$Fn9 = null;
    static final ModuleMethod lambda$Fn90 = null;
    static final ModuleMethod lambda$Fn91 = null;
    static final ModuleMethod lambda$Fn92 = null;
    static final ModuleMethod lambda$Fn93 = null;
    static final ModuleMethod lambda$Fn94 = null;
    static final ModuleMethod lambda$Fn95 = null;
    static final ModuleMethod lambda$Fn96 = null;
    static final ModuleMethod lambda$Fn97 = null;
    static final ModuleMethod lambda$Fn98 = null;
    static final ModuleMethod lambda$Fn99 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public ActivityStarter Activity_Starter1;
    public KodularFirebaseAuthentication Firebase_Authentication1;
    public MakeroidFab Floating_Action_Button1;
    public final ModuleMethod Floating_Action_Button1$Click;
    public final ModuleMethod Floating_Action_Button1$LongClick;
    public HiperLinks HiperLinks1;
    public HorizontalArrangement Horizontal_Arrangement1;
    public HorizontalArrangement Horizontal_Arrangement10;
    public HorizontalArrangement Horizontal_Arrangement10_copy;
    public HorizontalArrangement Horizontal_Arrangement11_copy_copy;
    public HorizontalArrangement Horizontal_Arrangement12;
    public HorizontalArrangement Horizontal_Arrangement12_copy;
    public HorizontalArrangement Horizontal_Arrangement14;
    public HorizontalArrangement Horizontal_Arrangement15;
    public HorizontalArrangement Horizontal_Arrangement16;
    public HorizontalArrangement Horizontal_Arrangement16_copy;
    public final ModuleMethod Horizontal_Arrangement16_copy$Click;
    public HorizontalArrangement Horizontal_Arrangement16_copy_copy;
    public final ModuleMethod Horizontal_Arrangement16_copy_copy$Click;
    public HorizontalArrangement Horizontal_Arrangement17;
    public HorizontalArrangement Horizontal_Arrangement3;
    public HorizontalArrangement Horizontal_Arrangement4;
    public HorizontalArrangement Horizontal_Arrangement5;
    public HorizontalArrangement Horizontal_Arrangement6;
    public final ModuleMethod Horizontal_Arrangement6$Click;
    public HorizontalArrangement Horizontal_Arrangement7;
    public final ModuleMethod Horizontal_Arrangement7$Click;
    public HorizontalArrangement Horizontal_Arrangement8;
    public final ModuleMethod Horizontal_Arrangement8$Click;
    public HorizontalArrangement Horizontal_Arrangement9;
    public final ModuleMethod Horizontal_Arrangement9$Click;
    public Image Image2_copy_copy;
    public KodularImageUtilities Image_Utilities1;
    public C1691InApp_PDFViewer InApp_PDFViewer4;
    public Label Label1;
    public Label Label11;
    public Label Label11_copy;
    public Label Label12;
    public Label Label12_copy;
    public Label Label14_copy_copy;
    public final ModuleMethod Label14_copy_copy$Click;
    public Label Label19;
    public Label Label19_copy;
    public Label Label2;
    public Label Label20;
    public Label Label20_copy;
    public Label Label21;
    public Label Label21_copy;
    public Label Label22;
    public Label Label22_copy;
    public Label Label23;
    public Label Label23_copy;
    public Label Label24;
    public Label Label24_copy;
    public Label Label26;
    public final ModuleMethod Label26$Click;
    public Label Label27;
    public Label Label28;
    public Label Label29;
    public final ModuleMethod Label29$Click;
    public Label Label29_copy;
    public final ModuleMethod Label29_copy$Click;
    public Label Label29_copy_copy;
    public final ModuleMethod Label29_copy_copy$Click;
    public Label Label3;
    public Label Label30;
    public final ModuleMethod Label30$Click;
    public Label Label31;
    public Label Label32;
    public Label Label33;
    public Label Label34;
    public Label Label35;
    public final ModuleMethod Label35$Click;
    public Label Label9_copy_copy;
    public final ModuleMethod Label9_copy_copy$Click;
    public Notifier Notifier1;
    public Notifier Notifier2;
    public Notifier Notifier3;
    public Notifier Notifier4;
    public Notifier Notifier5;
    public Notifier Notifier6;
    public SpaceView Space14;
    public SpaceView Space15;
    public SpaceView Space16;
    public SpaceView Space16_copy;
    public SpaceView Space17;
    public SpaceView Space18_copy_copy;
    public SpaceView Space23;
    public SpaceView Space23_copy;
    public SpaceView Space24;
    public SpaceView Space24_copy;
    public SpaceView Space25;
    public SpaceView Space25_copy;
    public SpaceView Space26;
    public SpaceView Space27;
    public SpaceView Space28;
    public SpaceView Space3;
    public SpaceView Space31;
    public SpaceView Space33;
    public SpaceView Space34;
    public SpaceView Space4;
    public SpaceView Space5;
    public SpaceView Space6;
    public SpaceView Space7;
    public SpaceView Space8;
    public SpaceView Space9_copy_copy;
    public TinyDB Tiny_DB1;
    public VerticalArrangement Vertical_Arrangement1;
    public VerticalArrangement Vertical_Arrangement4;
    public VerticalArrangement Vertical_Arrangement4_copy;
    public VerticalArrangement Vertical_Arrangement6;
    public VerticalArrangement Vertical_Arrangement7;
    public VerticalArrangement Vertical_Arrangement_symptoms_copy_copy;
    public VerticalScrollArrangement Vertical_Scroll_Arrangement3;
    public VerticalScrollArrangement Vertical_Scroll_Arrangement3_copy;
    public MakeroidViewFlipper View_Flipper1_copy_copy;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod home$BackPressed;
    public final ModuleMethod home$Initialize;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        SimpleSymbol simpleSymbol15;
        FString fString;
        FString fString2;
        FString fString3;
        FString fString4;
        FString fString5;
        FString fString6;
        FString fString7;
        FString fString8;
        SimpleSymbol simpleSymbol16;
        SimpleSymbol simpleSymbol17;
        SimpleSymbol simpleSymbol18;
        SimpleSymbol simpleSymbol19;
        FString fString9;
        SimpleSymbol simpleSymbol20;
        SimpleSymbol simpleSymbol21;
        FString fString10;
        FString fString11;
        SimpleSymbol simpleSymbol22;
        FString fString12;
        FString fString13;
        SimpleSymbol simpleSymbol23;
        FString fString14;
        FString fString15;
        SimpleSymbol simpleSymbol24;
        FString fString16;
        FString fString17;
        SimpleSymbol simpleSymbol25;
        FString fString18;
        FString fString19;
        FString fString20;
        FString fString21;
        SimpleSymbol simpleSymbol26;
        FString fString22;
        FString fString23;
        FString fString24;
        FString fString25;
        SimpleSymbol simpleSymbol27;
        SimpleSymbol simpleSymbol28;
        SimpleSymbol simpleSymbol29;
        FString fString26;
        FString fString27;
        SimpleSymbol simpleSymbol30;
        FString fString28;
        SimpleSymbol simpleSymbol31;
        FString fString29;
        SimpleSymbol simpleSymbol32;
        SimpleSymbol simpleSymbol33;
        FString fString30;
        FString fString31;
        FString fString32;
        SimpleSymbol simpleSymbol34;
        FString fString33;
        SimpleSymbol simpleSymbol35;
        FString fString34;
        SimpleSymbol simpleSymbol36;
        FString fString35;
        SimpleSymbol simpleSymbol37;
        FString fString36;
        FString fString37;
        SimpleSymbol simpleSymbol38;
        FString fString38;
        FString fString39;
        SimpleSymbol simpleSymbol39;
        FString fString40;
        FString fString41;
        FString fString42;
        FString fString43;
        SimpleSymbol simpleSymbol40;
        FString fString44;
        FString fString45;
        FString fString46;
        FString fString47;
        SimpleSymbol simpleSymbol41;
        FString fString48;
        FString fString49;
        SimpleSymbol simpleSymbol42;
        FString fString50;
        FString fString51;
        SimpleSymbol simpleSymbol43;
        FString fString52;
        FString fString53;
        SimpleSymbol simpleSymbol44;
        FString fString54;
        FString fString55;
        SimpleSymbol simpleSymbol45;
        FString fString56;
        FString fString57;
        SimpleSymbol simpleSymbol46;
        FString fString58;
        FString fString59;
        SimpleSymbol simpleSymbol47;
        FString fString60;
        FString fString61;
        SimpleSymbol simpleSymbol48;
        FString fString62;
        FString fString63;
        SimpleSymbol simpleSymbol49;
        FString fString64;
        FString fString65;
        FString fString66;
        SimpleSymbol simpleSymbol50;
        FString fString67;
        SimpleSymbol simpleSymbol51;
        FString fString68;
        SimpleSymbol simpleSymbol52;
        FString fString69;
        SimpleSymbol simpleSymbol53;
        FString fString70;
        FString fString71;
        SimpleSymbol simpleSymbol54;
        FString fString72;
        FString fString73;
        SimpleSymbol simpleSymbol55;
        FString fString74;
        FString fString75;
        FString fString76;
        FString fString77;
        SimpleSymbol simpleSymbol56;
        FString fString78;
        FString fString79;
        FString fString80;
        FString fString81;
        SimpleSymbol simpleSymbol57;
        FString fString82;
        FString fString83;
        SimpleSymbol simpleSymbol58;
        FString fString84;
        FString fString85;
        SimpleSymbol simpleSymbol59;
        FString fString86;
        FString fString87;
        SimpleSymbol simpleSymbol60;
        FString fString88;
        FString fString89;
        SimpleSymbol simpleSymbol61;
        FString fString90;
        FString fString91;
        SimpleSymbol simpleSymbol62;
        FString fString92;
        FString fString93;
        SimpleSymbol simpleSymbol63;
        FString fString94;
        FString fString95;
        SimpleSymbol simpleSymbol64;
        FString fString96;
        FString fString97;
        SimpleSymbol simpleSymbol65;
        FString fString98;
        FString fString99;
        FString fString100;
        FString fString101;
        FString fString102;
        FString fString103;
        SimpleSymbol simpleSymbol66;
        FString fString104;
        SimpleSymbol simpleSymbol67;
        SimpleSymbol simpleSymbol68;
        FString fString105;
        SimpleSymbol simpleSymbol69;
        FString fString106;
        FString fString107;
        SimpleSymbol simpleSymbol70;
        FString fString108;
        FString fString109;
        SimpleSymbol simpleSymbol71;
        FString fString110;
        FString fString111;
        SimpleSymbol simpleSymbol72;
        SimpleSymbol simpleSymbol73;
        FString fString112;
        SimpleSymbol simpleSymbol74;
        SimpleSymbol simpleSymbol75;
        FString fString113;
        SimpleSymbol simpleSymbol76;
        FString fString114;
        FString fString115;
        FString fString116;
        FString fString117;
        SimpleSymbol simpleSymbol77;
        FString fString118;
        SimpleSymbol simpleSymbol78;
        FString fString119;
        SimpleSymbol simpleSymbol79;
        FString fString120;
        FString fString121;
        SimpleSymbol simpleSymbol80;
        FString fString122;
        FString fString123;
        SimpleSymbol simpleSymbol81;
        FString fString124;
        SimpleSymbol simpleSymbol82;
        FString fString125;
        SimpleSymbol simpleSymbol83;
        FString fString126;
        FString fString127;
        SimpleSymbol simpleSymbol84;
        FString fString128;
        FString fString129;
        SimpleSymbol simpleSymbol85;
        FString fString130;
        SimpleSymbol simpleSymbol86;
        FString fString131;
        SimpleSymbol simpleSymbol87;
        FString fString132;
        FString fString133;
        SimpleSymbol simpleSymbol88;
        FString fString134;
        FString fString135;
        SimpleSymbol simpleSymbol89;
        FString fString136;
        FString fString137;
        SimpleSymbol simpleSymbol90;
        FString fString138;
        FString fString139;
        SimpleSymbol simpleSymbol91;
        FString fString140;
        FString fString141;
        SimpleSymbol simpleSymbol92;
        FString fString142;
        FString fString143;
        SimpleSymbol simpleSymbol93;
        FString fString144;
        FString fString145;
        SimpleSymbol simpleSymbol94;
        FString fString146;
        FString fString147;
        SimpleSymbol simpleSymbol95;
        FString fString148;
        FString fString149;
        SimpleSymbol simpleSymbol96;
        FString fString150;
        FString fString151;
        SimpleSymbol simpleSymbol97;
        FString fString152;
        FString fString153;
        SimpleSymbol simpleSymbol98;
        FString fString154;
        SimpleSymbol simpleSymbol99;
        FString fString155;
        SimpleSymbol simpleSymbol100;
        FString fString156;
        FString fString157;
        SimpleSymbol simpleSymbol101;
        FString fString158;
        SimpleSymbol simpleSymbol102;
        FString fString159;
        SimpleSymbol simpleSymbol103;
        FString fString160;
        FString fString161;
        SimpleSymbol simpleSymbol104;
        FString fString162;
        FString fString163;
        SimpleSymbol simpleSymbol105;
        FString fString164;
        FString fString165;
        SimpleSymbol simpleSymbol106;
        FString fString166;
        FString fString167;
        SimpleSymbol simpleSymbol107;
        FString fString168;
        FString fString169;
        SimpleSymbol simpleSymbol108;
        FString fString170;
        FString fString171;
        SimpleSymbol simpleSymbol109;
        FString fString172;
        FString fString173;
        SimpleSymbol simpleSymbol110;
        FString fString174;
        FString fString175;
        SimpleSymbol simpleSymbol111;
        FString fString176;
        SimpleSymbol simpleSymbol112;
        FString fString177;
        SimpleSymbol simpleSymbol113;
        FString fString178;
        FString fString179;
        SimpleSymbol simpleSymbol114;
        FString fString180;
        SimpleSymbol simpleSymbol115;
        SimpleSymbol simpleSymbol116;
        FString fString181;
        SimpleSymbol simpleSymbol117;
        SimpleSymbol simpleSymbol118;
        SimpleSymbol simpleSymbol119;
        FString fString182;
        FString fString183;
        SimpleSymbol simpleSymbol120;
        FString fString184;
        FString fString185;
        SimpleSymbol simpleSymbol121;
        FString fString186;
        FString fString187;
        SimpleSymbol simpleSymbol122;
        FString fString188;
        FString fString189;
        SimpleSymbol simpleSymbol123;
        FString fString190;
        FString fString191;
        SimpleSymbol simpleSymbol124;
        SimpleSymbol simpleSymbol125;
        FString fString192;
        FString fString193;
        SimpleSymbol simpleSymbol126;
        SimpleSymbol simpleSymbol127;
        FString fString194;
        FString fString195;
        SimpleSymbol simpleSymbol128;
        FString fString196;
        FString fString197;
        SimpleSymbol simpleSymbol129;
        SimpleSymbol simpleSymbol130;
        SimpleSymbol simpleSymbol131;
        SimpleSymbol simpleSymbol132;
        SimpleSymbol simpleSymbol133;
        FString fString198;
        FString fString199;
        SimpleSymbol simpleSymbol134;
        SimpleSymbol simpleSymbol135;
        SimpleSymbol simpleSymbol136;
        SimpleSymbol simpleSymbol137;
        SimpleSymbol simpleSymbol138;
        FString fString200;
        SimpleSymbol simpleSymbol139;
        SimpleSymbol simpleSymbol140;
        SimpleSymbol simpleSymbol141;
        SimpleSymbol simpleSymbol142;
        SimpleSymbol simpleSymbol143;
        SimpleSymbol simpleSymbol144;
        SimpleSymbol simpleSymbol145;
        SimpleSymbol simpleSymbol146;
        SimpleSymbol simpleSymbol147;
        SimpleSymbol simpleSymbol148;
        SimpleSymbol simpleSymbol149;
        SimpleSymbol simpleSymbol150;
        SimpleSymbol simpleSymbol151;
        SimpleSymbol simpleSymbol152;
        SimpleSymbol simpleSymbol153;
        SimpleSymbol simpleSymbol154;
        SimpleSymbol simpleSymbol155;
        SimpleSymbol simpleSymbol156;
        SimpleSymbol simpleSymbol157;
        SimpleSymbol simpleSymbol158;
        SimpleSymbol simpleSymbol159;
        SimpleSymbol simpleSymbol160;
        SimpleSymbol simpleSymbol161;
        SimpleSymbol simpleSymbol162;
        SimpleSymbol simpleSymbol163;
        SimpleSymbol simpleSymbol164;
        SimpleSymbol simpleSymbol165;
        SimpleSymbol simpleSymbol166;
        SimpleSymbol simpleSymbol167;
        SimpleSymbol simpleSymbol168;
        SimpleSymbol simpleSymbol169;
        SimpleSymbol simpleSymbol170;
        SimpleSymbol simpleSymbol171;
        SimpleSymbol simpleSymbol172;
        SimpleSymbol simpleSymbol173;
        SimpleSymbol simpleSymbol174;
        SimpleSymbol simpleSymbol175;
        SimpleSymbol simpleSymbol176;
        SimpleSymbol simpleSymbol177;
        SimpleSymbol simpleSymbol178;
        SimpleSymbol simpleSymbol179;
        SimpleSymbol simpleSymbol180;
        SimpleSymbol simpleSymbol181;
        SimpleSymbol simpleSymbol182;
        SimpleSymbol simpleSymbol183;
        SimpleSymbol simpleSymbol184;
        SimpleSymbol simpleSymbol185;
        SimpleSymbol simpleSymbol186;
        new SimpleSymbol("any");
        Lit491 = (SimpleSymbol) simpleSymbol.readResolve();
        new SimpleSymbol("lookup-handler");
        Lit490 = (SimpleSymbol) simpleSymbol2.readResolve();
        new SimpleSymbol("dispatchGenericEvent");
        Lit489 = (SimpleSymbol) simpleSymbol3.readResolve();
        new SimpleSymbol("dispatchEvent");
        Lit488 = (SimpleSymbol) simpleSymbol4.readResolve();
        new SimpleSymbol("send-error");
        Lit487 = (SimpleSymbol) simpleSymbol5.readResolve();
        new SimpleSymbol("add-to-form-do-after-creation");
        Lit486 = (SimpleSymbol) simpleSymbol6.readResolve();
        new SimpleSymbol("add-to-global-vars");
        Lit485 = (SimpleSymbol) simpleSymbol7.readResolve();
        new SimpleSymbol("add-to-components");
        Lit484 = (SimpleSymbol) simpleSymbol8.readResolve();
        new SimpleSymbol("add-to-events");
        Lit483 = (SimpleSymbol) simpleSymbol9.readResolve();
        new SimpleSymbol("add-to-global-var-environment");
        Lit482 = (SimpleSymbol) simpleSymbol10.readResolve();
        new SimpleSymbol("is-bound-in-form-environment");
        Lit481 = (SimpleSymbol) simpleSymbol11.readResolve();
        new SimpleSymbol("lookup-in-form-environment");
        Lit480 = (SimpleSymbol) simpleSymbol12.readResolve();
        new SimpleSymbol("add-to-form-environment");
        Lit479 = (SimpleSymbol) simpleSymbol13.readResolve();
        new SimpleSymbol("android-log-form");
        Lit478 = (SimpleSymbol) simpleSymbol14.readResolve();
        new SimpleSymbol("get-simple-name");
        Lit477 = (SimpleSymbol) simpleSymbol15.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit476 = fString;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit475 = fString2;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit474 = fString3;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit473 = fString4;
        new FString("com.google.appinventor.components.runtime.TinyDB");
        Lit472 = fString5;
        new FString("com.google.appinventor.components.runtime.TinyDB");
        Lit471 = fString6;
        new FString("com.google.appinventor.components.runtime.KodularFirebaseAuthentication");
        Lit470 = fString7;
        new FString("com.google.appinventor.components.runtime.KodularFirebaseAuthentication");
        Lit469 = fString8;
        new SimpleSymbol("LongClick");
        Lit468 = (SimpleSymbol) simpleSymbol16.readResolve();
        new SimpleSymbol("Floating_Action_Button1$LongClick");
        Lit467 = (SimpleSymbol) simpleSymbol17.readResolve();
        new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol187 = (SimpleSymbol) simpleSymbol18.readResolve();
        Lit22 = simpleSymbol187;
        Lit466 = PairWithPosition.make(simpleSymbol187, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 4726863);
        new SimpleSymbol("Floating_Action_Button1$Click");
        Lit465 = (SimpleSymbol) simpleSymbol19.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidFab");
        Lit463 = fString9;
        new SimpleSymbol("IconName");
        Lit462 = (SimpleSymbol) simpleSymbol20.readResolve();
        int[] iArr = new int[2];
        iArr[0] = -769226;
        Lit461 = IntNum.make(iArr);
        new SimpleSymbol("Floating_Action_Button1");
        Lit460 = (SimpleSymbol) simpleSymbol21.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidFab");
        Lit459 = fString10;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit458 = fString11;
        new SimpleSymbol("Notifier5");
        Lit457 = (SimpleSymbol) simpleSymbol22.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit456 = fString12;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit455 = fString13;
        new SimpleSymbol("Notifier4");
        Lit454 = (SimpleSymbol) simpleSymbol23.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit453 = fString14;
        new FString("com.google.appinventor.components.runtime.ActivityStarter");
        Lit452 = fString15;
        new SimpleSymbol("Activity_Starter1");
        Lit451 = (SimpleSymbol) simpleSymbol24.readResolve();
        new FString("com.google.appinventor.components.runtime.ActivityStarter");
        Lit450 = fString16;
        new FString("com.google.appinventor.components.runtime.KodularImageUtilities");
        Lit449 = fString17;
        new SimpleSymbol("Image_Utilities1");
        Lit448 = (SimpleSymbol) simpleSymbol25.readResolve();
        new FString("com.google.appinventor.components.runtime.KodularImageUtilities");
        Lit447 = fString18;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit446 = fString19;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit445 = fString20;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit444 = fString21;
        new SimpleSymbol("Notifier2");
        Lit443 = (SimpleSymbol) simpleSymbol26.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit442 = fString22;
        new FString("yt.DeepHost.HyperLinks.HiperLinks");
        Lit441 = fString23;
        new FString("yt.DeepHost.HyperLinks.HiperLinks");
        Lit440 = fString24;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit439 = fString25;
        new SimpleSymbol("Linkify");
        Lit438 = (SimpleSymbol) simpleSymbol27.readResolve();
        new SimpleSymbol("LightTheme");
        Lit437 = (SimpleSymbol) simpleSymbol28.readResolve();
        new SimpleSymbol("Notifier1");
        Lit436 = (SimpleSymbol) simpleSymbol29.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit435 = fString26;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit434 = fString27;
        int[] iArr2 = new int[2];
        iArr2[0] = -16537101;
        Lit433 = IntNum.make(iArr2);
        new SimpleSymbol("Label3");
        Lit431 = (SimpleSymbol) simpleSymbol30.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit430 = fString28;
        new SimpleSymbol("Label35$Click");
        Lit429 = (SimpleSymbol) simpleSymbol31.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit428 = fString29;
        new SimpleSymbol("FontBold");
        Lit427 = (SimpleSymbol) simpleSymbol32.readResolve();
        new SimpleSymbol("Label35");
        Lit426 = (SimpleSymbol) simpleSymbol33.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit425 = fString30;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit424 = fString31;
        int[] iArr3 = new int[2];
        iArr3[0] = -5138;
        Lit423 = IntNum.make(iArr3);
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit422 = fString32;
        new SimpleSymbol("Label29_copy_copy$Click");
        Lit421 = (SimpleSymbol) simpleSymbol34.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit419 = fString33;
        int[] iArr4 = new int[2];
        iArr4[0] = -5138;
        Lit418 = IntNum.make(iArr4);
        new SimpleSymbol("Label29_copy_copy");
        Lit416 = (SimpleSymbol) simpleSymbol35.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit415 = fString34;
        new SimpleSymbol("Horizontal_Arrangement16_copy_copy$Click");
        Lit414 = (SimpleSymbol) simpleSymbol36.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit412 = fString35;
        int[] iArr5 = new int[2];
        iArr5[0] = -769226;
        Lit411 = IntNum.make(iArr5);
        new SimpleSymbol("Horizontal_Arrangement16_copy_copy");
        Lit410 = (SimpleSymbol) simpleSymbol37.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit409 = fString36;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit408 = fString37;
        new SimpleSymbol("Label34");
        Lit407 = (SimpleSymbol) simpleSymbol38.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit406 = fString38;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit405 = fString39;
        new SimpleSymbol("Label24_copy");
        Lit404 = (SimpleSymbol) simpleSymbol39.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit403 = fString40;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit402 = fString41;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit401 = fString42;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit400 = fString43;
        new SimpleSymbol("Space28");
        Lit398 = (SimpleSymbol) simpleSymbol40.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit397 = fString44;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit396 = fString45;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit395 = fString46;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit394 = fString47;
        new SimpleSymbol("Space24_copy");
        Lit392 = (SimpleSymbol) simpleSymbol41.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit391 = fString48;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit390 = fString49;
        new SimpleSymbol("Label22_copy");
        Lit389 = (SimpleSymbol) simpleSymbol42.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit388 = fString50;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit387 = fString51;
        new SimpleSymbol("Label21_copy");
        Lit386 = (SimpleSymbol) simpleSymbol43.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit385 = fString52;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit384 = fString53;
        new SimpleSymbol("Vertical_Arrangement4_copy");
        Lit383 = (SimpleSymbol) simpleSymbol44.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit382 = fString54;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit381 = fString55;
        new SimpleSymbol("Space25_copy");
        Lit379 = (SimpleSymbol) simpleSymbol45.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit378 = fString56;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit377 = fString57;
        new SimpleSymbol("Label20");
        Lit376 = (SimpleSymbol) simpleSymbol46.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit375 = fString58;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit374 = fString59;
        int[] iArr6 = new int[2];
        iArr6[0] = -5138;
        Lit373 = IntNum.make(iArr6);
        new SimpleSymbol("Horizontal_Arrangement12_copy");
        Lit372 = (SimpleSymbol) simpleSymbol47.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit371 = fString60;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit370 = fString61;
        new SimpleSymbol("Space23_copy");
        Lit368 = (SimpleSymbol) simpleSymbol48.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit367 = fString62;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit366 = fString63;
        new SimpleSymbol("Label19_copy");
        Lit364 = (SimpleSymbol) simpleSymbol49.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit363 = fString64;
        new FString("com.google.appinventor.components.runtime.VerticalScrollArrangement");
        Lit362 = fString65;
        new FString("com.google.appinventor.components.runtime.VerticalScrollArrangement");
        Lit361 = fString66;
        new SimpleSymbol("Label29_copy$Click");
        Lit360 = (SimpleSymbol) simpleSymbol50.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit358 = fString67;
        int[] iArr7 = new int[2];
        iArr7[0] = -5138;
        Lit357 = IntNum.make(iArr7);
        new SimpleSymbol("Label29_copy");
        Lit356 = (SimpleSymbol) simpleSymbol51.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit355 = fString68;
        new SimpleSymbol("Horizontal_Arrangement16_copy$Click");
        Lit354 = (SimpleSymbol) simpleSymbol52.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit352 = fString69;
        int[] iArr8 = new int[2];
        iArr8[0] = -769226;
        Lit351 = IntNum.make(iArr8);
        new SimpleSymbol("Horizontal_Arrangement16_copy");
        Lit350 = (SimpleSymbol) simpleSymbol53.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit349 = fString70;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit348 = fString71;
        new SimpleSymbol("Label33");
        Lit347 = (SimpleSymbol) simpleSymbol54.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit346 = fString72;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit345 = fString73;
        new SimpleSymbol("Label24");
        Lit343 = (SimpleSymbol) simpleSymbol55.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit342 = fString74;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit341 = fString75;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit340 = fString76;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit339 = fString77;
        new SimpleSymbol("Space27");
        Lit337 = (SimpleSymbol) simpleSymbol56.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit336 = fString78;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit335 = fString79;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit334 = fString80;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit333 = fString81;
        new SimpleSymbol("Space24");
        Lit331 = (SimpleSymbol) simpleSymbol57.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit330 = fString82;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit329 = fString83;
        new SimpleSymbol("Label22");
        Lit328 = (SimpleSymbol) simpleSymbol58.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit327 = fString84;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit326 = fString85;
        new SimpleSymbol("Label21");
        Lit324 = (SimpleSymbol) simpleSymbol59.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit323 = fString86;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit322 = fString87;
        new SimpleSymbol("Vertical_Arrangement4");
        Lit321 = (SimpleSymbol) simpleSymbol60.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit320 = fString88;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit319 = fString89;
        new SimpleSymbol("Space25");
        Lit317 = (SimpleSymbol) simpleSymbol61.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit316 = fString90;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit315 = fString91;
        new SimpleSymbol("Label20_copy");
        Lit313 = (SimpleSymbol) simpleSymbol62.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit312 = fString92;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit311 = fString93;
        int[] iArr9 = new int[2];
        iArr9[0] = -5138;
        Lit310 = IntNum.make(iArr9);
        new SimpleSymbol("Horizontal_Arrangement12");
        Lit309 = (SimpleSymbol) simpleSymbol63.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit308 = fString94;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit307 = fString95;
        new SimpleSymbol("Space23");
        Lit305 = (SimpleSymbol) simpleSymbol64.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit304 = fString96;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit303 = fString97;
        new SimpleSymbol("Label19");
        Lit301 = (SimpleSymbol) simpleSymbol65.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit300 = fString98;
        new FString("com.google.appinventor.components.runtime.VerticalScrollArrangement");
        Lit299 = fString99;
        new FString("com.google.appinventor.components.runtime.VerticalScrollArrangement");
        Lit298 = fString100;
        new FString("com.google.appinventor.components.runtime.MakeroidViewFlipper");
        Lit297 = fString101;
        new FString("com.google.appinventor.components.runtime.MakeroidViewFlipper");
        Lit296 = fString102;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit295 = fString103;
        new SimpleSymbol("Space18_copy_copy");
        Lit293 = (SimpleSymbol) simpleSymbol66.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit292 = fString104;
        new SimpleSymbol("Label14_copy_copy$Click");
        Lit291 = (SimpleSymbol) simpleSymbol67.readResolve();
        new SimpleSymbol("ShowNext");
        Lit290 = (SimpleSymbol) simpleSymbol68.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit288 = fString105;
        int[] iArr10 = new int[2];
        iArr10[0] = -5138;
        Lit287 = IntNum.make(iArr10);
        new SimpleSymbol("Label14_copy_copy");
        Lit286 = (SimpleSymbol) simpleSymbol69.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit285 = fString106;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit284 = fString107;
        int[] iArr11 = new int[2];
        iArr11[0] = -769226;
        Lit282 = IntNum.make(iArr11);
        new SimpleSymbol("Horizontal_Arrangement11_copy_copy");
        Lit281 = (SimpleSymbol) simpleSymbol70.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit280 = fString108;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit279 = fString109;
        new SimpleSymbol("Space9_copy_copy");
        Lit277 = (SimpleSymbol) simpleSymbol71.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit276 = fString110;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit275 = fString111;
        new SimpleSymbol("Picture");
        Lit274 = (SimpleSymbol) simpleSymbol72.readResolve();
        new SimpleSymbol("Image2_copy_copy");
        Lit271 = (SimpleSymbol) simpleSymbol73.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit270 = fString112;
        new SimpleSymbol("Label9_copy_copy$Click");
        Lit269 = (SimpleSymbol) simpleSymbol74.readResolve();
        new SimpleSymbol("DismissCustomDialog");
        Lit268 = (SimpleSymbol) simpleSymbol75.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit267 = fString113;
        new SimpleSymbol("Label9_copy_copy");
        Lit265 = (SimpleSymbol) simpleSymbol76.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit264 = fString114;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit263 = fString115;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit262 = fString116;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit261 = fString117;
        new SimpleSymbol("Space6");
        Lit259 = (SimpleSymbol) simpleSymbol77.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit258 = fString118;
        new SimpleSymbol("Label26$Click");
        Lit257 = (SimpleSymbol) simpleSymbol78.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit255 = fString119;
        new SimpleSymbol("Label26");
        Lit254 = (SimpleSymbol) simpleSymbol79.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit253 = fString120;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit252 = fString121;
        int[] iArr12 = new int[2];
        iArr12[0] = -5138;
        Lit250 = IntNum.make(iArr12);
        new SimpleSymbol("Horizontal_Arrangement14");
        Lit249 = (SimpleSymbol) simpleSymbol80.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit248 = fString122;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit247 = fString123;
        new SimpleSymbol("Space26");
        Lit245 = (SimpleSymbol) simpleSymbol81.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit244 = fString124;
        new SimpleSymbol("Label30$Click");
        Lit243 = (SimpleSymbol) simpleSymbol82.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit242 = fString125;
        int[] iArr13 = new int[2];
        iArr13[0] = -5138;
        Lit241 = IntNum.make(iArr13);
        new SimpleSymbol("Label30");
        Lit240 = (SimpleSymbol) simpleSymbol83.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit239 = fString126;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit238 = fString127;
        int[] iArr14 = new int[2];
        iArr14[0] = -769226;
        Lit237 = IntNum.make(iArr14);
        new SimpleSymbol("Horizontal_Arrangement17");
        Lit236 = (SimpleSymbol) simpleSymbol84.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit235 = fString128;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit234 = fString129;
        new SimpleSymbol("Space33");
        Lit232 = (SimpleSymbol) simpleSymbol85.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit231 = fString130;
        new SimpleSymbol("Label29$Click");
        Lit230 = (SimpleSymbol) simpleSymbol86.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit229 = fString131;
        int[] iArr15 = new int[2];
        iArr15[0] = -5138;
        Lit228 = IntNum.make(iArr15);
        new SimpleSymbol("Label29");
        Lit227 = (SimpleSymbol) simpleSymbol87.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit226 = fString132;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit225 = fString133;
        int[] iArr16 = new int[2];
        iArr16[0] = -769226;
        Lit224 = IntNum.make(iArr16);
        new SimpleSymbol("Horizontal_Arrangement16");
        Lit223 = (SimpleSymbol) simpleSymbol88.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit222 = fString134;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit221 = fString135;
        int[] iArr17 = new int[2];
        iArr17[0] = -1;
        Lit220 = IntNum.make(iArr17);
        new SimpleSymbol("Horizontal_Arrangement15");
        Lit219 = (SimpleSymbol) simpleSymbol89.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit218 = fString136;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit217 = fString137;
        new SimpleSymbol("Space34");
        Lit215 = (SimpleSymbol) simpleSymbol90.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit214 = fString138;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit213 = fString139;
        new SimpleSymbol("Label31");
        Lit211 = (SimpleSymbol) simpleSymbol91.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit210 = fString140;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit209 = fString141;
        int[] iArr18 = new int[2];
        iArr18[0] = -5138;
        Lit208 = IntNum.make(iArr18);
        new SimpleSymbol("Vertical_Arrangement6");
        Lit207 = (SimpleSymbol) simpleSymbol92.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit206 = fString142;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit205 = fString143;
        new SimpleSymbol("Space31");
        Lit203 = (SimpleSymbol) simpleSymbol93.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit202 = fString144;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit201 = fString145;
        new SimpleSymbol("Space15");
        Lit199 = (SimpleSymbol) simpleSymbol94.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit198 = fString146;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit197 = fString147;
        new SimpleSymbol("Label12_copy");
        Lit195 = (SimpleSymbol) simpleSymbol95.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit194 = fString148;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit193 = fString149;
        new SimpleSymbol("Space16_copy");
        Lit191 = (SimpleSymbol) simpleSymbol96.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit190 = fString150;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit189 = fString151;
        new SimpleSymbol("Label11_copy");
        Lit188 = (SimpleSymbol) simpleSymbol97.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit187 = fString152;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit186 = fString153;
        new SimpleSymbol("Horizontal_Arrangement10_copy");
        Lit185 = (SimpleSymbol) simpleSymbol98.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit184 = fString154;
        new SimpleSymbol("Horizontal_Arrangement9$Click");
        Lit183 = (SimpleSymbol) simpleSymbol99.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit181 = fString155;
        int[] iArr19 = new int[2];
        iArr19[0] = -5138;
        Lit178 = IntNum.make(iArr19);
        new SimpleSymbol("Horizontal_Arrangement9");
        Lit177 = (SimpleSymbol) simpleSymbol100.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit176 = fString156;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit175 = fString157;
        new SimpleSymbol("Space5");
        Lit173 = (SimpleSymbol) simpleSymbol101.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit172 = fString158;
        new SimpleSymbol("Horizontal_Arrangement8$Click");
        Lit171 = (SimpleSymbol) simpleSymbol102.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit169 = fString159;
        int[] iArr20 = new int[2];
        iArr20[0] = -5138;
        Lit166 = IntNum.make(iArr20);
        new SimpleSymbol("Horizontal_Arrangement8");
        Lit165 = (SimpleSymbol) simpleSymbol103.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit164 = fString160;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit163 = fString161;
        new SimpleSymbol("Horizontal_Arrangement5");
        Lit162 = (SimpleSymbol) simpleSymbol104.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit161 = fString162;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit160 = fString163;
        new SimpleSymbol("Space7");
        Lit158 = (SimpleSymbol) simpleSymbol105.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit157 = fString164;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit156 = fString165;
        new SimpleSymbol("Label12");
        Lit154 = (SimpleSymbol) simpleSymbol106.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit153 = fString166;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit152 = fString167;
        new SimpleSymbol("Space16");
        Lit150 = (SimpleSymbol) simpleSymbol107.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit149 = fString168;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit148 = fString169;
        new SimpleSymbol("Label11");
        Lit147 = (SimpleSymbol) simpleSymbol108.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit146 = fString170;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit145 = fString171;
        new SimpleSymbol("Label32");
        Lit144 = (SimpleSymbol) simpleSymbol109.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit143 = fString172;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit142 = fString173;
        new SimpleSymbol("Horizontal_Arrangement10");
        Lit141 = (SimpleSymbol) simpleSymbol110.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit140 = fString174;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit139 = fString175;
        new SimpleSymbol("Space17");
        Lit137 = (SimpleSymbol) simpleSymbol111.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit136 = fString176;
        new SimpleSymbol("Horizontal_Arrangement7$Click");
        Lit135 = (SimpleSymbol) simpleSymbol112.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit133 = fString177;
        int[] iArr21 = new int[2];
        iArr21[0] = -5138;
        Lit130 = IntNum.make(iArr21);
        new SimpleSymbol("Horizontal_Arrangement7");
        Lit129 = (SimpleSymbol) simpleSymbol113.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit128 = fString178;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit127 = fString179;
        new SimpleSymbol("Space4");
        Lit125 = (SimpleSymbol) simpleSymbol114.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit124 = fString180;
        new SimpleSymbol("Click");
        Lit123 = (SimpleSymbol) simpleSymbol115.readResolve();
        new SimpleSymbol("Horizontal_Arrangement6$Click");
        Lit122 = (SimpleSymbol) simpleSymbol116.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit120 = fString181;
        new SimpleSymbol("Image");
        Lit119 = (SimpleSymbol) simpleSymbol117.readResolve();
        new SimpleSymbol("Clickable");
        Lit116 = (SimpleSymbol) simpleSymbol118.readResolve();
        int[] iArr22 = new int[2];
        iArr22[0] = -5138;
        Lit115 = IntNum.make(iArr22);
        new SimpleSymbol("Horizontal_Arrangement6");
        Lit114 = (SimpleSymbol) simpleSymbol119.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit113 = fString182;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit112 = fString183;
        new SimpleSymbol("Horizontal_Arrangement4");
        Lit111 = (SimpleSymbol) simpleSymbol120.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit110 = fString184;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit109 = fString185;
        new SimpleSymbol("Space14");
        Lit107 = (SimpleSymbol) simpleSymbol121.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit106 = fString186;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit105 = fString187;
        int[] iArr23 = new int[2];
        iArr23[0] = -5138;
        Lit104 = IntNum.make(iArr23);
        new SimpleSymbol("Vertical_Arrangement1");
        Lit103 = (SimpleSymbol) simpleSymbol122.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit102 = fString188;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit101 = fString189;
        new SimpleSymbol("Space8");
        Lit99 = (SimpleSymbol) simpleSymbol123.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit98 = fString190;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit97 = fString191;
        int[] iArr24 = new int[2];
        iArr24[0] = -5138;
        Lit96 = IntNum.make(iArr24);
        new SimpleSymbol("TextColor");
        Lit95 = (SimpleSymbol) simpleSymbol124.readResolve();
        new SimpleSymbol("Label2");
        Lit93 = (SimpleSymbol) simpleSymbol125.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit92 = fString192;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit91 = fString193;
        new SimpleSymbol("UseRoundCard");
        Lit90 = (SimpleSymbol) simpleSymbol126.readResolve();
        int[] iArr25 = new int[2];
        iArr25[0] = -769226;
        Lit89 = IntNum.make(iArr25);
        new SimpleSymbol("Horizontal_Arrangement3");
        Lit88 = (SimpleSymbol) simpleSymbol127.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit87 = fString194;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit86 = fString195;
        new SimpleSymbol("Space3");
        Lit84 = (SimpleSymbol) simpleSymbol128.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit83 = fString196;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit82 = fString197;
        new SimpleSymbol("TextAlignment");
        Lit81 = (SimpleSymbol) simpleSymbol129.readResolve();
        new SimpleSymbol("Text");
        Lit80 = (SimpleSymbol) simpleSymbol130.readResolve();
        new SimpleSymbol("FontTypefaceImport");
        Lit79 = (SimpleSymbol) simpleSymbol131.readResolve();
        new SimpleSymbol("FontSize");
        Lit77 = (SimpleSymbol) simpleSymbol132.readResolve();
        new SimpleSymbol("Label1");
        Lit76 = (SimpleSymbol) simpleSymbol133.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit75 = fString198;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit74 = fString199;
        new SimpleSymbol("isCard");
        Lit73 = (SimpleSymbol) simpleSymbol134.readResolve();
        new SimpleSymbol("Width");
        Lit71 = (SimpleSymbol) simpleSymbol135.readResolve();
        new SimpleSymbol("Height");
        Lit69 = (SimpleSymbol) simpleSymbol136.readResolve();
        int[] iArr26 = new int[2];
        iArr26[0] = -5138;
        Lit68 = IntNum.make(iArr26);
        new SimpleSymbol("BackgroundColor");
        Lit67 = (SimpleSymbol) simpleSymbol137.readResolve();
        new SimpleSymbol("Horizontal_Arrangement1");
        Lit66 = (SimpleSymbol) simpleSymbol138.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit65 = fString200;
        new SimpleSymbol("BackPressed");
        Lit64 = (SimpleSymbol) simpleSymbol139.readResolve();
        new SimpleSymbol("home$BackPressed");
        Lit63 = (SimpleSymbol) simpleSymbol140.readResolve();
        new SimpleSymbol("Initialize");
        Lit62 = (SimpleSymbol) simpleSymbol141.readResolve();
        new SimpleSymbol("home$Initialize");
        Lit61 = (SimpleSymbol) simpleSymbol142.readResolve();
        new SimpleSymbol("Label28");
        Lit60 = (SimpleSymbol) simpleSymbol143.readResolve();
        new SimpleSymbol("Label27");
        Lit59 = (SimpleSymbol) simpleSymbol144.readResolve();
        new SimpleSymbol("Label23_copy");
        Lit58 = (SimpleSymbol) simpleSymbol145.readResolve();
        new SimpleSymbol("component");
        Lit57 = (SimpleSymbol) simpleSymbol146.readResolve();
        new SimpleSymbol("Label23");
        Lit56 = (SimpleSymbol) simpleSymbol147.readResolve();
        new SimpleSymbol("Create");
        Lit55 = (SimpleSymbol) simpleSymbol148.readResolve();
        new SimpleSymbol("HiperLinks");
        Lit54 = (SimpleSymbol) simpleSymbol149.readResolve();
        new SimpleSymbol("HiperLinks1");
        Lit53 = (SimpleSymbol) simpleSymbol150.readResolve();
        SimpleSymbol simpleSymbol188 = Lit57;
        SimpleSymbol simpleSymbol189 = Lit22;
        SimpleSymbol simpleSymbol190 = Lit22;
        SimpleSymbol simpleSymbol191 = Lit22;
        new SimpleSymbol("boolean");
        SimpleSymbol simpleSymbol192 = (SimpleSymbol) simpleSymbol151.readResolve();
        Lit30 = simpleSymbol192;
        Lit52 = PairWithPosition.make(simpleSymbol188, PairWithPosition.make(simpleSymbol189, PairWithPosition.make(simpleSymbol190, PairWithPosition.make(simpleSymbol191, PairWithPosition.make(simpleSymbol192, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107513), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107508), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107503), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107498), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/home.yail", 107487);
        new SimpleSymbol("Vertical_Arrangement_symptoms_copy_copy");
        Lit50 = (SimpleSymbol) simpleSymbol152.readResolve();
        new SimpleSymbol("CreateCustomDialog");
        Lit49 = (SimpleSymbol) simpleSymbol153.readResolve();
        new SimpleSymbol("Notifier3");
        Lit48 = (SimpleSymbol) simpleSymbol154.readResolve();
        new SimpleSymbol("Vertical_Scroll_Arrangement3_copy");
        Lit46 = (SimpleSymbol) simpleSymbol155.readResolve();
        new SimpleSymbol("Vertical_Scroll_Arrangement3");
        Lit44 = (SimpleSymbol) simpleSymbol156.readResolve();
        new SimpleSymbol("AddComponentToView");
        Lit43 = (SimpleSymbol) simpleSymbol157.readResolve();
        new SimpleSymbol("View_Flipper1_copy_copy");
        Lit42 = (SimpleSymbol) simpleSymbol158.readResolve();
        new SimpleSymbol("StoreValue");
        Lit40 = (SimpleSymbol) simpleSymbol159.readResolve();
        new SimpleSymbol("GoogleSignIn");
        Lit39 = (SimpleSymbol) simpleSymbol160.readResolve();
        new SimpleSymbol("Firebase_Authentication1");
        Lit38 = (SimpleSymbol) simpleSymbol161.readResolve();
        new SimpleSymbol("GetValue");
        Lit34 = (SimpleSymbol) simpleSymbol162.readResolve();
        new SimpleSymbol("Tiny_DB1");
        Lit33 = (SimpleSymbol) simpleSymbol163.readResolve();
        new SimpleSymbol("TitleVisible");
        Lit32 = (SimpleSymbol) simpleSymbol164.readResolve();
        new SimpleSymbol("Title");
        Lit31 = (SimpleSymbol) simpleSymbol165.readResolve();
        new SimpleSymbol("Scrollable");
        Lit29 = (SimpleSymbol) simpleSymbol166.readResolve();
        new SimpleSymbol("ReceiveSharedText");
        Lit28 = (SimpleSymbol) simpleSymbol167.readResolve();
        int[] iArr27 = new int[2];
        iArr27[0] = -769226;
        Lit27 = IntNum.make(iArr27);
        new SimpleSymbol("PrimaryColorDark");
        Lit26 = (SimpleSymbol) simpleSymbol168.readResolve();
        int[] iArr28 = new int[2];
        iArr28[0] = -769226;
        Lit25 = IntNum.make(iArr28);
        new SimpleSymbol("PrimaryColor");
        Lit24 = (SimpleSymbol) simpleSymbol169.readResolve();
        new SimpleSymbol("AppName");
        Lit23 = (SimpleSymbol) simpleSymbol170.readResolve();
        new SimpleSymbol("AppId");
        Lit21 = (SimpleSymbol) simpleSymbol171.readResolve();
        new SimpleSymbol("AlignVertical");
        Lit19 = (SimpleSymbol) simpleSymbol172.readResolve();
        new SimpleSymbol("AlignHorizontal");
        Lit17 = (SimpleSymbol) simpleSymbol173.readResolve();
        new SimpleSymbol("number");
        Lit16 = (SimpleSymbol) simpleSymbol174.readResolve();
        int[] iArr29 = new int[2];
        iArr29[0] = -769226;
        Lit15 = IntNum.make(iArr29);
        new SimpleSymbol("AccentColor");
        Lit14 = (SimpleSymbol) simpleSymbol175.readResolve();
        new SimpleSymbol("ShowCustomDialog");
        Lit12 = (SimpleSymbol) simpleSymbol176.readResolve();
        new SimpleSymbol("Notifier6");
        Lit11 = (SimpleSymbol) simpleSymbol177.readResolve();
        new SimpleSymbol("VERTICAL");
        Lit9 = (SimpleSymbol) simpleSymbol178.readResolve();
        new SimpleSymbol("Vertical_Arrangement7");
        Lit8 = (SimpleSymbol) simpleSymbol179.readResolve();
        new SimpleSymbol("PDF_Load_From_Assest");
        Lit7 = (SimpleSymbol) simpleSymbol180.readResolve();
        new SimpleSymbol("InApp_PDFViewer4");
        Lit6 = (SimpleSymbol) simpleSymbol181.readResolve();
        new SimpleSymbol("p$procedure");
        Lit5 = (SimpleSymbol) simpleSymbol182.readResolve();
        new SimpleSymbol("g$signin");
        Lit3 = (SimpleSymbol) simpleSymbol183.readResolve();
        new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol184.readResolve();
        new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol185.readResolve();
        new SimpleSymbol("home");
        Lit0 = (SimpleSymbol) simpleSymbol186.readResolve();
    }

    public home() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleMethod moduleMethod29;
        ModuleMethod moduleMethod30;
        ModuleMethod moduleMethod31;
        ModuleMethod moduleMethod32;
        ModuleMethod moduleMethod33;
        ModuleMethod moduleMethod34;
        ModuleMethod moduleMethod35;
        ModuleMethod moduleMethod36;
        ModuleMethod moduleMethod37;
        ModuleMethod moduleMethod38;
        ModuleMethod moduleMethod39;
        ModuleMethod moduleMethod40;
        ModuleMethod moduleMethod41;
        ModuleMethod moduleMethod42;
        ModuleMethod moduleMethod43;
        ModuleMethod moduleMethod44;
        ModuleMethod moduleMethod45;
        ModuleMethod moduleMethod46;
        ModuleMethod moduleMethod47;
        ModuleMethod moduleMethod48;
        ModuleMethod moduleMethod49;
        ModuleMethod moduleMethod50;
        ModuleMethod moduleMethod51;
        ModuleMethod moduleMethod52;
        ModuleMethod moduleMethod53;
        ModuleMethod moduleMethod54;
        ModuleMethod moduleMethod55;
        ModuleMethod moduleMethod56;
        ModuleMethod moduleMethod57;
        ModuleMethod moduleMethod58;
        ModuleMethod moduleMethod59;
        ModuleMethod moduleMethod60;
        ModuleMethod moduleMethod61;
        ModuleMethod moduleMethod62;
        ModuleMethod moduleMethod63;
        ModuleMethod moduleMethod64;
        ModuleMethod moduleMethod65;
        ModuleMethod moduleMethod66;
        ModuleMethod moduleMethod67;
        ModuleMethod moduleMethod68;
        ModuleMethod moduleMethod69;
        ModuleMethod moduleMethod70;
        ModuleMethod moduleMethod71;
        ModuleMethod moduleMethod72;
        ModuleMethod moduleMethod73;
        ModuleMethod moduleMethod74;
        ModuleMethod moduleMethod75;
        ModuleMethod moduleMethod76;
        ModuleMethod moduleMethod77;
        ModuleMethod moduleMethod78;
        ModuleMethod moduleMethod79;
        ModuleMethod moduleMethod80;
        ModuleMethod moduleMethod81;
        ModuleMethod moduleMethod82;
        ModuleMethod moduleMethod83;
        ModuleMethod moduleMethod84;
        ModuleMethod moduleMethod85;
        ModuleMethod moduleMethod86;
        ModuleMethod moduleMethod87;
        ModuleMethod moduleMethod88;
        ModuleMethod moduleMethod89;
        ModuleMethod moduleMethod90;
        ModuleMethod moduleMethod91;
        ModuleMethod moduleMethod92;
        ModuleMethod moduleMethod93;
        ModuleMethod moduleMethod94;
        ModuleMethod moduleMethod95;
        ModuleMethod moduleMethod96;
        ModuleMethod moduleMethod97;
        ModuleMethod moduleMethod98;
        ModuleMethod moduleMethod99;
        ModuleMethod moduleMethod100;
        ModuleMethod moduleMethod101;
        ModuleMethod moduleMethod102;
        ModuleMethod moduleMethod103;
        ModuleMethod moduleMethod104;
        ModuleMethod moduleMethod105;
        ModuleMethod moduleMethod106;
        ModuleMethod moduleMethod107;
        ModuleMethod moduleMethod108;
        ModuleMethod moduleMethod109;
        ModuleMethod moduleMethod110;
        ModuleMethod moduleMethod111;
        ModuleMethod moduleMethod112;
        ModuleMethod moduleMethod113;
        ModuleMethod moduleMethod114;
        ModuleMethod moduleMethod115;
        ModuleMethod moduleMethod116;
        ModuleMethod moduleMethod117;
        ModuleMethod moduleMethod118;
        ModuleMethod moduleMethod119;
        ModuleMethod moduleMethod120;
        ModuleMethod moduleMethod121;
        ModuleMethod moduleMethod122;
        ModuleMethod moduleMethod123;
        ModuleMethod moduleMethod124;
        ModuleMethod moduleMethod125;
        ModuleMethod moduleMethod126;
        ModuleMethod moduleMethod127;
        ModuleMethod moduleMethod128;
        ModuleMethod moduleMethod129;
        ModuleMethod moduleMethod130;
        ModuleMethod moduleMethod131;
        ModuleMethod moduleMethod132;
        ModuleMethod moduleMethod133;
        ModuleMethod moduleMethod134;
        ModuleMethod moduleMethod135;
        ModuleMethod moduleMethod136;
        ModuleMethod moduleMethod137;
        ModuleMethod moduleMethod138;
        ModuleMethod moduleMethod139;
        ModuleMethod moduleMethod140;
        ModuleMethod moduleMethod141;
        ModuleMethod moduleMethod142;
        ModuleMethod moduleMethod143;
        ModuleMethod moduleMethod144;
        ModuleMethod moduleMethod145;
        ModuleMethod moduleMethod146;
        ModuleMethod moduleMethod147;
        ModuleMethod moduleMethod148;
        ModuleMethod moduleMethod149;
        ModuleMethod moduleMethod150;
        ModuleMethod moduleMethod151;
        ModuleMethod moduleMethod152;
        ModuleMethod moduleMethod153;
        ModuleMethod moduleMethod154;
        ModuleMethod moduleMethod155;
        ModuleMethod moduleMethod156;
        ModuleMethod moduleMethod157;
        ModuleMethod moduleMethod158;
        ModuleMethod moduleMethod159;
        ModuleMethod moduleMethod160;
        ModuleMethod moduleMethod161;
        ModuleMethod moduleMethod162;
        ModuleMethod moduleMethod163;
        ModuleMethod moduleMethod164;
        ModuleMethod moduleMethod165;
        ModuleMethod moduleMethod166;
        ModuleMethod moduleMethod167;
        ModuleMethod moduleMethod168;
        ModuleMethod moduleMethod169;
        ModuleMethod moduleMethod170;
        ModuleMethod moduleMethod171;
        ModuleMethod moduleMethod172;
        ModuleMethod moduleMethod173;
        ModuleMethod moduleMethod174;
        ModuleMethod moduleMethod175;
        ModuleMethod moduleMethod176;
        ModuleMethod moduleMethod177;
        ModuleMethod moduleMethod178;
        ModuleMethod moduleMethod179;
        ModuleMethod moduleMethod180;
        ModuleMethod moduleMethod181;
        ModuleMethod moduleMethod182;
        ModuleMethod moduleMethod183;
        ModuleMethod moduleMethod184;
        ModuleMethod moduleMethod185;
        ModuleMethod moduleMethod186;
        ModuleMethod moduleMethod187;
        ModuleMethod moduleMethod188;
        ModuleMethod moduleMethod189;
        ModuleMethod moduleMethod190;
        ModuleMethod moduleMethod191;
        ModuleMethod moduleMethod192;
        ModuleMethod moduleMethod193;
        ModuleMethod moduleMethod194;
        ModuleMethod moduleMethod195;
        ModuleMethod moduleMethod196;
        ModuleMethod moduleMethod197;
        ModuleMethod moduleMethod198;
        ModuleMethod moduleMethod199;
        ModuleMethod moduleMethod200;
        ModuleMethod moduleMethod201;
        ModuleMethod moduleMethod202;
        ModuleMethod moduleMethod203;
        ModuleMethod moduleMethod204;
        ModuleMethod moduleMethod205;
        ModuleMethod moduleMethod206;
        ModuleMethod moduleMethod207;
        ModuleMethod moduleMethod208;
        ModuleMethod moduleMethod209;
        ModuleMethod moduleMethod210;
        ModuleMethod moduleMethod211;
        ModuleMethod moduleMethod212;
        ModuleMethod moduleMethod213;
        ModuleMethod moduleMethod214;
        ModuleMethod moduleMethod215;
        ModuleMethod moduleMethod216;
        ModuleMethod moduleMethod217;
        ModuleMethod moduleMethod218;
        ModuleMethod moduleMethod219;
        ModuleMethod moduleMethod220;
        ModuleMethod moduleMethod221;
        ModuleMethod moduleMethod222;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod223 = moduleMethod;
        new frame();
        frame frame3 = frame2;
        frame3.$main = this;
        frame frame4 = frame3;
        new ModuleMethod(frame4, 1, Lit477, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod223;
        new ModuleMethod(frame4, 2, Lit478, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod2;
        new ModuleMethod(frame4, 3, Lit479, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod3;
        new ModuleMethod(frame4, 4, Lit480, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod4;
        new ModuleMethod(frame4, 6, Lit481, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod5;
        new ModuleMethod(frame4, 7, Lit482, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod6;
        new ModuleMethod(frame4, 8, Lit483, 8194);
        this.add$Mnto$Mnevents = moduleMethod7;
        new ModuleMethod(frame4, 9, Lit484, 16388);
        this.add$Mnto$Mncomponents = moduleMethod8;
        new ModuleMethod(frame4, 10, Lit485, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod9;
        new ModuleMethod(frame4, 11, Lit486, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod10;
        new ModuleMethod(frame4, 12, Lit487, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod11;
        new ModuleMethod(frame4, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod12;
        new ModuleMethod(frame4, 14, Lit488, 16388);
        this.dispatchEvent = moduleMethod13;
        new ModuleMethod(frame4, 15, Lit489, 16388);
        this.dispatchGenericEvent = moduleMethod14;
        new ModuleMethod(frame4, 16, Lit490, 8194);
        this.lookup$Mnhandler = moduleMethod15;
        new ModuleMethod(frame4, 17, (Object) null, 0);
        ModuleMethod moduleMethod224 = moduleMethod16;
        moduleMethod224.setProperty("source-location", "/tmp/runtime7522387041397852836.scm:615");
        lambda$Fn1 = moduleMethod224;
        new ModuleMethod(frame4, 18, "$define", 0);
        this.$define = moduleMethod17;
        new ModuleMethod(frame4, 19, (Object) null, 0);
        lambda$Fn2 = moduleMethod18;
        new ModuleMethod(frame4, 20, (Object) null, 0);
        lambda$Fn3 = moduleMethod19;
        new ModuleMethod(frame4, 21, (Object) null, 0);
        lambda$Fn5 = moduleMethod20;
        new ModuleMethod(frame4, 22, (Object) null, 0);
        lambda$Fn4 = moduleMethod21;
        new ModuleMethod(frame4, 23, (Object) null, 0);
        lambda$Fn6 = moduleMethod22;
        new ModuleMethod(frame4, 24, Lit61, 0);
        this.home$Initialize = moduleMethod23;
        new ModuleMethod(frame4, 25, Lit63, 0);
        this.home$BackPressed = moduleMethod24;
        new ModuleMethod(frame4, 26, (Object) null, 0);
        lambda$Fn7 = moduleMethod25;
        new ModuleMethod(frame4, 27, (Object) null, 0);
        lambda$Fn8 = moduleMethod26;
        new ModuleMethod(frame4, 28, (Object) null, 0);
        lambda$Fn9 = moduleMethod27;
        new ModuleMethod(frame4, 29, (Object) null, 0);
        lambda$Fn10 = moduleMethod28;
        new ModuleMethod(frame4, 30, (Object) null, 0);
        lambda$Fn11 = moduleMethod29;
        new ModuleMethod(frame4, 31, (Object) null, 0);
        lambda$Fn12 = moduleMethod30;
        new ModuleMethod(frame4, 32, (Object) null, 0);
        lambda$Fn13 = moduleMethod31;
        new ModuleMethod(frame4, 33, (Object) null, 0);
        lambda$Fn14 = moduleMethod32;
        new ModuleMethod(frame4, 34, (Object) null, 0);
        lambda$Fn15 = moduleMethod33;
        new ModuleMethod(frame4, 35, (Object) null, 0);
        lambda$Fn16 = moduleMethod34;
        new ModuleMethod(frame4, 36, (Object) null, 0);
        lambda$Fn17 = moduleMethod35;
        new ModuleMethod(frame4, 37, (Object) null, 0);
        lambda$Fn18 = moduleMethod36;
        new ModuleMethod(frame4, 38, (Object) null, 0);
        lambda$Fn19 = moduleMethod37;
        new ModuleMethod(frame4, 39, (Object) null, 0);
        lambda$Fn20 = moduleMethod38;
        new ModuleMethod(frame4, 40, (Object) null, 0);
        lambda$Fn21 = moduleMethod39;
        new ModuleMethod(frame4, 41, (Object) null, 0);
        lambda$Fn22 = moduleMethod40;
        new ModuleMethod(frame4, 42, (Object) null, 0);
        lambda$Fn23 = moduleMethod41;
        new ModuleMethod(frame4, 43, (Object) null, 0);
        lambda$Fn24 = moduleMethod42;
        new ModuleMethod(frame4, 44, (Object) null, 0);
        lambda$Fn25 = moduleMethod43;
        new ModuleMethod(frame4, 45, (Object) null, 0);
        lambda$Fn26 = moduleMethod44;
        new ModuleMethod(frame4, 46, Lit122, 0);
        this.Horizontal_Arrangement6$Click = moduleMethod45;
        new ModuleMethod(frame4, 47, (Object) null, 0);
        lambda$Fn27 = moduleMethod46;
        new ModuleMethod(frame4, 48, (Object) null, 0);
        lambda$Fn28 = moduleMethod47;
        new ModuleMethod(frame4, 49, (Object) null, 0);
        lambda$Fn29 = moduleMethod48;
        new ModuleMethod(frame4, 50, (Object) null, 0);
        lambda$Fn30 = moduleMethod49;
        new ModuleMethod(frame4, 51, Lit135, 0);
        this.Horizontal_Arrangement7$Click = moduleMethod50;
        new ModuleMethod(frame4, 52, (Object) null, 0);
        lambda$Fn31 = moduleMethod51;
        new ModuleMethod(frame4, 53, (Object) null, 0);
        lambda$Fn32 = moduleMethod52;
        new ModuleMethod(frame4, 54, (Object) null, 0);
        lambda$Fn33 = moduleMethod53;
        new ModuleMethod(frame4, 55, (Object) null, 0);
        lambda$Fn34 = moduleMethod54;
        new ModuleMethod(frame4, 56, (Object) null, 0);
        lambda$Fn35 = moduleMethod55;
        new ModuleMethod(frame4, 57, (Object) null, 0);
        lambda$Fn36 = moduleMethod56;
        new ModuleMethod(frame4, 58, (Object) null, 0);
        lambda$Fn37 = moduleMethod57;
        new ModuleMethod(frame4, 59, (Object) null, 0);
        lambda$Fn38 = moduleMethod58;
        new ModuleMethod(frame4, 60, (Object) null, 0);
        lambda$Fn39 = moduleMethod59;
        new ModuleMethod(frame4, 61, (Object) null, 0);
        lambda$Fn40 = moduleMethod60;
        new ModuleMethod(frame4, 62, (Object) null, 0);
        lambda$Fn41 = moduleMethod61;
        new ModuleMethod(frame4, 63, (Object) null, 0);
        lambda$Fn42 = moduleMethod62;
        new ModuleMethod(frame4, 64, (Object) null, 0);
        lambda$Fn43 = moduleMethod63;
        new ModuleMethod(frame4, 65, (Object) null, 0);
        lambda$Fn44 = moduleMethod64;
        new ModuleMethod(frame4, 66, (Object) null, 0);
        lambda$Fn45 = moduleMethod65;
        new ModuleMethod(frame4, 67, (Object) null, 0);
        lambda$Fn46 = moduleMethod66;
        new ModuleMethod(frame4, 68, (Object) null, 0);
        lambda$Fn47 = moduleMethod67;
        new ModuleMethod(frame4, 69, (Object) null, 0);
        lambda$Fn48 = moduleMethod68;
        new ModuleMethod(frame4, 70, Lit171, 0);
        this.Horizontal_Arrangement8$Click = moduleMethod69;
        new ModuleMethod(frame4, 71, (Object) null, 0);
        lambda$Fn49 = moduleMethod70;
        new ModuleMethod(frame4, 72, (Object) null, 0);
        lambda$Fn50 = moduleMethod71;
        new ModuleMethod(frame4, 73, (Object) null, 0);
        lambda$Fn51 = moduleMethod72;
        new ModuleMethod(frame4, 74, (Object) null, 0);
        lambda$Fn52 = moduleMethod73;
        new ModuleMethod(frame4, 75, Lit183, 0);
        this.Horizontal_Arrangement9$Click = moduleMethod74;
        new ModuleMethod(frame4, 76, (Object) null, 0);
        lambda$Fn53 = moduleMethod75;
        new ModuleMethod(frame4, 77, (Object) null, 0);
        lambda$Fn54 = moduleMethod76;
        new ModuleMethod(frame4, 78, (Object) null, 0);
        lambda$Fn55 = moduleMethod77;
        new ModuleMethod(frame4, 79, (Object) null, 0);
        lambda$Fn56 = moduleMethod78;
        new ModuleMethod(frame4, 80, (Object) null, 0);
        lambda$Fn57 = moduleMethod79;
        new ModuleMethod(frame4, 81, (Object) null, 0);
        lambda$Fn58 = moduleMethod80;
        new ModuleMethod(frame4, 82, (Object) null, 0);
        lambda$Fn59 = moduleMethod81;
        new ModuleMethod(frame4, 83, (Object) null, 0);
        lambda$Fn60 = moduleMethod82;
        new ModuleMethod(frame4, 84, (Object) null, 0);
        lambda$Fn61 = moduleMethod83;
        new ModuleMethod(frame4, 85, (Object) null, 0);
        lambda$Fn62 = moduleMethod84;
        new ModuleMethod(frame4, 86, (Object) null, 0);
        lambda$Fn63 = moduleMethod85;
        new ModuleMethod(frame4, 87, (Object) null, 0);
        lambda$Fn64 = moduleMethod86;
        new ModuleMethod(frame4, 88, (Object) null, 0);
        lambda$Fn65 = moduleMethod87;
        new ModuleMethod(frame4, 89, (Object) null, 0);
        lambda$Fn66 = moduleMethod88;
        new ModuleMethod(frame4, 90, (Object) null, 0);
        lambda$Fn67 = moduleMethod89;
        new ModuleMethod(frame4, 91, (Object) null, 0);
        lambda$Fn68 = moduleMethod90;
        new ModuleMethod(frame4, 92, (Object) null, 0);
        lambda$Fn69 = moduleMethod91;
        new ModuleMethod(frame4, 93, (Object) null, 0);
        lambda$Fn70 = moduleMethod92;
        new ModuleMethod(frame4, 94, (Object) null, 0);
        lambda$Fn71 = moduleMethod93;
        new ModuleMethod(frame4, 95, (Object) null, 0);
        lambda$Fn72 = moduleMethod94;
        new ModuleMethod(frame4, 96, (Object) null, 0);
        lambda$Fn73 = moduleMethod95;
        new ModuleMethod(frame4, 97, (Object) null, 0);
        lambda$Fn74 = moduleMethod96;
        new ModuleMethod(frame4, 98, (Object) null, 0);
        lambda$Fn75 = moduleMethod97;
        new ModuleMethod(frame4, 99, (Object) null, 0);
        lambda$Fn76 = moduleMethod98;
        new ModuleMethod(frame4, 100, Lit230, 0);
        this.Label29$Click = moduleMethod99;
        new ModuleMethod(frame4, 101, (Object) null, 0);
        lambda$Fn77 = moduleMethod100;
        new ModuleMethod(frame4, 102, (Object) null, 0);
        lambda$Fn78 = moduleMethod101;
        new ModuleMethod(frame4, 103, (Object) null, 0);
        lambda$Fn79 = moduleMethod102;
        new ModuleMethod(frame4, 104, (Object) null, 0);
        lambda$Fn80 = moduleMethod103;
        new ModuleMethod(frame4, 105, (Object) null, 0);
        lambda$Fn81 = moduleMethod104;
        new ModuleMethod(frame4, 106, (Object) null, 0);
        lambda$Fn82 = moduleMethod105;
        new ModuleMethod(frame4, 107, Lit243, 0);
        this.Label30$Click = moduleMethod106;
        new ModuleMethod(frame4, 108, (Object) null, 0);
        lambda$Fn83 = moduleMethod107;
        new ModuleMethod(frame4, 109, (Object) null, 0);
        lambda$Fn84 = moduleMethod108;
        new ModuleMethod(frame4, 110, (Object) null, 0);
        lambda$Fn85 = moduleMethod109;
        new ModuleMethod(frame4, 111, (Object) null, 0);
        lambda$Fn86 = moduleMethod110;
        new ModuleMethod(frame4, 112, (Object) null, 0);
        lambda$Fn87 = moduleMethod111;
        new ModuleMethod(frame4, 113, (Object) null, 0);
        lambda$Fn88 = moduleMethod112;
        new ModuleMethod(frame4, 114, Lit257, 0);
        this.Label26$Click = moduleMethod113;
        new ModuleMethod(frame4, 115, (Object) null, 0);
        lambda$Fn89 = moduleMethod114;
        new ModuleMethod(frame4, 116, (Object) null, 0);
        lambda$Fn90 = moduleMethod115;
        new ModuleMethod(frame4, 117, (Object) null, 0);
        lambda$Fn91 = moduleMethod116;
        new ModuleMethod(frame4, 118, (Object) null, 0);
        lambda$Fn92 = moduleMethod117;
        new ModuleMethod(frame4, 119, (Object) null, 0);
        lambda$Fn93 = moduleMethod118;
        new ModuleMethod(frame4, 120, (Object) null, 0);
        lambda$Fn94 = moduleMethod119;
        new ModuleMethod(frame4, 121, Lit269, 0);
        this.Label9_copy_copy$Click = moduleMethod120;
        new ModuleMethod(frame4, 122, (Object) null, 0);
        lambda$Fn95 = moduleMethod121;
        new ModuleMethod(frame4, 123, (Object) null, 0);
        lambda$Fn96 = moduleMethod122;
        new ModuleMethod(frame4, 124, (Object) null, 0);
        lambda$Fn97 = moduleMethod123;
        new ModuleMethod(frame4, ErrorLogHelper.MAX_PROPERTY_ITEM_LENGTH, (Object) null, 0);
        lambda$Fn98 = moduleMethod124;
        new ModuleMethod(frame4, 126, (Object) null, 0);
        lambda$Fn99 = moduleMethod125;
        new ModuleMethod(frame4, 127, (Object) null, 0);
        lambda$Fn100 = moduleMethod126;
        new ModuleMethod(frame4, 128, (Object) null, 0);
        lambda$Fn101 = moduleMethod127;
        new ModuleMethod(frame4, 129, (Object) null, 0);
        lambda$Fn102 = moduleMethod128;
        new ModuleMethod(frame4, 130, Lit291, 0);
        this.Label14_copy_copy$Click = moduleMethod129;
        new ModuleMethod(frame4, 131, (Object) null, 0);
        lambda$Fn103 = moduleMethod130;
        new ModuleMethod(frame4, 132, (Object) null, 0);
        lambda$Fn104 = moduleMethod131;
        new ModuleMethod(frame4, 133, (Object) null, 0);
        lambda$Fn105 = moduleMethod132;
        new ModuleMethod(frame4, 134, (Object) null, 0);
        lambda$Fn106 = moduleMethod133;
        new ModuleMethod(frame4, 135, (Object) null, 0);
        lambda$Fn107 = moduleMethod134;
        new ModuleMethod(frame4, 136, (Object) null, 0);
        lambda$Fn108 = moduleMethod135;
        new ModuleMethod(frame4, 137, (Object) null, 0);
        lambda$Fn109 = moduleMethod136;
        new ModuleMethod(frame4, 138, (Object) null, 0);
        lambda$Fn110 = moduleMethod137;
        new ModuleMethod(frame4, 139, (Object) null, 0);
        lambda$Fn111 = moduleMethod138;
        new ModuleMethod(frame4, 140, (Object) null, 0);
        lambda$Fn112 = moduleMethod139;
        new ModuleMethod(frame4, 141, (Object) null, 0);
        lambda$Fn113 = moduleMethod140;
        new ModuleMethod(frame4, 142, (Object) null, 0);
        lambda$Fn114 = moduleMethod141;
        new ModuleMethod(frame4, 143, (Object) null, 0);
        lambda$Fn115 = moduleMethod142;
        new ModuleMethod(frame4, 144, (Object) null, 0);
        lambda$Fn116 = moduleMethod143;
        new ModuleMethod(frame4, 145, (Object) null, 0);
        lambda$Fn117 = moduleMethod144;
        new ModuleMethod(frame4, 146, (Object) null, 0);
        lambda$Fn118 = moduleMethod145;
        new ModuleMethod(frame4, 147, (Object) null, 0);
        lambda$Fn119 = moduleMethod146;
        new ModuleMethod(frame4, 148, (Object) null, 0);
        lambda$Fn120 = moduleMethod147;
        new ModuleMethod(frame4, 149, (Object) null, 0);
        lambda$Fn121 = moduleMethod148;
        new ModuleMethod(frame4, 150, (Object) null, 0);
        lambda$Fn122 = moduleMethod149;
        new ModuleMethod(frame4, 151, (Object) null, 0);
        lambda$Fn123 = moduleMethod150;
        new ModuleMethod(frame4, 152, (Object) null, 0);
        lambda$Fn124 = moduleMethod151;
        new ModuleMethod(frame4, 153, (Object) null, 0);
        lambda$Fn125 = moduleMethod152;
        new ModuleMethod(frame4, 154, (Object) null, 0);
        lambda$Fn126 = moduleMethod153;
        new ModuleMethod(frame4, 155, (Object) null, 0);
        lambda$Fn127 = moduleMethod154;
        new ModuleMethod(frame4, 156, (Object) null, 0);
        lambda$Fn128 = moduleMethod155;
        new ModuleMethod(frame4, 157, (Object) null, 0);
        lambda$Fn129 = moduleMethod156;
        new ModuleMethod(frame4, 158, (Object) null, 0);
        lambda$Fn130 = moduleMethod157;
        new ModuleMethod(frame4, 159, (Object) null, 0);
        lambda$Fn131 = moduleMethod158;
        new ModuleMethod(frame4, ComponentConstants.TEXTBOX_PREFERRED_WIDTH, (Object) null, 0);
        lambda$Fn132 = moduleMethod159;
        new ModuleMethod(frame4, 161, (Object) null, 0);
        lambda$Fn133 = moduleMethod160;
        new ModuleMethod(frame4, 162, (Object) null, 0);
        lambda$Fn134 = moduleMethod161;
        new ModuleMethod(frame4, 163, (Object) null, 0);
        lambda$Fn135 = moduleMethod162;
        new ModuleMethod(frame4, 164, (Object) null, 0);
        lambda$Fn136 = moduleMethod163;
        new ModuleMethod(frame4, 165, Lit354, 0);
        this.Horizontal_Arrangement16_copy$Click = moduleMethod164;
        new ModuleMethod(frame4, 166, (Object) null, 0);
        lambda$Fn137 = moduleMethod165;
        new ModuleMethod(frame4, 167, (Object) null, 0);
        lambda$Fn138 = moduleMethod166;
        new ModuleMethod(frame4, 168, Lit360, 0);
        this.Label29_copy$Click = moduleMethod167;
        new ModuleMethod(frame4, 169, (Object) null, 0);
        lambda$Fn139 = moduleMethod168;
        new ModuleMethod(frame4, 170, (Object) null, 0);
        lambda$Fn140 = moduleMethod169;
        new ModuleMethod(frame4, 171, (Object) null, 0);
        lambda$Fn141 = moduleMethod170;
        new ModuleMethod(frame4, 172, (Object) null, 0);
        lambda$Fn142 = moduleMethod171;
        new ModuleMethod(frame4, 173, (Object) null, 0);
        lambda$Fn143 = moduleMethod172;
        new ModuleMethod(frame4, 174, (Object) null, 0);
        lambda$Fn144 = moduleMethod173;
        new ModuleMethod(frame4, 175, (Object) null, 0);
        lambda$Fn145 = moduleMethod174;
        new ModuleMethod(frame4, 176, (Object) null, 0);
        lambda$Fn146 = moduleMethod175;
        new ModuleMethod(frame4, 177, (Object) null, 0);
        lambda$Fn147 = moduleMethod176;
        new ModuleMethod(frame4, 178, (Object) null, 0);
        lambda$Fn148 = moduleMethod177;
        new ModuleMethod(frame4, 179, (Object) null, 0);
        lambda$Fn149 = moduleMethod178;
        new ModuleMethod(frame4, 180, (Object) null, 0);
        lambda$Fn150 = moduleMethod179;
        new ModuleMethod(frame4, 181, (Object) null, 0);
        lambda$Fn151 = moduleMethod180;
        new ModuleMethod(frame4, 182, (Object) null, 0);
        lambda$Fn152 = moduleMethod181;
        new ModuleMethod(frame4, 183, (Object) null, 0);
        lambda$Fn153 = moduleMethod182;
        new ModuleMethod(frame4, 184, (Object) null, 0);
        lambda$Fn154 = moduleMethod183;
        new ModuleMethod(frame4, 185, (Object) null, 0);
        lambda$Fn155 = moduleMethod184;
        new ModuleMethod(frame4, 186, (Object) null, 0);
        lambda$Fn156 = moduleMethod185;
        new ModuleMethod(frame4, 187, (Object) null, 0);
        lambda$Fn157 = moduleMethod186;
        new ModuleMethod(frame4, 188, (Object) null, 0);
        lambda$Fn158 = moduleMethod187;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_DIALOG_FLAG, (Object) null, 0);
        lambda$Fn159 = moduleMethod188;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SEEK, (Object) null, 0);
        lambda$Fn160 = moduleMethod189;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PLAY, (Object) null, 0);
        lambda$Fn161 = moduleMethod190;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PAUSE, (Object) null, 0);
        lambda$Fn162 = moduleMethod191;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_STOP, (Object) null, 0);
        lambda$Fn163 = moduleMethod192;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SOURCE, (Object) null, 0);
        lambda$Fn164 = moduleMethod193;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_FULLSCREEN, (Object) null, 0);
        lambda$Fn165 = moduleMethod194;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_DURATION, (Object) null, 0);
        lambda$Fn166 = moduleMethod195;
        new ModuleMethod(frame4, 197, (Object) null, 0);
        lambda$Fn167 = moduleMethod196;
        new ModuleMethod(frame4, 198, (Object) null, 0);
        lambda$Fn168 = moduleMethod197;
        new ModuleMethod(frame4, 199, Lit414, 0);
        this.Horizontal_Arrangement16_copy_copy$Click = moduleMethod198;
        new ModuleMethod(frame4, 200, (Object) null, 0);
        lambda$Fn169 = moduleMethod199;
        new ModuleMethod(frame4, 201, (Object) null, 0);
        lambda$Fn170 = moduleMethod200;
        new ModuleMethod(frame4, 202, Lit421, 0);
        this.Label29_copy_copy$Click = moduleMethod201;
        new ModuleMethod(frame4, HttpStatus.SC_NON_AUTHORITATIVE_INFORMATION, (Object) null, 0);
        lambda$Fn171 = moduleMethod202;
        new ModuleMethod(frame4, HttpStatus.SC_NO_CONTENT, (Object) null, 0);
        lambda$Fn172 = moduleMethod203;
        new ModuleMethod(frame4, HttpStatus.SC_RESET_CONTENT, (Object) null, 0);
        lambda$Fn173 = moduleMethod204;
        new ModuleMethod(frame4, HttpStatus.SC_PARTIAL_CONTENT, (Object) null, 0);
        lambda$Fn174 = moduleMethod205;
        new ModuleMethod(frame4, HttpStatus.SC_MULTI_STATUS, Lit429, 0);
        this.Label35$Click = moduleMethod206;
        new ModuleMethod(frame4, 208, (Object) null, 0);
        lambda$Fn175 = moduleMethod207;
        new ModuleMethod(frame4, 209, (Object) null, 0);
        lambda$Fn176 = moduleMethod208;
        new ModuleMethod(frame4, 210, (Object) null, 0);
        lambda$Fn177 = moduleMethod209;
        new ModuleMethod(frame4, 211, (Object) null, 0);
        lambda$Fn178 = moduleMethod210;
        new ModuleMethod(frame4, 212, (Object) null, 0);
        lambda$Fn179 = moduleMethod211;
        new ModuleMethod(frame4, 213, (Object) null, 0);
        lambda$Fn180 = moduleMethod212;
        new ModuleMethod(frame4, 214, (Object) null, 0);
        lambda$Fn181 = moduleMethod213;
        new ModuleMethod(frame4, 215, (Object) null, 0);
        lambda$Fn182 = moduleMethod214;
        new ModuleMethod(frame4, 216, (Object) null, 0);
        lambda$Fn183 = moduleMethod215;
        new ModuleMethod(frame4, 217, (Object) null, 0);
        lambda$Fn184 = moduleMethod216;
        new ModuleMethod(frame4, 218, (Object) null, 0);
        lambda$Fn185 = moduleMethod217;
        new ModuleMethod(frame4, 219, (Object) null, 0);
        lambda$Fn186 = moduleMethod218;
        new ModuleMethod(frame4, 220, (Object) null, 0);
        lambda$Fn187 = moduleMethod219;
        new ModuleMethod(frame4, 221, (Object) null, 0);
        lambda$Fn188 = moduleMethod220;
        new ModuleMethod(frame4, 222, Lit465, 0);
        this.Floating_Action_Button1$Click = moduleMethod221;
        new ModuleMethod(frame4, 223, Lit467, 0);
        this.Floating_Action_Button1$LongClick = moduleMethod222;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        String obj;
        Object obj2;
        Consumer $result = $ctx.consumer;
        C1241runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
        Object[] objArr = new Object[2];
        objArr[0] = misc.symbol$To$String(Lit0);
        Object[] objArr2 = objArr;
        objArr2[1] = "-global-vars";
        FString stringAppend = strings.stringAppend(objArr2);
        FString fString = stringAppend;
        if (stringAppend == null) {
            obj = null;
        } else {
            obj = fString.toString();
        }
        this.global$Mnvar$Mnenvironment = Environment.make(obj);
        home = null;
        this.form$Mnname$Mnsymbol = Lit0;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        C1241runtime.$instance.run();
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit3, Lit4), $result);
        } else {
            addToGlobalVars(Lit3, lambda$Fn2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit5, lambda$Fn3), $result);
        } else {
            addToGlobalVars(Lit5, lambda$Fn4);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, Lit15, Lit16);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit17, Lit18, Lit16);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, Lit20, Lit16);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, "6193580781600768", Lit22);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit23, "COVID19ANALYZER", Lit22);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, Lit25, Lit16);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit26, Lit27, Lit16);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit28, AlgorithmIdentifiers.NONE, Lit22);
            Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit29, Boolean.TRUE, Lit30);
            Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit31, "home", Lit22);
            Values.writeValues(C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit32, Boolean.FALSE, Lit30), $result);
        } else {
            new Promise(lambda$Fn6);
            addToFormDoAfterCreation(obj2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment = C1241runtime.addToCurrentFormEnvironment(Lit61, this.home$Initialize);
        } else {
            addToFormEnvironment(Lit61, this.home$Initialize);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "home", "Initialize");
        } else {
            addToEvents(Lit0, Lit62);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment2 = C1241runtime.addToCurrentFormEnvironment(Lit63, this.home$BackPressed);
        } else {
            addToFormEnvironment(Lit63, this.home$BackPressed);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "home", "BackPressed");
        } else {
            addToEvents(Lit0, Lit64);
        }
        this.Horizontal_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit65, Lit66, lambda$Fn7), $result);
        } else {
            addToComponents(Lit0, Lit74, Lit66, lambda$Fn8);
        }
        this.Label1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit66, Lit75, Lit76, lambda$Fn9), $result);
        } else {
            addToComponents(Lit66, Lit82, Lit76, lambda$Fn10);
        }
        this.Space3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit83, Lit84, lambda$Fn11), $result);
        } else {
            addToComponents(Lit0, Lit86, Lit84, lambda$Fn12);
        }
        this.Horizontal_Arrangement3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit87, Lit88, lambda$Fn13), $result);
        } else {
            addToComponents(Lit0, Lit91, Lit88, lambda$Fn14);
        }
        this.Label2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit88, Lit92, Lit93, lambda$Fn15), $result);
        } else {
            addToComponents(Lit88, Lit97, Lit93, lambda$Fn16);
        }
        this.Space8 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit98, Lit99, lambda$Fn17), $result);
        } else {
            addToComponents(Lit0, Lit101, Lit99, lambda$Fn18);
        }
        this.Vertical_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit102, Lit103, lambda$Fn19), $result);
        } else {
            addToComponents(Lit0, Lit105, Lit103, lambda$Fn20);
        }
        this.Space14 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit106, Lit107, lambda$Fn21), $result);
        } else {
            addToComponents(Lit103, Lit109, Lit107, lambda$Fn22);
        }
        this.Horizontal_Arrangement4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit110, Lit111, lambda$Fn23), $result);
        } else {
            addToComponents(Lit103, Lit112, Lit111, lambda$Fn24);
        }
        this.Horizontal_Arrangement6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit111, Lit113, Lit114, lambda$Fn25), $result);
        } else {
            addToComponents(Lit111, Lit120, Lit114, lambda$Fn26);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment3 = C1241runtime.addToCurrentFormEnvironment(Lit122, this.Horizontal_Arrangement6$Click);
        } else {
            addToFormEnvironment(Lit122, this.Horizontal_Arrangement6$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Horizontal_Arrangement6", "Click");
        } else {
            addToEvents(Lit114, Lit123);
        }
        this.Space4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit111, Lit124, Lit125, lambda$Fn27), $result);
        } else {
            addToComponents(Lit111, Lit127, Lit125, lambda$Fn28);
        }
        this.Horizontal_Arrangement7 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit111, Lit128, Lit129, lambda$Fn29), $result);
        } else {
            addToComponents(Lit111, Lit133, Lit129, lambda$Fn30);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment4 = C1241runtime.addToCurrentFormEnvironment(Lit135, this.Horizontal_Arrangement7$Click);
        } else {
            addToFormEnvironment(Lit135, this.Horizontal_Arrangement7$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Horizontal_Arrangement7", "Click");
        } else {
            addToEvents(Lit129, Lit123);
        }
        this.Space17 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit136, Lit137, lambda$Fn31), $result);
        } else {
            addToComponents(Lit103, Lit139, Lit137, lambda$Fn32);
        }
        this.Horizontal_Arrangement10 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit140, Lit141, lambda$Fn33), $result);
        } else {
            addToComponents(Lit103, Lit142, Lit141, lambda$Fn34);
        }
        this.Label32 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit141, Lit143, Lit144, lambda$Fn35), $result);
        } else {
            addToComponents(Lit141, Lit145, Lit144, lambda$Fn36);
        }
        this.Label11 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit141, Lit146, Lit147, lambda$Fn37), $result);
        } else {
            addToComponents(Lit141, Lit148, Lit147, lambda$Fn38);
        }
        this.Space16 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit141, Lit149, Lit150, lambda$Fn39), $result);
        } else {
            addToComponents(Lit141, Lit152, Lit150, lambda$Fn40);
        }
        this.Label12 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit141, Lit153, Lit154, lambda$Fn41), $result);
        } else {
            addToComponents(Lit141, Lit156, Lit154, lambda$Fn42);
        }
        this.Space7 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit157, Lit158, lambda$Fn43), $result);
        } else {
            addToComponents(Lit103, Lit160, Lit158, lambda$Fn44);
        }
        this.Horizontal_Arrangement5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit161, Lit162, lambda$Fn45), $result);
        } else {
            addToComponents(Lit103, Lit163, Lit162, lambda$Fn46);
        }
        this.Horizontal_Arrangement8 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit162, Lit164, Lit165, lambda$Fn47), $result);
        } else {
            addToComponents(Lit162, Lit169, Lit165, lambda$Fn48);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment5 = C1241runtime.addToCurrentFormEnvironment(Lit171, this.Horizontal_Arrangement8$Click);
        } else {
            addToFormEnvironment(Lit171, this.Horizontal_Arrangement8$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Horizontal_Arrangement8", "Click");
        } else {
            addToEvents(Lit165, Lit123);
        }
        this.Space5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit162, Lit172, Lit173, lambda$Fn49), $result);
        } else {
            addToComponents(Lit162, Lit175, Lit173, lambda$Fn50);
        }
        this.Horizontal_Arrangement9 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit162, Lit176, Lit177, lambda$Fn51), $result);
        } else {
            addToComponents(Lit162, Lit181, Lit177, lambda$Fn52);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment6 = C1241runtime.addToCurrentFormEnvironment(Lit183, this.Horizontal_Arrangement9$Click);
        } else {
            addToFormEnvironment(Lit183, this.Horizontal_Arrangement9$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Horizontal_Arrangement9", "Click");
        } else {
            addToEvents(Lit177, Lit123);
        }
        this.Horizontal_Arrangement10_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit184, Lit185, lambda$Fn53), $result);
        } else {
            addToComponents(Lit103, Lit186, Lit185, lambda$Fn54);
        }
        this.Label11_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit185, Lit187, Lit188, lambda$Fn55), $result);
        } else {
            addToComponents(Lit185, Lit189, Lit188, lambda$Fn56);
        }
        this.Space16_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit185, Lit190, Lit191, lambda$Fn57), $result);
        } else {
            addToComponents(Lit185, Lit193, Lit191, lambda$Fn58);
        }
        this.Label12_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit185, Lit194, Lit195, lambda$Fn59), $result);
        } else {
            addToComponents(Lit185, Lit197, Lit195, lambda$Fn60);
        }
        this.Space15 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit103, Lit198, Lit199, lambda$Fn61), $result);
        } else {
            addToComponents(Lit103, Lit201, Lit199, lambda$Fn62);
        }
        this.Space31 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit202, Lit203, lambda$Fn63), $result);
        } else {
            addToComponents(Lit0, Lit205, Lit203, lambda$Fn64);
        }
        this.Vertical_Arrangement6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit206, Lit207, lambda$Fn65), $result);
        } else {
            addToComponents(Lit0, Lit209, Lit207, lambda$Fn66);
        }
        this.Label31 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit207, Lit210, Lit211, lambda$Fn67), $result);
        } else {
            addToComponents(Lit207, Lit213, Lit211, lambda$Fn68);
        }
        this.Space34 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit207, Lit214, Lit215, lambda$Fn69), $result);
        } else {
            addToComponents(Lit207, Lit217, Lit215, lambda$Fn70);
        }
        this.Horizontal_Arrangement15 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit207, Lit218, Lit219, lambda$Fn71), $result);
        } else {
            addToComponents(Lit207, Lit221, Lit219, lambda$Fn72);
        }
        this.Horizontal_Arrangement16 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit219, Lit222, Lit223, lambda$Fn73), $result);
        } else {
            addToComponents(Lit219, Lit225, Lit223, lambda$Fn74);
        }
        this.Label29 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit223, Lit226, Lit227, lambda$Fn75), $result);
        } else {
            addToComponents(Lit223, Lit229, Lit227, lambda$Fn76);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment7 = C1241runtime.addToCurrentFormEnvironment(Lit230, this.Label29$Click);
        } else {
            addToFormEnvironment(Lit230, this.Label29$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label29", "Click");
        } else {
            addToEvents(Lit227, Lit123);
        }
        this.Space33 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit219, Lit231, Lit232, lambda$Fn77), $result);
        } else {
            addToComponents(Lit219, Lit234, Lit232, lambda$Fn78);
        }
        this.Horizontal_Arrangement17 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit219, Lit235, Lit236, lambda$Fn79), $result);
        } else {
            addToComponents(Lit219, Lit238, Lit236, lambda$Fn80);
        }
        this.Label30 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit236, Lit239, Lit240, lambda$Fn81), $result);
        } else {
            addToComponents(Lit236, Lit242, Lit240, lambda$Fn82);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment8 = C1241runtime.addToCurrentFormEnvironment(Lit243, this.Label30$Click);
        } else {
            addToFormEnvironment(Lit243, this.Label30$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label30", "Click");
        } else {
            addToEvents(Lit240, Lit123);
        }
        this.Space26 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit244, Lit245, lambda$Fn83), $result);
        } else {
            addToComponents(Lit0, Lit247, Lit245, lambda$Fn84);
        }
        this.Horizontal_Arrangement14 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit248, Lit249, lambda$Fn85), $result);
        } else {
            addToComponents(Lit0, Lit252, Lit249, lambda$Fn86);
        }
        this.Label26 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit249, Lit253, Lit254, lambda$Fn87), $result);
        } else {
            addToComponents(Lit249, Lit255, Lit254, lambda$Fn88);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment9 = C1241runtime.addToCurrentFormEnvironment(Lit257, this.Label26$Click);
        } else {
            addToFormEnvironment(Lit257, this.Label26$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label26", "Click");
        } else {
            addToEvents(Lit254, Lit123);
        }
        this.Space6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit258, Lit259, lambda$Fn89), $result);
        } else {
            addToComponents(Lit0, Lit261, Lit259, lambda$Fn90);
        }
        this.Vertical_Arrangement_symptoms_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit262, Lit50, lambda$Fn91), $result);
        } else {
            addToComponents(Lit0, Lit263, Lit50, lambda$Fn92);
        }
        this.Label9_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit50, Lit264, Lit265, lambda$Fn93), $result);
        } else {
            addToComponents(Lit50, Lit267, Lit265, lambda$Fn94);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment10 = C1241runtime.addToCurrentFormEnvironment(Lit269, this.Label9_copy_copy$Click);
        } else {
            addToFormEnvironment(Lit269, this.Label9_copy_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label9_copy_copy", "Click");
        } else {
            addToEvents(Lit265, Lit123);
        }
        this.Image2_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit50, Lit270, Lit271, lambda$Fn95), $result);
        } else {
            addToComponents(Lit50, Lit275, Lit271, lambda$Fn96);
        }
        this.Space9_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit50, Lit276, Lit277, lambda$Fn97), $result);
        } else {
            addToComponents(Lit50, Lit279, Lit277, lambda$Fn98);
        }
        this.Horizontal_Arrangement11_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit50, Lit280, Lit281, lambda$Fn99), $result);
        } else {
            addToComponents(Lit50, Lit284, Lit281, lambda$Fn100);
        }
        this.Label14_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit281, Lit285, Lit286, lambda$Fn101), $result);
        } else {
            addToComponents(Lit281, Lit288, Lit286, lambda$Fn102);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment11 = C1241runtime.addToCurrentFormEnvironment(Lit291, this.Label14_copy_copy$Click);
        } else {
            addToFormEnvironment(Lit291, this.Label14_copy_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label14_copy_copy", "Click");
        } else {
            addToEvents(Lit286, Lit123);
        }
        this.Space18_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit50, Lit292, Lit293, lambda$Fn103), $result);
        } else {
            addToComponents(Lit50, Lit295, Lit293, lambda$Fn104);
        }
        this.View_Flipper1_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit50, Lit296, Lit42, lambda$Fn105), $result);
        } else {
            addToComponents(Lit50, Lit297, Lit42, lambda$Fn106);
        }
        this.Vertical_Scroll_Arrangement3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit298, Lit44, lambda$Fn107), $result);
        } else {
            addToComponents(Lit0, Lit299, Lit44, lambda$Fn108);
        }
        this.Label19 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit44, Lit300, Lit301, lambda$Fn109), $result);
        } else {
            addToComponents(Lit44, Lit303, Lit301, lambda$Fn110);
        }
        this.Space23 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit44, Lit304, Lit305, lambda$Fn111), $result);
        } else {
            addToComponents(Lit44, Lit307, Lit305, lambda$Fn112);
        }
        this.Horizontal_Arrangement12 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit44, Lit308, Lit309, lambda$Fn113), $result);
        } else {
            addToComponents(Lit44, Lit311, Lit309, lambda$Fn114);
        }
        this.Label20_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit309, Lit312, Lit313, lambda$Fn115), $result);
        } else {
            addToComponents(Lit309, Lit315, Lit313, lambda$Fn116);
        }
        this.Space25 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit44, Lit316, Lit317, lambda$Fn117), $result);
        } else {
            addToComponents(Lit44, Lit319, Lit317, lambda$Fn118);
        }
        this.Vertical_Arrangement4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit44, Lit320, Lit321, lambda$Fn119), $result);
        } else {
            addToComponents(Lit44, Lit322, Lit321, lambda$Fn120);
        }
        this.Label21 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit323, Lit324, lambda$Fn121), $result);
        } else {
            addToComponents(Lit321, Lit326, Lit324, lambda$Fn122);
        }
        this.Label22 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit327, Lit328, lambda$Fn123), $result);
        } else {
            addToComponents(Lit321, Lit329, Lit328, lambda$Fn124);
        }
        this.Space24 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit330, Lit331, lambda$Fn125), $result);
        } else {
            addToComponents(Lit321, Lit333, Lit331, lambda$Fn126);
        }
        this.Label23 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit334, Lit56, lambda$Fn127), $result);
        } else {
            addToComponents(Lit321, Lit335, Lit56, lambda$Fn128);
        }
        this.Space27 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit336, Lit337, lambda$Fn129), $result);
        } else {
            addToComponents(Lit321, Lit339, Lit337, lambda$Fn130);
        }
        this.Label27 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit340, Lit59, lambda$Fn131), $result);
        } else {
            addToComponents(Lit321, Lit341, Lit59, lambda$Fn132);
        }
        this.Label24 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit342, Lit343, lambda$Fn133), $result);
        } else {
            addToComponents(Lit321, Lit345, Lit343, lambda$Fn134);
        }
        this.Label33 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit346, Lit347, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit321, Lit348, Lit347, Boolean.FALSE);
        }
        this.Horizontal_Arrangement16_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit321, Lit349, Lit350, lambda$Fn135), $result);
        } else {
            addToComponents(Lit321, Lit352, Lit350, lambda$Fn136);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment12 = C1241runtime.addToCurrentFormEnvironment(Lit354, this.Horizontal_Arrangement16_copy$Click);
        } else {
            addToFormEnvironment(Lit354, this.Horizontal_Arrangement16_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Horizontal_Arrangement16_copy", "Click");
        } else {
            addToEvents(Lit350, Lit123);
        }
        this.Label29_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit350, Lit355, Lit356, lambda$Fn137), $result);
        } else {
            addToComponents(Lit350, Lit358, Lit356, lambda$Fn138);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment13 = C1241runtime.addToCurrentFormEnvironment(Lit360, this.Label29_copy$Click);
        } else {
            addToFormEnvironment(Lit360, this.Label29_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label29_copy", "Click");
        } else {
            addToEvents(Lit356, Lit123);
        }
        this.Vertical_Scroll_Arrangement3_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit361, Lit46, lambda$Fn139), $result);
        } else {
            addToComponents(Lit0, Lit362, Lit46, lambda$Fn140);
        }
        this.Label19_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit46, Lit363, Lit364, lambda$Fn141), $result);
        } else {
            addToComponents(Lit46, Lit366, Lit364, lambda$Fn142);
        }
        this.Space23_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit46, Lit367, Lit368, lambda$Fn143), $result);
        } else {
            addToComponents(Lit46, Lit370, Lit368, lambda$Fn144);
        }
        this.Horizontal_Arrangement12_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit46, Lit371, Lit372, lambda$Fn145), $result);
        } else {
            addToComponents(Lit46, Lit374, Lit372, lambda$Fn146);
        }
        this.Label20 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit372, Lit375, Lit376, lambda$Fn147), $result);
        } else {
            addToComponents(Lit372, Lit377, Lit376, lambda$Fn148);
        }
        this.Space25_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit46, Lit378, Lit379, lambda$Fn149), $result);
        } else {
            addToComponents(Lit46, Lit381, Lit379, lambda$Fn150);
        }
        this.Vertical_Arrangement4_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit46, Lit382, Lit383, lambda$Fn151), $result);
        } else {
            addToComponents(Lit46, Lit384, Lit383, lambda$Fn152);
        }
        this.Label21_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit385, Lit386, lambda$Fn153), $result);
        } else {
            addToComponents(Lit383, Lit387, Lit386, lambda$Fn154);
        }
        this.Label22_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit388, Lit389, lambda$Fn155), $result);
        } else {
            addToComponents(Lit383, Lit390, Lit389, lambda$Fn156);
        }
        this.Space24_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit391, Lit392, lambda$Fn157), $result);
        } else {
            addToComponents(Lit383, Lit394, Lit392, lambda$Fn158);
        }
        this.Label23_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit395, Lit58, lambda$Fn159), $result);
        } else {
            addToComponents(Lit383, Lit396, Lit58, lambda$Fn160);
        }
        this.Space28 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit397, Lit398, lambda$Fn161), $result);
        } else {
            addToComponents(Lit383, Lit400, Lit398, lambda$Fn162);
        }
        this.Label28 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit401, Lit60, lambda$Fn163), $result);
        } else {
            addToComponents(Lit383, Lit402, Lit60, lambda$Fn164);
        }
        this.Label24_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit403, Lit404, lambda$Fn165), $result);
        } else {
            addToComponents(Lit383, Lit405, Lit404, lambda$Fn166);
        }
        this.Label34 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit406, Lit407, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit383, Lit408, Lit407, Boolean.FALSE);
        }
        this.Horizontal_Arrangement16_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit383, Lit409, Lit410, lambda$Fn167), $result);
        } else {
            addToComponents(Lit383, Lit412, Lit410, lambda$Fn168);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment14 = C1241runtime.addToCurrentFormEnvironment(Lit414, this.Horizontal_Arrangement16_copy_copy$Click);
        } else {
            addToFormEnvironment(Lit414, this.Horizontal_Arrangement16_copy_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Horizontal_Arrangement16_copy_copy", "Click");
        } else {
            addToEvents(Lit410, Lit123);
        }
        this.Label29_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit410, Lit415, Lit416, lambda$Fn169), $result);
        } else {
            addToComponents(Lit410, Lit419, Lit416, lambda$Fn170);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment15 = C1241runtime.addToCurrentFormEnvironment(Lit421, this.Label29_copy_copy$Click);
        } else {
            addToFormEnvironment(Lit421, this.Label29_copy_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label29_copy_copy", "Click");
        } else {
            addToEvents(Lit416, Lit123);
        }
        this.Vertical_Arrangement7 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit422, Lit8, lambda$Fn171), $result);
        } else {
            addToComponents(Lit0, Lit424, Lit8, lambda$Fn172);
        }
        this.Label35 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit8, Lit425, Lit426, lambda$Fn173), $result);
        } else {
            addToComponents(Lit8, Lit428, Lit426, lambda$Fn174);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment16 = C1241runtime.addToCurrentFormEnvironment(Lit429, this.Label35$Click);
        } else {
            addToFormEnvironment(Lit429, this.Label35$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label35", "Click");
        } else {
            addToEvents(Lit426, Lit123);
        }
        this.Label3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit430, Lit431, lambda$Fn175), $result);
        } else {
            addToComponents(Lit0, Lit434, Lit431, lambda$Fn176);
        }
        this.Notifier1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit435, Lit436, lambda$Fn177), $result);
        } else {
            addToComponents(Lit0, Lit439, Lit436, lambda$Fn178);
        }
        this.HiperLinks1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit440, Lit53, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit441, Lit53, Boolean.FALSE);
        }
        this.Notifier2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit442, Lit443, lambda$Fn179), $result);
        } else {
            addToComponents(Lit0, Lit444, Lit443, lambda$Fn180);
        }
        this.Notifier3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit445, Lit48, lambda$Fn181), $result);
        } else {
            addToComponents(Lit0, Lit446, Lit48, lambda$Fn182);
        }
        this.Image_Utilities1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit447, Lit448, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit449, Lit448, Boolean.FALSE);
        }
        this.Activity_Starter1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit450, Lit451, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit452, Lit451, Boolean.FALSE);
        }
        this.Notifier4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit453, Lit454, lambda$Fn183), $result);
        } else {
            addToComponents(Lit0, Lit455, Lit454, lambda$Fn184);
        }
        this.Notifier5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit456, Lit457, lambda$Fn185), $result);
        } else {
            addToComponents(Lit0, Lit458, Lit457, lambda$Fn186);
        }
        this.Floating_Action_Button1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit459, Lit460, lambda$Fn187), $result);
        } else {
            addToComponents(Lit0, Lit463, Lit460, lambda$Fn188);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment17 = C1241runtime.addToCurrentFormEnvironment(Lit465, this.Floating_Action_Button1$Click);
        } else {
            addToFormEnvironment(Lit465, this.Floating_Action_Button1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Floating_Action_Button1", "Click");
        } else {
            addToEvents(Lit460, Lit123);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment18 = C1241runtime.addToCurrentFormEnvironment(Lit467, this.Floating_Action_Button1$LongClick);
        } else {
            addToFormEnvironment(Lit467, this.Floating_Action_Button1$LongClick);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Floating_Action_Button1", "LongClick");
        } else {
            addToEvents(Lit460, Lit468);
        }
        this.Firebase_Authentication1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit469, Lit38, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit470, Lit38, Boolean.FALSE);
        }
        this.Tiny_DB1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit471, Lit33, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit472, Lit33, Boolean.FALSE);
        }
        this.InApp_PDFViewer4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit473, Lit6, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit474, Lit6, Boolean.FALSE);
        }
        this.Notifier6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit475, Lit11, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit476, Lit11, Boolean.FALSE);
        }
        C1241runtime.initRuntime();
    }

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.home$frame */
    /* compiled from: home.yail */
    public class frame extends ModuleBody {
        home $main;

        public frame() {
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return home.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return home.lambda3();
                case 20:
                    return home.lambda4();
                case 21:
                    return home.lambda6();
                case 22:
                    return home.lambda5();
                case 23:
                    return home.lambda7();
                case 24:
                    return this.$main.home$Initialize();
                case 25:
                    return this.$main.home$BackPressed();
                case 26:
                    return home.lambda8();
                case 27:
                    return home.lambda9();
                case 28:
                    return home.lambda10();
                case 29:
                    return home.lambda11();
                case 30:
                    return home.lambda12();
                case 31:
                    return home.lambda13();
                case 32:
                    return home.lambda14();
                case 33:
                    return home.lambda15();
                case 34:
                    return home.lambda16();
                case 35:
                    return home.lambda17();
                case 36:
                    return home.lambda18();
                case 37:
                    return home.lambda19();
                case 38:
                    return home.lambda20();
                case 39:
                    return home.lambda21();
                case 40:
                    return home.lambda22();
                case 41:
                    return home.lambda23();
                case 42:
                    return home.lambda24();
                case 43:
                    return home.lambda25();
                case 44:
                    return home.lambda26();
                case 45:
                    return home.lambda27();
                case 46:
                    return this.$main.Horizontal_Arrangement6$Click();
                case 47:
                    return home.lambda28();
                case 48:
                    return home.lambda29();
                case 49:
                    return home.lambda30();
                case 50:
                    return home.lambda31();
                case 51:
                    return this.$main.Horizontal_Arrangement7$Click();
                case 52:
                    return home.lambda32();
                case 53:
                    return home.lambda33();
                case 54:
                    return home.lambda34();
                case 55:
                    return home.lambda35();
                case 56:
                    return home.lambda36();
                case 57:
                    return home.lambda37();
                case 58:
                    return home.lambda38();
                case 59:
                    return home.lambda39();
                case 60:
                    return home.lambda40();
                case 61:
                    return home.lambda41();
                case 62:
                    return home.lambda42();
                case 63:
                    return home.lambda43();
                case 64:
                    return home.lambda44();
                case 65:
                    return home.lambda45();
                case 66:
                    return home.lambda46();
                case 67:
                    return home.lambda47();
                case 68:
                    return home.lambda48();
                case 69:
                    return home.lambda49();
                case 70:
                    return this.$main.Horizontal_Arrangement8$Click();
                case 71:
                    return home.lambda50();
                case 72:
                    return home.lambda51();
                case 73:
                    return home.lambda52();
                case 74:
                    return home.lambda53();
                case 75:
                    return this.$main.Horizontal_Arrangement9$Click();
                case 76:
                    return home.lambda54();
                case 77:
                    return home.lambda55();
                case 78:
                    return home.lambda56();
                case 79:
                    return home.lambda57();
                case 80:
                    return home.lambda58();
                case 81:
                    return home.lambda59();
                case 82:
                    return home.lambda60();
                case 83:
                    return home.lambda61();
                case 84:
                    return home.lambda62();
                case 85:
                    return home.lambda63();
                case 86:
                    return home.lambda64();
                case 87:
                    return home.lambda65();
                case 88:
                    return home.lambda66();
                case 89:
                    return home.lambda67();
                case 90:
                    return home.lambda68();
                case 91:
                    return home.lambda69();
                case 92:
                    return home.lambda70();
                case 93:
                    return home.lambda71();
                case 94:
                    return home.lambda72();
                case 95:
                    return home.lambda73();
                case 96:
                    return home.lambda74();
                case 97:
                    return home.lambda75();
                case 98:
                    return home.lambda76();
                case 99:
                    return home.lambda77();
                case 100:
                    return this.$main.Label29$Click();
                case 101:
                    return home.lambda78();
                case 102:
                    return home.lambda79();
                case 103:
                    return home.lambda80();
                case 104:
                    return home.lambda81();
                case 105:
                    return home.lambda82();
                case 106:
                    return home.lambda83();
                case 107:
                    return this.$main.Label30$Click();
                case 108:
                    return home.lambda84();
                case 109:
                    return home.lambda85();
                case 110:
                    return home.lambda86();
                case 111:
                    return home.lambda87();
                case 112:
                    return home.lambda88();
                case 113:
                    return home.lambda89();
                case 114:
                    return this.$main.Label26$Click();
                case 115:
                    return home.lambda90();
                case 116:
                    return home.lambda91();
                case 117:
                    return home.lambda92();
                case 118:
                    return home.lambda93();
                case 119:
                    return home.lambda94();
                case 120:
                    return home.lambda95();
                case 121:
                    return this.$main.Label9_copy_copy$Click();
                case 122:
                    return home.lambda96();
                case 123:
                    return home.lambda97();
                case 124:
                    return home.lambda98();
                case ErrorLogHelper.MAX_PROPERTY_ITEM_LENGTH /*125*/:
                    return home.lambda99();
                case 126:
                    return home.lambda100();
                case 127:
                    return home.lambda101();
                case 128:
                    return home.lambda102();
                case 129:
                    return home.lambda103();
                case 130:
                    return this.$main.Label14_copy_copy$Click();
                case 131:
                    return home.lambda104();
                case 132:
                    return home.lambda105();
                case 133:
                    return home.lambda106();
                case 134:
                    return home.lambda107();
                case 135:
                    return home.lambda108();
                case 136:
                    return home.lambda109();
                case 137:
                    return home.lambda110();
                case 138:
                    return home.lambda111();
                case 139:
                    return home.lambda112();
                case 140:
                    return home.lambda113();
                case 141:
                    return home.lambda114();
                case 142:
                    return home.lambda115();
                case 143:
                    return home.lambda116();
                case 144:
                    return home.lambda117();
                case 145:
                    return home.lambda118();
                case 146:
                    return home.lambda119();
                case 147:
                    return home.lambda120();
                case 148:
                    return home.lambda121();
                case 149:
                    return home.lambda122();
                case 150:
                    return home.lambda123();
                case 151:
                    return home.lambda124();
                case 152:
                    return home.lambda125();
                case 153:
                    return home.lambda126();
                case 154:
                    return home.lambda127();
                case 155:
                    return home.lambda128();
                case 156:
                    return home.lambda129();
                case 157:
                    return home.lambda130();
                case 158:
                    return home.lambda131();
                case 159:
                    return home.lambda132();
                case ComponentConstants.TEXTBOX_PREFERRED_WIDTH:
                    return home.lambda133();
                case 161:
                    return home.lambda134();
                case 162:
                    return home.lambda135();
                case 163:
                    return home.lambda136();
                case 164:
                    return home.lambda137();
                case 165:
                    return this.$main.Horizontal_Arrangement16_copy$Click();
                case 166:
                    return home.lambda138();
                case 167:
                    return home.lambda139();
                case 168:
                    return this.$main.Label29_copy$Click();
                case 169:
                    return home.lambda140();
                case 170:
                    return home.lambda141();
                case 171:
                    return home.lambda142();
                case 172:
                    return home.lambda143();
                case 173:
                    return home.lambda144();
                case 174:
                    return home.lambda145();
                case 175:
                    return home.lambda146();
                case 176:
                    return home.lambda147();
                case 177:
                    return home.lambda148();
                case 178:
                    return home.lambda149();
                case 179:
                    return home.lambda150();
                case 180:
                    return home.lambda151();
                case 181:
                    return home.lambda152();
                case 182:
                    return home.lambda153();
                case 183:
                    return home.lambda154();
                case 184:
                    return home.lambda155();
                case 185:
                    return home.lambda156();
                case 186:
                    return home.lambda157();
                case 187:
                    return home.lambda158();
                case 188:
                    return home.lambda159();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_DIALOG_FLAG:
                    return home.lambda160();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SEEK:
                    return home.lambda161();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PLAY:
                    return home.lambda162();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PAUSE:
                    return home.lambda163();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_STOP:
                    return home.lambda164();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SOURCE:
                    return home.lambda165();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_FULLSCREEN:
                    return home.lambda166();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_DURATION:
                    return home.lambda167();
                case 197:
                    return home.lambda168();
                case 198:
                    return home.lambda169();
                case 199:
                    return this.$main.Horizontal_Arrangement16_copy_copy$Click();
                case 200:
                    return home.lambda170();
                case 201:
                    return home.lambda171();
                case 202:
                    return this.$main.Label29_copy_copy$Click();
                case HttpStatus.SC_NON_AUTHORITATIVE_INFORMATION /*203*/:
                    return home.lambda172();
                case HttpStatus.SC_NO_CONTENT /*204*/:
                    return home.lambda173();
                case HttpStatus.SC_RESET_CONTENT /*205*/:
                    return home.lambda174();
                case HttpStatus.SC_PARTIAL_CONTENT /*206*/:
                    return home.lambda175();
                case HttpStatus.SC_MULTI_STATUS /*207*/:
                    return this.$main.Label35$Click();
                case 208:
                    return home.lambda176();
                case 209:
                    return home.lambda177();
                case 210:
                    return home.lambda178();
                case 211:
                    return home.lambda179();
                case 212:
                    return home.lambda180();
                case 213:
                    return home.lambda181();
                case 214:
                    return home.lambda182();
                case 215:
                    return home.lambda183();
                case 216:
                    return home.lambda184();
                case 217:
                    return home.lambda185();
                case 218:
                    return home.lambda186();
                case 219:
                    return home.lambda187();
                case 220:
                    return home.lambda188();
                case 221:
                    return home.lambda189();
                case 222:
                    return this.$main.Floating_Action_Button1$Click();
                case 223:
                    return this.$main.Floating_Action_Button1$LongClick();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 20:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 23:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 24:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 30:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 31:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 32:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 33:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 34:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 35:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 36:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 37:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 38:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 39:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 40:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 41:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 42:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 43:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 44:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 45:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 46:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 47:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 48:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 49:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 50:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 51:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 52:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 53:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 54:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 55:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 56:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 57:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 58:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 59:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 60:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 61:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 62:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 63:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 64:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 65:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 66:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 67:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 68:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 69:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 70:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 71:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 72:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 73:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 74:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 75:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 76:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 77:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 78:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 79:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 80:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 81:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 82:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 83:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 84:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 85:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 86:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 87:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 88:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 89:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 90:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 91:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 92:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 93:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 94:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 95:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 96:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 97:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 98:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 99:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 100:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 101:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 102:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 103:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 104:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 105:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 106:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 107:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 108:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 109:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 110:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 111:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 112:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 113:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 114:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 115:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 116:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 117:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 118:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 119:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 120:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 121:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 122:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 123:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 124:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case ErrorLogHelper.MAX_PROPERTY_ITEM_LENGTH /*125*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 126:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 127:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 128:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 129:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 130:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 131:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 132:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 133:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 134:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 135:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 136:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 137:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 138:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 139:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 140:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 141:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 142:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 143:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 144:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 145:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 146:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 147:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 148:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 149:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 150:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 151:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 152:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 153:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 154:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 155:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 156:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 157:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 158:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 159:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case ComponentConstants.TEXTBOX_PREFERRED_WIDTH:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 161:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 162:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 163:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 164:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 165:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 166:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 167:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 168:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 169:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 170:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 171:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 172:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 173:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 174:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 175:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 176:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 177:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 178:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 179:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 180:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 181:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 182:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 183:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 184:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 185:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 186:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 187:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 188:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_DIALOG_FLAG:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SEEK:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PLAY:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PAUSE:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_STOP:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SOURCE:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_FULLSCREEN:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_DURATION:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 197:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 198:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 199:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 200:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 201:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 202:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_NON_AUTHORITATIVE_INFORMATION /*203*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_NO_CONTENT /*204*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_RESET_CONTENT /*205*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_PARTIAL_CONTENT /*206*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_MULTI_STATUS /*207*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 208:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 209:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 210:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 211:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 212:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 213:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 214:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 215:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 216:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 217:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 218:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 219:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 220:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 221:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 222:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 223:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof home)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof home)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof home)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            Throwable th;
            Throwable th2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th3 = th2;
                        new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw th3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th4 = th;
                        new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw th4;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            Throwable th6;
            Throwable th7;
            Throwable th8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    Throwable th9 = th8;
                                    new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw th9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                Throwable th10 = th7;
                                new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw th10;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            Throwable th11 = th6;
                            new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw th11;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        Throwable th12 = th5;
                        new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw th12;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    Throwable th13 = th4;
                                    new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw th13;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                Throwable th14 = th3;
                                new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw th14;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            Throwable th15 = th2;
                            new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw th15;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        Throwable th16 = th;
                        new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw th16;
                    }
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th4 = th3;
                        new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw th4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th2;
                        new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw th5;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        Throwable th6 = th;
                        new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw th6;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }
    }

    static IntNum lambda3() {
        return Lit4;
    }

    static Object lambda4() {
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit6, Lit7, LList.list3(C1241runtime.lookupInCurrentFormEnvironment(Lit8), "coronvavirushelplinenumber.pdf", C1241runtime.get$Mnproperty.apply2(Lit6, Lit9)), Lit10);
        return C1241runtime.callComponentMethod(Lit11, Lit12, LList.Empty, LList.Empty);
    }

    static Procedure lambda5() {
        return lambda$Fn5;
    }

    static Object lambda6() {
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit6, Lit7, LList.list3(C1241runtime.lookupInCurrentFormEnvironment(Lit8), "coronvavirushelplinenumber.pdf", C1241runtime.get$Mnproperty.apply2(Lit6, Lit9)), Lit13);
        return C1241runtime.callComponentMethod(Lit11, Lit12, LList.Empty, LList.Empty);
    }

    static Object lambda7() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, Lit15, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, "6193580781600768", Lit22);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit23, "COVID19ANALYZER", Lit22);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, Lit25, Lit16);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit26, Lit27, Lit16);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit28, AlgorithmIdentifiers.NONE, Lit22);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit29, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit31, "home", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit32, Boolean.FALSE, Lit30);
    }

    public Object home$Initialize() {
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnnot$Mnequal$Qu, LList.list2(C1241runtime.callComponentMethod(Lit33, Lit34, LList.list2("signin", ""), Lit35), Lit36), Lit37, "not =") != Boolean.FALSE) {
            Object callComponentMethod = C1241runtime.callComponentMethod(Lit38, Lit39, LList.Empty, LList.Empty);
            Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit33, Lit40, LList.list2("signin", Lit36), Lit41);
        }
        Object callComponentMethod3 = C1241runtime.callComponentMethod(Lit42, Lit43, LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit44)), Lit45);
        Object callComponentMethod4 = C1241runtime.callComponentMethod(Lit42, Lit43, LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit46)), Lit47);
        SimpleSymbol simpleSymbol = Lit48;
        SimpleSymbol simpleSymbol2 = Lit49;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit50));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.TRUE);
        Object callComponentMethod5 = C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit51);
        SimpleSymbol simpleSymbol3 = Lit11;
        SimpleSymbol simpleSymbol4 = Lit49;
        Pair list12 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit8));
        Pair chain42 = LList.chain4(list12, "", "", "", Boolean.TRUE);
        Object callComponentMethod6 = C1241runtime.callComponentMethod(simpleSymbol3, simpleSymbol4, list12, Lit52);
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit54, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit55, C1241runtime.lookupInCurrentFormEnvironment(Lit56), Lit57);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit55, C1241runtime.lookupInCurrentFormEnvironment(Lit58), Lit57);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit55, C1241runtime.lookupInCurrentFormEnvironment(Lit59), Lit57);
        return C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit55, C1241runtime.lookupInCurrentFormEnvironment(Lit60), Lit57);
    }

    public Object home$BackPressed() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.close$Mnapplication, LList.Empty, LList.Empty, "close application");
    }

    static Object lambda8() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit67, Lit68, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit69, Lit70, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda9() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit67, Lit68, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit69, Lit70, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda10() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit77, Lit78, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit80, "COV-AID 2.0", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit81, Lit36, Lit16);
    }

    static Object lambda11() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit77, Lit78, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit80, "COV-AID 2.0", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit76, Lit81, Lit36, Lit16);
    }

    static Object lambda12() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit69, Lit85, Lit16);
    }

    static Object lambda13() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit69, Lit85, Lit16);
    }

    static Object lambda14() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit67, Lit89, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda15() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit67, Lit89, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit88, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda16() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit77, Lit94, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit80, "COV-AID 2.0: New Version For A New Wave.", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit95, Lit96, Lit16);
    }

    static Object lambda17() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit77, Lit94, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit80, "COV-AID 2.0: New Version For A New Wave.", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit95, Lit96, Lit16);
    }

    static Object lambda18() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit69, Lit100, Lit16);
    }

    static Object lambda19() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit69, Lit100, Lit16);
    }

    static Object lambda20() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit67, Lit104, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda21() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit67, Lit104, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda22() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit69, Lit108, Lit16);
    }

    static Object lambda23() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit69, Lit108, Lit16);
    }

    static Object lambda24() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit71, Lit72, Lit16);
    }

    static Object lambda25() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit71, Lit72, Lit16);
    }

    static Object lambda26() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit19, Lit18, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit67, Lit115, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit69, Lit117, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit71, Lit118, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit119, "image-removebg-preview.png", Lit22);
    }

    static Object lambda27() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit19, Lit18, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit67, Lit115, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit69, Lit117, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit71, Lit118, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit114, Lit119, "image-removebg-preview.png", Lit22);
    }

    public Object Horizontal_Arrangement6$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen5"), Lit121, "open another screen");
    }

    static Object lambda28() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit125, Lit71, Lit126, Lit16);
    }

    static Object lambda29() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit125, Lit71, Lit126, Lit16);
    }

    static Object lambda30() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit67, Lit130, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit69, Lit131, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit71, Lit132, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit119, "tips.png", Lit22);
    }

    static Object lambda31() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit67, Lit130, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit69, Lit131, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit71, Lit132, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit129, Lit119, "tips.png", Lit22);
    }

    public Object Horizontal_Arrangement7$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen4"), Lit134, "open another screen");
    }

    static Object lambda32() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit137, Lit69, Lit138, Lit16);
    }

    static Object lambda33() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit137, Lit69, Lit138, Lit16);
    }

    static Object lambda34() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit71, Lit72, Lit16);
    }

    static Object lambda35() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit71, Lit72, Lit16);
    }

    static Object lambda36() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit71, Lit36, Lit16);
    }

    static Object lambda37() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit71, Lit36, Lit16);
    }

    static Object lambda38() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit147, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit147, Lit80, "COV-AID", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit147, Lit81, Lit36, Lit16);
    }

    static Object lambda39() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit147, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit147, Lit80, "COV-AID", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit147, Lit81, Lit36, Lit16);
    }

    static Object lambda40() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit150, Lit71, Lit151, Lit16);
    }

    static Object lambda41() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit150, Lit71, Lit151, Lit16);
    }

    static Object lambda42() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit154, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit154, Lit71, Lit155, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit154, Lit80, "Tips", Lit22);
    }

    static Object lambda43() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit154, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit154, Lit71, Lit155, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit154, Lit80, "Tips", Lit22);
    }

    static Object lambda44() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit158, Lit69, Lit159, Lit16);
    }

    static Object lambda45() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit158, Lit69, Lit159, Lit16);
    }

    static Object lambda46() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit162, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit162, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit162, Lit71, Lit72, Lit16);
    }

    static Object lambda47() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit162, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit162, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit162, Lit71, Lit72, Lit16);
    }

    static Object lambda48() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit67, Lit166, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit69, Lit167, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit71, Lit168, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit119, "world.png", Lit22);
    }

    static Object lambda49() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit67, Lit166, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit69, Lit167, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit71, Lit168, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit165, Lit119, "world.png", Lit22);
    }

    public Object Horizontal_Arrangement8$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen2"), Lit170, "open another screen");
    }

    static Object lambda50() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit71, Lit174, Lit16);
    }

    static Object lambda51() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit173, Lit71, Lit174, Lit16);
    }

    static Object lambda52() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit67, Lit178, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit69, Lit179, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit71, Lit180, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit119, "virus-scan.png", Lit22);
    }

    static Object lambda53() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit67, Lit178, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit69, Lit179, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit71, Lit180, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit177, Lit119, "virus-scan.png", Lit22);
    }

    public Object Horizontal_Arrangement9$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen3"), Lit182, "open another screen");
    }

    static Object lambda54() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit185, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit185, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit185, Lit71, Lit72, Lit16);
    }

    static Object lambda55() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit185, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit185, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit185, Lit71, Lit72, Lit16);
    }

    static Object lambda56() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit188, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit188, Lit80, "Centres", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit188, Lit81, Lit36, Lit16);
    }

    static Object lambda57() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit188, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit188, Lit80, "Centres", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit188, Lit81, Lit36, Lit16);
    }

    static Object lambda58() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit191, Lit71, Lit192, Lit16);
    }

    static Object lambda59() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit191, Lit71, Lit192, Lit16);
    }

    static Object lambda60() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit77, Lit196, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit80, "COV-AID Tracker", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit81, Lit36, Lit16);
    }

    static Object lambda61() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit77, Lit196, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit80, "COV-AID Tracker", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit195, Lit81, Lit36, Lit16);
    }

    static Object lambda62() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit199, Lit69, Lit200, Lit16);
    }

    static Object lambda63() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit199, Lit69, Lit200, Lit16);
    }

    static Object lambda64() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit69, Lit204, Lit16);
    }

    static Object lambda65() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit69, Lit204, Lit16);
    }

    static Object lambda66() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit67, Lit208, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda67() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit67, Lit208, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit207, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda68() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit77, Lit212, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit80, "Useful Information", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit81, Lit36, Lit16);
    }

    static Object lambda69() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit77, Lit212, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit80, "Useful Information", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit81, Lit36, Lit16);
    }

    static Object lambda70() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit215, Lit69, Lit216, Lit16);
    }

    static Object lambda71() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit215, Lit69, Lit216, Lit16);
    }

    static Object lambda72() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit67, Lit220, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda73() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit67, Lit220, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda74() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit67, Lit224, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda75() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit67, Lit224, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit223, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda76() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit80, "Information", Lit22);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit95, Lit228, Lit16);
    }

    static Object lambda77() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit80, "Information", Lit22);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit227, Lit95, Lit228, Lit16);
    }

    public Object Label29$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit48, Lit12, LList.Empty, LList.Empty);
    }

    static Object lambda78() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit232, Lit71, Lit233, Lit16);
    }

    static Object lambda79() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit232, Lit71, Lit233, Lit16);
    }

    static Object lambda80() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit67, Lit237, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda81() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit67, Lit237, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit236, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda82() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit80, "Helpline(s)", Lit22);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit95, Lit241, Lit16);
    }

    static Object lambda83() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit80, "Helpline(s)", Lit22);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit95, Lit241, Lit16);
    }

    public Object Label30$Click() {
        C1241runtime.setThisForm();
        return Scheme.applyToArgs.apply1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit5, C1241runtime.$Stthe$Mnnull$Mnvalue$St));
    }

    static Object lambda84() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit245, Lit69, Lit246, Lit16);
    }

    static Object lambda85() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit245, Lit69, Lit246, Lit16);
    }

    static Object lambda86() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit67, Lit250, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit71, Lit251, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda87() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit67, Lit250, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit71, Lit251, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda88() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit80, "COV-AID 1.0", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit81, Lit36, Lit16);
    }

    static Object lambda89() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit80, "COV-AID 1.0", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit254, Lit81, Lit36, Lit16);
    }

    public Object Label26$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen18"), Lit256, "open another screen");
    }

    static Object lambda90() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit259, Lit69, Lit260, Lit16);
    }

    static Object lambda91() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit259, Lit69, Lit260, Lit16);
    }

    static Object lambda92() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda93() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit71, Lit72, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit50, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda94() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit80, "X  ", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit81, Lit20, Lit16);
    }

    static Object lambda95() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit80, "X  ", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit81, Lit20, Lit16);
    }

    public Object Label9_copy_copy$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit48, Lit268, LList.Empty, LList.Empty);
    }

    static Object lambda96() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit69, Lit272, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit71, Lit273, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit274, "COV-AID_LOGO.png", Lit22);
    }

    static Object lambda97() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit69, Lit272, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit71, Lit273, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit271, Lit274, "COV-AID_LOGO.png", Lit22);
    }

    static Object lambda98() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit277, Lit69, Lit278, Lit16);
    }

    static Object lambda99() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit277, Lit69, Lit278, Lit16);
    }

    static Object lambda100() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit67, Lit282, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit71, Lit283, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda101() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit67, Lit282, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit71, Lit283, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit281, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda102() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit80, "हिंदी में देखें", Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit95, Lit287, Lit16);
    }

    static Object lambda103() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit80, "हिंदी में देखें", Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit95, Lit287, Lit16);
    }

    public Object Label14_copy_copy$Click() {
        Object callComponentMethod;
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.get$Mnproperty.apply2(Lit286, Lit80), "हिंदी में देखें"), Lit289, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit80, "View in English", Lit22);
            callComponentMethod = C1241runtime.callComponentMethod(Lit42, Lit290, LList.Empty, LList.Empty);
        } else {
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit286, Lit80, "हिंदी में देखें", Lit22);
            callComponentMethod = C1241runtime.callComponentMethod(Lit42, Lit290, LList.Empty, LList.Empty);
        }
        return callComponentMethod;
    }

    static Object lambda104() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit69, Lit294, Lit16);
    }

    static Object lambda105() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit69, Lit294, Lit16);
    }

    static Object lambda106() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit42, Lit71, Lit72, Lit16);
    }

    static Object lambda107() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit42, Lit71, Lit72, Lit16);
    }

    static Object lambda108() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit44, Lit17, Lit18, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit44, Lit71, Lit72, Lit16);
    }

    static Object lambda109() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit44, Lit17, Lit18, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit44, Lit71, Lit72, Lit16);
    }

    static Object lambda110() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit77, Lit302, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit80, "Useful Information", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit81, Lit36, Lit16);
    }

    static Object lambda111() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit77, Lit302, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit80, "Useful Information", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit301, Lit81, Lit36, Lit16);
    }

    static Object lambda112() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit305, Lit69, Lit306, Lit16);
    }

    static Object lambda113() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit305, Lit69, Lit306, Lit16);
    }

    static Object lambda114() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit67, Lit310, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda115() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit67, Lit310, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit309, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda116() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit313, Lit77, Lit314, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit313, Lit79, "Montserrat-Medium.ttf", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit313, Lit80, "ⓘ Help and Information", Lit22);
    }

    static Object lambda117() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit313, Lit77, Lit314, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit313, Lit79, "Montserrat-Medium.ttf", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit313, Lit80, "ⓘ Help and Information", Lit22);
    }

    static Object lambda118() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit317, Lit69, Lit318, Lit16);
    }

    static Object lambda119() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit317, Lit69, Lit318, Lit16);
    }

    static Object lambda120() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit321, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit321, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit321, Lit71, Lit72, Lit16);
    }

    static Object lambda121() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit321, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit321, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit321, Lit71, Lit72, Lit16);
    }

    static Object lambda122() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit77, Lit325, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit80, "Coronavirus information - India", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit81, Lit36, Lit16);
    }

    static Object lambda123() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit77, Lit325, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit80, "Coronavirus information - India", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit81, Lit36, Lit16);
    }

    static Object lambda124() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit80, "Ministry of Health and Family Welfare, Govt. of India", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit81, Lit36, Lit16);
    }

    static Object lambda125() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit80, "Ministry of Health and Family Welfare, Govt. of India", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit81, Lit36, Lit16);
    }

    static Object lambda126() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit331, Lit69, Lit332, Lit16);
    }

    static Object lambda127() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit331, Lit69, Lit332, Lit16);
    }

    static Object lambda128() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit56, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit56, Lit80, "https://www.mohfw.gov.in/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit56, Lit81, Lit36, Lit16);
    }

    static Object lambda129() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit56, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit56, Lit80, "https://www.mohfw.gov.in/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit56, Lit81, Lit36, Lit16);
    }

    static Object lambda130() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit337, Lit69, Lit338, Lit16);
    }

    static Object lambda131() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit337, Lit69, Lit338, Lit16);
    }

    static Object lambda132() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit80, "https://www.mygov.in/covid-19/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit81, Lit36, Lit16);
    }

    static Object lambda133() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit80, "https://www.mygov.in/covid-19/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit81, Lit36, Lit16);
    }

    static Object lambda134() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit77, Lit344, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit80, "The Helpline Number for corona-virus : +91-11-23978046 or 1075", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit81, Lit36, Lit16);
    }

    static Object lambda135() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit77, Lit344, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit80, "The Helpline Number for corona-virus : +91-11-23978046 or 1075", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit343, Lit81, Lit36, Lit16);
    }

    static Object lambda136() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit67, Lit351, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda137() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit67, Lit351, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit350, Lit73, Boolean.TRUE, Lit30);
    }

    public Object Horizontal_Arrangement16_copy$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen31"), Lit353, "open another screen");
    }

    static Object lambda138() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit80, "Co-WIN", Lit22);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit95, Lit357, Lit16);
    }

    static Object lambda139() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit80, "Co-WIN", Lit22);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit356, Lit95, Lit357, Lit16);
    }

    public Object Label29_copy$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen31"), Lit359, "open another screen");
    }

    static Object lambda140() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit46, Lit17, Lit18, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit46, Lit71, Lit72, Lit16);
    }

    static Object lambda141() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit46, Lit17, Lit18, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit46, Lit71, Lit72, Lit16);
    }

    static Object lambda142() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit77, Lit365, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit80, "उपयोगी जानकारी", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit81, Lit36, Lit16);
    }

    static Object lambda143() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit77, Lit365, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit80, "उपयोगी जानकारी", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit364, Lit81, Lit36, Lit16);
    }

    static Object lambda144() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit368, Lit69, Lit369, Lit16);
    }

    static Object lambda145() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit368, Lit69, Lit369, Lit16);
    }

    static Object lambda146() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit67, Lit373, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda147() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit67, Lit373, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit372, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda148() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit80, "ⓘ सहायता और सूचना", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit81, Lit36, Lit16);
    }

    static Object lambda149() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit80, "ⓘ सहायता और सूचना", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit81, Lit36, Lit16);
    }

    static Object lambda150() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit379, Lit69, Lit380, Lit16);
    }

    static Object lambda151() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit379, Lit69, Lit380, Lit16);
    }

    static Object lambda152() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit383, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit383, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit383, Lit71, Lit72, Lit16);
    }

    static Object lambda153() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit383, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit383, Lit19, Lit20, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit383, Lit71, Lit72, Lit16);
    }

    static Object lambda154() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit77, Lit325, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit80, "कोरोनावायरस सूचना - भारत", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit81, Lit36, Lit16);
    }

    static Object lambda155() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit77, Lit325, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit79, "Montserrat-Bold.ttf", Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit80, "कोरोनावायरस सूचना - भारत", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit386, Lit81, Lit36, Lit16);
    }

    static Object lambda156() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit389, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit389, Lit80, "स्वास्थ्य और परिवार कल्याण मंत्रालय, भारत सरकार", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit389, Lit81, Lit36, Lit16);
    }

    static Object lambda157() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit389, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit389, Lit80, "स्वास्थ्य और परिवार कल्याण मंत्रालय, भारत सरकार", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit389, Lit81, Lit36, Lit16);
    }

    static Object lambda158() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit392, Lit69, Lit393, Lit16);
    }

    static Object lambda159() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit392, Lit69, Lit393, Lit16);
    }

    static Object lambda160() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit58, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit58, Lit80, "https://www.mohfw.gov.in/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit58, Lit81, Lit36, Lit16);
    }

    static Object lambda161() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit58, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit58, Lit80, "https://www.mohfw.gov.in/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit58, Lit81, Lit36, Lit16);
    }

    static Object lambda162() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit398, Lit69, Lit399, Lit16);
    }

    static Object lambda163() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit398, Lit69, Lit399, Lit16);
    }

    static Object lambda164() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit80, "https://www.mygov.in/covid-19/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit81, Lit36, Lit16);
    }

    static Object lambda165() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit80, "https://www.mygov.in/covid-19/", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit81, Lit36, Lit16);
    }

    static Object lambda166() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit404, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit404, Lit80, "कोरोना-वायरस के लिए हेल्पलाइन नंबर: + 91-11-23978046 या 1075", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit404, Lit81, Lit36, Lit16);
    }

    static Object lambda167() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit404, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit404, Lit80, "कोरोना-वायरस के लिए हेल्पलाइन नंबर: + 91-11-23978046 या 1075", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit404, Lit81, Lit36, Lit16);
    }

    static Object lambda168() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit67, Lit411, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit73, Boolean.TRUE, Lit30);
    }

    static Object lambda169() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit19, Lit20, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit67, Lit411, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit90, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit410, Lit73, Boolean.TRUE, Lit30);
    }

    public Object Horizontal_Arrangement16_copy_copy$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen31"), Lit413, "open another screen");
    }

    static Object lambda170() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit77, Lit417, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit80, "को-विन", Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit95, Lit418, Lit16);
    }

    static Object lambda171() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit77, Lit417, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit69, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit80, "को-विन", Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit416, Lit95, Lit418, Lit16);
    }

    public Object Label29_copy_copy$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen31"), Lit420, "open another screen");
    }

    static Object lambda172() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit67, Lit423, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit71, Lit72, Lit16);
    }

    static Object lambda173() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit67, Lit423, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit71, Lit72, Lit16);
    }

    static Object lambda174() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit427, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit80, "X", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit81, Lit20, Lit16);
    }

    static Object lambda175() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit427, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit77, Lit266, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit80, "X", Lit22);
        return C1241runtime.setAndCoerceProperty$Ex(Lit426, Lit81, Lit20, Lit16);
    }

    public Object Label35$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit11, Lit268, LList.Empty, LList.Empty);
    }

    static Object lambda176() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit77, Lit344, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit69, Lit432, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit80, "© COV-AID, 2021", Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit95, Lit433, Lit16);
    }

    static Object lambda177() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit116, Boolean.TRUE, Lit30);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit77, Lit344, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit79, "Montserrat-Medium.ttf", Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit69, Lit432, Lit16);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit71, Lit72, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit80, "© COV-AID, 2021", Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit81, Lit36, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit431, Lit95, Lit433, Lit16);
    }

    static Object lambda178() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit436, Lit437, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit436, Lit438, Boolean.TRUE, Lit30);
    }

    static Object lambda179() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit436, Lit437, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit436, Lit438, Boolean.TRUE, Lit30);
    }

    static Object lambda180() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit443, Lit437, Boolean.TRUE, Lit30);
    }

    static Object lambda181() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit443, Lit437, Boolean.TRUE, Lit30);
    }

    static Object lambda182() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit437, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit438, Boolean.TRUE, Lit30);
    }

    static Object lambda183() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit437, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit438, Boolean.TRUE, Lit30);
    }

    static Object lambda184() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit437, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit438, Boolean.TRUE, Lit30);
    }

    static Object lambda185() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit437, Boolean.TRUE, Lit30);
        return C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit438, Boolean.TRUE, Lit30);
    }

    static Object lambda186() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit457, Lit437, Boolean.TRUE, Lit30);
    }

    static Object lambda187() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit457, Lit437, Boolean.TRUE, Lit30);
    }

    static Object lambda188() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit460, Lit67, Lit461, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit460, Lit462, "feedback", Lit22);
    }

    static Object lambda189() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit460, Lit67, Lit461, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit460, Lit462, "feedback", Lit22);
    }

    public Object Floating_Action_Button1$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("feedback"), Lit464, "open another screen");
    }

    public Object Floating_Action_Button1$LongClick() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("feedback"), Lit466, "open another screen");
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.form$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name = symbol;
        Object default$Mnvalue = obj;
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & true;
        if (!x ? !x : !this.form$Mnenvironment.isBound(name)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = C1271lists.cons(C1271lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = C1271lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = C1271lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = C1271lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        Object obj = error;
        RetValManager.sendError(obj == null ? null : obj.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        objArr2[0] = "any$";
        Object[] objArr3 = objArr2;
        objArr3[1] = getSimpleName(componentObject);
        Object[] objArr4 = objArr3;
        objArr4[2] = "$";
        Object[] objArr5 = objArr4;
        objArr5[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr5)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1271lists.cons(component2, C1271lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object componentName, Object obj) {
        Object eventName = obj;
        Object obj2 = componentName;
        String obj3 = obj2 == null ? null : obj2.toString();
        Object obj4 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj3, obj4 == null ? null : obj4.toString())));
    }

    public void $define() {
        Object obj;
        Throwable th;
        Object obj2;
        Throwable th2;
        Object obj3;
        Throwable th3;
        Object obj4;
        Throwable th4;
        Object obj5;
        Throwable th5;
        Object obj6;
        Throwable th6;
        Object obj7;
        Throwable th7;
        Object obj8;
        Throwable th8;
        Throwable th9;
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception e) {
            Exception exception = e;
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        home = this;
        addToFormEnvironment(Lit0, this);
        Object obj9 = this.events$Mnto$Mnregister;
        while (true) {
            Object obj10 = obj9;
            if (obj10 == LList.Empty) {
                break;
            }
            Object obj11 = obj10;
            Object obj12 = obj11;
            try {
                Pair arg0 = (Pair) obj11;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = C1271lists.car.apply1(event$Mninfo);
                String obj13 = apply1 == null ? null : apply1.toString();
                Object apply12 = C1271lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj13, apply12 == null ? null : apply12.toString());
                obj9 = arg0.getCdr();
            } catch (ClassCastException e2) {
                ClassCastException classCastException = e2;
                Throwable th10 = th9;
                new WrongType(classCastException, "arg0", -2, obj12);
                throw th10;
            }
        }
        try {
            LList components = C1271lists.reverse(this.components$Mnto$Mncreate);
            addToGlobalVars(Lit2, lambda$Fn1);
            LList event$Mninfo2 = components;
            while (event$Mninfo2 != LList.Empty) {
                Object obj14 = event$Mninfo2;
                obj6 = obj14;
                Pair arg02 = (Pair) obj14;
                Object component$Mninfo = arg02.getCar();
                Object apply13 = C1271lists.caddr.apply1(component$Mninfo);
                Object apply14 = C1271lists.cadddr.apply1(component$Mninfo);
                Object component$Mntype = C1271lists.cadr.apply1(component$Mninfo);
                Object apply15 = C1271lists.car.apply1(component$Mninfo);
                obj7 = apply15;
                Object component$Mnname = apply13;
                Object component$Mnobject = Invoke.make.apply2(component$Mntype, lookupInFormEnvironment((Symbol) apply15));
                Object apply3 = SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
                Object obj15 = component$Mnname;
                obj8 = obj15;
                addToFormEnvironment((Symbol) obj15, component$Mnobject);
                event$Mninfo2 = arg02.getCdr();
            }
            LList reverse = C1271lists.reverse(this.global$Mnvars$Mnto$Mncreate);
            while (reverse != LList.Empty) {
                Object obj16 = reverse;
                obj4 = obj16;
                Pair arg03 = (Pair) obj16;
                Object var$Mnval = arg03.getCar();
                Object apply16 = C1271lists.car.apply1(var$Mnval);
                obj5 = apply16;
                addToGlobalVarEnvironment((Symbol) apply16, Scheme.applyToArgs.apply1(C1271lists.cadr.apply1(var$Mnval)));
                reverse = arg03.getCdr();
            }
            Object reverse2 = C1271lists.reverse(this.form$Mndo$Mnafter$Mncreation);
            while (reverse2 != LList.Empty) {
                Object obj17 = reverse2;
                obj3 = obj17;
                Pair arg04 = (Pair) obj17;
                Object force = misc.force(arg04.getCar());
                reverse2 = arg04.getCdr();
            }
            LList component$Mndescriptors = components;
            LList lList = component$Mndescriptors;
            while (lList != LList.Empty) {
                Object obj18 = lList;
                obj2 = obj18;
                Pair arg05 = (Pair) obj18;
                Object component$Mninfo2 = arg05.getCar();
                Object apply17 = C1271lists.caddr.apply1(component$Mninfo2);
                Object init$Mnthunk = C1271lists.cadddr.apply1(component$Mninfo2);
                if (init$Mnthunk != Boolean.FALSE) {
                    Object apply18 = Scheme.applyToArgs.apply1(init$Mnthunk);
                }
                lList = arg05.getCdr();
            }
            LList lList2 = component$Mndescriptors;
            while (lList2 != LList.Empty) {
                Object obj19 = lList2;
                obj = obj19;
                Pair arg06 = (Pair) obj19;
                Object component$Mninfo3 = arg06.getCar();
                Object component$Mnname2 = C1271lists.caddr.apply1(component$Mninfo3);
                Object apply19 = C1271lists.cadddr.apply1(component$Mninfo3);
                callInitialize(SlotGet.field.apply2(this, component$Mnname2));
                lList2 = arg06.getCdr();
            }
        } catch (ClassCastException e3) {
            ClassCastException classCastException2 = e3;
            Throwable th11 = th;
            new WrongType(classCastException2, "arg0", -2, obj);
            throw th11;
        } catch (ClassCastException e4) {
            ClassCastException classCastException3 = e4;
            Throwable th12 = th2;
            new WrongType(classCastException3, "arg0", -2, obj2);
            throw th12;
        } catch (ClassCastException e5) {
            ClassCastException classCastException4 = e5;
            Throwable th13 = th3;
            new WrongType(classCastException4, "arg0", -2, obj3);
            throw th13;
        } catch (ClassCastException e6) {
            ClassCastException classCastException5 = e6;
            Throwable th14 = th5;
            new WrongType(classCastException5, "add-to-global-var-environment", 0, obj5);
            throw th14;
        } catch (ClassCastException e7) {
            ClassCastException classCastException6 = e7;
            Throwable th15 = th4;
            new WrongType(classCastException6, "arg0", -2, obj4);
            throw th15;
        } catch (ClassCastException e8) {
            ClassCastException classCastException7 = e8;
            Throwable th16 = th8;
            new WrongType(classCastException7, "add-to-form-environment", 0, obj8);
            throw th16;
        } catch (ClassCastException e9) {
            ClassCastException classCastException8 = e9;
            Throwable th17 = th7;
            new WrongType(classCastException8, "lookup-in-form-environment", 0, obj7);
            throw th17;
        } catch (ClassCastException e10) {
            ClassCastException classCastException9 = e10;
            Throwable th18 = th6;
            new WrongType(classCastException9, "arg0", -2, obj6);
            throw th18;
        } catch (YailRuntimeError e11) {
            processException(e11);
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        LList symbols = LList.makeList(argsArray, 0);
        LList lList = symbols;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj = symbols;
        Object obj2 = LList.Empty;
        while (true) {
            Object obj3 = obj2;
            Object obj4 = obj;
            if (obj4 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj3));
                Object obj5 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    Throwable th4 = th;
                    new WrongType(classCastException, "string->symbol", 1, obj5);
                    throw th4;
                }
            } else {
                Object obj6 = obj4;
                Object obj7 = obj6;
                try {
                    Pair arg0 = (Pair) obj6;
                    obj = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj8 = car;
                    try {
                        obj2 = Pair.make(misc.symbol$To$String((Symbol) car), obj3);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th3;
                        new WrongType(classCastException2, "symbol->string", 1, obj8);
                        throw th5;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    Throwable th6 = th2;
                    new WrongType(classCastException3, "arg0", -2, obj7);
                    throw th6;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
