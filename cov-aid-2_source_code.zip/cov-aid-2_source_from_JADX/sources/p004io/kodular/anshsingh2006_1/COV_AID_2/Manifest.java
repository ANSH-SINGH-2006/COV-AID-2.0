package p004io.kodular.anshsingh2006_1.COV_AID_2;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Manifest */
public final class Manifest {

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Manifest$permission */
    public static final class permission {
        public static final String C2D_MESSAGE = "io.kodular.anshsingh2006_1.COV_AID_2.permission.C2D_MESSAGE";

        public permission() {
        }
    }

    public Manifest() {
    }
}
