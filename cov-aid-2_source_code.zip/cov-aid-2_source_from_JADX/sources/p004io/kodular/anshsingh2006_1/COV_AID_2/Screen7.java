package p004io.kodular.anshsingh2006_1.COV_AID_2;

import android.support.p000v4.app.FragmentTransaction;
import android.support.p000v4.app.NotificationCompat;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.ListView;
import com.google.appinventor.components.runtime.MakeroidCircularProgress;
import com.google.appinventor.components.runtime.MakeroidFab;
import com.google.appinventor.components.runtime.MakeroidListViewImageText;
import com.google.appinventor.components.runtime.MakeroidViewPager;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1241runtime;
import com.microsoft.appcenter.ingestion.models.CommonProperties;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.C1271lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import org.jose4j.jws.AlgorithmIdentifiers;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen7 */
/* compiled from: Screen7.yail */
public class Screen7 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final PairWithPosition Lit100 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415720), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415714);
    static final PairWithPosition Lit101 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415757), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415751);
    static final SimpleSymbol Lit102;
    static final PairWithPosition Lit103 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 416020), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 416014);
    static final PairWithPosition Lit104 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 416057), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 416051);
    static final SimpleSymbol Lit105;
    static final SimpleSymbol Lit106;
    static final SimpleSymbol Lit107;
    static final FString Lit108;
    static final IntNum Lit109;
    static final SimpleSymbol Lit11;
    static final FString Lit110;
    static final FString Lit111;
    static final SimpleSymbol Lit112;
    static final IntNum Lit113;
    static final SimpleSymbol Lit114;
    static final SimpleSymbol Lit115;
    static final IntNum Lit116 = IntNum.make(7);
    static final FString Lit117;
    static final SimpleSymbol Lit118;
    static final SimpleSymbol Lit119;
    static final SimpleSymbol Lit12;
    static final SimpleSymbol Lit120;
    static final FString Lit121;
    static final SimpleSymbol Lit122;
    static final FString Lit123;
    static final FString Lit124;
    static final SimpleSymbol Lit125;
    static final IntNum Lit126 = IntNum.make(20);
    static final IntNum Lit127;
    static final FString Lit128;
    static final FString Lit129;
    static final SimpleSymbol Lit13;
    static final SimpleSymbol Lit130;
    static final FString Lit131;
    static final FString Lit132;
    static final IntNum Lit133;
    static final FString Lit134;
    static final FString Lit135;
    static final SimpleSymbol Lit136;
    static final FString Lit137;
    static final FString Lit138;
    static final IntNum Lit139;
    static final SimpleSymbol Lit14;
    static final FString Lit140;
    static final FString Lit141;
    static final SimpleSymbol Lit142;
    static final FString Lit143;
    static final FString Lit144;
    static final IntNum Lit145;
    static final FString Lit146;
    static final FString Lit147;
    static final SimpleSymbol Lit148;
    static final FString Lit149;
    static final IntNum Lit15;
    static final FString Lit150;
    static final IntNum Lit151;
    static final FString Lit152;
    static final FString Lit153;
    static final SimpleSymbol Lit154;
    static final FString Lit155;
    static final FString Lit156;
    static final IntNum Lit157;
    static final FString Lit158;
    static final FString Lit159;
    static final SimpleSymbol Lit16;
    static final SimpleSymbol Lit160;
    static final FString Lit161;
    static final FString Lit162;
    static final IntNum Lit163;
    static final FString Lit164;
    static final FString Lit165;
    static final SimpleSymbol Lit166;
    static final FString Lit167;
    static final FString Lit168;
    static final IntNum Lit169;
    static final SimpleSymbol Lit17;
    static final FString Lit170;
    static final FString Lit171;
    static final FString Lit172;
    static final SimpleSymbol Lit173;
    static final PairWithPosition Lit174 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1056890);
    static final IntNum Lit175 = IntNum.make(8);
    static final PairWithPosition Lit176 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057009), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057003);
    static final IntNum Lit177 = IntNum.make(1);
    static final PairWithPosition Lit178 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057125), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057119);
    static final IntNum Lit179 = IntNum.make(2);
    static final IntNum Lit18 = IntNum.make(3);
    static final PairWithPosition Lit180 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057241), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057235);
    static final PairWithPosition Lit181 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057357), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057351);
    static final IntNum Lit182 = IntNum.make(4);
    static final PairWithPosition Lit183 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057473), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057467);
    static final IntNum Lit184 = IntNum.make(5);
    static final PairWithPosition Lit185 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057589), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057583);
    static final IntNum Lit186 = IntNum.make(6);
    static final PairWithPosition Lit187 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057705), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057699);
    static final PairWithPosition Lit188 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057821), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057815);
    static final PairWithPosition Lit189 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057937), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1057931);
    static final SimpleSymbol Lit19;
    static final IntNum Lit190 = IntNum.make(9);
    static final PairWithPosition Lit191 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058053), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058047);
    static final PairWithPosition Lit192 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058169), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058163);
    static final PairWithPosition Lit193 = PairWithPosition.make(Lit214, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058378);
    static final PairWithPosition Lit194 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058411), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058405);
    static final SimpleSymbol Lit195;
    static final PairWithPosition Lit196 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058643), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058637);
    static final PairWithPosition Lit197 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058680), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058674);
    static final PairWithPosition Lit198 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058882), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058876);
    static final PairWithPosition Lit199 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058919), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1058913);
    static final SimpleSymbol Lit2;
    static final SimpleSymbol Lit20;
    static final PairWithPosition Lit200 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059119), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059113);
    static final PairWithPosition Lit201 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059156), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059150);
    static final PairWithPosition Lit202 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059359), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059353);
    static final PairWithPosition Lit203 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059396), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059390);
    static final PairWithPosition Lit204 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059597), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059591);
    static final PairWithPosition Lit205 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059634), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059628);
    static final PairWithPosition Lit206 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059836), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059830);
    static final PairWithPosition Lit207 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059873), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1059867);
    static final PairWithPosition Lit208 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060076), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060070);
    static final PairWithPosition Lit209 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060113), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060107);
    static final SimpleSymbol Lit21;
    static final PairWithPosition Lit210 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060312), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060306);
    static final PairWithPosition Lit211 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit252, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060349), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060343);
    static final SimpleSymbol Lit212;
    static final SimpleSymbol Lit213;
    static final SimpleSymbol Lit214;
    static final SimpleSymbol Lit215;
    static final SimpleSymbol Lit216;
    static final PairWithPosition Lit217 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060765), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060759);
    static final PairWithPosition Lit218;
    static final PairWithPosition Lit219 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060947), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060942), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060936);
    static final SimpleSymbol Lit22;
    static final PairWithPosition Lit220;
    static final SimpleSymbol Lit221;
    static final SimpleSymbol Lit222;
    static final FString Lit223;
    static final FString Lit224;
    static final FString Lit225;
    static final SimpleSymbol Lit226;
    static final IntNum Lit227;
    static final SimpleSymbol Lit228;
    static final SimpleSymbol Lit229;
    static final IntNum Lit23;
    static final FString Lit230;
    static final SimpleSymbol Lit231;
    static final PairWithPosition Lit232 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1130599);
    static final SimpleSymbol Lit233;
    static final PairWithPosition Lit234;
    static final SimpleSymbol Lit235;
    static final SimpleSymbol Lit236;
    static final SimpleSymbol Lit237;
    static final SimpleSymbol Lit238;
    static final SimpleSymbol Lit239;
    static final SimpleSymbol Lit24;
    static final SimpleSymbol Lit240;
    static final SimpleSymbol Lit241;
    static final SimpleSymbol Lit242;
    static final SimpleSymbol Lit243;
    static final SimpleSymbol Lit244;
    static final SimpleSymbol Lit245;
    static final SimpleSymbol Lit246;
    static final SimpleSymbol Lit247;
    static final SimpleSymbol Lit248;
    static final SimpleSymbol Lit249;
    static final IntNum Lit25;
    static final SimpleSymbol Lit250;
    static final SimpleSymbol Lit251;
    static final SimpleSymbol Lit252;
    static final SimpleSymbol Lit253;
    static final SimpleSymbol Lit26;
    static final IntNum Lit27;
    static final SimpleSymbol Lit28;
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final SimpleSymbol Lit31;
    static final SimpleSymbol Lit32;
    static final SimpleSymbol Lit33;
    static final SimpleSymbol Lit34;
    static final SimpleSymbol Lit35;
    static final SimpleSymbol Lit36;
    static final SimpleSymbol Lit37;
    static final PairWithPosition Lit38 = PairWithPosition.make(Lit253, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139610), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139599);
    static final SimpleSymbol Lit39;
    static final SimpleSymbol Lit4;
    static final PairWithPosition Lit40 = PairWithPosition.make(Lit253, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139754), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139743);
    static final SimpleSymbol Lit41;
    static final SimpleSymbol Lit42;
    static final SimpleSymbol Lit43;
    static final PairWithPosition Lit44;
    static final SimpleSymbol Lit45;
    static final SimpleSymbol Lit46;
    static final FString Lit47;
    static final SimpleSymbol Lit48;
    static final IntNum Lit49;
    static final SimpleSymbol Lit5;
    static final SimpleSymbol Lit50;
    static final IntNum Lit51;
    static final FString Lit52;
    static final FString Lit53;
    static final SimpleSymbol Lit54;
    static final IntNum Lit55 = IntNum.make(-2);
    static final SimpleSymbol Lit56;
    static final FString Lit57;
    static final FString Lit58;
    static final SimpleSymbol Lit59;
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final IntNum Lit61;
    static final FString Lit62;
    static final FString Lit63;
    static final SimpleSymbol Lit64;
    static final FString Lit65;
    static final FString Lit66;
    static final SimpleSymbol Lit67;
    static final SimpleSymbol Lit68;
    static final FString Lit69;
    static final SimpleSymbol Lit7;
    static final FString Lit70;
    static final FString Lit71;
    static final FString Lit72;
    static final SimpleSymbol Lit73;
    static final IntNum Lit74;
    static final SimpleSymbol Lit75;
    static final SimpleSymbol Lit76;
    static final IntNum Lit77;
    static final FString Lit78;
    static final SimpleSymbol Lit79;
    static final SimpleSymbol Lit8;
    static final SimpleSymbol Lit80;
    static final SimpleSymbol Lit81;
    static final PairWithPosition Lit82 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 413935), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 413929);
    static final PairWithPosition Lit83 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 413972), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 413966);
    static final SimpleSymbol Lit84;
    static final PairWithPosition Lit85 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414230), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414224);
    static final PairWithPosition Lit86 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414267), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414261);
    static final SimpleSymbol Lit87;
    static final PairWithPosition Lit88 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414521), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414515);
    static final PairWithPosition Lit89 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414558), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414552);
    static final SimpleSymbol Lit9;
    static final SimpleSymbol Lit90;
    static final PairWithPosition Lit91 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414817), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414811);
    static final PairWithPosition Lit92 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414854), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 414848);
    static final SimpleSymbol Lit93;
    static final PairWithPosition Lit94 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415111), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415105);
    static final PairWithPosition Lit95 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415148), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415142);
    static final SimpleSymbol Lit96;
    static final PairWithPosition Lit97 = PairWithPosition.make(Lit214, PairWithPosition.make(Lit16, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415408), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415402);
    static final PairWithPosition Lit98 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415445), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 415439);
    static final SimpleSymbol Lit99;
    public static Screen7 Screen7;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn31 = null;
    static final ModuleMethod lambda$Fn32 = null;
    static final ModuleMethod lambda$Fn33 = null;
    static final ModuleMethod lambda$Fn34 = null;
    static final ModuleMethod lambda$Fn35 = null;
    static final ModuleMethod lambda$Fn36 = null;
    static final ModuleMethod lambda$Fn37 = null;
    static final ModuleMethod lambda$Fn38 = null;
    static final ModuleMethod lambda$Fn39 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn40 = null;
    static final ModuleMethod lambda$Fn41 = null;
    static final ModuleMethod lambda$Fn42 = null;
    static final ModuleMethod lambda$Fn43 = null;
    static final ModuleMethod lambda$Fn44 = null;
    static final ModuleMethod lambda$Fn45 = null;
    static final ModuleMethod lambda$Fn46 = null;
    static final ModuleMethod lambda$Fn47 = null;
    static final ModuleMethod lambda$Fn48 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn50 = null;
    static final ModuleMethod lambda$Fn51 = null;
    static final ModuleMethod lambda$Fn52 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn9 = null;
    static final ModuleMethod proc$Fn49 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public Button Button1;
    public final ModuleMethod Button1$Click;
    public MakeroidCircularProgress Circular_Progress1;
    public MakeroidFab Floating_Action_Button1;
    public final ModuleMethod Floating_Action_Button1$Click;
    public final ModuleMethod Floating_Action_Button1$LongClick;
    public HorizontalArrangement Horizontal_Arrangement1_copy;
    public Label Label10;
    public Label Label12;
    public Label Label14;
    public Label Label2;
    public Label Label20;
    public Label Label4;
    public Label Label6;
    public Label Label8;
    public ListView List_View1;
    public final ModuleMethod List_View1$AfterPicking;
    public MakeroidListViewImageText List_View_Image_and_Text1;
    public Notifier Notifier1;
    public final ModuleMethod Screen7$Initialize;
    public VerticalArrangement Vertical_Arrangement1;
    public VerticalArrangement Vertical_Arrangement2;
    public VerticalScrollArrangement Vertical_Scroll_Arrangement1;
    public MakeroidViewPager View_Pager1;
    public Web Web1;
    public final ModuleMethod Web1$GotText;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public Label cans;
    public LList components$Mnto$Mncreate;
    public Label contact;
    public Label cylinder;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public Label location;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public Label name;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;
    public Label state;
    public Label status;
    public Label updated;

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        SimpleSymbol simpleSymbol15;
        SimpleSymbol simpleSymbol16;
        SimpleSymbol simpleSymbol17;
        SimpleSymbol simpleSymbol18;
        SimpleSymbol simpleSymbol19;
        SimpleSymbol simpleSymbol20;
        SimpleSymbol simpleSymbol21;
        SimpleSymbol simpleSymbol22;
        FString fString;
        SimpleSymbol simpleSymbol23;
        SimpleSymbol simpleSymbol24;
        SimpleSymbol simpleSymbol25;
        FString fString2;
        FString fString3;
        FString fString4;
        SimpleSymbol simpleSymbol26;
        SimpleSymbol simpleSymbol27;
        SimpleSymbol simpleSymbol28;
        SimpleSymbol simpleSymbol29;
        SimpleSymbol simpleSymbol30;
        SimpleSymbol simpleSymbol31;
        SimpleSymbol simpleSymbol32;
        SimpleSymbol simpleSymbol33;
        SimpleSymbol simpleSymbol34;
        SimpleSymbol simpleSymbol35;
        FString fString5;
        FString fString6;
        FString fString7;
        FString fString8;
        FString fString9;
        SimpleSymbol simpleSymbol36;
        FString fString10;
        FString fString11;
        FString fString12;
        FString fString13;
        SimpleSymbol simpleSymbol37;
        FString fString14;
        FString fString15;
        FString fString16;
        FString fString17;
        SimpleSymbol simpleSymbol38;
        FString fString18;
        FString fString19;
        FString fString20;
        FString fString21;
        SimpleSymbol simpleSymbol39;
        FString fString22;
        FString fString23;
        FString fString24;
        FString fString25;
        SimpleSymbol simpleSymbol40;
        FString fString26;
        FString fString27;
        FString fString28;
        FString fString29;
        SimpleSymbol simpleSymbol41;
        FString fString30;
        FString fString31;
        FString fString32;
        FString fString33;
        SimpleSymbol simpleSymbol42;
        FString fString34;
        FString fString35;
        SimpleSymbol simpleSymbol43;
        FString fString36;
        FString fString37;
        SimpleSymbol simpleSymbol44;
        FString fString38;
        SimpleSymbol simpleSymbol45;
        SimpleSymbol simpleSymbol46;
        SimpleSymbol simpleSymbol47;
        FString fString39;
        SimpleSymbol simpleSymbol48;
        SimpleSymbol simpleSymbol49;
        SimpleSymbol simpleSymbol50;
        FString fString40;
        FString fString41;
        FString fString42;
        SimpleSymbol simpleSymbol51;
        SimpleSymbol simpleSymbol52;
        SimpleSymbol simpleSymbol53;
        SimpleSymbol simpleSymbol54;
        SimpleSymbol simpleSymbol55;
        SimpleSymbol simpleSymbol56;
        SimpleSymbol simpleSymbol57;
        SimpleSymbol simpleSymbol58;
        SimpleSymbol simpleSymbol59;
        SimpleSymbol simpleSymbol60;
        SimpleSymbol simpleSymbol61;
        SimpleSymbol simpleSymbol62;
        SimpleSymbol simpleSymbol63;
        FString fString43;
        SimpleSymbol simpleSymbol64;
        SimpleSymbol simpleSymbol65;
        SimpleSymbol simpleSymbol66;
        FString fString44;
        FString fString45;
        FString fString46;
        FString fString47;
        SimpleSymbol simpleSymbol67;
        SimpleSymbol simpleSymbol68;
        FString fString48;
        FString fString49;
        SimpleSymbol simpleSymbol69;
        FString fString50;
        FString fString51;
        SimpleSymbol simpleSymbol70;
        SimpleSymbol simpleSymbol71;
        FString fString52;
        FString fString53;
        SimpleSymbol simpleSymbol72;
        SimpleSymbol simpleSymbol73;
        FString fString54;
        FString fString55;
        SimpleSymbol simpleSymbol74;
        SimpleSymbol simpleSymbol75;
        FString fString56;
        SimpleSymbol simpleSymbol76;
        SimpleSymbol simpleSymbol77;
        SimpleSymbol simpleSymbol78;
        SimpleSymbol simpleSymbol79;
        SimpleSymbol simpleSymbol80;
        SimpleSymbol simpleSymbol81;
        SimpleSymbol simpleSymbol82;
        SimpleSymbol simpleSymbol83;
        SimpleSymbol simpleSymbol84;
        SimpleSymbol simpleSymbol85;
        SimpleSymbol simpleSymbol86;
        SimpleSymbol simpleSymbol87;
        SimpleSymbol simpleSymbol88;
        SimpleSymbol simpleSymbol89;
        SimpleSymbol simpleSymbol90;
        SimpleSymbol simpleSymbol91;
        SimpleSymbol simpleSymbol92;
        SimpleSymbol simpleSymbol93;
        SimpleSymbol simpleSymbol94;
        SimpleSymbol simpleSymbol95;
        SimpleSymbol simpleSymbol96;
        SimpleSymbol simpleSymbol97;
        SimpleSymbol simpleSymbol98;
        SimpleSymbol simpleSymbol99;
        SimpleSymbol simpleSymbol100;
        SimpleSymbol simpleSymbol101;
        SimpleSymbol simpleSymbol102;
        SimpleSymbol simpleSymbol103;
        SimpleSymbol simpleSymbol104;
        SimpleSymbol simpleSymbol105;
        SimpleSymbol simpleSymbol106;
        SimpleSymbol simpleSymbol107;
        SimpleSymbol simpleSymbol108;
        SimpleSymbol simpleSymbol109;
        SimpleSymbol simpleSymbol110;
        SimpleSymbol simpleSymbol111;
        SimpleSymbol simpleSymbol112;
        new SimpleSymbol("component");
        Lit253 = (SimpleSymbol) simpleSymbol.readResolve();
        new SimpleSymbol("any");
        Lit252 = (SimpleSymbol) simpleSymbol2.readResolve();
        new SimpleSymbol("proc");
        Lit251 = (SimpleSymbol) simpleSymbol3.readResolve();
        new SimpleSymbol("lookup-handler");
        Lit250 = (SimpleSymbol) simpleSymbol4.readResolve();
        new SimpleSymbol("dispatchGenericEvent");
        Lit249 = (SimpleSymbol) simpleSymbol5.readResolve();
        new SimpleSymbol("dispatchEvent");
        Lit248 = (SimpleSymbol) simpleSymbol6.readResolve();
        new SimpleSymbol("send-error");
        Lit247 = (SimpleSymbol) simpleSymbol7.readResolve();
        new SimpleSymbol("add-to-form-do-after-creation");
        Lit246 = (SimpleSymbol) simpleSymbol8.readResolve();
        new SimpleSymbol("add-to-global-vars");
        Lit245 = (SimpleSymbol) simpleSymbol9.readResolve();
        new SimpleSymbol("add-to-components");
        Lit244 = (SimpleSymbol) simpleSymbol10.readResolve();
        new SimpleSymbol("add-to-events");
        Lit243 = (SimpleSymbol) simpleSymbol11.readResolve();
        new SimpleSymbol("add-to-global-var-environment");
        Lit242 = (SimpleSymbol) simpleSymbol12.readResolve();
        new SimpleSymbol("is-bound-in-form-environment");
        Lit241 = (SimpleSymbol) simpleSymbol13.readResolve();
        new SimpleSymbol("lookup-in-form-environment");
        Lit240 = (SimpleSymbol) simpleSymbol14.readResolve();
        new SimpleSymbol("add-to-form-environment");
        Lit239 = (SimpleSymbol) simpleSymbol15.readResolve();
        new SimpleSymbol("android-log-form");
        Lit238 = (SimpleSymbol) simpleSymbol16.readResolve();
        new SimpleSymbol("get-simple-name");
        Lit237 = (SimpleSymbol) simpleSymbol17.readResolve();
        new SimpleSymbol("LongClick");
        Lit236 = (SimpleSymbol) simpleSymbol18.readResolve();
        new SimpleSymbol("Floating_Action_Button1$LongClick");
        Lit235 = (SimpleSymbol) simpleSymbol19.readResolve();
        new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol113 = (SimpleSymbol) simpleSymbol20.readResolve();
        Lit20 = simpleSymbol113;
        Lit234 = PairWithPosition.make(simpleSymbol113, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1138791);
        new SimpleSymbol("Floating_Action_Button1$Click");
        Lit233 = (SimpleSymbol) simpleSymbol21.readResolve();
        new SimpleSymbol("ShowAlert");
        Lit231 = (SimpleSymbol) simpleSymbol22.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidFab");
        Lit230 = fString;
        new SimpleSymbol("IconName");
        Lit229 = (SimpleSymbol) simpleSymbol23.readResolve();
        new SimpleSymbol("Icon");
        Lit228 = (SimpleSymbol) simpleSymbol24.readResolve();
        int[] iArr = new int[2];
        iArr[0] = -769226;
        Lit227 = IntNum.make(iArr);
        new SimpleSymbol("Floating_Action_Button1");
        Lit226 = (SimpleSymbol) simpleSymbol25.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidFab");
        Lit225 = fString2;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit224 = fString3;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit223 = fString4;
        new SimpleSymbol("GotText");
        Lit222 = (SimpleSymbol) simpleSymbol26.readResolve();
        new SimpleSymbol("Web1$GotText");
        Lit221 = (SimpleSymbol) simpleSymbol27.readResolve();
        new SimpleSymbol("list");
        SimpleSymbol simpleSymbol114 = (SimpleSymbol) simpleSymbol28.readResolve();
        Lit214 = simpleSymbol114;
        Lit220 = PairWithPosition.make(simpleSymbol114, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1061035);
        SimpleSymbol simpleSymbol115 = Lit214;
        new SimpleSymbol("number");
        SimpleSymbol simpleSymbol116 = (SimpleSymbol) simpleSymbol29.readResolve();
        Lit16 = simpleSymbol116;
        Lit218 = PairWithPosition.make(simpleSymbol115, PairWithPosition.make(simpleSymbol116, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060906), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 1060900);
        new SimpleSymbol("$number");
        Lit216 = (SimpleSymbol) simpleSymbol30.readResolve();
        new SimpleSymbol("AddItem");
        Lit215 = (SimpleSymbol) simpleSymbol31.readResolve();
        new SimpleSymbol("Elements");
        Lit213 = (SimpleSymbol) simpleSymbol32.readResolve();
        new SimpleSymbol("Visible");
        Lit212 = (SimpleSymbol) simpleSymbol33.readResolve();
        new SimpleSymbol("$item");
        Lit195 = (SimpleSymbol) simpleSymbol34.readResolve();
        new SimpleSymbol("$responseContent");
        Lit173 = (SimpleSymbol) simpleSymbol35.readResolve();
        new FString("com.google.appinventor.components.runtime.Web");
        Lit172 = fString5;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit171 = fString6;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit170 = fString7;
        int[] iArr2 = new int[2];
        iArr2[0] = -769226;
        Lit169 = IntNum.make(iArr2);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit168 = fString8;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit167 = fString9;
        new SimpleSymbol("Label14");
        Lit166 = (SimpleSymbol) simpleSymbol36.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit165 = fString10;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit164 = fString11;
        int[] iArr3 = new int[2];
        iArr3[0] = -769226;
        Lit163 = IntNum.make(iArr3);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit162 = fString12;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit161 = fString13;
        new SimpleSymbol("Label12");
        Lit160 = (SimpleSymbol) simpleSymbol37.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit159 = fString14;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit158 = fString15;
        int[] iArr4 = new int[2];
        iArr4[0] = -769226;
        Lit157 = IntNum.make(iArr4);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit156 = fString16;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit155 = fString17;
        new SimpleSymbol("Label10");
        Lit154 = (SimpleSymbol) simpleSymbol38.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit153 = fString18;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit152 = fString19;
        int[] iArr5 = new int[2];
        iArr5[0] = -769226;
        Lit151 = IntNum.make(iArr5);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit150 = fString20;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit149 = fString21;
        new SimpleSymbol("Label8");
        Lit148 = (SimpleSymbol) simpleSymbol39.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit147 = fString22;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit146 = fString23;
        int[] iArr6 = new int[2];
        iArr6[0] = -769226;
        Lit145 = IntNum.make(iArr6);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit144 = fString24;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit143 = fString25;
        new SimpleSymbol("Label6");
        Lit142 = (SimpleSymbol) simpleSymbol40.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit141 = fString26;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit140 = fString27;
        int[] iArr7 = new int[2];
        iArr7[0] = -769226;
        Lit139 = IntNum.make(iArr7);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit138 = fString28;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit137 = fString29;
        new SimpleSymbol("Label4");
        Lit136 = (SimpleSymbol) simpleSymbol41.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit135 = fString30;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit134 = fString31;
        int[] iArr8 = new int[2];
        iArr8[0] = -769226;
        Lit133 = IntNum.make(iArr8);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit132 = fString32;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit131 = fString33;
        new SimpleSymbol("Label2");
        Lit130 = (SimpleSymbol) simpleSymbol42.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit129 = fString34;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit128 = fString35;
        int[] iArr9 = new int[2];
        iArr9[0] = -769226;
        Lit127 = IntNum.make(iArr9);
        new SimpleSymbol("FontSize");
        Lit125 = (SimpleSymbol) simpleSymbol43.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit124 = fString36;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit123 = fString37;
        new SimpleSymbol("Label20");
        Lit122 = (SimpleSymbol) simpleSymbol44.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit121 = fString38;
        new SimpleSymbol("Click");
        Lit120 = (SimpleSymbol) simpleSymbol45.readResolve();
        new SimpleSymbol("Button1$Click");
        Lit119 = (SimpleSymbol) simpleSymbol46.readResolve();
        new SimpleSymbol("DismissCustomDialog");
        Lit118 = (SimpleSymbol) simpleSymbol47.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit117 = fString39;
        new SimpleSymbol("FontTypeface");
        Lit115 = (SimpleSymbol) simpleSymbol48.readResolve();
        new SimpleSymbol("FontBold");
        Lit114 = (SimpleSymbol) simpleSymbol49.readResolve();
        int[] iArr10 = new int[2];
        iArr10[0] = -769226;
        Lit113 = IntNum.make(iArr10);
        new SimpleSymbol("Button1");
        Lit112 = (SimpleSymbol) simpleSymbol50.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit111 = fString40;
        new FString("com.google.appinventor.components.runtime.VerticalScrollArrangement");
        Lit110 = fString41;
        int[] iArr11 = new int[2];
        iArr11[0] = -5138;
        Lit109 = IntNum.make(iArr11);
        new FString("com.google.appinventor.components.runtime.VerticalScrollArrangement");
        Lit108 = fString42;
        new SimpleSymbol("AfterPicking");
        Lit107 = (SimpleSymbol) simpleSymbol51.readResolve();
        new SimpleSymbol("List_View1$AfterPicking");
        Lit106 = (SimpleSymbol) simpleSymbol52.readResolve();
        new SimpleSymbol("ShowCustomDialog");
        Lit105 = (SimpleSymbol) simpleSymbol53.readResolve();
        new SimpleSymbol("cans");
        Lit102 = (SimpleSymbol) simpleSymbol54.readResolve();
        new SimpleSymbol("cylinder");
        Lit99 = (SimpleSymbol) simpleSymbol55.readResolve();
        new SimpleSymbol("updated");
        Lit96 = (SimpleSymbol) simpleSymbol56.readResolve();
        new SimpleSymbol(NotificationCompat.CATEGORY_STATUS);
        Lit93 = (SimpleSymbol) simpleSymbol57.readResolve();
        new SimpleSymbol("location");
        Lit90 = (SimpleSymbol) simpleSymbol58.readResolve();
        new SimpleSymbol("state");
        Lit87 = (SimpleSymbol) simpleSymbol59.readResolve();
        new SimpleSymbol("contact");
        Lit84 = (SimpleSymbol) simpleSymbol60.readResolve();
        new SimpleSymbol("SelectionIndex");
        Lit81 = (SimpleSymbol) simpleSymbol61.readResolve();
        new SimpleSymbol("Text");
        Lit80 = (SimpleSymbol) simpleSymbol62.readResolve();
        new SimpleSymbol(CommonProperties.NAME);
        Lit79 = (SimpleSymbol) simpleSymbol63.readResolve();
        new FString("com.google.appinventor.components.runtime.ListView");
        Lit78 = fString43;
        int[] iArr12 = new int[2];
        iArr12[0] = -1;
        Lit77 = IntNum.make(iArr12);
        new SimpleSymbol("TextColor");
        Lit76 = (SimpleSymbol) simpleSymbol64.readResolve();
        new SimpleSymbol("ShowFilterBar");
        Lit75 = (SimpleSymbol) simpleSymbol65.readResolve();
        int[] iArr13 = new int[2];
        iArr13[0] = -769226;
        Lit74 = IntNum.make(iArr13);
        new SimpleSymbol("List_View1");
        Lit73 = (SimpleSymbol) simpleSymbol66.readResolve();
        new FString("com.google.appinventor.components.runtime.ListView");
        Lit72 = fString44;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit71 = fString45;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit70 = fString46;
        new FString("com.google.appinventor.components.runtime.MakeroidListViewImageText");
        Lit69 = fString47;
        new SimpleSymbol("TitleBold");
        Lit68 = (SimpleSymbol) simpleSymbol67.readResolve();
        new SimpleSymbol("List_View_Image_and_Text1");
        Lit67 = (SimpleSymbol) simpleSymbol68.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidListViewImageText");
        Lit66 = fString48;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit65 = fString49;
        new SimpleSymbol("Horizontal_Arrangement1_copy");
        Lit64 = (SimpleSymbol) simpleSymbol69.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit63 = fString50;
        new FString("com.google.appinventor.components.runtime.MakeroidCircularProgress");
        Lit62 = fString51;
        int[] iArr14 = new int[2];
        iArr14[0] = -769226;
        Lit61 = IntNum.make(iArr14);
        new SimpleSymbol("Color");
        Lit60 = (SimpleSymbol) simpleSymbol70.readResolve();
        new SimpleSymbol("Circular_Progress1");
        Lit59 = (SimpleSymbol) simpleSymbol71.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidCircularProgress");
        Lit58 = fString52;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit57 = fString53;
        new SimpleSymbol("Width");
        Lit56 = (SimpleSymbol) simpleSymbol72.readResolve();
        new SimpleSymbol("Height");
        Lit54 = (SimpleSymbol) simpleSymbol73.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit53 = fString54;
        new FString("com.google.appinventor.components.runtime.MakeroidViewPager");
        Lit52 = fString55;
        int[] iArr15 = new int[2];
        iArr15[0] = -769226;
        Lit51 = IntNum.make(iArr15);
        new SimpleSymbol("TabsBackgroundColor");
        Lit50 = (SimpleSymbol) simpleSymbol74.readResolve();
        int[] iArr16 = new int[2];
        iArr16[0] = -1;
        Lit49 = IntNum.make(iArr16);
        new SimpleSymbol("TabsActiveTextColor");
        Lit48 = (SimpleSymbol) simpleSymbol75.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidViewPager");
        Lit47 = fString56;
        new SimpleSymbol("Initialize");
        Lit46 = (SimpleSymbol) simpleSymbol76.readResolve();
        new SimpleSymbol("Screen7$Initialize");
        Lit45 = (SimpleSymbol) simpleSymbol77.readResolve();
        SimpleSymbol simpleSymbol117 = Lit253;
        SimpleSymbol simpleSymbol118 = Lit20;
        SimpleSymbol simpleSymbol119 = Lit20;
        SimpleSymbol simpleSymbol120 = Lit20;
        new SimpleSymbol("boolean");
        SimpleSymbol simpleSymbol121 = (SimpleSymbol) simpleSymbol78.readResolve();
        Lit31 = simpleSymbol121;
        Lit44 = PairWithPosition.make(simpleSymbol117, PairWithPosition.make(simpleSymbol118, PairWithPosition.make(simpleSymbol119, PairWithPosition.make(simpleSymbol120, PairWithPosition.make(simpleSymbol121, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139923), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139918), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139913), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139908), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen7.yail", 139897);
        new SimpleSymbol("Vertical_Scroll_Arrangement1");
        Lit43 = (SimpleSymbol) simpleSymbol79.readResolve();
        new SimpleSymbol("CreateCustomDialog");
        Lit42 = (SimpleSymbol) simpleSymbol80.readResolve();
        new SimpleSymbol("Notifier1");
        Lit41 = (SimpleSymbol) simpleSymbol81.readResolve();
        new SimpleSymbol("Vertical_Arrangement2");
        Lit39 = (SimpleSymbol) simpleSymbol82.readResolve();
        new SimpleSymbol("Vertical_Arrangement1");
        Lit37 = (SimpleSymbol) simpleSymbol83.readResolve();
        new SimpleSymbol("AddComponentToView");
        Lit36 = (SimpleSymbol) simpleSymbol84.readResolve();
        new SimpleSymbol("View_Pager1");
        Lit35 = (SimpleSymbol) simpleSymbol85.readResolve();
        new SimpleSymbol("Get");
        Lit34 = (SimpleSymbol) simpleSymbol86.readResolve();
        new SimpleSymbol("Url");
        Lit33 = (SimpleSymbol) simpleSymbol87.readResolve();
        new SimpleSymbol("Web1");
        Lit32 = (SimpleSymbol) simpleSymbol88.readResolve();
        new SimpleSymbol("TitleVisible");
        Lit30 = (SimpleSymbol) simpleSymbol89.readResolve();
        new SimpleSymbol("Title");
        Lit29 = (SimpleSymbol) simpleSymbol90.readResolve();
        new SimpleSymbol("ReceiveSharedText");
        Lit28 = (SimpleSymbol) simpleSymbol91.readResolve();
        int[] iArr17 = new int[2];
        iArr17[0] = -769226;
        Lit27 = IntNum.make(iArr17);
        new SimpleSymbol("PrimaryColorDark");
        Lit26 = (SimpleSymbol) simpleSymbol92.readResolve();
        int[] iArr18 = new int[2];
        iArr18[0] = -769226;
        Lit25 = IntNum.make(iArr18);
        new SimpleSymbol("PrimaryColor");
        Lit24 = (SimpleSymbol) simpleSymbol93.readResolve();
        int[] iArr19 = new int[2];
        iArr19[0] = -5138;
        Lit23 = IntNum.make(iArr19);
        new SimpleSymbol("BackgroundColor");
        Lit22 = (SimpleSymbol) simpleSymbol94.readResolve();
        new SimpleSymbol("AppName");
        Lit21 = (SimpleSymbol) simpleSymbol95.readResolve();
        new SimpleSymbol("AppId");
        Lit19 = (SimpleSymbol) simpleSymbol96.readResolve();
        new SimpleSymbol("AlignHorizontal");
        Lit17 = (SimpleSymbol) simpleSymbol97.readResolve();
        int[] iArr20 = new int[2];
        iArr20[0] = -769226;
        Lit15 = IntNum.make(iArr20);
        new SimpleSymbol("AccentColor");
        Lit14 = (SimpleSymbol) simpleSymbol98.readResolve();
        new SimpleSymbol("g$info");
        Lit13 = (SimpleSymbol) simpleSymbol99.readResolve();
        new SimpleSymbol("g$cans");
        Lit12 = (SimpleSymbol) simpleSymbol100.readResolve();
        new SimpleSymbol("g$updated");
        Lit11 = (SimpleSymbol) simpleSymbol101.readResolve();
        new SimpleSymbol("g$location");
        Lit10 = (SimpleSymbol) simpleSymbol102.readResolve();
        new SimpleSymbol("g$state");
        Lit9 = (SimpleSymbol) simpleSymbol103.readResolve();
        new SimpleSymbol("g$name");
        Lit8 = (SimpleSymbol) simpleSymbol104.readResolve();
        new SimpleSymbol("g$contact");
        Lit7 = (SimpleSymbol) simpleSymbol105.readResolve();
        new SimpleSymbol("g$o2");
        Lit6 = (SimpleSymbol) simpleSymbol106.readResolve();
        new SimpleSymbol("g$refill");
        Lit5 = (SimpleSymbol) simpleSymbol107.readResolve();
        new SimpleSymbol("g$cylinder");
        Lit4 = (SimpleSymbol) simpleSymbol108.readResolve();
        new SimpleSymbol("g$status");
        Lit3 = (SimpleSymbol) simpleSymbol109.readResolve();
        new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol110.readResolve();
        new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol111.readResolve();
        new SimpleSymbol("Screen7");
        Lit0 = (SimpleSymbol) simpleSymbol112.readResolve();
    }

    public Screen7() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleMethod moduleMethod29;
        ModuleMethod moduleMethod30;
        ModuleMethod moduleMethod31;
        ModuleMethod moduleMethod32;
        ModuleMethod moduleMethod33;
        ModuleMethod moduleMethod34;
        ModuleMethod moduleMethod35;
        ModuleMethod moduleMethod36;
        ModuleMethod moduleMethod37;
        ModuleMethod moduleMethod38;
        ModuleMethod moduleMethod39;
        ModuleMethod moduleMethod40;
        ModuleMethod moduleMethod41;
        ModuleMethod moduleMethod42;
        ModuleMethod moduleMethod43;
        ModuleMethod moduleMethod44;
        ModuleMethod moduleMethod45;
        ModuleMethod moduleMethod46;
        ModuleMethod moduleMethod47;
        ModuleMethod moduleMethod48;
        ModuleMethod moduleMethod49;
        ModuleMethod moduleMethod50;
        ModuleMethod moduleMethod51;
        ModuleMethod moduleMethod52;
        ModuleMethod moduleMethod53;
        ModuleMethod moduleMethod54;
        ModuleMethod moduleMethod55;
        ModuleMethod moduleMethod56;
        ModuleMethod moduleMethod57;
        ModuleMethod moduleMethod58;
        ModuleMethod moduleMethod59;
        ModuleMethod moduleMethod60;
        ModuleMethod moduleMethod61;
        ModuleMethod moduleMethod62;
        ModuleMethod moduleMethod63;
        ModuleMethod moduleMethod64;
        ModuleMethod moduleMethod65;
        ModuleMethod moduleMethod66;
        ModuleMethod moduleMethod67;
        ModuleMethod moduleMethod68;
        ModuleMethod moduleMethod69;
        ModuleMethod moduleMethod70;
        ModuleMethod moduleMethod71;
        ModuleMethod moduleMethod72;
        ModuleMethod moduleMethod73;
        ModuleMethod moduleMethod74;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod75 = moduleMethod;
        new frame();
        frame frame3 = frame2;
        frame3.$main = this;
        frame frame4 = frame3;
        new ModuleMethod(frame4, 1, Lit237, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod75;
        new ModuleMethod(frame4, 2, Lit238, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod2;
        new ModuleMethod(frame4, 3, Lit239, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod3;
        new ModuleMethod(frame4, 4, Lit240, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod4;
        new ModuleMethod(frame4, 6, Lit241, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod5;
        new ModuleMethod(frame4, 7, Lit242, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod6;
        new ModuleMethod(frame4, 8, Lit243, 8194);
        this.add$Mnto$Mnevents = moduleMethod7;
        new ModuleMethod(frame4, 9, Lit244, 16388);
        this.add$Mnto$Mncomponents = moduleMethod8;
        new ModuleMethod(frame4, 10, Lit245, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod9;
        new ModuleMethod(frame4, 11, Lit246, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod10;
        new ModuleMethod(frame4, 12, Lit247, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod11;
        new ModuleMethod(frame4, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod12;
        new ModuleMethod(frame4, 14, Lit248, 16388);
        this.dispatchEvent = moduleMethod13;
        new ModuleMethod(frame4, 15, Lit249, 16388);
        this.dispatchGenericEvent = moduleMethod14;
        new ModuleMethod(frame4, 16, Lit250, 8194);
        this.lookup$Mnhandler = moduleMethod15;
        new ModuleMethod(frame4, 17, (Object) null, 0);
        ModuleMethod moduleMethod76 = moduleMethod16;
        moduleMethod76.setProperty("source-location", "/tmp/runtime7522387041397852836.scm:615");
        lambda$Fn1 = moduleMethod76;
        new ModuleMethod(frame4, 18, "$define", 0);
        this.$define = moduleMethod17;
        new ModuleMethod(frame4, 19, (Object) null, 0);
        lambda$Fn2 = moduleMethod18;
        new ModuleMethod(frame4, 20, (Object) null, 0);
        lambda$Fn3 = moduleMethod19;
        new ModuleMethod(frame4, 21, (Object) null, 0);
        lambda$Fn4 = moduleMethod20;
        new ModuleMethod(frame4, 22, (Object) null, 0);
        lambda$Fn5 = moduleMethod21;
        new ModuleMethod(frame4, 23, (Object) null, 0);
        lambda$Fn6 = moduleMethod22;
        new ModuleMethod(frame4, 24, (Object) null, 0);
        lambda$Fn7 = moduleMethod23;
        new ModuleMethod(frame4, 25, (Object) null, 0);
        lambda$Fn8 = moduleMethod24;
        new ModuleMethod(frame4, 26, (Object) null, 0);
        lambda$Fn9 = moduleMethod25;
        new ModuleMethod(frame4, 27, (Object) null, 0);
        lambda$Fn10 = moduleMethod26;
        new ModuleMethod(frame4, 28, (Object) null, 0);
        lambda$Fn11 = moduleMethod27;
        new ModuleMethod(frame4, 29, (Object) null, 0);
        lambda$Fn12 = moduleMethod28;
        new ModuleMethod(frame4, 30, (Object) null, 0);
        lambda$Fn13 = moduleMethod29;
        new ModuleMethod(frame4, 31, Lit45, 0);
        this.Screen7$Initialize = moduleMethod30;
        new ModuleMethod(frame4, 32, (Object) null, 0);
        lambda$Fn14 = moduleMethod31;
        new ModuleMethod(frame4, 33, (Object) null, 0);
        lambda$Fn15 = moduleMethod32;
        new ModuleMethod(frame4, 34, (Object) null, 0);
        lambda$Fn16 = moduleMethod33;
        new ModuleMethod(frame4, 35, (Object) null, 0);
        lambda$Fn17 = moduleMethod34;
        new ModuleMethod(frame4, 36, (Object) null, 0);
        lambda$Fn18 = moduleMethod35;
        new ModuleMethod(frame4, 37, (Object) null, 0);
        lambda$Fn19 = moduleMethod36;
        new ModuleMethod(frame4, 38, (Object) null, 0);
        lambda$Fn20 = moduleMethod37;
        new ModuleMethod(frame4, 39, (Object) null, 0);
        lambda$Fn21 = moduleMethod38;
        new ModuleMethod(frame4, 40, (Object) null, 0);
        lambda$Fn22 = moduleMethod39;
        new ModuleMethod(frame4, 41, (Object) null, 0);
        lambda$Fn23 = moduleMethod40;
        new ModuleMethod(frame4, 42, (Object) null, 0);
        lambda$Fn24 = moduleMethod41;
        new ModuleMethod(frame4, 43, (Object) null, 0);
        lambda$Fn25 = moduleMethod42;
        new ModuleMethod(frame4, 44, (Object) null, 0);
        lambda$Fn26 = moduleMethod43;
        new ModuleMethod(frame4, 45, (Object) null, 0);
        lambda$Fn27 = moduleMethod44;
        new ModuleMethod(frame4, 46, Lit106, 0);
        this.List_View1$AfterPicking = moduleMethod45;
        new ModuleMethod(frame4, 47, (Object) null, 0);
        lambda$Fn28 = moduleMethod46;
        new ModuleMethod(frame4, 48, (Object) null, 0);
        lambda$Fn29 = moduleMethod47;
        new ModuleMethod(frame4, 49, (Object) null, 0);
        lambda$Fn30 = moduleMethod48;
        new ModuleMethod(frame4, 50, (Object) null, 0);
        lambda$Fn31 = moduleMethod49;
        new ModuleMethod(frame4, 51, Lit119, 0);
        this.Button1$Click = moduleMethod50;
        new ModuleMethod(frame4, 52, (Object) null, 0);
        lambda$Fn32 = moduleMethod51;
        new ModuleMethod(frame4, 53, (Object) null, 0);
        lambda$Fn33 = moduleMethod52;
        new ModuleMethod(frame4, 54, (Object) null, 0);
        lambda$Fn34 = moduleMethod53;
        new ModuleMethod(frame4, 55, (Object) null, 0);
        lambda$Fn35 = moduleMethod54;
        new ModuleMethod(frame4, 56, (Object) null, 0);
        lambda$Fn36 = moduleMethod55;
        new ModuleMethod(frame4, 57, (Object) null, 0);
        lambda$Fn37 = moduleMethod56;
        new ModuleMethod(frame4, 58, (Object) null, 0);
        lambda$Fn38 = moduleMethod57;
        new ModuleMethod(frame4, 59, (Object) null, 0);
        lambda$Fn39 = moduleMethod58;
        new ModuleMethod(frame4, 60, (Object) null, 0);
        lambda$Fn40 = moduleMethod59;
        new ModuleMethod(frame4, 61, (Object) null, 0);
        lambda$Fn41 = moduleMethod60;
        new ModuleMethod(frame4, 62, (Object) null, 0);
        lambda$Fn42 = moduleMethod61;
        new ModuleMethod(frame4, 63, (Object) null, 0);
        lambda$Fn43 = moduleMethod62;
        new ModuleMethod(frame4, 64, (Object) null, 0);
        lambda$Fn44 = moduleMethod63;
        new ModuleMethod(frame4, 65, (Object) null, 0);
        lambda$Fn45 = moduleMethod64;
        new ModuleMethod(frame4, 66, (Object) null, 0);
        lambda$Fn46 = moduleMethod65;
        new ModuleMethod(frame4, 67, (Object) null, 0);
        lambda$Fn47 = moduleMethod66;
        new ModuleMethod(frame4, 68, (Object) null, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        lambda$Fn48 = moduleMethod67;
        new ModuleMethod(frame4, 69, Lit251, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        proc$Fn49 = moduleMethod68;
        new ModuleMethod(frame4, 70, (Object) null, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        lambda$Fn50 = moduleMethod69;
        new ModuleMethod(frame4, 71, Lit221, 16388);
        this.Web1$GotText = moduleMethod70;
        new ModuleMethod(frame4, 72, (Object) null, 0);
        lambda$Fn51 = moduleMethod71;
        new ModuleMethod(frame4, 73, (Object) null, 0);
        lambda$Fn52 = moduleMethod72;
        new ModuleMethod(frame4, 74, Lit233, 0);
        this.Floating_Action_Button1$Click = moduleMethod73;
        new ModuleMethod(frame4, 75, Lit235, 0);
        this.Floating_Action_Button1$LongClick = moduleMethod74;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        String obj;
        Object obj2;
        Consumer $result = $ctx.consumer;
        C1241runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
        Object[] objArr = new Object[2];
        objArr[0] = misc.symbol$To$String(Lit0);
        Object[] objArr2 = objArr;
        objArr2[1] = "-global-vars";
        FString stringAppend = strings.stringAppend(objArr2);
        FString fString = stringAppend;
        if (stringAppend == null) {
            obj = null;
        } else {
            obj = fString.toString();
        }
        this.global$Mnvar$Mnenvironment = Environment.make(obj);
        Screen7 = null;
        this.form$Mnname$Mnsymbol = Lit0;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        C1241runtime.$instance.run();
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit3, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit3, lambda$Fn2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit4, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit4, lambda$Fn3);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit5, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit5, lambda$Fn4);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit6, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit6, lambda$Fn5);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit7, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit7, lambda$Fn6);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit8, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit8, lambda$Fn7);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit9, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit9, lambda$Fn8);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit10, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit10, lambda$Fn9);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit11, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit11, lambda$Fn10);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit12, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit12, lambda$Fn11);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit13, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), $result);
        } else {
            addToGlobalVars(Lit13, lambda$Fn12);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, Lit15, Lit16);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit17, Lit18, Lit16);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, "6193580781600768", Lit20);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, "COV_AID_2", Lit20);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit22, Lit23, Lit16);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, Lit25, Lit16);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit26, Lit27, Lit16);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit28, AlgorithmIdentifiers.NONE, Lit20);
            Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit29, "Screen7", Lit20);
            Values.writeValues(C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit30, Boolean.FALSE, Lit31), $result);
        } else {
            new Promise(lambda$Fn13);
            addToFormDoAfterCreation(obj2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment = C1241runtime.addToCurrentFormEnvironment(Lit45, this.Screen7$Initialize);
        } else {
            addToFormEnvironment(Lit45, this.Screen7$Initialize);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Screen7", "Initialize");
        } else {
            addToEvents(Lit0, Lit46);
        }
        this.View_Pager1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit47, Lit35, lambda$Fn14), $result);
        } else {
            addToComponents(Lit0, Lit52, Lit35, lambda$Fn15);
        }
        this.Vertical_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit53, Lit37, lambda$Fn16), $result);
        } else {
            addToComponents(Lit0, Lit57, Lit37, lambda$Fn17);
        }
        this.Circular_Progress1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit37, Lit58, Lit59, lambda$Fn18), $result);
        } else {
            addToComponents(Lit37, Lit62, Lit59, lambda$Fn19);
        }
        this.Horizontal_Arrangement1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit37, Lit63, Lit64, lambda$Fn20), $result);
        } else {
            addToComponents(Lit37, Lit65, Lit64, lambda$Fn21);
        }
        this.List_View_Image_and_Text1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit64, Lit66, Lit67, lambda$Fn22), $result);
        } else {
            addToComponents(Lit64, Lit69, Lit67, lambda$Fn23);
        }
        this.Vertical_Arrangement2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit70, Lit39, lambda$Fn24), $result);
        } else {
            addToComponents(Lit0, Lit71, Lit39, lambda$Fn25);
        }
        this.List_View1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit39, Lit72, Lit73, lambda$Fn26), $result);
        } else {
            addToComponents(Lit39, Lit78, Lit73, lambda$Fn27);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment2 = C1241runtime.addToCurrentFormEnvironment(Lit106, this.List_View1$AfterPicking);
        } else {
            addToFormEnvironment(Lit106, this.List_View1$AfterPicking);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "List_View1", "AfterPicking");
        } else {
            addToEvents(Lit73, Lit107);
        }
        this.Vertical_Scroll_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit108, Lit43, lambda$Fn28), $result);
        } else {
            addToComponents(Lit0, Lit110, Lit43, lambda$Fn29);
        }
        this.Button1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit111, Lit112, lambda$Fn30), $result);
        } else {
            addToComponents(Lit43, Lit117, Lit112, lambda$Fn31);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment3 = C1241runtime.addToCurrentFormEnvironment(Lit119, this.Button1$Click);
        } else {
            addToFormEnvironment(Lit119, this.Button1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button1", "Click");
        } else {
            addToEvents(Lit112, Lit120);
        }
        this.Label20 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit121, Lit122, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit123, Lit122, Boolean.FALSE);
        }
        this.name = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit124, Lit79, lambda$Fn32), $result);
        } else {
            addToComponents(Lit43, Lit128, Lit79, lambda$Fn33);
        }
        this.Label2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit129, Lit130, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit131, Lit130, Boolean.FALSE);
        }
        this.contact = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit132, Lit84, lambda$Fn34), $result);
        } else {
            addToComponents(Lit43, Lit134, Lit84, lambda$Fn35);
        }
        this.Label4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit135, Lit136, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit137, Lit136, Boolean.FALSE);
        }
        this.state = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit138, Lit87, lambda$Fn36), $result);
        } else {
            addToComponents(Lit43, Lit140, Lit87, lambda$Fn37);
        }
        this.Label6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit141, Lit142, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit143, Lit142, Boolean.FALSE);
        }
        this.location = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit144, Lit90, lambda$Fn38), $result);
        } else {
            addToComponents(Lit43, Lit146, Lit90, lambda$Fn39);
        }
        this.Label8 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit147, Lit148, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit149, Lit148, Boolean.FALSE);
        }
        this.status = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit150, Lit93, lambda$Fn40), $result);
        } else {
            addToComponents(Lit43, Lit152, Lit93, lambda$Fn41);
        }
        this.Label10 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit153, Lit154, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit155, Lit154, Boolean.FALSE);
        }
        this.updated = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit156, Lit96, lambda$Fn42), $result);
        } else {
            addToComponents(Lit43, Lit158, Lit96, lambda$Fn43);
        }
        this.Label12 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit159, Lit160, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit161, Lit160, Boolean.FALSE);
        }
        this.cylinder = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit162, Lit99, lambda$Fn44), $result);
        } else {
            addToComponents(Lit43, Lit164, Lit99, lambda$Fn45);
        }
        this.Label14 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit165, Lit166, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit43, Lit167, Lit166, Boolean.FALSE);
        }
        this.cans = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit43, Lit168, Lit102, lambda$Fn46), $result);
        } else {
            addToComponents(Lit43, Lit170, Lit102, lambda$Fn47);
        }
        this.Web1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit171, Lit32, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit172, Lit32, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment4 = C1241runtime.addToCurrentFormEnvironment(Lit221, this.Web1$GotText);
        } else {
            addToFormEnvironment(Lit221, this.Web1$GotText);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Web1", "GotText");
        } else {
            addToEvents(Lit32, Lit222);
        }
        this.Notifier1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit223, Lit41, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit224, Lit41, Boolean.FALSE);
        }
        this.Floating_Action_Button1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit225, Lit226, lambda$Fn51), $result);
        } else {
            addToComponents(Lit0, Lit230, Lit226, lambda$Fn52);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment5 = C1241runtime.addToCurrentFormEnvironment(Lit233, this.Floating_Action_Button1$Click);
        } else {
            addToFormEnvironment(Lit233, this.Floating_Action_Button1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Floating_Action_Button1", "Click");
        } else {
            addToEvents(Lit226, Lit120);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment6 = C1241runtime.addToCurrentFormEnvironment(Lit235, this.Floating_Action_Button1$LongClick);
        } else {
            addToFormEnvironment(Lit235, this.Floating_Action_Button1$LongClick);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Floating_Action_Button1", "LongClick");
        } else {
            addToEvents(Lit226, Lit236);
        }
        C1241runtime.initRuntime();
    }

    static Object lambda3() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda4() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda5() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda6() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda7() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda8() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda9() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda10() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda11() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda12() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda13() {
        return C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda14() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, Lit15, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, "6193580781600768", Lit20);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, "COV_AID_2", Lit20);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit22, Lit23, Lit16);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, Lit25, Lit16);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit26, Lit27, Lit16);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit28, AlgorithmIdentifiers.NONE, Lit20);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit29, "Screen7", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit30, Boolean.FALSE, Lit31);
    }

    public Object Screen7$Initialize() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit32, Lit33, "https://docs.google.com/spreadsheets/d/1KtDiUWbYtGVWf9gO4FN1AUUerexnsHyQYa0AiKmNE3k/export?format=csv", Lit20);
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit32, Lit34, LList.Empty, LList.Empty);
        Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit35, Lit36, LList.list2(C1241runtime.lookupInCurrentFormEnvironment(Lit37), "List"), Lit38);
        Object callComponentMethod3 = C1241runtime.callComponentMethod(Lit35, Lit36, LList.list2(C1241runtime.lookupInCurrentFormEnvironment(Lit39), "Details"), Lit40);
        SimpleSymbol simpleSymbol = Lit41;
        SimpleSymbol simpleSymbol2 = Lit42;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit43));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.FALSE);
        return C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit44);
    }

    static Object lambda15() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit35, Lit48, Lit49, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit35, Lit50, Lit51, Lit16);
    }

    static Object lambda16() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit35, Lit48, Lit49, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit35, Lit50, Lit51, Lit16);
    }

    static Object lambda17() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit37, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit37, Lit54, Lit55, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit37, Lit56, Lit55, Lit16);
    }

    static Object lambda18() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit37, Lit17, Lit18, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit37, Lit54, Lit55, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit37, Lit56, Lit55, Lit16);
    }

    static Object lambda19() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit60, Lit61, Lit16);
    }

    static Object lambda20() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit60, Lit61, Lit16);
    }

    static Object lambda21() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit56, Lit55, Lit16);
    }

    static Object lambda22() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit56, Lit55, Lit16);
    }

    static Object lambda23() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit67, Lit68, Boolean.TRUE, Lit31);
    }

    static Object lambda24() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit67, Lit68, Boolean.TRUE, Lit31);
    }

    static Object lambda25() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit54, Lit55, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit56, Lit55, Lit16);
    }

    static Object lambda26() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit54, Lit55, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit56, Lit55, Lit16);
    }

    static Object lambda27() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit22, Lit74, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit54, Lit55, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit56, Lit55, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit75, Boolean.TRUE, Lit31);
        return C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit76, Lit77, Lit16);
    }

    static Object lambda28() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit22, Lit74, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit54, Lit55, Lit16);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit56, Lit55, Lit16);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit75, Boolean.TRUE, Lit31);
        return C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit76, Lit77, Lit16);
    }

    public Object List_View1$AfterPicking() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit79, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("Hospital: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit82, "select list item")), Lit83, "join"), Lit20);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("Phone: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit85, "select list item")), Lit86, "join"), Lit20);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit87, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("State: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit9, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit88, "select list item")), Lit89, "join"), Lit20);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit90, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("City: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit10, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit91, "select list item")), Lit92, "join"), Lit20);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("Status: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit94, "select list item")), Lit95, "join"), Lit20);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit96, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("Updated: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit11, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit97, "select list item")), Lit98, "join"), Lit20);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("Beds with ventilator: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit100, "select list item")), Lit101, "join"), Lit20);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit80, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("Beds with oxygen: ", C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnget$Mnitem, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit12, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.get$Mnproperty.apply2(Lit73, Lit81)), Lit103, "select list item")), Lit104, "join"), Lit20);
        return C1241runtime.callComponentMethod(Lit41, Lit105, LList.Empty, LList.Empty);
    }

    static Object lambda29() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit43, Lit22, Lit109, Lit16);
    }

    static Object lambda30() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit43, Lit22, Lit109, Lit16);
    }

    static Object lambda31() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit22, Lit113, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit114, Boolean.TRUE, Lit31);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit115, Lit116, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit80, "close", Lit20);
    }

    static Object lambda32() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit22, Lit113, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit114, Boolean.TRUE, Lit31);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit115, Lit116, Lit16);
        return C1241runtime.setAndCoerceProperty$Ex(Lit112, Lit80, "close", Lit20);
    }

    public Object Button1$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit41, Lit118, LList.Empty, LList.Empty);
    }

    static Object lambda33() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit79, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit79, Lit80, "Text for Label1", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit79, Lit76, Lit127, Lit16);
    }

    static Object lambda34() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit79, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit79, Lit80, "Text for Label1", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit79, Lit76, Lit127, Lit16);
    }

    static Object lambda35() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit80, "Text for Label3", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit76, Lit133, Lit16);
    }

    static Object lambda36() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit80, "Text for Label3", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit76, Lit133, Lit16);
    }

    static Object lambda37() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit87, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit87, Lit80, "Text for Label5", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit87, Lit76, Lit139, Lit16);
    }

    static Object lambda38() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit87, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit87, Lit80, "Text for Label5", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit87, Lit76, Lit139, Lit16);
    }

    static Object lambda39() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit90, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit90, Lit80, "Text for Label7", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit90, Lit76, Lit145, Lit16);
    }

    static Object lambda40() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit90, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit90, Lit80, "Text for Label7", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit90, Lit76, Lit145, Lit16);
    }

    static Object lambda41() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit80, "Text for Label9", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit76, Lit151, Lit16);
    }

    static Object lambda42() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit80, "Text for Label9", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit76, Lit151, Lit16);
    }

    static Object lambda43() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit96, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit96, Lit80, "Text for Label11", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit96, Lit76, Lit157, Lit16);
    }

    static Object lambda44() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit96, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit96, Lit80, "Text for Label11", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit96, Lit76, Lit157, Lit16);
    }

    static Object lambda45() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit80, "Text for Label13", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit76, Lit163, Lit16);
    }

    static Object lambda46() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit80, "Text for Label13", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit99, Lit76, Lit163, Lit16);
    }

    static Object lambda47() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit80, "Text for Label15", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit76, Lit169, Lit16);
    }

    static Object lambda48() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit125, Lit126, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit80, "Text for Label15", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit76, Lit169, Lit16);
    }

    public Object Web1$GotText(Object $url, Object $responseCode, Object $responseType, Object $responseContent) {
        Object obj;
        Object sanitizeComponentData = C1241runtime.sanitizeComponentData($url);
        Object sanitizeComponentData2 = C1241runtime.sanitizeComponentData($responseCode);
        Object sanitizeComponentData3 = C1241runtime.sanitizeComponentData($responseType);
        Object $responseContent2 = C1241runtime.sanitizeComponentData($responseContent);
        C1241runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit6;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnfrom$Mncsv$Mntable;
        if ($responseContent2 instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit173);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj = $responseContent2;
        }
        Object addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(simpleSymbol, C1241runtime.callYailPrimitive(moduleMethod, LList.list1(obj), Lit174, "list from csv table"));
        Object callYailPrimitive = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit175), Lit176, "remove list item");
        Object callYailPrimitive2 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit177), Lit178, "remove list item");
        Object callYailPrimitive3 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit179), Lit180, "remove list item");
        Object callYailPrimitive4 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit18), Lit181, "remove list item");
        Object callYailPrimitive5 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit182), Lit183, "remove list item");
        Object callYailPrimitive6 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit184), Lit185, "remove list item");
        Object callYailPrimitive7 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit186), Lit187, "remove list item");
        Object callYailPrimitive8 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit116), Lit188, "remove list item");
        Object callYailPrimitive9 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit175), Lit189, "remove list item");
        Object callYailPrimitive10 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit190), Lit191, "remove list item");
        Object callYailPrimitive11 = C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit190), Lit192, "remove list item");
        Object yailForRange = C1241runtime.yailForRange(lambda$Fn48, Lit177, Lit175, Lit177);
        ModuleMethod moduleMethod2 = proc$Fn49;
        Object yailForEach = C1241runtime.yailForEach(proc$Fn49, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St));
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit212, Boolean.FALSE, Lit31);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit213, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit214);
        return C1241runtime.yailForRange(lambda$Fn50, Lit177, C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnlength, LList.list1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit220, "length of list"), Lit177);
    }

    static Object lambda49(Object obj) {
        Object obj2 = obj;
        return C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnremove$Mnitem$Ex, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.callYailPrimitive(C1241runtime.yail$Mnlist$Mnlength, LList.list1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit193, "length of list")), Lit194, "remove list item");
    }

    public static Object lambda50proc(Object obj) {
        Object obj2;
        Object obj3;
        Object obj4;
        Object obj5;
        Object obj6;
        Object obj7;
        Object obj8;
        Object obj9;
        Object $item = obj;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod2 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj2 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj2 = $item;
        }
        Object callYailPrimitive = C1241runtime.callYailPrimitive(moduleMethod, LList.list2(lookupGlobalVarInCurrentFormEnvironment, C1241runtime.callYailPrimitive(moduleMethod2, LList.list2(obj2, Lit177), Lit196, "select list item")), Lit197, "add items to list");
        ModuleMethod moduleMethod3 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment2 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod4 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr4 = new Object[3];
            objArr4[0] = "The variable ";
            Object[] objArr5 = objArr4;
            objArr5[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr6 = objArr5;
            objArr6[2] = " is not bound in the current context";
            obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
        } else {
            obj3 = $item;
        }
        Object callYailPrimitive2 = C1241runtime.callYailPrimitive(moduleMethod3, LList.list2(lookupGlobalVarInCurrentFormEnvironment2, C1241runtime.callYailPrimitive(moduleMethod4, LList.list2(obj3, Lit179), Lit198, "select list item")), Lit199, "add items to list");
        ModuleMethod moduleMethod5 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment3 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit9, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod6 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr7 = new Object[3];
            objArr7[0] = "The variable ";
            Object[] objArr8 = objArr7;
            objArr8[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr9 = objArr8;
            objArr9[2] = " is not bound in the current context";
            obj4 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr9), "Unbound Variable");
        } else {
            obj4 = $item;
        }
        Object callYailPrimitive3 = C1241runtime.callYailPrimitive(moduleMethod5, LList.list2(lookupGlobalVarInCurrentFormEnvironment3, C1241runtime.callYailPrimitive(moduleMethod6, LList.list2(obj4, Lit18), Lit200, "select list item")), Lit201, "add items to list");
        ModuleMethod moduleMethod7 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment4 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit10, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod8 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr10 = new Object[3];
            objArr10[0] = "The variable ";
            Object[] objArr11 = objArr10;
            objArr11[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr12 = objArr11;
            objArr12[2] = " is not bound in the current context";
            obj5 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr12), "Unbound Variable");
        } else {
            obj5 = $item;
        }
        Object callYailPrimitive4 = C1241runtime.callYailPrimitive(moduleMethod7, LList.list2(lookupGlobalVarInCurrentFormEnvironment4, C1241runtime.callYailPrimitive(moduleMethod8, LList.list2(obj5, Lit182), Lit202, "select list item")), Lit203, "add items to list");
        ModuleMethod moduleMethod9 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment5 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod10 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr13 = new Object[3];
            objArr13[0] = "The variable ";
            Object[] objArr14 = objArr13;
            objArr14[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr15 = objArr14;
            objArr15[2] = " is not bound in the current context";
            obj6 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr15), "Unbound Variable");
        } else {
            obj6 = $item;
        }
        Object callYailPrimitive5 = C1241runtime.callYailPrimitive(moduleMethod9, LList.list2(lookupGlobalVarInCurrentFormEnvironment5, C1241runtime.callYailPrimitive(moduleMethod10, LList.list2(obj6, Lit184), Lit204, "select list item")), Lit205, "add items to list");
        ModuleMethod moduleMethod11 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment6 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit11, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod12 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr16 = new Object[3];
            objArr16[0] = "The variable ";
            Object[] objArr17 = objArr16;
            objArr17[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr18 = objArr17;
            objArr18[2] = " is not bound in the current context";
            obj7 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr18), "Unbound Variable");
        } else {
            obj7 = $item;
        }
        Object callYailPrimitive6 = C1241runtime.callYailPrimitive(moduleMethod11, LList.list2(lookupGlobalVarInCurrentFormEnvironment6, C1241runtime.callYailPrimitive(moduleMethod12, LList.list2(obj7, Lit186), Lit206, "select list item")), Lit207, "add items to list");
        ModuleMethod moduleMethod13 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment7 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod14 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr19 = new Object[3];
            objArr19[0] = "The variable ";
            Object[] objArr20 = objArr19;
            objArr20[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr21 = objArr20;
            objArr21[2] = " is not bound in the current context";
            obj8 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr21), "Unbound Variable");
        } else {
            obj8 = $item;
        }
        Object callYailPrimitive7 = C1241runtime.callYailPrimitive(moduleMethod13, LList.list2(lookupGlobalVarInCurrentFormEnvironment7, C1241runtime.callYailPrimitive(moduleMethod14, LList.list2(obj8, Lit175), Lit208, "select list item")), Lit209, "add items to list");
        ModuleMethod moduleMethod15 = C1241runtime.yail$Mnlist$Mnadd$Mnto$Mnlist$Ex;
        Object lookupGlobalVarInCurrentFormEnvironment8 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit12, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        ModuleMethod moduleMethod16 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        if ($item instanceof Package) {
            Object[] objArr22 = new Object[3];
            objArr22[0] = "The variable ";
            Object[] objArr23 = objArr22;
            objArr23[1] = C1241runtime.getDisplayRepresentation(Lit195);
            Object[] objArr24 = objArr23;
            objArr24[2] = " is not bound in the current context";
            obj9 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr24), "Unbound Variable");
        } else {
            obj9 = $item;
        }
        return C1241runtime.callYailPrimitive(moduleMethod15, LList.list2(lookupGlobalVarInCurrentFormEnvironment8, C1241runtime.callYailPrimitive(moduleMethod16, LList.list2(obj9, Lit190), Lit210, "select list item")), Lit211, "add items to list");
    }

    static Object lambda51(Object obj) {
        Object obj2;
        Object obj3;
        Object $number = obj;
        SimpleSymbol simpleSymbol = Lit67;
        SimpleSymbol simpleSymbol2 = Lit215;
        ModuleMethod moduleMethod = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        Object lookupGlobalVarInCurrentFormEnvironment = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit8, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        if ($number instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit216);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj2 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj2 = $number;
        }
        Object callYailPrimitive = C1241runtime.callYailPrimitive(moduleMethod, LList.list2(lookupGlobalVarInCurrentFormEnvironment, obj2), Lit217, "select list item");
        ModuleMethod moduleMethod2 = C1241runtime.yail$Mnlist$Mnget$Mnitem;
        Object lookupGlobalVarInCurrentFormEnvironment2 = C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St);
        if ($number instanceof Package) {
            Object[] objArr4 = new Object[3];
            objArr4[0] = "The variable ";
            Object[] objArr5 = objArr4;
            objArr5[1] = C1241runtime.getDisplayRepresentation(Lit216);
            Object[] objArr6 = objArr5;
            objArr6[2] = " is not bound in the current context";
            obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
        } else {
            obj3 = $number;
        }
        return C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, LList.list3("hospital-bed.png", callYailPrimitive, C1241runtime.callYailPrimitive(moduleMethod2, LList.list2(lookupGlobalVarInCurrentFormEnvironment2, obj3), Lit218, "select list item")), Lit219);
    }

    static Object lambda52() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit226, Lit22, Lit227, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit226, Lit228, "updated.png", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit226, Lit229, "", Lit20);
    }

    static Object lambda53() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit226, Lit22, Lit227, Lit16);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit226, Lit228, "updated.png", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit226, Lit229, "", Lit20);
    }

    public Object Floating_Action_Button1$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit41, Lit231, LList.list1("Real-Time Updated Statistics"), Lit232);
    }

    public Object Floating_Action_Button1$LongClick() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit41, Lit231, LList.list1("Real-Time Updated Statistics"), Lit234);
    }

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen7$frame */
    /* compiled from: Screen7.yail */
    public class frame extends ModuleBody {
        Screen7 $main;

        public frame() {
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Screen7)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 68:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 69:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 70:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Screen7)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof Screen7)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 71:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            Throwable th;
            Throwable th2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th3 = th2;
                        new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw th3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th4 = th;
                        new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw th4;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                case 68:
                    return Screen7.lambda49(obj2);
                case 69:
                    return Screen7.lambda50proc(obj2);
                case 70:
                    return Screen7.lambda51(obj2);
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            Throwable th6;
            Throwable th7;
            Throwable th8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    Throwable th9 = th8;
                                    new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw th9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                Throwable th10 = th7;
                                new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw th10;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            Throwable th11 = th6;
                            new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw th11;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        Throwable th12 = th5;
                        new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw th12;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    Throwable th13 = th4;
                                    new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw th13;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                Throwable th14 = th3;
                                new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw th14;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            Throwable th15 = th2;
                            new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw th15;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        Throwable th16 = th;
                        new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw th16;
                    }
                case 71:
                    return this.$main.Web1$GotText(obj5, obj6, obj7, obj8);
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th4 = th3;
                        new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw th4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th2;
                        new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw th5;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        Throwable th6 = th;
                        new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw th6;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return Screen7.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return Screen7.lambda3();
                case 20:
                    return Screen7.lambda4();
                case 21:
                    return Screen7.lambda5();
                case 22:
                    return Screen7.lambda6();
                case 23:
                    return Screen7.lambda7();
                case 24:
                    return Screen7.lambda8();
                case 25:
                    return Screen7.lambda9();
                case 26:
                    return Screen7.lambda10();
                case 27:
                    return Screen7.lambda11();
                case 28:
                    return Screen7.lambda12();
                case 29:
                    return Screen7.lambda13();
                case 30:
                    return Screen7.lambda14();
                case 31:
                    return this.$main.Screen7$Initialize();
                case 32:
                    return Screen7.lambda15();
                case 33:
                    return Screen7.lambda16();
                case 34:
                    return Screen7.lambda17();
                case 35:
                    return Screen7.lambda18();
                case 36:
                    return Screen7.lambda19();
                case 37:
                    return Screen7.lambda20();
                case 38:
                    return Screen7.lambda21();
                case 39:
                    return Screen7.lambda22();
                case 40:
                    return Screen7.lambda23();
                case 41:
                    return Screen7.lambda24();
                case 42:
                    return Screen7.lambda25();
                case 43:
                    return Screen7.lambda26();
                case 44:
                    return Screen7.lambda27();
                case 45:
                    return Screen7.lambda28();
                case 46:
                    return this.$main.List_View1$AfterPicking();
                case 47:
                    return Screen7.lambda29();
                case 48:
                    return Screen7.lambda30();
                case 49:
                    return Screen7.lambda31();
                case 50:
                    return Screen7.lambda32();
                case 51:
                    return this.$main.Button1$Click();
                case 52:
                    return Screen7.lambda33();
                case 53:
                    return Screen7.lambda34();
                case 54:
                    return Screen7.lambda35();
                case 55:
                    return Screen7.lambda36();
                case 56:
                    return Screen7.lambda37();
                case 57:
                    return Screen7.lambda38();
                case 58:
                    return Screen7.lambda39();
                case 59:
                    return Screen7.lambda40();
                case 60:
                    return Screen7.lambda41();
                case 61:
                    return Screen7.lambda42();
                case 62:
                    return Screen7.lambda43();
                case 63:
                    return Screen7.lambda44();
                case 64:
                    return Screen7.lambda45();
                case 65:
                    return Screen7.lambda46();
                case 66:
                    return Screen7.lambda47();
                case 67:
                    return Screen7.lambda48();
                case 72:
                    return Screen7.lambda52();
                case 73:
                    return Screen7.lambda53();
                case 74:
                    return this.$main.Floating_Action_Button1$Click();
                case 75:
                    return this.$main.Floating_Action_Button1$LongClick();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 20:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 23:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 24:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 30:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 31:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 32:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 33:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 34:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 35:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 36:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 37:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 38:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 39:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 40:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 41:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 42:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 43:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 44:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 45:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 46:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 47:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 48:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 49:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 50:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 51:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 52:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 53:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 54:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 55:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 56:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 57:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 58:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 59:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 60:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 61:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 62:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 63:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 64:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 65:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 66:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 67:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 72:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 73:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 74:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 75:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name2 = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name2;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.form$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.form$Mnenvironment.put(name2, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name2 = symbol;
        Object default$Mnvalue = obj;
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & true;
        if (!x ? !x : !this.form$Mnenvironment.isBound(name2)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name2);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol name2) {
        return this.form$Mnenvironment.isBound(name2);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name2 = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name2;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.global$Mnvar$Mnenvironment.put(name2, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = C1271lists.cons(C1271lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = C1271lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = C1271lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = C1271lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        Object obj = error;
        RetValManager.sendError(obj == null ? null : obj.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        objArr2[0] = "any$";
        Object[] objArr3 = objArr2;
        objArr3[1] = getSimpleName(componentObject);
        Object[] objArr4 = objArr3;
        objArr4[2] = "$";
        Object[] objArr5 = objArr4;
        objArr5[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr5)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1271lists.cons(component2, C1271lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object componentName, Object obj) {
        Object eventName = obj;
        Object obj2 = componentName;
        String obj3 = obj2 == null ? null : obj2.toString();
        Object obj4 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj3, obj4 == null ? null : obj4.toString())));
    }

    public void $define() {
        Object obj;
        Throwable th;
        Object obj2;
        Throwable th2;
        Object obj3;
        Throwable th3;
        Object obj4;
        Throwable th4;
        Object obj5;
        Throwable th5;
        Object obj6;
        Throwable th6;
        Object obj7;
        Throwable th7;
        Object obj8;
        Throwable th8;
        Throwable th9;
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception e) {
            Exception exception = e;
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        Screen7 = this;
        addToFormEnvironment(Lit0, this);
        Object obj9 = this.events$Mnto$Mnregister;
        while (true) {
            Object obj10 = obj9;
            if (obj10 == LList.Empty) {
                break;
            }
            Object obj11 = obj10;
            Object obj12 = obj11;
            try {
                Pair arg0 = (Pair) obj11;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = C1271lists.car.apply1(event$Mninfo);
                String obj13 = apply1 == null ? null : apply1.toString();
                Object apply12 = C1271lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj13, apply12 == null ? null : apply12.toString());
                obj9 = arg0.getCdr();
            } catch (ClassCastException e2) {
                ClassCastException classCastException = e2;
                Throwable th10 = th9;
                new WrongType(classCastException, "arg0", -2, obj12);
                throw th10;
            }
        }
        try {
            LList components = C1271lists.reverse(this.components$Mnto$Mncreate);
            addToGlobalVars(Lit2, lambda$Fn1);
            LList event$Mninfo2 = components;
            while (event$Mninfo2 != LList.Empty) {
                Object obj14 = event$Mninfo2;
                obj6 = obj14;
                Pair arg02 = (Pair) obj14;
                Object component$Mninfo = arg02.getCar();
                Object apply13 = C1271lists.caddr.apply1(component$Mninfo);
                Object apply14 = C1271lists.cadddr.apply1(component$Mninfo);
                Object component$Mntype = C1271lists.cadr.apply1(component$Mninfo);
                Object apply15 = C1271lists.car.apply1(component$Mninfo);
                obj7 = apply15;
                Object component$Mnname = apply13;
                Object component$Mnobject = Invoke.make.apply2(component$Mntype, lookupInFormEnvironment((Symbol) apply15));
                Object apply3 = SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
                Object obj15 = component$Mnname;
                obj8 = obj15;
                addToFormEnvironment((Symbol) obj15, component$Mnobject);
                event$Mninfo2 = arg02.getCdr();
            }
            LList reverse = C1271lists.reverse(this.global$Mnvars$Mnto$Mncreate);
            while (reverse != LList.Empty) {
                Object obj16 = reverse;
                obj4 = obj16;
                Pair arg03 = (Pair) obj16;
                Object var$Mnval = arg03.getCar();
                Object apply16 = C1271lists.car.apply1(var$Mnval);
                obj5 = apply16;
                addToGlobalVarEnvironment((Symbol) apply16, Scheme.applyToArgs.apply1(C1271lists.cadr.apply1(var$Mnval)));
                reverse = arg03.getCdr();
            }
            Object reverse2 = C1271lists.reverse(this.form$Mndo$Mnafter$Mncreation);
            while (reverse2 != LList.Empty) {
                Object obj17 = reverse2;
                obj3 = obj17;
                Pair arg04 = (Pair) obj17;
                Object force = misc.force(arg04.getCar());
                reverse2 = arg04.getCdr();
            }
            LList component$Mndescriptors = components;
            LList lList = component$Mndescriptors;
            while (lList != LList.Empty) {
                Object obj18 = lList;
                obj2 = obj18;
                Pair arg05 = (Pair) obj18;
                Object component$Mninfo2 = arg05.getCar();
                Object apply17 = C1271lists.caddr.apply1(component$Mninfo2);
                Object init$Mnthunk = C1271lists.cadddr.apply1(component$Mninfo2);
                if (init$Mnthunk != Boolean.FALSE) {
                    Object apply18 = Scheme.applyToArgs.apply1(init$Mnthunk);
                }
                lList = arg05.getCdr();
            }
            LList lList2 = component$Mndescriptors;
            while (lList2 != LList.Empty) {
                Object obj19 = lList2;
                obj = obj19;
                Pair arg06 = (Pair) obj19;
                Object component$Mninfo3 = arg06.getCar();
                Object component$Mnname2 = C1271lists.caddr.apply1(component$Mninfo3);
                Object apply19 = C1271lists.cadddr.apply1(component$Mninfo3);
                callInitialize(SlotGet.field.apply2(this, component$Mnname2));
                lList2 = arg06.getCdr();
            }
        } catch (ClassCastException e3) {
            ClassCastException classCastException2 = e3;
            Throwable th11 = th;
            new WrongType(classCastException2, "arg0", -2, obj);
            throw th11;
        } catch (ClassCastException e4) {
            ClassCastException classCastException3 = e4;
            Throwable th12 = th2;
            new WrongType(classCastException3, "arg0", -2, obj2);
            throw th12;
        } catch (ClassCastException e5) {
            ClassCastException classCastException4 = e5;
            Throwable th13 = th3;
            new WrongType(classCastException4, "arg0", -2, obj3);
            throw th13;
        } catch (ClassCastException e6) {
            ClassCastException classCastException5 = e6;
            Throwable th14 = th5;
            new WrongType(classCastException5, "add-to-global-var-environment", 0, obj5);
            throw th14;
        } catch (ClassCastException e7) {
            ClassCastException classCastException6 = e7;
            Throwable th15 = th4;
            new WrongType(classCastException6, "arg0", -2, obj4);
            throw th15;
        } catch (ClassCastException e8) {
            ClassCastException classCastException7 = e8;
            Throwable th16 = th8;
            new WrongType(classCastException7, "add-to-form-environment", 0, obj8);
            throw th16;
        } catch (ClassCastException e9) {
            ClassCastException classCastException8 = e9;
            Throwable th17 = th7;
            new WrongType(classCastException8, "lookup-in-form-environment", 0, obj7);
            throw th17;
        } catch (ClassCastException e10) {
            ClassCastException classCastException9 = e10;
            Throwable th18 = th6;
            new WrongType(classCastException9, "arg0", -2, obj6);
            throw th18;
        } catch (YailRuntimeError e11) {
            processException(e11);
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        LList symbols = LList.makeList(argsArray, 0);
        LList lList = symbols;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj = symbols;
        Object obj2 = LList.Empty;
        while (true) {
            Object obj3 = obj2;
            Object obj4 = obj;
            if (obj4 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj3));
                Object obj5 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    Throwable th4 = th;
                    new WrongType(classCastException, "string->symbol", 1, obj5);
                    throw th4;
                }
            } else {
                Object obj6 = obj4;
                Object obj7 = obj6;
                try {
                    Pair arg0 = (Pair) obj6;
                    obj = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj8 = car;
                    try {
                        obj2 = Pair.make(misc.symbol$To$String((Symbol) car), obj3);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th3;
                        new WrongType(classCastException2, "symbol->string", 1, obj8);
                        throw th5;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    Throwable th6 = th2;
                    new WrongType(classCastException3, "arg0", -2, obj7);
                    throw th6;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
