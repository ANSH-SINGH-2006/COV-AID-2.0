package p004io.kodular.anshsingh2006_1.COV_AID_2;

import android.support.p000v4.app.FragmentTransaction;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.ActivityStarter;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.PhoneCall;
import com.google.appinventor.components.runtime.Sharing;
import com.google.appinventor.components.runtime.TextToSpeech;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1241runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.DFloNum;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.C1271lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import kawa.standard.require;
import org.jose4j.jws.AlgorithmIdentifiers;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen18 */
/* compiled from: Screen18.yail */
public class Screen18 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final SimpleSymbol Lit100;
    static final FString Lit101;
    static final FString Lit102;
    static final SimpleSymbol Lit103;
    static final IntNum Lit104;
    static final IntNum Lit105 = IntNum.make(-1080);
    static final IntNum Lit106;
    static final FString Lit107;
    static final SimpleSymbol Lit108;
    static final SimpleSymbol Lit109;
    static final SimpleSymbol Lit11;
    static final SimpleSymbol Lit110;
    static final FString Lit111;
    static final SimpleSymbol Lit112;
    static final FString Lit113;
    static final FString Lit114;
    static final SimpleSymbol Lit115;
    static final IntNum Lit116;
    static final IntNum Lit117 = IntNum.make(-1080);
    static final FString Lit118;
    static final SimpleSymbol Lit119;
    static final IntNum Lit12;
    static final SimpleSymbol Lit120;
    static final SimpleSymbol Lit121;
    static final SimpleSymbol Lit122;
    static final FString Lit123;
    static final SimpleSymbol Lit124;
    static final FString Lit125;
    static final FString Lit126;
    static final SimpleSymbol Lit127;
    static final IntNum Lit128;
    static final IntNum Lit129 = IntNum.make(-1080);
    static final SimpleSymbol Lit13;
    static final IntNum Lit130;
    static final FString Lit131;
    static final PairWithPosition Lit132 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 995407);
    static final SimpleSymbol Lit133;
    static final FString Lit134;
    static final SimpleSymbol Lit135;
    static final FString Lit136;
    static final FString Lit137;
    static final SimpleSymbol Lit138;
    static final IntNum Lit139;
    static final SimpleSymbol Lit14;
    static final IntNum Lit140 = IntNum.make(-1080);
    static final IntNum Lit141;
    static final FString Lit142;
    static final SimpleSymbol Lit143;
    static final FString Lit144;
    static final SimpleSymbol Lit145;
    static final FString Lit146;
    static final FString Lit147;
    static final SimpleSymbol Lit148;
    static final IntNum Lit149;
    static final SimpleSymbol Lit15;
    static final IntNum Lit150 = IntNum.make(-1080);
    static final IntNum Lit151;
    static final FString Lit152;
    static final SimpleSymbol Lit153;
    static final SimpleSymbol Lit154;
    static final PairWithPosition Lit155 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 1200292), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 1200287), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 1200281);
    static final SimpleSymbol Lit156;
    static final SimpleSymbol Lit157;
    static final PairWithPosition Lit158;
    static final SimpleSymbol Lit159;
    static final SimpleSymbol Lit16;
    static final FString Lit160;
    static final SimpleSymbol Lit161;
    static final FString Lit162;
    static final FString Lit163;
    static final SimpleSymbol Lit164;
    static final FString Lit165;
    static final FString Lit166;
    static final FString Lit167;
    static final FString Lit168;
    static final SimpleSymbol Lit169;
    static final IntNum Lit17;
    static final DFloNum Lit170 = DFloNum.make(0.8d);
    static final FString Lit171;
    static final FString Lit172;
    static final SimpleSymbol Lit173;
    static final FString Lit174;
    static final FString Lit175;
    static final SimpleSymbol Lit176;
    static final FString Lit177;
    static final FString Lit178;
    static final SimpleSymbol Lit179;
    static final SimpleSymbol Lit18;
    static final FString Lit180;
    static final SimpleSymbol Lit181;
    static final SimpleSymbol Lit182;
    static final SimpleSymbol Lit183;
    static final SimpleSymbol Lit184;
    static final SimpleSymbol Lit185;
    static final SimpleSymbol Lit186;
    static final SimpleSymbol Lit187;
    static final SimpleSymbol Lit188;
    static final SimpleSymbol Lit189;
    static final IntNum Lit19;
    static final SimpleSymbol Lit190;
    static final SimpleSymbol Lit191;
    static final SimpleSymbol Lit192;
    static final SimpleSymbol Lit193;
    static final SimpleSymbol Lit194;
    static final SimpleSymbol Lit2;
    static final SimpleSymbol Lit20;
    static final SimpleSymbol Lit21;
    static final SimpleSymbol Lit22;
    static final SimpleSymbol Lit23;
    static final SimpleSymbol Lit24;
    static final SimpleSymbol Lit25;
    static final FString Lit26;
    static final SimpleSymbol Lit27;
    static final IntNum Lit28;
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final SimpleSymbol Lit31;
    static final IntNum Lit32 = IntNum.make(29);
    static final SimpleSymbol Lit33;
    static final IntNum Lit34 = IntNum.make(2);
    static final SimpleSymbol Lit35;
    static final SimpleSymbol Lit36;
    static final IntNum Lit37 = IntNum.make(-2);
    static final SimpleSymbol Lit38;
    static final SimpleSymbol Lit39;
    static final IntNum Lit4;
    static final IntNum Lit40 = IntNum.make(1);
    static final SimpleSymbol Lit41;
    static final IntNum Lit42;
    static final FString Lit43;
    static final FString Lit44;
    static final SimpleSymbol Lit45;
    static final FString Lit46;
    static final FString Lit47;
    static final SimpleSymbol Lit48;
    static final IntNum Lit49;
    static final SimpleSymbol Lit5;
    static final IntNum Lit50 = IntNum.make(-1080);
    static final SimpleSymbol Lit51;
    static final FString Lit52;
    static final PairWithPosition Lit53 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 299087);
    static final SimpleSymbol Lit54;
    static final SimpleSymbol Lit55;
    static final FString Lit56;
    static final SimpleSymbol Lit57;
    static final FString Lit58;
    static final FString Lit59;
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final IntNum Lit61;
    static final IntNum Lit62 = IntNum.make(-1080);
    static final IntNum Lit63;
    static final FString Lit64;
    static final PairWithPosition Lit65 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 397391);
    static final SimpleSymbol Lit66;
    static final FString Lit67;
    static final SimpleSymbol Lit68;
    static final FString Lit69;
    static final IntNum Lit7 = IntNum.make(3);
    static final FString Lit70;
    static final SimpleSymbol Lit71;
    static final IntNum Lit72;
    static final IntNum Lit73 = IntNum.make(14);
    static final IntNum Lit74 = IntNum.make(-1080);
    static final FString Lit75;
    static final PairWithPosition Lit76 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 495695);
    static final SimpleSymbol Lit77;
    static final FString Lit78;
    static final SimpleSymbol Lit79;
    static final SimpleSymbol Lit8;
    static final FString Lit80;
    static final FString Lit81;
    static final SimpleSymbol Lit82;
    static final IntNum Lit83;
    static final IntNum Lit84 = IntNum.make(-1080);
    static final IntNum Lit85;
    static final FString Lit86;
    static final PairWithPosition Lit87 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 602191);
    static final SimpleSymbol Lit88;
    static final FString Lit89;
    static final SimpleSymbol Lit9;
    static final SimpleSymbol Lit90;
    static final FString Lit91;
    static final FString Lit92;
    static final SimpleSymbol Lit93;
    static final IntNum Lit94;
    static final IntNum Lit95 = IntNum.make(-1080);
    static final FString Lit96;
    static final PairWithPosition Lit97 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 700495);
    static final SimpleSymbol Lit98;
    static final FString Lit99;
    public static Screen18 Screen18;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn9 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public ActivityStarter ActivityStarter1;
    public Button Button10;
    public final ModuleMethod Button10$Click;
    public Button Button11;
    public final ModuleMethod Button11$Click;
    public Button Button12;
    public final ModuleMethod Button12$Click;
    public Button Button2;
    public final ModuleMethod Button2$Click;
    public Button Button3;
    public final ModuleMethod Button3$Click;
    public Button Button4;
    public final ModuleMethod Button4$Click;
    public Button Button5;
    public final ModuleMethod Button5$Click;
    public Button Button6;
    public final ModuleMethod Button6$Click;
    public Button Button8;
    public final ModuleMethod Button8$Click;
    public Button Button9;
    public final ModuleMethod Button9$Click;
    public Label Label1;
    public Label Label10;
    public Label Label11;
    public Label Label16;
    public Label Label18;
    public Label Label19;
    public Label Label20;
    public Label Label21;
    public Label Label22;
    public Label Label23;
    public Label Label24;
    public Label Label27;
    public Label Label7;
    public Notifier Notifier1;
    public PhoneCall Phone_Call1;
    public Sharing Sharing1;
    public TextToSpeech TextToSpeech1;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        FString fString;
        SimpleSymbol simpleSymbol15;
        FString fString2;
        FString fString3;
        SimpleSymbol simpleSymbol16;
        FString fString4;
        FString fString5;
        SimpleSymbol simpleSymbol17;
        FString fString6;
        FString fString7;
        SimpleSymbol simpleSymbol18;
        FString fString8;
        FString fString9;
        FString fString10;
        FString fString11;
        SimpleSymbol simpleSymbol19;
        FString fString12;
        FString fString13;
        SimpleSymbol simpleSymbol20;
        FString fString14;
        SimpleSymbol simpleSymbol21;
        SimpleSymbol simpleSymbol22;
        SimpleSymbol simpleSymbol23;
        SimpleSymbol simpleSymbol24;
        SimpleSymbol simpleSymbol25;
        SimpleSymbol simpleSymbol26;
        FString fString15;
        SimpleSymbol simpleSymbol27;
        FString fString16;
        FString fString17;
        SimpleSymbol simpleSymbol28;
        FString fString18;
        SimpleSymbol simpleSymbol29;
        FString fString19;
        SimpleSymbol simpleSymbol30;
        FString fString20;
        FString fString21;
        SimpleSymbol simpleSymbol31;
        FString fString22;
        SimpleSymbol simpleSymbol32;
        FString fString23;
        SimpleSymbol simpleSymbol33;
        FString fString24;
        FString fString25;
        SimpleSymbol simpleSymbol34;
        FString fString26;
        SimpleSymbol simpleSymbol35;
        SimpleSymbol simpleSymbol36;
        SimpleSymbol simpleSymbol37;
        SimpleSymbol simpleSymbol38;
        FString fString27;
        SimpleSymbol simpleSymbol39;
        FString fString28;
        FString fString29;
        SimpleSymbol simpleSymbol40;
        FString fString30;
        SimpleSymbol simpleSymbol41;
        SimpleSymbol simpleSymbol42;
        SimpleSymbol simpleSymbol43;
        FString fString31;
        SimpleSymbol simpleSymbol44;
        FString fString32;
        FString fString33;
        SimpleSymbol simpleSymbol45;
        FString fString34;
        SimpleSymbol simpleSymbol46;
        FString fString35;
        SimpleSymbol simpleSymbol47;
        FString fString36;
        FString fString37;
        SimpleSymbol simpleSymbol48;
        FString fString38;
        SimpleSymbol simpleSymbol49;
        FString fString39;
        SimpleSymbol simpleSymbol50;
        FString fString40;
        FString fString41;
        SimpleSymbol simpleSymbol51;
        FString fString42;
        SimpleSymbol simpleSymbol52;
        FString fString43;
        SimpleSymbol simpleSymbol53;
        FString fString44;
        FString fString45;
        SimpleSymbol simpleSymbol54;
        FString fString46;
        SimpleSymbol simpleSymbol55;
        FString fString47;
        SimpleSymbol simpleSymbol56;
        FString fString48;
        FString fString49;
        SimpleSymbol simpleSymbol57;
        FString fString50;
        SimpleSymbol simpleSymbol58;
        SimpleSymbol simpleSymbol59;
        FString fString51;
        SimpleSymbol simpleSymbol60;
        SimpleSymbol simpleSymbol61;
        FString fString52;
        FString fString53;
        SimpleSymbol simpleSymbol62;
        FString fString54;
        FString fString55;
        SimpleSymbol simpleSymbol63;
        SimpleSymbol simpleSymbol64;
        SimpleSymbol simpleSymbol65;
        SimpleSymbol simpleSymbol66;
        SimpleSymbol simpleSymbol67;
        SimpleSymbol simpleSymbol68;
        SimpleSymbol simpleSymbol69;
        SimpleSymbol simpleSymbol70;
        SimpleSymbol simpleSymbol71;
        SimpleSymbol simpleSymbol72;
        FString fString56;
        SimpleSymbol simpleSymbol73;
        SimpleSymbol simpleSymbol74;
        SimpleSymbol simpleSymbol75;
        SimpleSymbol simpleSymbol76;
        SimpleSymbol simpleSymbol77;
        SimpleSymbol simpleSymbol78;
        SimpleSymbol simpleSymbol79;
        SimpleSymbol simpleSymbol80;
        SimpleSymbol simpleSymbol81;
        SimpleSymbol simpleSymbol82;
        SimpleSymbol simpleSymbol83;
        SimpleSymbol simpleSymbol84;
        SimpleSymbol simpleSymbol85;
        SimpleSymbol simpleSymbol86;
        SimpleSymbol simpleSymbol87;
        SimpleSymbol simpleSymbol88;
        SimpleSymbol simpleSymbol89;
        SimpleSymbol simpleSymbol90;
        SimpleSymbol simpleSymbol91;
        SimpleSymbol simpleSymbol92;
        new SimpleSymbol("lookup-handler");
        Lit194 = (SimpleSymbol) simpleSymbol.readResolve();
        new SimpleSymbol("dispatchGenericEvent");
        Lit193 = (SimpleSymbol) simpleSymbol2.readResolve();
        new SimpleSymbol("dispatchEvent");
        Lit192 = (SimpleSymbol) simpleSymbol3.readResolve();
        new SimpleSymbol("send-error");
        Lit191 = (SimpleSymbol) simpleSymbol4.readResolve();
        new SimpleSymbol("add-to-form-do-after-creation");
        Lit190 = (SimpleSymbol) simpleSymbol5.readResolve();
        new SimpleSymbol("add-to-global-vars");
        Lit189 = (SimpleSymbol) simpleSymbol6.readResolve();
        new SimpleSymbol("add-to-components");
        Lit188 = (SimpleSymbol) simpleSymbol7.readResolve();
        new SimpleSymbol("add-to-events");
        Lit187 = (SimpleSymbol) simpleSymbol8.readResolve();
        new SimpleSymbol("add-to-global-var-environment");
        Lit186 = (SimpleSymbol) simpleSymbol9.readResolve();
        new SimpleSymbol("is-bound-in-form-environment");
        Lit185 = (SimpleSymbol) simpleSymbol10.readResolve();
        new SimpleSymbol("lookup-in-form-environment");
        Lit184 = (SimpleSymbol) simpleSymbol11.readResolve();
        new SimpleSymbol("add-to-form-environment");
        Lit183 = (SimpleSymbol) simpleSymbol12.readResolve();
        new SimpleSymbol("android-log-form");
        Lit182 = (SimpleSymbol) simpleSymbol13.readResolve();
        new SimpleSymbol("get-simple-name");
        Lit181 = (SimpleSymbol) simpleSymbol14.readResolve();
        new FString("com.google.appinventor.components.runtime.PhoneCall");
        Lit180 = fString;
        new SimpleSymbol("PhoneNumber");
        Lit179 = (SimpleSymbol) simpleSymbol15.readResolve();
        new FString("com.google.appinventor.components.runtime.PhoneCall");
        Lit178 = fString2;
        new FString("com.google.appinventor.components.runtime.ActivityStarter");
        Lit177 = fString3;
        new SimpleSymbol("Action");
        Lit176 = (SimpleSymbol) simpleSymbol16.readResolve();
        new FString("com.google.appinventor.components.runtime.ActivityStarter");
        Lit175 = fString4;
        new FString("com.google.appinventor.components.runtime.Sharing");
        Lit174 = fString5;
        new SimpleSymbol("Sharing1");
        Lit173 = (SimpleSymbol) simpleSymbol17.readResolve();
        new FString("com.google.appinventor.components.runtime.Sharing");
        Lit172 = fString6;
        new FString("com.google.appinventor.components.runtime.TextToSpeech");
        Lit171 = fString7;
        new SimpleSymbol("SpeechRate");
        Lit169 = (SimpleSymbol) simpleSymbol18.readResolve();
        new FString("com.google.appinventor.components.runtime.TextToSpeech");
        Lit168 = fString8;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit167 = fString9;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit166 = fString10;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit165 = fString11;
        new SimpleSymbol("Label20");
        Lit164 = (SimpleSymbol) simpleSymbol19.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit163 = fString12;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit162 = fString13;
        new SimpleSymbol("Label18");
        Lit161 = (SimpleSymbol) simpleSymbol20.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit160 = fString14;
        new SimpleSymbol("Button4$Click");
        Lit159 = (SimpleSymbol) simpleSymbol21.readResolve();
        new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol93 = (SimpleSymbol) simpleSymbol22.readResolve();
        Lit9 = simpleSymbol93;
        Lit158 = PairWithPosition.make(simpleSymbol93, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen18.yail", 1200421);
        new SimpleSymbol("Speak");
        Lit157 = (SimpleSymbol) simpleSymbol23.readResolve();
        new SimpleSymbol("TextToSpeech1");
        Lit156 = (SimpleSymbol) simpleSymbol24.readResolve();
        new SimpleSymbol("ShowMessageDialog");
        Lit154 = (SimpleSymbol) simpleSymbol25.readResolve();
        new SimpleSymbol("Notifier1");
        Lit153 = (SimpleSymbol) simpleSymbol26.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit152 = fString15;
        int[] iArr = new int[2];
        iArr[0] = -16777216;
        Lit151 = IntNum.make(iArr);
        int[] iArr2 = new int[2];
        iArr2[0] = -10819687;
        Lit149 = IntNum.make(iArr2);
        new SimpleSymbol("Button4");
        Lit148 = (SimpleSymbol) simpleSymbol27.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit147 = fString16;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit146 = fString17;
        new SimpleSymbol("Label22");
        Lit145 = (SimpleSymbol) simpleSymbol28.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit144 = fString18;
        new SimpleSymbol("Button12$Click");
        Lit143 = (SimpleSymbol) simpleSymbol29.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit142 = fString19;
        int[] iArr3 = new int[2];
        iArr3[0] = -16777216;
        Lit141 = IntNum.make(iArr3);
        int[] iArr4 = new int[2];
        iArr4[0] = -7472762;
        Lit139 = IntNum.make(iArr4);
        new SimpleSymbol("Button12");
        Lit138 = (SimpleSymbol) simpleSymbol30.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit137 = fString20;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit136 = fString21;
        new SimpleSymbol("Label27");
        Lit135 = (SimpleSymbol) simpleSymbol31.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit134 = fString22;
        new SimpleSymbol("Button11$Click");
        Lit133 = (SimpleSymbol) simpleSymbol32.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit131 = fString23;
        int[] iArr5 = new int[2];
        iArr5[0] = -16777216;
        Lit130 = IntNum.make(iArr5);
        int[] iArr6 = new int[2];
        iArr6[0] = -9186760;
        Lit128 = IntNum.make(iArr6);
        new SimpleSymbol("Button11");
        Lit127 = (SimpleSymbol) simpleSymbol33.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit126 = fString24;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit125 = fString25;
        new SimpleSymbol("Label21");
        Lit124 = (SimpleSymbol) simpleSymbol34.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit123 = fString26;
        new SimpleSymbol("Button10$Click");
        Lit122 = (SimpleSymbol) simpleSymbol35.readResolve();
        new SimpleSymbol("StartActivity");
        Lit121 = (SimpleSymbol) simpleSymbol36.readResolve();
        new SimpleSymbol("DataUri");
        Lit120 = (SimpleSymbol) simpleSymbol37.readResolve();
        new SimpleSymbol("ActivityStarter1");
        Lit119 = (SimpleSymbol) simpleSymbol38.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit118 = fString27;
        int[] iArr7 = new int[2];
        iArr7[0] = -5819649;
        Lit116 = IntNum.make(iArr7);
        new SimpleSymbol("Button10");
        Lit115 = (SimpleSymbol) simpleSymbol39.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit114 = fString28;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit113 = fString29;
        new SimpleSymbol("Label23");
        Lit112 = (SimpleSymbol) simpleSymbol40.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit111 = fString30;
        new SimpleSymbol("Button6$Click");
        Lit110 = (SimpleSymbol) simpleSymbol41.readResolve();
        new SimpleSymbol("MakePhoneCall");
        Lit109 = (SimpleSymbol) simpleSymbol42.readResolve();
        new SimpleSymbol("Phone_Call1");
        Lit108 = (SimpleSymbol) simpleSymbol43.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit107 = fString31;
        int[] iArr8 = new int[2];
        iArr8[0] = -16777216;
        Lit106 = IntNum.make(iArr8);
        int[] iArr9 = new int[2];
        iArr9[0] = -33489429;
        Lit104 = IntNum.make(iArr9);
        new SimpleSymbol("Button6");
        Lit103 = (SimpleSymbol) simpleSymbol44.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit102 = fString32;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit101 = fString33;
        new SimpleSymbol("Label11");
        Lit100 = (SimpleSymbol) simpleSymbol45.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit99 = fString34;
        new SimpleSymbol("Button5$Click");
        Lit98 = (SimpleSymbol) simpleSymbol46.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit96 = fString35;
        int[] iArr10 = new int[2];
        iArr10[0] = -16776961;
        Lit94 = IntNum.make(iArr10);
        new SimpleSymbol("Button5");
        Lit93 = (SimpleSymbol) simpleSymbol47.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit92 = fString36;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit91 = fString37;
        new SimpleSymbol("Label10");
        Lit90 = (SimpleSymbol) simpleSymbol48.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit89 = fString38;
        new SimpleSymbol("Button3$Click");
        Lit88 = (SimpleSymbol) simpleSymbol49.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit86 = fString39;
        int[] iArr11 = new int[2];
        iArr11[0] = -16777216;
        Lit85 = IntNum.make(iArr11);
        int[] iArr12 = new int[2];
        iArr12[0] = -20561;
        Lit83 = IntNum.make(iArr12);
        new SimpleSymbol("Button3");
        Lit82 = (SimpleSymbol) simpleSymbol50.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit81 = fString40;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit80 = fString41;
        new SimpleSymbol("Label7");
        Lit79 = (SimpleSymbol) simpleSymbol51.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit78 = fString42;
        new SimpleSymbol("Button2$Click");
        Lit77 = (SimpleSymbol) simpleSymbol52.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit75 = fString43;
        int[] iArr13 = new int[2];
        iArr13[0] = -65281;
        Lit72 = IntNum.make(iArr13);
        new SimpleSymbol("Button2");
        Lit71 = (SimpleSymbol) simpleSymbol53.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit70 = fString44;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit69 = fString45;
        new SimpleSymbol("Label19");
        Lit68 = (SimpleSymbol) simpleSymbol54.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit67 = fString46;
        new SimpleSymbol("Button8$Click");
        Lit66 = (SimpleSymbol) simpleSymbol55.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit64 = fString47;
        int[] iArr14 = new int[2];
        iArr14[0] = -16777216;
        Lit63 = IntNum.make(iArr14);
        int[] iArr15 = new int[2];
        iArr15[0] = -2955879;
        Lit61 = IntNum.make(iArr15);
        new SimpleSymbol("Button8");
        Lit60 = (SimpleSymbol) simpleSymbol56.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit59 = fString48;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit58 = fString49;
        new SimpleSymbol("Label24");
        Lit57 = (SimpleSymbol) simpleSymbol57.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit56 = fString50;
        new SimpleSymbol("Click");
        Lit55 = (SimpleSymbol) simpleSymbol58.readResolve();
        new SimpleSymbol("Button9$Click");
        Lit54 = (SimpleSymbol) simpleSymbol59.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit52 = fString51;
        new SimpleSymbol("Shape");
        Lit51 = (SimpleSymbol) simpleSymbol60.readResolve();
        int[] iArr16 = new int[2];
        iArr16[0] = -65536;
        Lit49 = IntNum.make(iArr16);
        new SimpleSymbol("Button9");
        Lit48 = (SimpleSymbol) simpleSymbol61.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit47 = fString52;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit46 = fString53;
        new SimpleSymbol("Label16");
        Lit45 = (SimpleSymbol) simpleSymbol62.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit44 = fString54;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit43 = fString55;
        int[] iArr17 = new int[2];
        iArr17[0] = -65536;
        Lit42 = IntNum.make(iArr17);
        new SimpleSymbol("TextColor");
        Lit41 = (SimpleSymbol) simpleSymbol63.readResolve();
        new SimpleSymbol("TextAlignment");
        Lit39 = (SimpleSymbol) simpleSymbol64.readResolve();
        new SimpleSymbol("Text");
        Lit38 = (SimpleSymbol) simpleSymbol65.readResolve();
        new SimpleSymbol("Width");
        Lit36 = (SimpleSymbol) simpleSymbol66.readResolve();
        new SimpleSymbol("HasMargins");
        Lit35 = (SimpleSymbol) simpleSymbol67.readResolve();
        new SimpleSymbol("FontTypeface");
        Lit33 = (SimpleSymbol) simpleSymbol68.readResolve();
        new SimpleSymbol("FontSize");
        Lit31 = (SimpleSymbol) simpleSymbol69.readResolve();
        new SimpleSymbol("FontItalic");
        Lit30 = (SimpleSymbol) simpleSymbol70.readResolve();
        new SimpleSymbol("FontBold");
        Lit29 = (SimpleSymbol) simpleSymbol71.readResolve();
        int[] iArr18 = new int[2];
        iArr18[0] = -1;
        Lit28 = IntNum.make(iArr18);
        new SimpleSymbol("Label1");
        Lit27 = (SimpleSymbol) simpleSymbol72.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit26 = fString56;
        new SimpleSymbol("VersionName");
        Lit25 = (SimpleSymbol) simpleSymbol73.readResolve();
        new SimpleSymbol("Title");
        Lit24 = (SimpleSymbol) simpleSymbol74.readResolve();
        new SimpleSymbol("ShowOptionsMenu");
        Lit23 = (SimpleSymbol) simpleSymbol75.readResolve();
        new SimpleSymbol("boolean");
        Lit22 = (SimpleSymbol) simpleSymbol76.readResolve();
        new SimpleSymbol("Scrollable");
        Lit21 = (SimpleSymbol) simpleSymbol77.readResolve();
        new SimpleSymbol("ReceiveSharedText");
        Lit20 = (SimpleSymbol) simpleSymbol78.readResolve();
        int[] iArr19 = new int[2];
        iArr19[0] = -769226;
        Lit19 = IntNum.make(iArr19);
        new SimpleSymbol("PrimaryColorDark");
        Lit18 = (SimpleSymbol) simpleSymbol79.readResolve();
        int[] iArr20 = new int[2];
        iArr20[0] = -769226;
        Lit17 = IntNum.make(iArr20);
        new SimpleSymbol("PrimaryColor");
        Lit16 = (SimpleSymbol) simpleSymbol80.readResolve();
        new SimpleSymbol("OpenScreenAnimation");
        Lit15 = (SimpleSymbol) simpleSymbol81.readResolve();
        new SimpleSymbol("Icon");
        Lit14 = (SimpleSymbol) simpleSymbol82.readResolve();
        new SimpleSymbol("CloseScreenAnimation");
        Lit13 = (SimpleSymbol) simpleSymbol83.readResolve();
        int[] iArr21 = new int[2];
        iArr21[0] = -14336;
        Lit12 = IntNum.make(iArr21);
        new SimpleSymbol("BackgroundColor");
        Lit11 = (SimpleSymbol) simpleSymbol84.readResolve();
        new SimpleSymbol("AppName");
        Lit10 = (SimpleSymbol) simpleSymbol85.readResolve();
        new SimpleSymbol("AppId");
        Lit8 = (SimpleSymbol) simpleSymbol86.readResolve();
        new SimpleSymbol("AlignHorizontal");
        Lit6 = (SimpleSymbol) simpleSymbol87.readResolve();
        new SimpleSymbol("number");
        Lit5 = (SimpleSymbol) simpleSymbol88.readResolve();
        int[] iArr22 = new int[2];
        iArr22[0] = -769226;
        Lit4 = IntNum.make(iArr22);
        new SimpleSymbol("AccentColor");
        Lit3 = (SimpleSymbol) simpleSymbol89.readResolve();
        new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol90.readResolve();
        new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol91.readResolve();
        new SimpleSymbol("Screen18");
        Lit0 = (SimpleSymbol) simpleSymbol92.readResolve();
    }

    public Screen18() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleMethod moduleMethod29;
        ModuleMethod moduleMethod30;
        ModuleMethod moduleMethod31;
        ModuleMethod moduleMethod32;
        ModuleMethod moduleMethod33;
        ModuleMethod moduleMethod34;
        ModuleMethod moduleMethod35;
        ModuleMethod moduleMethod36;
        ModuleMethod moduleMethod37;
        ModuleMethod moduleMethod38;
        ModuleMethod moduleMethod39;
        ModuleMethod moduleMethod40;
        ModuleMethod moduleMethod41;
        ModuleMethod moduleMethod42;
        ModuleMethod moduleMethod43;
        ModuleMethod moduleMethod44;
        ModuleMethod moduleMethod45;
        ModuleMethod moduleMethod46;
        ModuleMethod moduleMethod47;
        ModuleMethod moduleMethod48;
        ModuleMethod moduleMethod49;
        ModuleMethod moduleMethod50;
        ModuleMethod moduleMethod51;
        ModuleMethod moduleMethod52;
        ModuleMethod moduleMethod53;
        ModuleMethod moduleMethod54;
        ModuleMethod moduleMethod55;
        ModuleMethod moduleMethod56;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod57 = moduleMethod;
        new frame();
        frame frame3 = frame2;
        frame3.$main = this;
        frame frame4 = frame3;
        new ModuleMethod(frame4, 1, Lit181, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod57;
        new ModuleMethod(frame4, 2, Lit182, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod2;
        new ModuleMethod(frame4, 3, Lit183, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod3;
        new ModuleMethod(frame4, 4, Lit184, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod4;
        new ModuleMethod(frame4, 6, Lit185, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod5;
        new ModuleMethod(frame4, 7, Lit186, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod6;
        new ModuleMethod(frame4, 8, Lit187, 8194);
        this.add$Mnto$Mnevents = moduleMethod7;
        new ModuleMethod(frame4, 9, Lit188, 16388);
        this.add$Mnto$Mncomponents = moduleMethod8;
        new ModuleMethod(frame4, 10, Lit189, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod9;
        new ModuleMethod(frame4, 11, Lit190, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod10;
        new ModuleMethod(frame4, 12, Lit191, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod11;
        new ModuleMethod(frame4, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod12;
        new ModuleMethod(frame4, 14, Lit192, 16388);
        this.dispatchEvent = moduleMethod13;
        new ModuleMethod(frame4, 15, Lit193, 16388);
        this.dispatchGenericEvent = moduleMethod14;
        new ModuleMethod(frame4, 16, Lit194, 8194);
        this.lookup$Mnhandler = moduleMethod15;
        new ModuleMethod(frame4, 17, (Object) null, 0);
        ModuleMethod moduleMethod58 = moduleMethod16;
        moduleMethod58.setProperty("source-location", "/tmp/runtime7522387041397852836.scm:615");
        lambda$Fn1 = moduleMethod58;
        new ModuleMethod(frame4, 18, "$define", 0);
        this.$define = moduleMethod17;
        new ModuleMethod(frame4, 19, (Object) null, 0);
        lambda$Fn2 = moduleMethod18;
        new ModuleMethod(frame4, 20, (Object) null, 0);
        lambda$Fn3 = moduleMethod19;
        new ModuleMethod(frame4, 21, (Object) null, 0);
        lambda$Fn4 = moduleMethod20;
        new ModuleMethod(frame4, 22, (Object) null, 0);
        lambda$Fn5 = moduleMethod21;
        new ModuleMethod(frame4, 23, (Object) null, 0);
        lambda$Fn6 = moduleMethod22;
        new ModuleMethod(frame4, 24, Lit54, 0);
        this.Button9$Click = moduleMethod23;
        new ModuleMethod(frame4, 25, (Object) null, 0);
        lambda$Fn7 = moduleMethod24;
        new ModuleMethod(frame4, 26, (Object) null, 0);
        lambda$Fn8 = moduleMethod25;
        new ModuleMethod(frame4, 27, Lit66, 0);
        this.Button8$Click = moduleMethod26;
        new ModuleMethod(frame4, 28, (Object) null, 0);
        lambda$Fn9 = moduleMethod27;
        new ModuleMethod(frame4, 29, (Object) null, 0);
        lambda$Fn10 = moduleMethod28;
        new ModuleMethod(frame4, 30, Lit77, 0);
        this.Button2$Click = moduleMethod29;
        new ModuleMethod(frame4, 31, (Object) null, 0);
        lambda$Fn11 = moduleMethod30;
        new ModuleMethod(frame4, 32, (Object) null, 0);
        lambda$Fn12 = moduleMethod31;
        new ModuleMethod(frame4, 33, Lit88, 0);
        this.Button3$Click = moduleMethod32;
        new ModuleMethod(frame4, 34, (Object) null, 0);
        lambda$Fn13 = moduleMethod33;
        new ModuleMethod(frame4, 35, (Object) null, 0);
        lambda$Fn14 = moduleMethod34;
        new ModuleMethod(frame4, 36, Lit98, 0);
        this.Button5$Click = moduleMethod35;
        new ModuleMethod(frame4, 37, (Object) null, 0);
        lambda$Fn15 = moduleMethod36;
        new ModuleMethod(frame4, 38, (Object) null, 0);
        lambda$Fn16 = moduleMethod37;
        new ModuleMethod(frame4, 39, Lit110, 0);
        this.Button6$Click = moduleMethod38;
        new ModuleMethod(frame4, 40, (Object) null, 0);
        lambda$Fn17 = moduleMethod39;
        new ModuleMethod(frame4, 41, (Object) null, 0);
        lambda$Fn18 = moduleMethod40;
        new ModuleMethod(frame4, 42, Lit122, 0);
        this.Button10$Click = moduleMethod41;
        new ModuleMethod(frame4, 43, (Object) null, 0);
        lambda$Fn19 = moduleMethod42;
        new ModuleMethod(frame4, 44, (Object) null, 0);
        lambda$Fn20 = moduleMethod43;
        new ModuleMethod(frame4, 45, Lit133, 0);
        this.Button11$Click = moduleMethod44;
        new ModuleMethod(frame4, 46, (Object) null, 0);
        lambda$Fn21 = moduleMethod45;
        new ModuleMethod(frame4, 47, (Object) null, 0);
        lambda$Fn22 = moduleMethod46;
        new ModuleMethod(frame4, 48, Lit143, 0);
        this.Button12$Click = moduleMethod47;
        new ModuleMethod(frame4, 49, (Object) null, 0);
        lambda$Fn23 = moduleMethod48;
        new ModuleMethod(frame4, 50, (Object) null, 0);
        lambda$Fn24 = moduleMethod49;
        new ModuleMethod(frame4, 51, Lit159, 0);
        this.Button4$Click = moduleMethod50;
        new ModuleMethod(frame4, 52, (Object) null, 0);
        lambda$Fn25 = moduleMethod51;
        new ModuleMethod(frame4, 53, (Object) null, 0);
        lambda$Fn26 = moduleMethod52;
        new ModuleMethod(frame4, 54, (Object) null, 0);
        lambda$Fn27 = moduleMethod53;
        new ModuleMethod(frame4, 55, (Object) null, 0);
        lambda$Fn28 = moduleMethod54;
        new ModuleMethod(frame4, 56, (Object) null, 0);
        lambda$Fn29 = moduleMethod55;
        new ModuleMethod(frame4, 57, (Object) null, 0);
        lambda$Fn30 = moduleMethod56;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        Throwable th;
        String obj;
        Throwable th2;
        Object obj2;
        Consumer $result = $ctx.consumer;
        Object find = require.find("com.google.youngandroid.runtime");
        Object obj3 = find;
        try {
            ((Runnable) find).run();
            this.$Stdebug$Mnform$St = Boolean.FALSE;
            this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
            Object[] objArr = new Object[2];
            objArr[0] = misc.symbol$To$String(Lit0);
            Object[] objArr2 = objArr;
            objArr2[1] = "-global-vars";
            FString stringAppend = strings.stringAppend(objArr2);
            FString fString = stringAppend;
            if (stringAppend == null) {
                obj = null;
            } else {
                obj = fString.toString();
            }
            this.global$Mnvar$Mnenvironment = Environment.make(obj);
            Screen18 = null;
            this.form$Mnname$Mnsymbol = Lit0;
            this.events$Mnto$Mnregister = LList.Empty;
            this.components$Mnto$Mncreate = LList.Empty;
            this.global$Mnvars$Mnto$Mncreate = LList.Empty;
            this.form$Mndo$Mnafter$Mncreation = LList.Empty;
            Object find2 = require.find("com.google.youngandroid.runtime");
            Object obj4 = find2;
            try {
                ((Runnable) find2).run();
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
                    Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit6, Lit7, Lit5);
                    Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "6193580781600768", Lit9);
                    Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit10, "Cov-Aid", Lit9);
                    Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
                    Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit13, "slidevertical", Lit9);
                    Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, "ICON.png", Lit9);
                    Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit15, "fade", Lit9);
                    Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit16, Lit17, Lit5);
                    Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, Lit19, Lit5);
                    Object andCoerceProperty$Ex11 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit20, AlgorithmIdentifiers.NONE, Lit9);
                    Object andCoerceProperty$Ex12 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, Boolean.TRUE, Lit22);
                    Object andCoerceProperty$Ex13 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit23, Boolean.FALSE, Lit22);
                    Object andCoerceProperty$Ex14 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, "HomePage", Lit9);
                    Values.writeValues(C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit25, "0.1", Lit9), $result);
                } else {
                    new Promise(lambda$Fn2);
                    addToFormDoAfterCreation(obj2);
                }
                this.Label1 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit26, Lit27, lambda$Fn3), $result);
                } else {
                    addToComponents(Lit0, Lit43, Lit27, lambda$Fn4);
                }
                this.Label16 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit44, Lit45, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit46, Lit45, Boolean.FALSE);
                }
                this.Button9 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit47, Lit48, lambda$Fn5), $result);
                } else {
                    addToComponents(Lit0, Lit52, Lit48, lambda$Fn6);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment = C1241runtime.addToCurrentFormEnvironment(Lit54, this.Button9$Click);
                } else {
                    addToFormEnvironment(Lit54, this.Button9$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button9", "Click");
                } else {
                    addToEvents(Lit48, Lit55);
                }
                this.Label24 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit56, Lit57, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit58, Lit57, Boolean.FALSE);
                }
                this.Button8 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit59, Lit60, lambda$Fn7), $result);
                } else {
                    addToComponents(Lit0, Lit64, Lit60, lambda$Fn8);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment2 = C1241runtime.addToCurrentFormEnvironment(Lit66, this.Button8$Click);
                } else {
                    addToFormEnvironment(Lit66, this.Button8$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button8", "Click");
                } else {
                    addToEvents(Lit60, Lit55);
                }
                this.Label19 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit67, Lit68, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit69, Lit68, Boolean.FALSE);
                }
                this.Button2 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit70, Lit71, lambda$Fn9), $result);
                } else {
                    addToComponents(Lit0, Lit75, Lit71, lambda$Fn10);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment3 = C1241runtime.addToCurrentFormEnvironment(Lit77, this.Button2$Click);
                } else {
                    addToFormEnvironment(Lit77, this.Button2$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button2", "Click");
                } else {
                    addToEvents(Lit71, Lit55);
                }
                this.Label7 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit78, Lit79, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit80, Lit79, Boolean.FALSE);
                }
                this.Button3 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit81, Lit82, lambda$Fn11), $result);
                } else {
                    addToComponents(Lit0, Lit86, Lit82, lambda$Fn12);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment4 = C1241runtime.addToCurrentFormEnvironment(Lit88, this.Button3$Click);
                } else {
                    addToFormEnvironment(Lit88, this.Button3$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button3", "Click");
                } else {
                    addToEvents(Lit82, Lit55);
                }
                this.Label10 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit89, Lit90, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit91, Lit90, Boolean.FALSE);
                }
                this.Button5 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit92, Lit93, lambda$Fn13), $result);
                } else {
                    addToComponents(Lit0, Lit96, Lit93, lambda$Fn14);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment5 = C1241runtime.addToCurrentFormEnvironment(Lit98, this.Button5$Click);
                } else {
                    addToFormEnvironment(Lit98, this.Button5$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button5", "Click");
                } else {
                    addToEvents(Lit93, Lit55);
                }
                this.Label11 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit99, Lit100, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit101, Lit100, Boolean.FALSE);
                }
                this.Button6 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit102, Lit103, lambda$Fn15), $result);
                } else {
                    addToComponents(Lit0, Lit107, Lit103, lambda$Fn16);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment6 = C1241runtime.addToCurrentFormEnvironment(Lit110, this.Button6$Click);
                } else {
                    addToFormEnvironment(Lit110, this.Button6$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button6", "Click");
                } else {
                    addToEvents(Lit103, Lit55);
                }
                this.Label23 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit111, Lit112, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit113, Lit112, Boolean.FALSE);
                }
                this.Button10 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit114, Lit115, lambda$Fn17), $result);
                } else {
                    addToComponents(Lit0, Lit118, Lit115, lambda$Fn18);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment7 = C1241runtime.addToCurrentFormEnvironment(Lit122, this.Button10$Click);
                } else {
                    addToFormEnvironment(Lit122, this.Button10$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button10", "Click");
                } else {
                    addToEvents(Lit115, Lit55);
                }
                this.Label21 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit123, Lit124, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit125, Lit124, Boolean.FALSE);
                }
                this.Button11 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit126, Lit127, lambda$Fn19), $result);
                } else {
                    addToComponents(Lit0, Lit131, Lit127, lambda$Fn20);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment8 = C1241runtime.addToCurrentFormEnvironment(Lit133, this.Button11$Click);
                } else {
                    addToFormEnvironment(Lit133, this.Button11$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button11", "Click");
                } else {
                    addToEvents(Lit127, Lit55);
                }
                this.Label27 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit134, Lit135, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit136, Lit135, Boolean.FALSE);
                }
                this.Button12 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit137, Lit138, lambda$Fn21), $result);
                } else {
                    addToComponents(Lit0, Lit142, Lit138, lambda$Fn22);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment9 = C1241runtime.addToCurrentFormEnvironment(Lit143, this.Button12$Click);
                } else {
                    addToFormEnvironment(Lit143, this.Button12$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button12", "Click");
                } else {
                    addToEvents(Lit138, Lit55);
                }
                this.Label22 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit144, Lit145, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit146, Lit145, Boolean.FALSE);
                }
                this.Button4 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit147, Lit148, lambda$Fn23), $result);
                } else {
                    addToComponents(Lit0, Lit152, Lit148, lambda$Fn24);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment10 = C1241runtime.addToCurrentFormEnvironment(Lit159, this.Button4$Click);
                } else {
                    addToFormEnvironment(Lit159, this.Button4$Click);
                }
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button4", "Click");
                } else {
                    addToEvents(Lit148, Lit55);
                }
                this.Label18 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit160, Lit161, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit162, Lit161, Boolean.FALSE);
                }
                this.Label20 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit163, Lit164, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit165, Lit164, Boolean.FALSE);
                }
                this.Notifier1 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit166, Lit153, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit167, Lit153, Boolean.FALSE);
                }
                this.TextToSpeech1 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit168, Lit156, lambda$Fn25), $result);
                } else {
                    addToComponents(Lit0, Lit171, Lit156, lambda$Fn26);
                }
                this.Sharing1 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit172, Lit173, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit174, Lit173, Boolean.FALSE);
                }
                this.ActivityStarter1 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit175, Lit119, lambda$Fn27), $result);
                } else {
                    addToComponents(Lit0, Lit177, Lit119, lambda$Fn28);
                }
                this.Phone_Call1 = null;
                if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit178, Lit108, lambda$Fn29), $result);
                } else {
                    addToComponents(Lit0, Lit180, Lit108, lambda$Fn30);
                }
                C1241runtime.initRuntime();
            } catch (ClassCastException e) {
                ClassCastException classCastException = e;
                Throwable th3 = th2;
                new WrongType(classCastException, "java.lang.Runnable.run()", 1, obj4);
                throw th3;
            }
        } catch (ClassCastException e2) {
            ClassCastException classCastException2 = e2;
            Throwable th4 = th;
            new WrongType(classCastException2, "java.lang.Runnable.run()", 1, obj3);
            throw th4;
        }
    }

    static Object lambda3() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit6, Lit7, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "6193580781600768", Lit9);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit10, "Cov-Aid", Lit9);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit13, "slidevertical", Lit9);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit14, "ICON.png", Lit9);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit15, "fade", Lit9);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit16, Lit17, Lit5);
        Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, Lit19, Lit5);
        Object andCoerceProperty$Ex11 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit20, AlgorithmIdentifiers.NONE, Lit9);
        Object andCoerceProperty$Ex12 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex13 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit23, Boolean.FALSE, Lit22);
        Object andCoerceProperty$Ex14 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit24, "HomePage", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit25, "0.1", Lit9);
    }

    static Object lambda4() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit11, Lit28, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit30, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit31, Lit32, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit33, Lit34, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit35, Boolean.FALSE, Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit36, Lit37, Lit5);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit38, "Cov-Aid   ", Lit9);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit39, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit41, Lit42, Lit5);
    }

    static Object lambda5() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit11, Lit28, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit30, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit31, Lit32, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit33, Lit34, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit35, Boolean.FALSE, Lit22);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit36, Lit37, Lit5);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit38, "Cov-Aid   ", Lit9);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit39, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit27, Lit41, Lit42, Lit5);
    }

    static Object lambda6() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit11, Lit49, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit36, Lit50, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit38, "CoronaVirus Probability Test", Lit9);
    }

    static Object lambda7() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit11, Lit49, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit36, Lit50, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit38, "CoronaVirus Probability Test", Lit9);
    }

    public Object Button9$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen17"), Lit53, "open another screen");
    }

    static Object lambda8() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit11, Lit61, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit36, Lit62, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit38, "Donate or Retrieve Food", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit41, Lit63, Lit5);
    }

    static Object lambda9() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit11, Lit61, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit36, Lit62, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit38, "Donate or Retrieve Food", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit60, Lit41, Lit63, Lit5);
    }

    public Object Button8$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen28"), Lit65, "open another screen");
    }

    static Object lambda10() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit11, Lit72, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit36, Lit74, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit38, "Corona Games", Lit9);
    }

    static Object lambda11() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit11, Lit72, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit36, Lit74, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit71, Lit38, "Corona Games", Lit9);
    }

    public Object Button2$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen24"), Lit76, "open another screen");
    }

    static Object lambda12() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit11, Lit83, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit36, Lit84, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit38, "Respiration Exercise", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit41, Lit85, Lit5);
    }

    static Object lambda13() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit11, Lit83, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit36, Lit84, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit38, "Respiration Exercise", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit82, Lit41, Lit85, Lit5);
    }

    public Object Button3$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen22"), Lit87, "open another screen");
    }

    static Object lambda14() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit11, Lit94, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit36, Lit95, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit38, "Web-Page", Lit9);
    }

    static Object lambda15() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit11, Lit94, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit36, Lit95, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit38, "Web-Page", Lit9);
    }

    public Object Button5$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen23"), Lit97, "open another screen");
    }

    static Object lambda16() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit11, Lit104, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit36, Lit105, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit38, "Emergency Helpline Call", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit41, Lit106, Lit5);
    }

    static Object lambda17() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit11, Lit104, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit36, Lit105, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit38, "Emergency Helpline Call", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit103, Lit41, Lit106, Lit5);
    }

    public Object Button6$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit108, Lit109, LList.Empty, LList.Empty);
    }

    static Object lambda18() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit11, Lit116, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit36, Lit117, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit38, "No Face Touch Sensing", Lit9);
    }

    static Object lambda19() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit11, Lit116, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit36, Lit117, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit51, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit115, Lit38, "No Face Touch Sensing", Lit9);
    }

    public Object Button10$Click() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit120, "https://editor.p5js.org/amitabisen.1/present/t31ajbcPYb", Lit9);
        return C1241runtime.callComponentMethod(Lit119, Lit121, LList.Empty, LList.Empty);
    }

    static Object lambda20() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit11, Lit128, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit36, Lit129, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit38, "MEDICINE REMINDER", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit41, Lit130, Lit5);
    }

    static Object lambda21() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit11, Lit128, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit36, Lit129, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit38, "MEDICINE REMINDER", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit41, Lit130, Lit5);
    }

    public Object Button11$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen30"), Lit132, "open another screen");
    }

    static Object lambda22() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit11, Lit139, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit36, Lit140, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit38, "WEBSITE", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit41, Lit141, Lit5);
    }

    static Object lambda23() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit11, Lit139, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit36, Lit140, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit38, "WEBSITE", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit41, Lit141, Lit5);
    }

    public Object Button12$Click() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit120, "https://cov-aid-ansh.web.app/", Lit9);
        return C1241runtime.callComponentMethod(Lit119, Lit121, LList.Empty, LList.Empty);
    }

    static Object lambda24() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit11, Lit149, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit36, Lit150, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit38, "Credits", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit41, Lit151, Lit5);
    }

    static Object lambda25() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit11, Lit149, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit29, Boolean.TRUE, Lit22);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit31, Lit73, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit36, Lit150, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit51, Lit40, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit38, "Credits", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit148, Lit41, Lit151, Lit5);
    }

    public Object Button4$Click() {
        C1241runtime.setThisForm();
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit153, Lit154, LList.list3("App by Ansh Singh- EMAIL- anshsingh2006.1@gmail.com", "CREDITS", "OKAY"), Lit155);
        return C1241runtime.callComponentMethod(Lit156, Lit157, LList.list1("App by (Ansh Singh). EMAIL- anshsingh2006.1@gmail.com"), Lit158);
    }

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen18$frame */
    /* compiled from: Screen18.yail */
    public class frame extends ModuleBody {
        Screen18 $main;

        public frame() {
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Screen18)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Screen18)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof Screen18)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            Throwable th;
            Throwable th2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th3 = th2;
                        new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw th3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th4 = th;
                        new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw th4;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            Throwable th6;
            Throwable th7;
            Throwable th8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    Throwable th9 = th8;
                                    new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw th9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                Throwable th10 = th7;
                                new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw th10;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            Throwable th11 = th6;
                            new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw th11;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        Throwable th12 = th5;
                        new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw th12;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    Throwable th13 = th4;
                                    new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw th13;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                Throwable th14 = th3;
                                new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw th14;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            Throwable th15 = th2;
                            new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw th15;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        Throwable th16 = th;
                        new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw th16;
                    }
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th4 = th3;
                        new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw th4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th2;
                        new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw th5;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        Throwable th6 = th;
                        new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw th6;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return Screen18.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return Screen18.lambda3();
                case 20:
                    return Screen18.lambda4();
                case 21:
                    return Screen18.lambda5();
                case 22:
                    return Screen18.lambda6();
                case 23:
                    return Screen18.lambda7();
                case 24:
                    return this.$main.Button9$Click();
                case 25:
                    return Screen18.lambda8();
                case 26:
                    return Screen18.lambda9();
                case 27:
                    return this.$main.Button8$Click();
                case 28:
                    return Screen18.lambda10();
                case 29:
                    return Screen18.lambda11();
                case 30:
                    return this.$main.Button2$Click();
                case 31:
                    return Screen18.lambda12();
                case 32:
                    return Screen18.lambda13();
                case 33:
                    return this.$main.Button3$Click();
                case 34:
                    return Screen18.lambda14();
                case 35:
                    return Screen18.lambda15();
                case 36:
                    return this.$main.Button5$Click();
                case 37:
                    return Screen18.lambda16();
                case 38:
                    return Screen18.lambda17();
                case 39:
                    return this.$main.Button6$Click();
                case 40:
                    return Screen18.lambda18();
                case 41:
                    return Screen18.lambda19();
                case 42:
                    return this.$main.Button10$Click();
                case 43:
                    return Screen18.lambda20();
                case 44:
                    return Screen18.lambda21();
                case 45:
                    return this.$main.Button11$Click();
                case 46:
                    return Screen18.lambda22();
                case 47:
                    return Screen18.lambda23();
                case 48:
                    return this.$main.Button12$Click();
                case 49:
                    return Screen18.lambda24();
                case 50:
                    return Screen18.lambda25();
                case 51:
                    return this.$main.Button4$Click();
                case 52:
                    return Screen18.lambda26();
                case 53:
                    return Screen18.lambda27();
                case 54:
                    return Screen18.lambda28();
                case 55:
                    return Screen18.lambda29();
                case 56:
                    return Screen18.lambda30();
                case 57:
                    return Screen18.lambda31();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 20:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 23:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 24:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 30:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 31:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 32:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 33:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 34:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 35:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 36:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 37:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 38:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 39:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 40:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 41:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 42:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 43:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 44:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 45:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 46:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 47:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 48:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 49:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 50:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 51:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 52:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 53:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 54:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 55:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 56:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 57:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }
    }

    static Object lambda26() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit156, Lit169, Lit170, Lit5);
    }

    static Object lambda27() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit156, Lit169, Lit170, Lit5);
    }

    static Object lambda28() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit176, "android.intent.action.VIEW", Lit9);
    }

    static Object lambda29() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit176, "android.intent.action.VIEW", Lit9);
    }

    static Object lambda30() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit108, Lit179, "91-1123978046", Lit9);
    }

    static Object lambda31() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit108, Lit179, "91-1123978046", Lit9);
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.form$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name = symbol;
        Object default$Mnvalue = obj;
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & true;
        if (!x ? !x : !this.form$Mnenvironment.isBound(name)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = C1271lists.cons(C1271lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = C1271lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = C1271lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = C1271lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        Object obj = error;
        RetValManager.sendError(obj == null ? null : obj.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        objArr2[0] = "any$";
        Object[] objArr3 = objArr2;
        objArr3[1] = getSimpleName(componentObject);
        Object[] objArr4 = objArr3;
        objArr4[2] = "$";
        Object[] objArr5 = objArr4;
        objArr5[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr5)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1271lists.cons(component2, C1271lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object componentName, Object obj) {
        Object eventName = obj;
        Object obj2 = componentName;
        String obj3 = obj2 == null ? null : obj2.toString();
        Object obj4 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj3, obj4 == null ? null : obj4.toString())));
    }

    public void $define() {
        Object obj;
        Throwable th;
        Object obj2;
        Throwable th2;
        Object obj3;
        Throwable th3;
        Object obj4;
        Throwable th4;
        Object obj5;
        Throwable th5;
        Object obj6;
        Throwable th6;
        Object obj7;
        Throwable th7;
        Object obj8;
        Throwable th8;
        Throwable th9;
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception e) {
            Exception exception = e;
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        Screen18 = this;
        addToFormEnvironment(Lit0, this);
        Object obj9 = this.events$Mnto$Mnregister;
        while (true) {
            Object obj10 = obj9;
            if (obj10 == LList.Empty) {
                break;
            }
            Object obj11 = obj10;
            Object obj12 = obj11;
            try {
                Pair arg0 = (Pair) obj11;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = C1271lists.car.apply1(event$Mninfo);
                String obj13 = apply1 == null ? null : apply1.toString();
                Object apply12 = C1271lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj13, apply12 == null ? null : apply12.toString());
                obj9 = arg0.getCdr();
            } catch (ClassCastException e2) {
                ClassCastException classCastException = e2;
                Throwable th10 = th9;
                new WrongType(classCastException, "arg0", -2, obj12);
                throw th10;
            }
        }
        try {
            LList components = C1271lists.reverse(this.components$Mnto$Mncreate);
            addToGlobalVars(Lit2, lambda$Fn1);
            LList event$Mninfo2 = components;
            while (event$Mninfo2 != LList.Empty) {
                Object obj14 = event$Mninfo2;
                obj6 = obj14;
                Pair arg02 = (Pair) obj14;
                Object component$Mninfo = arg02.getCar();
                Object apply13 = C1271lists.caddr.apply1(component$Mninfo);
                Object apply14 = C1271lists.cadddr.apply1(component$Mninfo);
                Object component$Mntype = C1271lists.cadr.apply1(component$Mninfo);
                Object apply15 = C1271lists.car.apply1(component$Mninfo);
                obj7 = apply15;
                Object component$Mnname = apply13;
                Object component$Mnobject = Invoke.make.apply2(component$Mntype, lookupInFormEnvironment((Symbol) apply15));
                Object apply3 = SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
                Object obj15 = component$Mnname;
                obj8 = obj15;
                addToFormEnvironment((Symbol) obj15, component$Mnobject);
                event$Mninfo2 = arg02.getCdr();
            }
            LList reverse = C1271lists.reverse(this.global$Mnvars$Mnto$Mncreate);
            while (reverse != LList.Empty) {
                Object obj16 = reverse;
                obj4 = obj16;
                Pair arg03 = (Pair) obj16;
                Object var$Mnval = arg03.getCar();
                Object apply16 = C1271lists.car.apply1(var$Mnval);
                obj5 = apply16;
                addToGlobalVarEnvironment((Symbol) apply16, Scheme.applyToArgs.apply1(C1271lists.cadr.apply1(var$Mnval)));
                reverse = arg03.getCdr();
            }
            Object reverse2 = C1271lists.reverse(this.form$Mndo$Mnafter$Mncreation);
            while (reverse2 != LList.Empty) {
                Object obj17 = reverse2;
                obj3 = obj17;
                Pair arg04 = (Pair) obj17;
                Object force = misc.force(arg04.getCar());
                reverse2 = arg04.getCdr();
            }
            LList component$Mndescriptors = components;
            LList lList = component$Mndescriptors;
            while (lList != LList.Empty) {
                Object obj18 = lList;
                obj2 = obj18;
                Pair arg05 = (Pair) obj18;
                Object component$Mninfo2 = arg05.getCar();
                Object apply17 = C1271lists.caddr.apply1(component$Mninfo2);
                Object init$Mnthunk = C1271lists.cadddr.apply1(component$Mninfo2);
                if (init$Mnthunk != Boolean.FALSE) {
                    Object apply18 = Scheme.applyToArgs.apply1(init$Mnthunk);
                }
                lList = arg05.getCdr();
            }
            LList lList2 = component$Mndescriptors;
            while (lList2 != LList.Empty) {
                Object obj19 = lList2;
                obj = obj19;
                Pair arg06 = (Pair) obj19;
                Object component$Mninfo3 = arg06.getCar();
                Object component$Mnname2 = C1271lists.caddr.apply1(component$Mninfo3);
                Object apply19 = C1271lists.cadddr.apply1(component$Mninfo3);
                callInitialize(SlotGet.field.apply2(this, component$Mnname2));
                lList2 = arg06.getCdr();
            }
        } catch (ClassCastException e3) {
            ClassCastException classCastException2 = e3;
            Throwable th11 = th;
            new WrongType(classCastException2, "arg0", -2, obj);
            throw th11;
        } catch (ClassCastException e4) {
            ClassCastException classCastException3 = e4;
            Throwable th12 = th2;
            new WrongType(classCastException3, "arg0", -2, obj2);
            throw th12;
        } catch (ClassCastException e5) {
            ClassCastException classCastException4 = e5;
            Throwable th13 = th3;
            new WrongType(classCastException4, "arg0", -2, obj3);
            throw th13;
        } catch (ClassCastException e6) {
            ClassCastException classCastException5 = e6;
            Throwable th14 = th5;
            new WrongType(classCastException5, "add-to-global-var-environment", 0, obj5);
            throw th14;
        } catch (ClassCastException e7) {
            ClassCastException classCastException6 = e7;
            Throwable th15 = th4;
            new WrongType(classCastException6, "arg0", -2, obj4);
            throw th15;
        } catch (ClassCastException e8) {
            ClassCastException classCastException7 = e8;
            Throwable th16 = th8;
            new WrongType(classCastException7, "add-to-form-environment", 0, obj8);
            throw th16;
        } catch (ClassCastException e9) {
            ClassCastException classCastException8 = e9;
            Throwable th17 = th7;
            new WrongType(classCastException8, "lookup-in-form-environment", 0, obj7);
            throw th17;
        } catch (ClassCastException e10) {
            ClassCastException classCastException9 = e10;
            Throwable th18 = th6;
            new WrongType(classCastException9, "arg0", -2, obj6);
            throw th18;
        } catch (YailRuntimeError e11) {
            processException(e11);
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        LList symbols = LList.makeList(argsArray, 0);
        LList lList = symbols;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj = symbols;
        Object obj2 = LList.Empty;
        while (true) {
            Object obj3 = obj2;
            Object obj4 = obj;
            if (obj4 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj3));
                Object obj5 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    Throwable th4 = th;
                    new WrongType(classCastException, "string->symbol", 1, obj5);
                    throw th4;
                }
            } else {
                Object obj6 = obj4;
                Object obj7 = obj6;
                try {
                    Pair arg0 = (Pair) obj6;
                    obj = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj8 = car;
                    try {
                        obj2 = Pair.make(misc.symbol$To$String((Symbol) car), obj3);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th3;
                        new WrongType(classCastException2, "symbol->string", 1, obj8);
                        throw th5;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    Throwable th6 = th2;
                    new WrongType(classCastException3, "arg0", -2, obj7);
                    throw th6;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
