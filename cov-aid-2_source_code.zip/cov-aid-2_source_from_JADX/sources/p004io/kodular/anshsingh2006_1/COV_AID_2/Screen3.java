package p004io.kodular.anshsingh2006_1.COV_AID_2;

import android.support.p000v4.app.FragmentTransaction;
import android.support.p000v4.view.InputDeviceCompat;
import android.support.p003v7.widget.helper.ItemTouchHelper;
import com.LukeGackle.JSONTools;
import com.google.appinventor.components.common.ComponentConstants;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.common.YaVersion;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.KodularImageUtilities;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.ListPicker;
import com.google.appinventor.components.runtime.MakeroidSnackbar;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.ProgressBar;
import com.google.appinventor.components.runtime.SpaceView;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.FullScreenVideoUtil;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1241runtime;
import com.microsoft.appcenter.crashes.utils.ErrorLogHelper;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.AddOp;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.Procedure;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.Telnet;
import kawa.lang.Promise;
import kawa.lib.C1271lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.shaded.apache.http.HttpStatus;
import org.slf4j.Marker;
import p011in.jsonutils.JsonUtils;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen3 */
/* compiled from: Screen3.yail */
public class Screen3 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final FString Lit100;
    static final FString Lit101;
    static final SimpleSymbol Lit102;
    static final FString Lit103;
    static final FString Lit104;
    static final SimpleSymbol Lit105;
    static final FString Lit106;
    static final FString Lit107;
    static final IntNum Lit108 = IntNum.make(16777215);
    static final FString Lit109;
    static final SimpleSymbol Lit11;
    static final FString Lit110;
    static final SimpleSymbol Lit111;
    static final IntNum Lit112;
    static final IntNum Lit113 = IntNum.make(-1015);
    static final FString Lit114;
    static final FString Lit115;
    static final SimpleSymbol Lit116;
    static final FString Lit117;
    static final FString Lit118;
    static final SimpleSymbol Lit119;
    static final SimpleSymbol Lit12;
    static final FString Lit120;
    static final FString Lit121;
    static final SimpleSymbol Lit122;
    static final IntNum Lit123;
    static final IntNum Lit124 = IntNum.make(-1015);
    static final FString Lit125;
    static final FString Lit126;
    static final SimpleSymbol Lit127;
    static final FString Lit128;
    static final FString Lit129;
    static final PairWithPosition Lit13 = PairWithPosition.make(Lit725, PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, PairWithPosition.make(Lit10, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49428), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49423), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49418), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49413), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49402);
    static final SimpleSymbol Lit130;
    static final FString Lit131;
    static final FString Lit132;
    static final SimpleSymbol Lit133;
    static final IntNum Lit134;
    static final IntNum Lit135 = IntNum.make(-1015);
    static final FString Lit136;
    static final FString Lit137;
    static final SimpleSymbol Lit138;
    static final FString Lit139;
    static final SimpleSymbol Lit14;
    static final FString Lit140;
    static final SimpleSymbol Lit141;
    static final FString Lit142;
    static final FString Lit143;
    static final SimpleSymbol Lit144;
    static final IntNum Lit145;
    static final IntNum Lit146 = IntNum.make(-1015);
    static final FString Lit147;
    static final FString Lit148;
    static final SimpleSymbol Lit149;
    static final PairWithPosition Lit15 = PairWithPosition.make(Lit725, PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, PairWithPosition.make(Lit10, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49428), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49423), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49418), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49413), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 49402);
    static final FString Lit150;
    static final FString Lit151;
    static final SimpleSymbol Lit152;
    static final FString Lit153;
    static final FString Lit154;
    static final SimpleSymbol Lit155;
    static final IntNum Lit156;
    static final IntNum Lit157 = IntNum.make(-1015);
    static final FString Lit158;
    static final FString Lit159;
    static final SimpleSymbol Lit16;
    static final SimpleSymbol Lit160;
    static final FString Lit161;
    static final FString Lit162;
    static final SimpleSymbol Lit163;
    static final FString Lit164;
    static final FString Lit165;
    static final IntNum Lit166 = IntNum.make(16777215);
    static final FString Lit167;
    static final FString Lit168;
    static final SimpleSymbol Lit169;
    static final SimpleSymbol Lit17;
    static final IntNum Lit170;
    static final IntNum Lit171 = IntNum.make(-1015);
    static final FString Lit172;
    static final FString Lit173;
    static final SimpleSymbol Lit174;
    static final IntNum Lit175 = IntNum.make(18);
    static final FString Lit176;
    static final FString Lit177;
    static final SimpleSymbol Lit178;
    static final FString Lit179;
    static final SimpleSymbol Lit18;
    static final FString Lit180;
    static final SimpleSymbol Lit181;
    static final IntNum Lit182;
    static final SimpleSymbol Lit183;
    static final IntNum Lit184 = IntNum.make(7);
    static final FString Lit185;
    static final SimpleSymbol Lit186;
    static final SimpleSymbol Lit187;
    static final FString Lit188;
    static final SimpleSymbol Lit189;
    static final PairWithPosition Lit19 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53401), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53395);
    static final FString Lit190;
    static final FString Lit191;
    static final SimpleSymbol Lit192;
    static final IntNum Lit193;
    static final IntNum Lit194 = IntNum.make(-1015);
    static final FString Lit195;
    static final FString Lit196;
    static final SimpleSymbol Lit197;
    static final FString Lit198;
    static final FString Lit199;
    static final SimpleSymbol Lit2;
    static final SimpleSymbol Lit20;
    static final SimpleSymbol Lit200;
    static final FString Lit201;
    static final FString Lit202;
    static final SimpleSymbol Lit203;
    static final IntNum Lit204;
    static final FString Lit205;
    static final SimpleSymbol Lit206;
    static final FString Lit207;
    static final SimpleSymbol Lit208;
    static final FString Lit209;
    static final SimpleSymbol Lit21;
    static final FString Lit210;
    static final SimpleSymbol Lit211;
    static final IntNum Lit212;
    static final IntNum Lit213 = IntNum.make(-1015);
    static final FString Lit214;
    static final FString Lit215;
    static final SimpleSymbol Lit216;
    static final FString Lit217;
    static final FString Lit218;
    static final SimpleSymbol Lit219;
    static final PairWithPosition Lit22 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53635), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53630);
    static final FString Lit220;
    static final FString Lit221;
    static final SimpleSymbol Lit222;
    static final FString Lit223;
    static final FString Lit224;
    static final SimpleSymbol Lit225;
    static final IntNum Lit226;
    static final IntNum Lit227 = IntNum.make(-1015);
    static final FString Lit228;
    static final FString Lit229;
    static final PairWithPosition Lit23 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53753), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53748);
    static final SimpleSymbol Lit230;
    static final FString Lit231;
    static final FString Lit232;
    static final SimpleSymbol Lit233;
    static final FString Lit234;
    static final FString Lit235;
    static final IntNum Lit236 = IntNum.make(-1030);
    static final IntNum Lit237 = IntNum.make(-1075);
    static final FString Lit238;
    static final FString Lit239;
    static final PairWithPosition Lit24 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53782), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53777);
    static final SimpleSymbol Lit240;
    static final SimpleSymbol Lit241;
    static final IntNum Lit242;
    static final FString Lit243;
    static final FString Lit244;
    static final SimpleSymbol Lit245;
    static final IntNum Lit246 = IntNum.make(-1002);
    static final FString Lit247;
    static final FString Lit248;
    static final SimpleSymbol Lit249;
    static final SimpleSymbol Lit25;
    static final IntNum Lit250;
    static final IntNum Lit251 = IntNum.make(24);
    static final FString Lit252;
    static final FString Lit253;
    static final IntNum Lit254;
    static final SimpleSymbol Lit255;
    static final FString Lit256;
    static final FString Lit257;
    static final SimpleSymbol Lit258;
    static final FString Lit259;
    static final SimpleSymbol Lit26;
    static final FString Lit260;
    static final IntNum Lit261 = IntNum.make(-1005);
    static final IntNum Lit262 = IntNum.make(-1010);
    static final FString Lit263;
    static final FString Lit264;
    static final SimpleSymbol Lit265;
    static final IntNum Lit266 = IntNum.make(-1003);
    static final FString Lit267;
    static final FString Lit268;
    static final SimpleSymbol Lit269;
    static final PairWithPosition Lit27 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53401), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53395);
    static final FString Lit270;
    static final FString Lit271;
    static final SimpleSymbol Lit272;
    static final IntNum Lit273 = IntNum.make(-1010);
    static final FString Lit274;
    static final FString Lit275;
    static final SimpleSymbol Lit276;
    static final IntNum Lit277;
    static final FString Lit278;
    static final FString Lit279;
    static final PairWithPosition Lit28 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53635), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53630);
    static final SimpleSymbol Lit280;
    static final SimpleSymbol Lit281;
    static final IntNum Lit282 = IntNum.make(12);
    static final SimpleSymbol Lit283;
    static final IntNum Lit284;
    static final FString Lit285;
    static final PairWithPosition Lit286 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3108975), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3108970);
    static final SimpleSymbol Lit287;
    static final SimpleSymbol Lit288;
    static final PairWithPosition Lit289 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3109497);
    static final PairWithPosition Lit29 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53753), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53748);
    static final SimpleSymbol Lit290;
    static final SimpleSymbol Lit291;
    static final PairWithPosition Lit292 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3109636), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3109630);
    static final SimpleSymbol Lit293;
    static final PairWithPosition Lit294 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3109794), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3109788);
    static final SimpleSymbol Lit295;
    static final PairWithPosition Lit296 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3109953), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3109947);
    static final SimpleSymbol Lit297;
    static final PairWithPosition Lit298 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3110118), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3110112);
    static final SimpleSymbol Lit299;
    static final SimpleSymbol Lit3;
    static final PairWithPosition Lit30 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53782), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 53777);
    static final PairWithPosition Lit300 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3110284), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3110278);
    static final SimpleSymbol Lit301;
    static final FString Lit302;
    static final IntNum Lit303;
    static final FString Lit304;
    static final FString Lit305;
    static final SimpleSymbol Lit306;
    static final IntNum Lit307 = IntNum.make(-1030);
    static final IntNum Lit308 = IntNum.make(-1060);
    static final SimpleSymbol Lit309;
    static final SimpleSymbol Lit31;
    static final FString Lit310;
    static final FString Lit311;
    static final SimpleSymbol Lit312;
    static final FString Lit313;
    static final FString Lit314;
    static final SimpleSymbol Lit315;
    static final IntNum Lit316;
    static final FString Lit317;
    static final FString Lit318;
    static final SimpleSymbol Lit319;
    static final IntNum Lit32 = IntNum.make(2);
    static final IntNum Lit320 = IntNum.make(30);
    static final IntNum Lit321;
    static final FString Lit322;
    static final FString Lit323;
    static final SimpleSymbol Lit324;
    static final IntNum Lit325 = IntNum.make(-1004);
    static final FString Lit326;
    static final FString Lit327;
    static final SimpleSymbol Lit328;
    static final IntNum Lit329;
    static final SimpleSymbol Lit33;
    static final SimpleSymbol Lit330;
    static final IntNum Lit331;
    static final FString Lit332;
    static final SimpleSymbol Lit333;
    static final SimpleSymbol Lit334;
    static final SimpleSymbol Lit335;
    static final FString Lit336;
    static final SimpleSymbol Lit337;
    static final IntNum Lit338 = IntNum.make(-1002);
    static final FString Lit339;
    static final IntNum Lit34;
    static final FString Lit340;
    static final SimpleSymbol Lit341;
    static final IntNum Lit342;
    static final IntNum Lit343;
    static final FString Lit344;
    static final SimpleSymbol Lit345;
    static final PairWithPosition Lit346 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3555484);
    static final PairWithPosition Lit347 = PairWithPosition.make(Lit10, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3555511);
    static final SimpleSymbol Lit348;
    static final PairWithPosition Lit349 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 3555756);
    static final SimpleSymbol Lit35;
    static final SimpleSymbol Lit350;
    static final FString Lit351;
    static final SimpleSymbol Lit352;
    static final SimpleSymbol Lit353;
    static final IntNum Lit354;
    static final SimpleSymbol Lit355;
    static final IntNum Lit356;
    static final SimpleSymbol Lit357;
    static final SimpleSymbol Lit358;
    static final IntNum Lit359;
    static final SimpleSymbol Lit36;
    static final SimpleSymbol Lit360;
    static final IntNum Lit361;
    static final FString Lit362;
    static final SimpleSymbol Lit363;
    static final SimpleSymbol Lit364;
    static final SimpleSymbol Lit365;
    static final FString Lit366;
    static final IntNum Lit367;
    static final FString Lit368;
    static final FString Lit369;
    static final IntNum Lit37 = IntNum.make(3);
    static final IntNum Lit370;
    static final FString Lit371;
    static final FString Lit372;
    static final SimpleSymbol Lit373;
    static final FString Lit374;
    static final FString Lit375;
    static final SimpleSymbol Lit376;
    static final IntNum Lit377 = IntNum.make(16777215);
    static final FString Lit378;
    static final FString Lit379;
    static final SimpleSymbol Lit38;
    static final SimpleSymbol Lit380;
    static final IntNum Lit381;
    static final IntNum Lit382 = IntNum.make(-1015);
    static final FString Lit383;
    static final FString Lit384;
    static final SimpleSymbol Lit385;
    static final FString Lit386;
    static final FString Lit387;
    static final FString Lit388;
    static final FString Lit389;
    static final SimpleSymbol Lit39;
    static final SimpleSymbol Lit390;
    static final IntNum Lit391;
    static final FString Lit392;
    static final SimpleSymbol Lit393;
    static final SimpleSymbol Lit394;
    static final PairWithPosition Lit395 = PairWithPosition.make(Lit725, PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, PairWithPosition.make(Lit20, PairWithPosition.make(Lit10, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100327), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100322), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100317), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100312), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100301);
    static final PairWithPosition Lit396 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100420);
    static final SimpleSymbol Lit397;
    static final PairWithPosition Lit398 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100578), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100572);
    static final SimpleSymbol Lit399;
    static final SimpleSymbol Lit4;
    static final SimpleSymbol Lit40;
    static final PairWithPosition Lit400 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100759), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100753);
    static final SimpleSymbol Lit401;
    static final PairWithPosition Lit402 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100944), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4100938);
    static final SimpleSymbol Lit403;
    static final PairWithPosition Lit404 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101126), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101120);
    static final SimpleSymbol Lit405;
    static final PairWithPosition Lit406 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101321), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101315);
    static final SimpleSymbol Lit407;
    static final PairWithPosition Lit408 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101514), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101508);
    static final SimpleSymbol Lit409;
    static final IntNum Lit41;
    static final PairWithPosition Lit410 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101705), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101699);
    static final SimpleSymbol Lit411;
    static final PairWithPosition Lit412 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101901), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4101895);
    static final SimpleSymbol Lit413;
    static final PairWithPosition Lit414 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4102098), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4102092);
    static final SimpleSymbol Lit415;
    static final FString Lit416;
    static final SimpleSymbol Lit417;
    static final FString Lit418;
    static final FString Lit419;
    static final SimpleSymbol Lit42;
    static final SimpleSymbol Lit420;
    static final IntNum Lit421;
    static final IntNum Lit422 = IntNum.make(-1015);
    static final FString Lit423;
    static final FString Lit424;
    static final SimpleSymbol Lit425;
    static final FString Lit426;
    static final FString Lit427;
    static final FString Lit428;
    static final FString Lit429;
    static final IntNum Lit43;
    static final SimpleSymbol Lit430;
    static final IntNum Lit431;
    static final FString Lit432;
    static final PairWithPosition Lit433;
    static final PairWithPosition Lit434 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4374852);
    static final PairWithPosition Lit435 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375010), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375004);
    static final PairWithPosition Lit436 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375191), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375185);
    static final PairWithPosition Lit437 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375376), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375370);
    static final PairWithPosition Lit438 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375558), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375552);
    static final PairWithPosition Lit439 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375753), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375747);
    static final SimpleSymbol Lit44;
    static final PairWithPosition Lit440 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375946), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4375940);
    static final PairWithPosition Lit441 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4376137), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4376131);
    static final PairWithPosition Lit442 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4376333), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4376327);
    static final PairWithPosition Lit443 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4376530), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4376524);
    static final SimpleSymbol Lit444;
    static final FString Lit445;
    static final SimpleSymbol Lit446;
    static final FString Lit447;
    static final FString Lit448;
    static final SimpleSymbol Lit449;
    static final SimpleSymbol Lit45;
    static final IntNum Lit450;
    static final IntNum Lit451 = IntNum.make(-1015);
    static final FString Lit452;
    static final FString Lit453;
    static final SimpleSymbol Lit454;
    static final FString Lit455;
    static final FString Lit456;
    static final FString Lit457;
    static final FString Lit458;
    static final SimpleSymbol Lit459;
    static final SimpleSymbol Lit46;
    static final FString Lit460;
    static final FString Lit461;
    static final SimpleSymbol Lit462;
    static final IntNum Lit463;
    static final IntNum Lit464 = IntNum.make(-1015);
    static final FString Lit465;
    static final FString Lit466;
    static final SimpleSymbol Lit467;
    static final FString Lit468;
    static final FString Lit469;
    static final SimpleSymbol Lit47;
    static final FString Lit470;
    static final FString Lit471;
    static final SimpleSymbol Lit472;
    static final FString Lit473;
    static final FString Lit474;
    static final SimpleSymbol Lit475;
    static final IntNum Lit476;
    static final FString Lit477;
    static final PairWithPosition Lit478 = PairWithPosition.make(Lit35, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874325), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874317);
    static final SimpleSymbol Lit479;
    static final SimpleSymbol Lit48;
    static final SimpleSymbol Lit480;
    static final PairWithPosition Lit481 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874456);
    static final PairWithPosition Lit482 = PairWithPosition.make(Lit35, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874569), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874561);
    static final PairWithPosition Lit483 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874666);
    static final PairWithPosition Lit484 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874823), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874817);
    static final PairWithPosition Lit485 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874999), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4874993);
    static final PairWithPosition Lit486 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4875176), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4875170);
    static final PairWithPosition Lit487 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4875359), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4875353);
    static final PairWithPosition Lit488 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4875543), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4875537);
    static final SimpleSymbol Lit489;
    static final SimpleSymbol Lit49;
    static final FString Lit490;
    static final SimpleSymbol Lit491;
    static final IntNum Lit492 = IntNum.make(-1002);
    static final FString Lit493;
    static final FString Lit494;
    static final SimpleSymbol Lit495;
    static final IntNum Lit496;
    static final FString Lit497;
    static final IntNum Lit498 = IntNum.make(37);
    static final PairWithPosition Lit499 = PairWithPosition.make(Lit35, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4972630), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4972622);
    static final SimpleSymbol Lit5;
    static final SimpleSymbol Lit50;
    static final PairWithPosition Lit500 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4972761);
    static final PairWithPosition Lit501 = PairWithPosition.make(Lit35, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4972875), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4972867);
    static final PairWithPosition Lit502 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4972973);
    static final PairWithPosition Lit503 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973130), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973124);
    static final PairWithPosition Lit504 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973306), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973300);
    static final PairWithPosition Lit505 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973483), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973477);
    static final PairWithPosition Lit506 = PairWithPosition.make(Lit20, PairWithPosition.make(Lit35, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973666), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973660);
    static final PairWithPosition Lit507;
    static final SimpleSymbol Lit508;
    static final FString Lit509;
    static final SimpleSymbol Lit51;
    static final IntNum Lit510;
    static final FString Lit511;
    static final FString Lit512;
    static final SimpleSymbol Lit513;
    static final FString Lit514;
    static final FString Lit515;
    static final IntNum Lit516;
    static final FString Lit517;
    static final FString Lit518;
    static final SimpleSymbol Lit519;
    static final PairWithPosition Lit52 = PairWithPosition.make(Lit725, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 123075), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 123064);
    static final IntNum Lit520;
    static final IntNum Lit521;
    static final FString Lit522;
    static final SimpleSymbol Lit523;
    static final SimpleSymbol Lit524;
    static final FString Lit525;
    static final SimpleSymbol Lit526;
    static final FString Lit527;
    static final FString Lit528;
    static final SimpleSymbol Lit529;
    static final SimpleSymbol Lit53;
    static final IntNum Lit530;
    static final IntNum Lit531 = IntNum.make(-1005);
    static final FString Lit532;
    static final FString Lit533;
    static final SimpleSymbol Lit534;
    static final FString Lit535;
    static final FString Lit536;
    static final FString Lit537;
    static final FString Lit538;
    static final SimpleSymbol Lit539;
    static final PairWithPosition Lit54 = PairWithPosition.make(Lit725, PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 123219), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 123208);
    static final FString Lit540;
    static final FString Lit541;
    static final SimpleSymbol Lit542;
    static final IntNum Lit543;
    static final IntNum Lit544 = IntNum.make(-1005);
    static final FString Lit545;
    static final FString Lit546;
    static final SimpleSymbol Lit547;
    static final FString Lit548;
    static final FString Lit549;
    static final SimpleSymbol Lit55;
    static final FString Lit550;
    static final FString Lit551;
    static final SimpleSymbol Lit552;
    static final FString Lit553;
    static final FString Lit554;
    static final SimpleSymbol Lit555;
    static final IntNum Lit556;
    static final IntNum Lit557 = IntNum.make(-1005);
    static final FString Lit558;
    static final FString Lit559;
    static final SimpleSymbol Lit56;
    static final SimpleSymbol Lit560;
    static final FString Lit561;
    static final FString Lit562;
    static final FString Lit563;
    static final FString Lit564;
    static final SimpleSymbol Lit565;
    static final FString Lit566;
    static final FString Lit567;
    static final SimpleSymbol Lit568;
    static final IntNum Lit569;
    static final SimpleSymbol Lit57;
    static final IntNum Lit570 = IntNum.make(-1005);
    static final FString Lit571;
    static final FString Lit572;
    static final SimpleSymbol Lit573;
    static final FString Lit574;
    static final FString Lit575;
    static final FString Lit576;
    static final FString Lit577;
    static final SimpleSymbol Lit578;
    static final FString Lit579;
    static final PairWithPosition Lit58 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 131208), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 131203);
    static final FString Lit580;
    static final SimpleSymbol Lit581;
    static final IntNum Lit582;
    static final IntNum Lit583 = IntNum.make(-1005);
    static final FString Lit584;
    static final FString Lit585;
    static final SimpleSymbol Lit586;
    static final FString Lit587;
    static final FString Lit588;
    static final FString Lit589;
    static final SimpleSymbol Lit59;
    static final FString Lit590;
    static final SimpleSymbol Lit591;
    static final FString Lit592;
    static final FString Lit593;
    static final SimpleSymbol Lit594;
    static final IntNum Lit595;
    static final IntNum Lit596 = IntNum.make(-1005);
    static final FString Lit597;
    static final FString Lit598;
    static final SimpleSymbol Lit599;
    static final SimpleSymbol Lit6;
    static final PairWithPosition Lit60 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 131345);
    static final FString Lit600;
    static final FString Lit601;
    static final FString Lit602;
    static final FString Lit603;
    static final SimpleSymbol Lit604;
    static final FString Lit605;
    static final FString Lit606;
    static final SimpleSymbol Lit607;
    static final IntNum Lit608;
    static final IntNum Lit609 = IntNum.make(-1005);
    static final SimpleSymbol Lit61;
    static final FString Lit610;
    static final FString Lit611;
    static final SimpleSymbol Lit612;
    static final FString Lit613;
    static final FString Lit614;
    static final FString Lit615;
    static final FString Lit616;
    static final SimpleSymbol Lit617;
    static final FString Lit618;
    static final FString Lit619;
    static final PairWithPosition Lit62 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 131487), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 131482);
    static final SimpleSymbol Lit620;
    static final IntNum Lit621;
    static final IntNum Lit622 = IntNum.make(-1010);
    static final FString Lit623;
    static final FString Lit624;
    static final SimpleSymbol Lit625;
    static final FString Lit626;
    static final FString Lit627;
    static final FString Lit628;
    static final FString Lit629;
    static final SimpleSymbol Lit63;
    static final SimpleSymbol Lit630;
    static final IntNum Lit631;
    static final FString Lit632;
    static final FString Lit633;
    static final SimpleSymbol Lit634;
    static final FString Lit635;
    static final FString Lit636;
    static final IntNum Lit637 = IntNum.make(-1005);
    static final IntNum Lit638 = IntNum.make(-1010);
    static final FString Lit639;
    static final SimpleSymbol Lit64;
    static final FString Lit640;
    static final SimpleSymbol Lit641;
    static final IntNum Lit642 = IntNum.make(-1002);
    static final FString Lit643;
    static final FString Lit644;
    static final SimpleSymbol Lit645;
    static final IntNum Lit646 = IntNum.make(14);
    static final FString Lit647;
    static final FString Lit648;
    static final FString Lit649;
    static final PairWithPosition Lit65 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 131844), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 131839);
    static final SimpleSymbol Lit650;
    static final IntNum Lit651 = IntNum.make(200);
    static final PairWithPosition Lit652 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7102567), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7102562);
    static final SimpleSymbol Lit653;
    static final SimpleSymbol Lit654;
    static final SimpleSymbol Lit655;
    static final PairWithPosition Lit656 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7102956);
    static final SimpleSymbol Lit657;
    static final PairWithPosition Lit658 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103113);
    static final PairWithPosition Lit659 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103123);
    static final SimpleSymbol Lit66;
    static final PairWithPosition Lit660 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103277);
    static final PairWithPosition Lit661 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103287);
    static final PairWithPosition Lit662 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103420);
    static final PairWithPosition Lit663 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103568);
    static final PairWithPosition Lit664 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103710);
    static final PairWithPosition Lit665 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7103858);
    static final PairWithPosition Lit666 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104010);
    static final PairWithPosition Lit667 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104164);
    static final PairWithPosition Lit668 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104310);
    static final PairWithPosition Lit669 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104409);
    static final PairWithPosition Lit67 = PairWithPosition.make(Lit724, PairWithPosition.make(Lit724, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 132126), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 132121);
    static final PairWithPosition Lit670 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104566);
    static final PairWithPosition Lit671 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104576);
    static final PairWithPosition Lit672 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104731);
    static final PairWithPosition Lit673 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104741);
    static final PairWithPosition Lit674 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7104875);
    static final PairWithPosition Lit675 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105008);
    static final PairWithPosition Lit676 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105155);
    static final PairWithPosition Lit677 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105254);
    static final PairWithPosition Lit678 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105411);
    static final PairWithPosition Lit679 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105421);
    static final SimpleSymbol Lit68;
    static final PairWithPosition Lit680 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105575);
    static final PairWithPosition Lit681 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105585);
    static final PairWithPosition Lit682 = PairWithPosition.make(Lit20, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7105717);
    static final SimpleSymbol Lit683;
    static final SimpleSymbol Lit684;
    static final FString Lit685;
    static final IntNum Lit686;
    static final FString Lit687;
    static final FString Lit688;
    static final FString Lit689;
    static final SimpleSymbol Lit69;
    static final FString Lit690;
    static final FString Lit691;
    static final FString Lit692;
    static final SimpleSymbol Lit693;
    static final FString Lit694;
    static final FString Lit695;
    static final SimpleSymbol Lit696;
    static final FString Lit697;
    static final FString Lit698;
    static final FString Lit699;
    static final SimpleSymbol Lit7;
    static final FString Lit70;
    static final PairWithPosition Lit700;
    static final SimpleSymbol Lit701;
    static final FString Lit702;
    static final FString Lit703;
    static final FString Lit704;
    static final FString Lit705;
    static final FString Lit706;
    static final IntNum Lit707;
    static final IntNum Lit708;
    static final FString Lit709;
    static final SimpleSymbol Lit71;
    static final SimpleSymbol Lit710;
    static final SimpleSymbol Lit711;
    static final SimpleSymbol Lit712;
    static final SimpleSymbol Lit713;
    static final SimpleSymbol Lit714;
    static final SimpleSymbol Lit715;
    static final SimpleSymbol Lit716;
    static final SimpleSymbol Lit717;
    static final SimpleSymbol Lit718;
    static final SimpleSymbol Lit719;
    static final SimpleSymbol Lit72;
    static final SimpleSymbol Lit720;
    static final SimpleSymbol Lit721;
    static final SimpleSymbol Lit722;
    static final SimpleSymbol Lit723;
    static final SimpleSymbol Lit724;
    static final SimpleSymbol Lit725;
    static final IntNum Lit73 = IntNum.make(-2);
    static final SimpleSymbol Lit74;
    static final FString Lit75;
    static final FString Lit76;
    static final SimpleSymbol Lit77;
    static final SimpleSymbol Lit78;
    static final IntNum Lit79;
    static final SimpleSymbol Lit8;
    static final IntNum Lit80 = IntNum.make(-1015);
    static final SimpleSymbol Lit81;
    static final FString Lit82;
    static final FString Lit83;
    static final SimpleSymbol Lit84;
    static final SimpleSymbol Lit85;
    static final SimpleSymbol Lit86;
    static final IntNum Lit87 = IntNum.make(20);
    static final SimpleSymbol Lit88;
    static final SimpleSymbol Lit89;
    static final SimpleSymbol Lit9;
    static final IntNum Lit90 = IntNum.make(1);
    static final FString Lit91;
    static final FString Lit92;
    static final SimpleSymbol Lit93;
    static final IntNum Lit94 = IntNum.make(17);
    static final FString Lit95;
    static final FString Lit96;
    static final SimpleSymbol Lit97;
    static final IntNum Lit98;
    static final IntNum Lit99 = IntNum.make(-1015);
    public static Screen3 Screen1;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn100 = null;
    static final ModuleMethod lambda$Fn101 = null;
    static final ModuleMethod lambda$Fn102 = null;
    static final ModuleMethod lambda$Fn103 = null;
    static final ModuleMethod lambda$Fn104 = null;
    static final ModuleMethod lambda$Fn105 = null;
    static final ModuleMethod lambda$Fn106 = null;
    static final ModuleMethod lambda$Fn107 = null;
    static final ModuleMethod lambda$Fn108 = null;
    static final ModuleMethod lambda$Fn109 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn110 = null;
    static final ModuleMethod lambda$Fn111 = null;
    static final ModuleMethod lambda$Fn112 = null;
    static final ModuleMethod lambda$Fn113 = null;
    static final ModuleMethod lambda$Fn114 = null;
    static final ModuleMethod lambda$Fn115 = null;
    static final ModuleMethod lambda$Fn116 = null;
    static final ModuleMethod lambda$Fn117 = null;
    static final ModuleMethod lambda$Fn118 = null;
    static final ModuleMethod lambda$Fn119 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn120 = null;
    static final ModuleMethod lambda$Fn121 = null;
    static final ModuleMethod lambda$Fn122 = null;
    static final ModuleMethod lambda$Fn123 = null;
    static final ModuleMethod lambda$Fn124 = null;
    static final ModuleMethod lambda$Fn125 = null;
    static final ModuleMethod lambda$Fn126 = null;
    static final ModuleMethod lambda$Fn127 = null;
    static final ModuleMethod lambda$Fn128 = null;
    static final ModuleMethod lambda$Fn129 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn130 = null;
    static final ModuleMethod lambda$Fn131 = null;
    static final ModuleMethod lambda$Fn132 = null;
    static final ModuleMethod lambda$Fn133 = null;
    static final ModuleMethod lambda$Fn134 = null;
    static final ModuleMethod lambda$Fn135 = null;
    static final ModuleMethod lambda$Fn136 = null;
    static final ModuleMethod lambda$Fn137 = null;
    static final ModuleMethod lambda$Fn138 = null;
    static final ModuleMethod lambda$Fn139 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn140 = null;
    static final ModuleMethod lambda$Fn141 = null;
    static final ModuleMethod lambda$Fn142 = null;
    static final ModuleMethod lambda$Fn143 = null;
    static final ModuleMethod lambda$Fn144 = null;
    static final ModuleMethod lambda$Fn145 = null;
    static final ModuleMethod lambda$Fn146 = null;
    static final ModuleMethod lambda$Fn147 = null;
    static final ModuleMethod lambda$Fn148 = null;
    static final ModuleMethod lambda$Fn149 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn150 = null;
    static final ModuleMethod lambda$Fn151 = null;
    static final ModuleMethod lambda$Fn152 = null;
    static final ModuleMethod lambda$Fn153 = null;
    static final ModuleMethod lambda$Fn154 = null;
    static final ModuleMethod lambda$Fn155 = null;
    static final ModuleMethod lambda$Fn156 = null;
    static final ModuleMethod lambda$Fn157 = null;
    static final ModuleMethod lambda$Fn158 = null;
    static final ModuleMethod lambda$Fn159 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn160 = null;
    static final ModuleMethod lambda$Fn161 = null;
    static final ModuleMethod lambda$Fn162 = null;
    static final ModuleMethod lambda$Fn163 = null;
    static final ModuleMethod lambda$Fn164 = null;
    static final ModuleMethod lambda$Fn165 = null;
    static final ModuleMethod lambda$Fn166 = null;
    static final ModuleMethod lambda$Fn167 = null;
    static final ModuleMethod lambda$Fn168 = null;
    static final ModuleMethod lambda$Fn169 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn170 = null;
    static final ModuleMethod lambda$Fn171 = null;
    static final ModuleMethod lambda$Fn172 = null;
    static final ModuleMethod lambda$Fn173 = null;
    static final ModuleMethod lambda$Fn174 = null;
    static final ModuleMethod lambda$Fn175 = null;
    static final ModuleMethod lambda$Fn176 = null;
    static final ModuleMethod lambda$Fn177 = null;
    static final ModuleMethod lambda$Fn178 = null;
    static final ModuleMethod lambda$Fn179 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn180 = null;
    static final ModuleMethod lambda$Fn181 = null;
    static final ModuleMethod lambda$Fn182 = null;
    static final ModuleMethod lambda$Fn183 = null;
    static final ModuleMethod lambda$Fn184 = null;
    static final ModuleMethod lambda$Fn185 = null;
    static final ModuleMethod lambda$Fn186 = null;
    static final ModuleMethod lambda$Fn187 = null;
    static final ModuleMethod lambda$Fn188 = null;
    static final ModuleMethod lambda$Fn189 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn190 = null;
    static final ModuleMethod lambda$Fn191 = null;
    static final ModuleMethod lambda$Fn192 = null;
    static final ModuleMethod lambda$Fn193 = null;
    static final ModuleMethod lambda$Fn194 = null;
    static final ModuleMethod lambda$Fn195 = null;
    static final ModuleMethod lambda$Fn196 = null;
    static final ModuleMethod lambda$Fn197 = null;
    static final ModuleMethod lambda$Fn198 = null;
    static final ModuleMethod lambda$Fn199 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn200 = null;
    static final ModuleMethod lambda$Fn201 = null;
    static final ModuleMethod lambda$Fn202 = null;
    static final ModuleMethod lambda$Fn203 = null;
    static final ModuleMethod lambda$Fn204 = null;
    static final ModuleMethod lambda$Fn205 = null;
    static final ModuleMethod lambda$Fn206 = null;
    static final ModuleMethod lambda$Fn207 = null;
    static final ModuleMethod lambda$Fn208 = null;
    static final ModuleMethod lambda$Fn209 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn210 = null;
    static final ModuleMethod lambda$Fn211 = null;
    static final ModuleMethod lambda$Fn212 = null;
    static final ModuleMethod lambda$Fn213 = null;
    static final ModuleMethod lambda$Fn214 = null;
    static final ModuleMethod lambda$Fn215 = null;
    static final ModuleMethod lambda$Fn216 = null;
    static final ModuleMethod lambda$Fn217 = null;
    static final ModuleMethod lambda$Fn218 = null;
    static final ModuleMethod lambda$Fn219 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn220 = null;
    static final ModuleMethod lambda$Fn221 = null;
    static final ModuleMethod lambda$Fn222 = null;
    static final ModuleMethod lambda$Fn223 = null;
    static final ModuleMethod lambda$Fn224 = null;
    static final ModuleMethod lambda$Fn225 = null;
    static final ModuleMethod lambda$Fn226 = null;
    static final ModuleMethod lambda$Fn227 = null;
    static final ModuleMethod lambda$Fn228 = null;
    static final ModuleMethod lambda$Fn229 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn230 = null;
    static final ModuleMethod lambda$Fn231 = null;
    static final ModuleMethod lambda$Fn232 = null;
    static final ModuleMethod lambda$Fn233 = null;
    static final ModuleMethod lambda$Fn234 = null;
    static final ModuleMethod lambda$Fn235 = null;
    static final ModuleMethod lambda$Fn236 = null;
    static final ModuleMethod lambda$Fn237 = null;
    static final ModuleMethod lambda$Fn238 = null;
    static final ModuleMethod lambda$Fn239 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn240 = null;
    static final ModuleMethod lambda$Fn241 = null;
    static final ModuleMethod lambda$Fn242 = null;
    static final ModuleMethod lambda$Fn243 = null;
    static final ModuleMethod lambda$Fn244 = null;
    static final ModuleMethod lambda$Fn245 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn31 = null;
    static final ModuleMethod lambda$Fn32 = null;
    static final ModuleMethod lambda$Fn33 = null;
    static final ModuleMethod lambda$Fn34 = null;
    static final ModuleMethod lambda$Fn35 = null;
    static final ModuleMethod lambda$Fn36 = null;
    static final ModuleMethod lambda$Fn37 = null;
    static final ModuleMethod lambda$Fn38 = null;
    static final ModuleMethod lambda$Fn39 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn40 = null;
    static final ModuleMethod lambda$Fn41 = null;
    static final ModuleMethod lambda$Fn42 = null;
    static final ModuleMethod lambda$Fn43 = null;
    static final ModuleMethod lambda$Fn44 = null;
    static final ModuleMethod lambda$Fn45 = null;
    static final ModuleMethod lambda$Fn46 = null;
    static final ModuleMethod lambda$Fn47 = null;
    static final ModuleMethod lambda$Fn48 = null;
    static final ModuleMethod lambda$Fn49 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn50 = null;
    static final ModuleMethod lambda$Fn51 = null;
    static final ModuleMethod lambda$Fn52 = null;
    static final ModuleMethod lambda$Fn53 = null;
    static final ModuleMethod lambda$Fn54 = null;
    static final ModuleMethod lambda$Fn55 = null;
    static final ModuleMethod lambda$Fn56 = null;
    static final ModuleMethod lambda$Fn57 = null;
    static final ModuleMethod lambda$Fn58 = null;
    static final ModuleMethod lambda$Fn59 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn60 = null;
    static final ModuleMethod lambda$Fn61 = null;
    static final ModuleMethod lambda$Fn62 = null;
    static final ModuleMethod lambda$Fn63 = null;
    static final ModuleMethod lambda$Fn64 = null;
    static final ModuleMethod lambda$Fn65 = null;
    static final ModuleMethod lambda$Fn66 = null;
    static final ModuleMethod lambda$Fn67 = null;
    static final ModuleMethod lambda$Fn68 = null;
    static final ModuleMethod lambda$Fn69 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn70 = null;
    static final ModuleMethod lambda$Fn71 = null;
    static final ModuleMethod lambda$Fn72 = null;
    static final ModuleMethod lambda$Fn73 = null;
    static final ModuleMethod lambda$Fn74 = null;
    static final ModuleMethod lambda$Fn75 = null;
    static final ModuleMethod lambda$Fn76 = null;
    static final ModuleMethod lambda$Fn77 = null;
    static final ModuleMethod lambda$Fn78 = null;
    static final ModuleMethod lambda$Fn79 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn80 = null;
    static final ModuleMethod lambda$Fn81 = null;
    static final ModuleMethod lambda$Fn82 = null;
    static final ModuleMethod lambda$Fn83 = null;
    static final ModuleMethod lambda$Fn84 = null;
    static final ModuleMethod lambda$Fn85 = null;
    static final ModuleMethod lambda$Fn86 = null;
    static final ModuleMethod lambda$Fn87 = null;
    static final ModuleMethod lambda$Fn88 = null;
    static final ModuleMethod lambda$Fn89 = null;
    static final ModuleMethod lambda$Fn9 = null;
    static final ModuleMethod lambda$Fn90 = null;
    static final ModuleMethod lambda$Fn91 = null;
    static final ModuleMethod lambda$Fn92 = null;
    static final ModuleMethod lambda$Fn93 = null;
    static final ModuleMethod lambda$Fn94 = null;
    static final ModuleMethod lambda$Fn95 = null;
    static final ModuleMethod lambda$Fn96 = null;
    static final ModuleMethod lambda$Fn97 = null;
    static final ModuleMethod lambda$Fn98 = null;
    static final ModuleMethod lambda$Fn99 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public HorizontalArrangement Active_Cases_Card;
    public Label Active_cases_tag;
    public Button Button1;
    public final ModuleMethod Button1$Click;
    public Button Button1_copy;
    public final ModuleMethod Button1_copy$Click;
    public Button Button2;
    public final ModuleMethod Button2$Click;
    public HorizontalArrangement Cases_Card;
    public HorizontalArrangement Cases_Card_copy;
    public HorizontalArrangement Cases_Card_copy_copy;
    public HorizontalArrangement Cases_Card_copy_copy1;
    public HorizontalArrangement Cases_Card_copy_copy2;
    public HorizontalArrangement Cases_Card_copy_copy2_copy;
    public HorizontalArrangement Cases_Card_copy_copy2_copy1;
    public HorizontalArrangement Cases_Card_copy_copy2_copy2;
    public HorizontalArrangement Cases_Card_copy_copy2_copy3;
    public HorizontalArrangement Cases_Card_copy_copy2_copy4;
    public VerticalArrangement Cases_Discription_Arrangement;
    public Label Cases_Label;
    public Label Cases_Label_copy;
    public Label Cases_Label_copy_copy;
    public Label Cases_Label_copy_copy1;
    public Label Cases_Label_copy_copy2;
    public Label Cases_Label_copy_copy2_copy;
    public Label Cases_Label_copy_copy2_copy1;
    public Label Cases_Label_copy_copy2_copy2;
    public Label Cases_Label_copy_copy2_copy3;
    public Label Cases_Label_copy_copy2_copy4;
    public Label Cases_Tag;
    public Label Cases_Tag_copy;
    public Label Cases_Tag_copy_copy;
    public Label Cases_Tag_copy_copy1;
    public Label Cases_Tag_copy_copy2;
    public Label Cases_Tag_copy_copy2_copy;
    public Label Cases_Tag_copy_copy2_copy1;
    public Label Cases_Tag_copy_copy2_copy2;
    public Label Cases_Tag_copy_copy2_copy3;
    public Label Cases_Tag_copy_copy2_copy4;
    public VerticalArrangement Choose_country_arrangement;
    public HorizontalArrangement Critical_Cases_Card;
    public Label Critical_cases_tag;
    public ProgressBar Custom_Progress1;
    public HorizontalArrangement Deaths_Card;
    public HorizontalArrangement Deaths_Card_copy;
    public VerticalArrangement Deaths_Description_card;
    public Label Deaths_label;
    public Label Deaths_label_copy;
    public Label Deaths_tag;
    public Label Deaths_tag_copy;
    public Label Fetching_Data_Tag;
    public Button Go_btn;
    public final ModuleMethod Go_btn$Click;
    public HorizontalArrangement Horizontal_Arrangement1;
    public HorizontalArrangement Horizontal_Arrangement1_copy;
    public HorizontalArrangement Horizontal_Arrangement2;
    public HorizontalArrangement Horizontal_Arrangement2_copy;
    public HorizontalArrangement Horizontal_Arrangement3;
    public HorizontalArrangement Horizontal_Arrangement4;
    public HorizontalArrangement Horizontal_Arrangement5;
    public Image Image1;
    public Image Image1_copy;
    public Image Image2;
    public KodularImageUtilities Image_Utilities1;
    public JSONTools JSONTools1;
    public JSONTools JSONTools2;
    public JsonUtils JsonUtils1;
    public Label Label10;
    public Label Label11;
    public Label Label12;
    public Label Label13;
    public Label Label14;
    public Label Label15;
    public Label Label16;
    public Label Label17;
    public Label Label18;
    public Label Label19;
    public Label Label2;
    public Label Label3;
    public Label Label3_copy;
    public Label Label4;
    public final ModuleMethod Label4$Click;
    public Label Label5;
    public Label Label5_copy;
    public Label Label6;
    public Label Label6_copy;
    public Label Label7;
    public Label Label7_copy;
    public Label Label8;
    public ListPicker List_Picker1;
    public final ModuleMethod List_Picker1$AfterPicking;
    public VerticalArrangement Loading_Data__Arrangement;
    public HorizontalArrangement New_Cases_Card;
    public Label New_Deaths_tag;
    public Label New_cases_tag;
    public Notifier Notifier1;
    public HorizontalArrangement Recovered_CArd;
    public HorizontalArrangement Recovered_CArd_copy;
    public HorizontalArrangement Recovered_Cases_CArd;
    public Label Recovered_TAg;
    public Label Recovered_TAg_copy;
    public Label Recovered_cases_tag;
    public Label Recovered_label;
    public Label Recovered_label_copy;
    public VerticalArrangement Rsults_Arrangement;
    public VerticalArrangement Rsults_Arrangement_copy;
    public final ModuleMethod Screen1$BackPressed;
    public final ModuleMethod Screen1$Initialize;
    public MakeroidSnackbar Snackbar1;
    public SpaceView Space1;
    public SpaceView Space2;
    public SpaceView Space4;
    public SpaceView Space4_copy;
    public SpaceView Space5;
    public SpaceView Space6;
    public SpaceView Space7;
    public SpaceView Space8;
    public HorizontalArrangement Test_Cards;
    public HorizontalArrangement Test_Cards_copy;
    public Label Test_albel;
    public Label Test_albel_copy;
    public Label Tests_tag;
    public Label Tests_tag_copy;
    public HorizontalArrangement Total_Cases_Card;
    public Label Total_Deaths_Tag;
    public Label Total_deaths_label;
    public VerticalArrangement Vertical_Arrangement1;
    public VerticalArrangement Vertical_Arrangement2;
    public VerticalArrangement Vertical_Arrangement3;
    public Web Web1;
    public final ModuleMethod Web1$GotText;
    public Web Web2;
    public Web Web3;
    public final ModuleMethod Web3$GotText;
    public Label active_cases_label;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public Button cases_description_btn;
    public final ModuleMethod cases_description_btn$Click;
    public Button cases_description_btn_copy;
    public final ModuleMethod cases_description_btn_copy$Click;
    public Label chose_country_tag;
    public LList components$Mnto$Mncreate;
    public Label critical_cases_label;
    public Button deaths_description_btn;
    public final ModuleMethod deaths_description_btn$Click;
    public Button deaths_description_btn_copy;
    public final ModuleMethod deaths_description_btn_copy$Click;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public Notifier fetching_data_notifier;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public Button list_viewer_button;
    public final ModuleMethod list_viewer_button$Click;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public Label new_cases_label;
    public HorizontalArrangement new_deaths_card;
    public final ModuleMethod process$Mnexception;
    public Label recovered_cases_label;
    public final ModuleMethod send$Mnerror;
    public Label total_cases_label;
    public Label total_cases_tag;
    public HorizontalArrangement total_deaths_card;

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        SimpleSymbol simpleSymbol15;
        SimpleSymbol simpleSymbol16;
        FString fString;
        FString fString2;
        FString fString3;
        FString fString4;
        FString fString5;
        FString fString6;
        SimpleSymbol simpleSymbol17;
        SimpleSymbol simpleSymbol18;
        FString fString7;
        FString fString8;
        FString fString9;
        SimpleSymbol simpleSymbol19;
        FString fString10;
        FString fString11;
        SimpleSymbol simpleSymbol20;
        FString fString12;
        FString fString13;
        FString fString14;
        FString fString15;
        FString fString16;
        FString fString17;
        FString fString18;
        SimpleSymbol simpleSymbol21;
        SimpleSymbol simpleSymbol22;
        SimpleSymbol simpleSymbol23;
        SimpleSymbol simpleSymbol24;
        SimpleSymbol simpleSymbol25;
        SimpleSymbol simpleSymbol26;
        SimpleSymbol simpleSymbol27;
        FString fString19;
        FString fString20;
        FString fString21;
        SimpleSymbol simpleSymbol28;
        FString fString22;
        FString fString23;
        SimpleSymbol simpleSymbol29;
        FString fString24;
        FString fString25;
        FString fString26;
        FString fString27;
        SimpleSymbol simpleSymbol30;
        FString fString28;
        FString fString29;
        SimpleSymbol simpleSymbol31;
        FString fString30;
        FString fString31;
        FString fString32;
        FString fString33;
        SimpleSymbol simpleSymbol32;
        FString fString34;
        FString fString35;
        SimpleSymbol simpleSymbol33;
        FString fString36;
        FString fString37;
        SimpleSymbol simpleSymbol34;
        FString fString38;
        FString fString39;
        FString fString40;
        FString fString41;
        SimpleSymbol simpleSymbol35;
        FString fString42;
        FString fString43;
        SimpleSymbol simpleSymbol36;
        FString fString44;
        FString fString45;
        SimpleSymbol simpleSymbol37;
        FString fString46;
        FString fString47;
        FString fString48;
        FString fString49;
        SimpleSymbol simpleSymbol38;
        FString fString50;
        FString fString51;
        SimpleSymbol simpleSymbol39;
        FString fString52;
        FString fString53;
        SimpleSymbol simpleSymbol40;
        FString fString54;
        FString fString55;
        FString fString56;
        FString fString57;
        SimpleSymbol simpleSymbol41;
        FString fString58;
        FString fString59;
        SimpleSymbol simpleSymbol42;
        FString fString60;
        FString fString61;
        SimpleSymbol simpleSymbol43;
        FString fString62;
        FString fString63;
        FString fString64;
        FString fString65;
        SimpleSymbol simpleSymbol44;
        FString fString66;
        FString fString67;
        SimpleSymbol simpleSymbol45;
        FString fString68;
        FString fString69;
        SimpleSymbol simpleSymbol46;
        FString fString70;
        FString fString71;
        FString fString72;
        FString fString73;
        SimpleSymbol simpleSymbol47;
        FString fString74;
        FString fString75;
        SimpleSymbol simpleSymbol48;
        FString fString76;
        FString fString77;
        SimpleSymbol simpleSymbol49;
        FString fString78;
        FString fString79;
        FString fString80;
        FString fString81;
        SimpleSymbol simpleSymbol50;
        FString fString82;
        FString fString83;
        SimpleSymbol simpleSymbol51;
        FString fString84;
        FString fString85;
        SimpleSymbol simpleSymbol52;
        FString fString86;
        FString fString87;
        FString fString88;
        FString fString89;
        SimpleSymbol simpleSymbol53;
        FString fString90;
        FString fString91;
        SimpleSymbol simpleSymbol54;
        FString fString92;
        FString fString93;
        SimpleSymbol simpleSymbol55;
        FString fString94;
        SimpleSymbol simpleSymbol56;
        SimpleSymbol simpleSymbol57;
        FString fString95;
        SimpleSymbol simpleSymbol58;
        FString fString96;
        FString fString97;
        FString fString98;
        FString fString99;
        SimpleSymbol simpleSymbol59;
        FString fString100;
        FString fString101;
        FString fString102;
        SimpleSymbol simpleSymbol60;
        SimpleSymbol simpleSymbol61;
        FString fString103;
        SimpleSymbol simpleSymbol62;
        FString fString104;
        FString fString105;
        SimpleSymbol simpleSymbol63;
        FString fString106;
        SimpleSymbol simpleSymbol64;
        SimpleSymbol simpleSymbol65;
        SimpleSymbol simpleSymbol66;
        FString fString107;
        SimpleSymbol simpleSymbol67;
        FString fString108;
        FString fString109;
        SimpleSymbol simpleSymbol68;
        FString fString110;
        FString fString111;
        FString fString112;
        FString fString113;
        SimpleSymbol simpleSymbol69;
        FString fString114;
        FString fString115;
        SimpleSymbol simpleSymbol70;
        FString fString116;
        FString fString117;
        SimpleSymbol simpleSymbol71;
        FString fString118;
        FString fString119;
        FString fString120;
        FString fString121;
        SimpleSymbol simpleSymbol72;
        FString fString122;
        FString fString123;
        SimpleSymbol simpleSymbol73;
        FString fString124;
        FString fString125;
        SimpleSymbol simpleSymbol74;
        FString fString126;
        SimpleSymbol simpleSymbol75;
        SimpleSymbol simpleSymbol76;
        FString fString127;
        SimpleSymbol simpleSymbol77;
        FString fString128;
        FString fString129;
        FString fString130;
        FString fString131;
        SimpleSymbol simpleSymbol78;
        FString fString132;
        FString fString133;
        SimpleSymbol simpleSymbol79;
        FString fString134;
        FString fString135;
        SimpleSymbol simpleSymbol80;
        FString fString136;
        SimpleSymbol simpleSymbol81;
        SimpleSymbol simpleSymbol82;
        SimpleSymbol simpleSymbol83;
        SimpleSymbol simpleSymbol84;
        SimpleSymbol simpleSymbol85;
        SimpleSymbol simpleSymbol86;
        SimpleSymbol simpleSymbol87;
        SimpleSymbol simpleSymbol88;
        SimpleSymbol simpleSymbol89;
        SimpleSymbol simpleSymbol90;
        SimpleSymbol simpleSymbol91;
        SimpleSymbol simpleSymbol92;
        FString fString137;
        SimpleSymbol simpleSymbol93;
        FString fString138;
        FString fString139;
        FString fString140;
        FString fString141;
        SimpleSymbol simpleSymbol94;
        FString fString142;
        FString fString143;
        SimpleSymbol simpleSymbol95;
        FString fString144;
        FString fString145;
        SimpleSymbol simpleSymbol96;
        FString fString146;
        FString fString147;
        SimpleSymbol simpleSymbol97;
        FString fString148;
        FString fString149;
        FString fString150;
        FString fString151;
        FString fString152;
        SimpleSymbol simpleSymbol98;
        SimpleSymbol simpleSymbol99;
        SimpleSymbol simpleSymbol100;
        FString fString153;
        SimpleSymbol simpleSymbol101;
        SimpleSymbol simpleSymbol102;
        SimpleSymbol simpleSymbol103;
        SimpleSymbol simpleSymbol104;
        SimpleSymbol simpleSymbol105;
        SimpleSymbol simpleSymbol106;
        FString fString154;
        SimpleSymbol simpleSymbol107;
        SimpleSymbol simpleSymbol108;
        SimpleSymbol simpleSymbol109;
        FString fString155;
        SimpleSymbol simpleSymbol110;
        FString fString156;
        FString fString157;
        SimpleSymbol simpleSymbol111;
        FString fString158;
        SimpleSymbol simpleSymbol112;
        SimpleSymbol simpleSymbol113;
        SimpleSymbol simpleSymbol114;
        FString fString159;
        SimpleSymbol simpleSymbol115;
        SimpleSymbol simpleSymbol116;
        FString fString160;
        FString fString161;
        SimpleSymbol simpleSymbol117;
        FString fString162;
        FString fString163;
        SimpleSymbol simpleSymbol118;
        FString fString164;
        FString fString165;
        SimpleSymbol simpleSymbol119;
        FString fString166;
        FString fString167;
        SimpleSymbol simpleSymbol120;
        FString fString168;
        FString fString169;
        SimpleSymbol simpleSymbol121;
        SimpleSymbol simpleSymbol122;
        FString fString170;
        FString fString171;
        FString fString172;
        SimpleSymbol simpleSymbol123;
        SimpleSymbol simpleSymbol124;
        SimpleSymbol simpleSymbol125;
        SimpleSymbol simpleSymbol126;
        SimpleSymbol simpleSymbol127;
        SimpleSymbol simpleSymbol128;
        SimpleSymbol simpleSymbol129;
        SimpleSymbol simpleSymbol130;
        SimpleSymbol simpleSymbol131;
        FString fString173;
        SimpleSymbol simpleSymbol132;
        SimpleSymbol simpleSymbol133;
        SimpleSymbol simpleSymbol134;
        FString fString174;
        FString fString175;
        SimpleSymbol simpleSymbol135;
        FString fString176;
        FString fString177;
        SimpleSymbol simpleSymbol136;
        FString fString178;
        FString fString179;
        SimpleSymbol simpleSymbol137;
        FString fString180;
        FString fString181;
        SimpleSymbol simpleSymbol138;
        FString fString182;
        FString fString183;
        FString fString184;
        FString fString185;
        SimpleSymbol simpleSymbol139;
        FString fString186;
        FString fString187;
        SimpleSymbol simpleSymbol140;
        FString fString188;
        FString fString189;
        SimpleSymbol simpleSymbol141;
        FString fString190;
        FString fString191;
        SimpleSymbol simpleSymbol142;
        FString fString192;
        FString fString193;
        SimpleSymbol simpleSymbol143;
        SimpleSymbol simpleSymbol144;
        FString fString194;
        FString fString195;
        FString fString196;
        FString fString197;
        SimpleSymbol simpleSymbol145;
        FString fString198;
        FString fString199;
        SimpleSymbol simpleSymbol146;
        FString fString200;
        FString fString201;
        SimpleSymbol simpleSymbol147;
        FString fString202;
        FString fString203;
        SimpleSymbol simpleSymbol148;
        FString fString204;
        FString fString205;
        SimpleSymbol simpleSymbol149;
        FString fString206;
        FString fString207;
        SimpleSymbol simpleSymbol150;
        FString fString208;
        FString fString209;
        SimpleSymbol simpleSymbol151;
        FString fString210;
        FString fString211;
        SimpleSymbol simpleSymbol152;
        FString fString212;
        SimpleSymbol simpleSymbol153;
        FString fString213;
        SimpleSymbol simpleSymbol154;
        FString fString214;
        FString fString215;
        SimpleSymbol simpleSymbol155;
        FString fString216;
        FString fString217;
        SimpleSymbol simpleSymbol156;
        FString fString218;
        FString fString219;
        SimpleSymbol simpleSymbol157;
        FString fString220;
        FString fString221;
        SimpleSymbol simpleSymbol158;
        FString fString222;
        SimpleSymbol simpleSymbol159;
        SimpleSymbol simpleSymbol160;
        FString fString223;
        SimpleSymbol simpleSymbol161;
        SimpleSymbol simpleSymbol162;
        FString fString224;
        FString fString225;
        SimpleSymbol simpleSymbol163;
        FString fString226;
        FString fString227;
        SimpleSymbol simpleSymbol164;
        FString fString228;
        FString fString229;
        SimpleSymbol simpleSymbol165;
        FString fString230;
        FString fString231;
        FString fString232;
        FString fString233;
        SimpleSymbol simpleSymbol166;
        FString fString234;
        FString fString235;
        SimpleSymbol simpleSymbol167;
        FString fString236;
        FString fString237;
        SimpleSymbol simpleSymbol168;
        FString fString238;
        FString fString239;
        SimpleSymbol simpleSymbol169;
        FString fString240;
        FString fString241;
        SimpleSymbol simpleSymbol170;
        FString fString242;
        FString fString243;
        SimpleSymbol simpleSymbol171;
        FString fString244;
        FString fString245;
        SimpleSymbol simpleSymbol172;
        FString fString246;
        FString fString247;
        SimpleSymbol simpleSymbol173;
        FString fString248;
        FString fString249;
        SimpleSymbol simpleSymbol174;
        FString fString250;
        FString fString251;
        SimpleSymbol simpleSymbol175;
        FString fString252;
        FString fString253;
        SimpleSymbol simpleSymbol176;
        FString fString254;
        FString fString255;
        SimpleSymbol simpleSymbol177;
        FString fString256;
        FString fString257;
        SimpleSymbol simpleSymbol178;
        FString fString258;
        FString fString259;
        SimpleSymbol simpleSymbol179;
        FString fString260;
        FString fString261;
        SimpleSymbol simpleSymbol180;
        FString fString262;
        FString fString263;
        FString fString264;
        FString fString265;
        SimpleSymbol simpleSymbol181;
        FString fString266;
        FString fString267;
        SimpleSymbol simpleSymbol182;
        FString fString268;
        FString fString269;
        SimpleSymbol simpleSymbol183;
        FString fString270;
        FString fString271;
        SimpleSymbol simpleSymbol184;
        FString fString272;
        FString fString273;
        SimpleSymbol simpleSymbol185;
        SimpleSymbol simpleSymbol186;
        SimpleSymbol simpleSymbol187;
        SimpleSymbol simpleSymbol188;
        SimpleSymbol simpleSymbol189;
        FString fString274;
        FString fString275;
        SimpleSymbol simpleSymbol190;
        SimpleSymbol simpleSymbol191;
        SimpleSymbol simpleSymbol192;
        FString fString276;
        FString fString277;
        SimpleSymbol simpleSymbol193;
        SimpleSymbol simpleSymbol194;
        SimpleSymbol simpleSymbol195;
        FString fString278;
        SimpleSymbol simpleSymbol196;
        SimpleSymbol simpleSymbol197;
        SimpleSymbol simpleSymbol198;
        SimpleSymbol simpleSymbol199;
        SimpleSymbol simpleSymbol200;
        SimpleSymbol simpleSymbol201;
        SimpleSymbol simpleSymbol202;
        SimpleSymbol simpleSymbol203;
        SimpleSymbol simpleSymbol204;
        SimpleSymbol simpleSymbol205;
        SimpleSymbol simpleSymbol206;
        SimpleSymbol simpleSymbol207;
        SimpleSymbol simpleSymbol208;
        SimpleSymbol simpleSymbol209;
        SimpleSymbol simpleSymbol210;
        SimpleSymbol simpleSymbol211;
        SimpleSymbol simpleSymbol212;
        SimpleSymbol simpleSymbol213;
        SimpleSymbol simpleSymbol214;
        SimpleSymbol simpleSymbol215;
        SimpleSymbol simpleSymbol216;
        SimpleSymbol simpleSymbol217;
        SimpleSymbol simpleSymbol218;
        SimpleSymbol simpleSymbol219;
        SimpleSymbol simpleSymbol220;
        SimpleSymbol simpleSymbol221;
        SimpleSymbol simpleSymbol222;
        SimpleSymbol simpleSymbol223;
        SimpleSymbol simpleSymbol224;
        SimpleSymbol simpleSymbol225;
        SimpleSymbol simpleSymbol226;
        SimpleSymbol simpleSymbol227;
        SimpleSymbol simpleSymbol228;
        SimpleSymbol simpleSymbol229;
        SimpleSymbol simpleSymbol230;
        SimpleSymbol simpleSymbol231;
        SimpleSymbol simpleSymbol232;
        SimpleSymbol simpleSymbol233;
        SimpleSymbol simpleSymbol234;
        SimpleSymbol simpleSymbol235;
        SimpleSymbol simpleSymbol236;
        SimpleSymbol simpleSymbol237;
        SimpleSymbol simpleSymbol238;
        SimpleSymbol simpleSymbol239;
        SimpleSymbol simpleSymbol240;
        new SimpleSymbol("component");
        Lit725 = (SimpleSymbol) simpleSymbol.readResolve();
        new SimpleSymbol("any");
        Lit724 = (SimpleSymbol) simpleSymbol2.readResolve();
        new SimpleSymbol("lookup-handler");
        Lit723 = (SimpleSymbol) simpleSymbol3.readResolve();
        new SimpleSymbol("dispatchGenericEvent");
        Lit722 = (SimpleSymbol) simpleSymbol4.readResolve();
        new SimpleSymbol("dispatchEvent");
        Lit721 = (SimpleSymbol) simpleSymbol5.readResolve();
        new SimpleSymbol("send-error");
        Lit720 = (SimpleSymbol) simpleSymbol6.readResolve();
        new SimpleSymbol("add-to-form-do-after-creation");
        Lit719 = (SimpleSymbol) simpleSymbol7.readResolve();
        new SimpleSymbol("add-to-global-vars");
        Lit718 = (SimpleSymbol) simpleSymbol8.readResolve();
        new SimpleSymbol("add-to-components");
        Lit717 = (SimpleSymbol) simpleSymbol9.readResolve();
        new SimpleSymbol("add-to-events");
        Lit716 = (SimpleSymbol) simpleSymbol10.readResolve();
        new SimpleSymbol("add-to-global-var-environment");
        Lit715 = (SimpleSymbol) simpleSymbol11.readResolve();
        new SimpleSymbol("is-bound-in-form-environment");
        Lit714 = (SimpleSymbol) simpleSymbol12.readResolve();
        new SimpleSymbol("lookup-in-form-environment");
        Lit713 = (SimpleSymbol) simpleSymbol13.readResolve();
        new SimpleSymbol("add-to-form-environment");
        Lit712 = (SimpleSymbol) simpleSymbol14.readResolve();
        new SimpleSymbol("android-log-form");
        Lit711 = (SimpleSymbol) simpleSymbol15.readResolve();
        new SimpleSymbol("get-simple-name");
        Lit710 = (SimpleSymbol) simpleSymbol16.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidSnackbar");
        Lit709 = fString;
        int[] iArr = new int[2];
        iArr[0] = -5138;
        Lit708 = IntNum.make(iArr);
        int[] iArr2 = new int[2];
        iArr2[0] = -769226;
        Lit707 = IntNum.make(iArr2);
        new FString("com.google.appinventor.components.runtime.MakeroidSnackbar");
        Lit706 = fString2;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit705 = fString3;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit704 = fString4;
        new FString("com.LukeGackle.JSONTools");
        Lit703 = fString5;
        new FString("com.LukeGackle.JSONTools");
        Lit702 = fString6;
        new SimpleSymbol("Web3$GotText");
        Lit701 = (SimpleSymbol) simpleSymbol17.readResolve();
        new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol241 = (SimpleSymbol) simpleSymbol18.readResolve();
        Lit20 = simpleSymbol241;
        Lit700 = PairWithPosition.make(simpleSymbol241, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 7250026);
        new FString("com.google.appinventor.components.runtime.Web");
        Lit699 = fString7;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit698 = fString8;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit697 = fString9;
        new SimpleSymbol("Web2");
        Lit696 = (SimpleSymbol) simpleSymbol19.readResolve();
        new FString("com.google.appinventor.components.runtime.Web");
        Lit695 = fString10;
        new FString("in.jsonutils.JsonUtils");
        Lit694 = fString11;
        new SimpleSymbol("JsonUtils1");
        Lit693 = (SimpleSymbol) simpleSymbol20.readResolve();
        new FString("in.jsonutils.JsonUtils");
        Lit692 = fString12;
        new FString("com.google.appinventor.components.runtime.KodularImageUtilities");
        Lit691 = fString13;
        new FString("com.google.appinventor.components.runtime.KodularImageUtilities");
        Lit690 = fString14;
        new FString("com.LukeGackle.JSONTools");
        Lit689 = fString15;
        new FString("com.LukeGackle.JSONTools");
        Lit688 = fString16;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit687 = fString17;
        int[] iArr3 = new int[2];
        iArr3[0] = -5138;
        Lit686 = IntNum.make(iArr3);
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit685 = fString18;
        new SimpleSymbol("GotText");
        Lit684 = (SimpleSymbol) simpleSymbol21.readResolve();
        new SimpleSymbol("Web1$GotText");
        Lit683 = (SimpleSymbol) simpleSymbol22.readResolve();
        new SimpleSymbol("GetStringValue");
        Lit657 = (SimpleSymbol) simpleSymbol23.readResolve();
        new SimpleSymbol("ParseJSON");
        Lit655 = (SimpleSymbol) simpleSymbol24.readResolve();
        new SimpleSymbol("JSONTools1");
        Lit654 = (SimpleSymbol) simpleSymbol25.readResolve();
        new SimpleSymbol("$responseContent");
        Lit653 = (SimpleSymbol) simpleSymbol26.readResolve();
        new SimpleSymbol("$responseCode");
        Lit650 = (SimpleSymbol) simpleSymbol27.readResolve();
        new FString("com.google.appinventor.components.runtime.Web");
        Lit649 = fString19;
        new FString("com.google.appinventor.components.runtime.Web");
        Lit648 = fString20;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit647 = fString21;
        new SimpleSymbol("Label3_copy");
        Lit645 = (SimpleSymbol) simpleSymbol28.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit644 = fString22;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit643 = fString23;
        new SimpleSymbol("Space4_copy");
        Lit641 = (SimpleSymbol) simpleSymbol29.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit640 = fString24;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit639 = fString25;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit636 = fString26;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit635 = fString27;
        new SimpleSymbol("Horizontal_Arrangement2_copy");
        Lit634 = (SimpleSymbol) simpleSymbol30.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit633 = fString28;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit632 = fString29;
        int[] iArr4 = new int[2];
        iArr4[0] = -5138;
        Lit631 = IntNum.make(iArr4);
        new SimpleSymbol("Horizontal_Arrangement1_copy");
        Lit630 = (SimpleSymbol) simpleSymbol31.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit629 = fString30;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit628 = fString31;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit627 = fString32;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit626 = fString33;
        new SimpleSymbol("Cases_Tag_copy_copy2_copy4");
        Lit625 = (SimpleSymbol) simpleSymbol32.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit624 = fString34;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit623 = fString35;
        int[] iArr5 = new int[2];
        iArr5[0] = -5138;
        Lit621 = IntNum.make(iArr5);
        new SimpleSymbol("Cases_Card_copy_copy2_copy4");
        Lit620 = (SimpleSymbol) simpleSymbol33.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit619 = fString36;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit618 = fString37;
        new SimpleSymbol("Label19");
        Lit617 = (SimpleSymbol) simpleSymbol34.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit616 = fString38;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit615 = fString39;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit614 = fString40;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit613 = fString41;
        new SimpleSymbol("Cases_Tag_copy_copy2_copy3");
        Lit612 = (SimpleSymbol) simpleSymbol35.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit611 = fString42;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit610 = fString43;
        int[] iArr6 = new int[2];
        iArr6[0] = -5138;
        Lit608 = IntNum.make(iArr6);
        new SimpleSymbol("Cases_Card_copy_copy2_copy3");
        Lit607 = (SimpleSymbol) simpleSymbol36.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit606 = fString44;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit605 = fString45;
        new SimpleSymbol("Label18");
        Lit604 = (SimpleSymbol) simpleSymbol37.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit603 = fString46;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit602 = fString47;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit601 = fString48;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit600 = fString49;
        new SimpleSymbol("Cases_Tag_copy_copy2_copy2");
        Lit599 = (SimpleSymbol) simpleSymbol38.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit598 = fString50;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit597 = fString51;
        int[] iArr7 = new int[2];
        iArr7[0] = -5138;
        Lit595 = IntNum.make(iArr7);
        new SimpleSymbol("Cases_Card_copy_copy2_copy2");
        Lit594 = (SimpleSymbol) simpleSymbol39.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit593 = fString52;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit592 = fString53;
        new SimpleSymbol("Label17");
        Lit591 = (SimpleSymbol) simpleSymbol40.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit590 = fString54;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit589 = fString55;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit588 = fString56;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit587 = fString57;
        new SimpleSymbol("Cases_Tag_copy_copy2_copy1");
        Lit586 = (SimpleSymbol) simpleSymbol41.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit585 = fString58;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit584 = fString59;
        int[] iArr8 = new int[2];
        iArr8[0] = -5138;
        Lit582 = IntNum.make(iArr8);
        new SimpleSymbol("Cases_Card_copy_copy2_copy1");
        Lit581 = (SimpleSymbol) simpleSymbol42.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit580 = fString60;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit579 = fString61;
        new SimpleSymbol("Label16");
        Lit578 = (SimpleSymbol) simpleSymbol43.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit577 = fString62;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit576 = fString63;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit575 = fString64;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit574 = fString65;
        new SimpleSymbol("Cases_Tag_copy_copy2_copy");
        Lit573 = (SimpleSymbol) simpleSymbol44.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit572 = fString66;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit571 = fString67;
        int[] iArr9 = new int[2];
        iArr9[0] = -5138;
        Lit569 = IntNum.make(iArr9);
        new SimpleSymbol("Cases_Card_copy_copy2_copy");
        Lit568 = (SimpleSymbol) simpleSymbol45.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit567 = fString68;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit566 = fString69;
        new SimpleSymbol("Label15");
        Lit565 = (SimpleSymbol) simpleSymbol46.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit564 = fString70;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit563 = fString71;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit562 = fString72;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit561 = fString73;
        new SimpleSymbol("Cases_Tag_copy_copy2");
        Lit560 = (SimpleSymbol) simpleSymbol47.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit559 = fString74;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit558 = fString75;
        int[] iArr10 = new int[2];
        iArr10[0] = -5138;
        Lit556 = IntNum.make(iArr10);
        new SimpleSymbol("Cases_Card_copy_copy2");
        Lit555 = (SimpleSymbol) simpleSymbol48.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit554 = fString76;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit553 = fString77;
        new SimpleSymbol("Label14");
        Lit552 = (SimpleSymbol) simpleSymbol49.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit551 = fString78;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit550 = fString79;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit549 = fString80;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit548 = fString81;
        new SimpleSymbol("Cases_Tag_copy_copy1");
        Lit547 = (SimpleSymbol) simpleSymbol50.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit546 = fString82;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit545 = fString83;
        int[] iArr11 = new int[2];
        iArr11[0] = -5138;
        Lit543 = IntNum.make(iArr11);
        new SimpleSymbol("Cases_Card_copy_copy1");
        Lit542 = (SimpleSymbol) simpleSymbol51.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit541 = fString84;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit540 = fString85;
        new SimpleSymbol("Label13");
        Lit539 = (SimpleSymbol) simpleSymbol52.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit538 = fString86;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit537 = fString87;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit536 = fString88;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit535 = fString89;
        new SimpleSymbol("Cases_Tag_copy_copy");
        Lit534 = (SimpleSymbol) simpleSymbol53.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit533 = fString90;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit532 = fString91;
        int[] iArr12 = new int[2];
        iArr12[0] = -5138;
        Lit530 = IntNum.make(iArr12);
        new SimpleSymbol("Cases_Card_copy_copy");
        Lit529 = (SimpleSymbol) simpleSymbol54.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit528 = fString92;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit527 = fString93;
        new SimpleSymbol("Label12");
        Lit526 = (SimpleSymbol) simpleSymbol55.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit525 = fString94;
        new SimpleSymbol("Button2$Click");
        Lit524 = (SimpleSymbol) simpleSymbol56.readResolve();
        new SimpleSymbol("DismissCustomDialog");
        Lit523 = (SimpleSymbol) simpleSymbol57.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit522 = fString95;
        int[] iArr13 = new int[2];
        iArr13[0] = -5138;
        Lit521 = IntNum.make(iArr13);
        int[] iArr14 = new int[2];
        iArr14[0] = -769226;
        Lit520 = IntNum.make(iArr14);
        new SimpleSymbol("Button2");
        Lit519 = (SimpleSymbol) simpleSymbol58.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit518 = fString96;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit517 = fString97;
        int[] iArr15 = new int[2];
        iArr15[0] = -769226;
        Lit516 = IntNum.make(iArr15);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit515 = fString98;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit514 = fString99;
        new SimpleSymbol("Horizontal_Arrangement5");
        Lit513 = (SimpleSymbol) simpleSymbol59.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit512 = fString100;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit511 = fString101;
        int[] iArr16 = new int[2];
        iArr16[0] = -1;
        Lit510 = IntNum.make(iArr16);
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit509 = fString102;
        new SimpleSymbol("Button1$Click");
        Lit508 = (SimpleSymbol) simpleSymbol60.readResolve();
        SimpleSymbol simpleSymbol242 = Lit20;
        new SimpleSymbol("number");
        SimpleSymbol simpleSymbol243 = (SimpleSymbol) simpleSymbol61.readResolve();
        Lit35 = simpleSymbol243;
        Lit507 = PairWithPosition.make(simpleSymbol242, PairWithPosition.make(simpleSymbol243, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973850), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4973844);
        new FString("com.google.appinventor.components.runtime.Button");
        Lit497 = fString103;
        int[] iArr17 = new int[2];
        iArr17[0] = -769226;
        Lit496 = IntNum.make(iArr17);
        new SimpleSymbol("Button1");
        Lit495 = (SimpleSymbol) simpleSymbol62.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit494 = fString104;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit493 = fString105;
        new SimpleSymbol("Space8");
        Lit491 = (SimpleSymbol) simpleSymbol63.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit490 = fString106;
        new SimpleSymbol("Button1_copy$Click");
        Lit489 = (SimpleSymbol) simpleSymbol64.readResolve();
        new SimpleSymbol("Show");
        Lit480 = (SimpleSymbol) simpleSymbol65.readResolve();
        new SimpleSymbol("Snackbar1");
        Lit479 = (SimpleSymbol) simpleSymbol66.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit477 = fString107;
        int[] iArr18 = new int[2];
        iArr18[0] = -769226;
        Lit476 = IntNum.make(iArr18);
        new SimpleSymbol("Button1_copy");
        Lit475 = (SimpleSymbol) simpleSymbol67.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit474 = fString108;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit473 = fString109;
        new SimpleSymbol("Horizontal_Arrangement4");
        Lit472 = (SimpleSymbol) simpleSymbol68.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit471 = fString110;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit470 = fString111;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit469 = fString112;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit468 = fString113;
        new SimpleSymbol("Tests_tag_copy");
        Lit467 = (SimpleSymbol) simpleSymbol69.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit466 = fString114;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit465 = fString115;
        int[] iArr19 = new int[2];
        iArr19[0] = -5138;
        Lit463 = IntNum.make(iArr19);
        new SimpleSymbol("Test_Cards_copy");
        Lit462 = (SimpleSymbol) simpleSymbol70.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit461 = fString116;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit460 = fString117;
        new SimpleSymbol("Label7_copy");
        Lit459 = (SimpleSymbol) simpleSymbol71.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit458 = fString118;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit457 = fString119;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit456 = fString120;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit455 = fString121;
        new SimpleSymbol("Recovered_TAg_copy");
        Lit454 = (SimpleSymbol) simpleSymbol72.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit453 = fString122;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit452 = fString123;
        int[] iArr20 = new int[2];
        iArr20[0] = -5138;
        Lit450 = IntNum.make(iArr20);
        new SimpleSymbol("Recovered_CArd_copy");
        Lit449 = (SimpleSymbol) simpleSymbol73.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit448 = fString124;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit447 = fString125;
        new SimpleSymbol("Label6_copy");
        Lit446 = (SimpleSymbol) simpleSymbol74.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit445 = fString126;
        new SimpleSymbol("deaths_description_btn_copy$Click");
        Lit444 = (SimpleSymbol) simpleSymbol75.readResolve();
        SimpleSymbol simpleSymbol244 = Lit725;
        SimpleSymbol simpleSymbol245 = Lit20;
        SimpleSymbol simpleSymbol246 = Lit20;
        SimpleSymbol simpleSymbol247 = Lit20;
        new SimpleSymbol("boolean");
        SimpleSymbol simpleSymbol248 = (SimpleSymbol) simpleSymbol76.readResolve();
        Lit10 = simpleSymbol248;
        Lit433 = PairWithPosition.make(simpleSymbol244, PairWithPosition.make(simpleSymbol245, PairWithPosition.make(simpleSymbol246, PairWithPosition.make(simpleSymbol247, PairWithPosition.make(simpleSymbol248, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4374759), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4374754), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4374749), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4374744), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen3.yail", 4374733);
        new FString("com.google.appinventor.components.runtime.Button");
        Lit432 = fString127;
        int[] iArr21 = new int[2];
        iArr21[0] = -769226;
        Lit431 = IntNum.make(iArr21);
        new SimpleSymbol("deaths_description_btn_copy");
        Lit430 = (SimpleSymbol) simpleSymbol77.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit429 = fString128;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit428 = fString129;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit427 = fString130;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit426 = fString131;
        new SimpleSymbol("Deaths_tag_copy");
        Lit425 = (SimpleSymbol) simpleSymbol78.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit424 = fString132;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit423 = fString133;
        int[] iArr22 = new int[2];
        iArr22[0] = -5138;
        Lit421 = IntNum.make(iArr22);
        new SimpleSymbol("Deaths_Card_copy");
        Lit420 = (SimpleSymbol) simpleSymbol79.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit419 = fString134;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit418 = fString135;
        new SimpleSymbol("Label5_copy");
        Lit417 = (SimpleSymbol) simpleSymbol80.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit416 = fString136;
        new SimpleSymbol("cases_description_btn_copy$Click");
        Lit415 = (SimpleSymbol) simpleSymbol81.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy2_copy4");
        Lit413 = (SimpleSymbol) simpleSymbol82.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy2_copy3");
        Lit411 = (SimpleSymbol) simpleSymbol83.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy2_copy2");
        Lit409 = (SimpleSymbol) simpleSymbol84.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy2_copy1");
        Lit407 = (SimpleSymbol) simpleSymbol85.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy2_copy");
        Lit405 = (SimpleSymbol) simpleSymbol86.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy2");
        Lit403 = (SimpleSymbol) simpleSymbol87.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy1");
        Lit401 = (SimpleSymbol) simpleSymbol88.readResolve();
        new SimpleSymbol("Cases_Label_copy_copy");
        Lit399 = (SimpleSymbol) simpleSymbol89.readResolve();
        new SimpleSymbol("Label11");
        Lit397 = (SimpleSymbol) simpleSymbol90.readResolve();
        new SimpleSymbol("Notifier1");
        Lit394 = (SimpleSymbol) simpleSymbol91.readResolve();
        new SimpleSymbol("Vertical_Arrangement3");
        Lit393 = (SimpleSymbol) simpleSymbol92.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit392 = fString137;
        int[] iArr23 = new int[2];
        iArr23[0] = -769226;
        Lit391 = IntNum.make(iArr23);
        new SimpleSymbol("cases_description_btn_copy");
        Lit390 = (SimpleSymbol) simpleSymbol93.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit389 = fString138;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit388 = fString139;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit387 = fString140;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit386 = fString141;
        new SimpleSymbol("Cases_Tag_copy");
        Lit385 = (SimpleSymbol) simpleSymbol94.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit384 = fString142;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit383 = fString143;
        int[] iArr24 = new int[2];
        iArr24[0] = -5138;
        Lit381 = IntNum.make(iArr24);
        new SimpleSymbol("Cases_Card_copy");
        Lit380 = (SimpleSymbol) simpleSymbol95.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit379 = fString144;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit378 = fString145;
        new SimpleSymbol("Rsults_Arrangement_copy");
        Lit376 = (SimpleSymbol) simpleSymbol96.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit375 = fString146;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit374 = fString147;
        new SimpleSymbol("Label10");
        Lit373 = (SimpleSymbol) simpleSymbol97.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit372 = fString148;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit371 = fString149;
        int[] iArr25 = new int[2];
        iArr25[0] = -769226;
        Lit370 = IntNum.make(iArr25);
        new FString("com.google.appinventor.components.runtime.Label");
        Lit369 = fString150;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit368 = fString151;
        int[] iArr26 = new int[2];
        iArr26[0] = -1;
        Lit367 = IntNum.make(iArr26);
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit366 = fString152;
        new SimpleSymbol("AfterPicking");
        Lit365 = (SimpleSymbol) simpleSymbol98.readResolve();
        new SimpleSymbol("List_Picker1$AfterPicking");
        Lit364 = (SimpleSymbol) simpleSymbol99.readResolve();
        new SimpleSymbol("$selection");
        Lit363 = (SimpleSymbol) simpleSymbol100.readResolve();
        new FString("com.google.appinventor.components.runtime.ListPicker");
        Lit362 = fString153;
        int[] iArr27 = new int[2];
        iArr27[0] = -769226;
        Lit361 = IntNum.make(iArr27);
        new SimpleSymbol("TitleBarColor");
        Lit360 = (SimpleSymbol) simpleSymbol101.readResolve();
        int[] iArr28 = new int[2];
        iArr28[0] = -769226;
        Lit359 = IntNum.make(iArr28);
        new SimpleSymbol("StatusBarColor");
        Lit358 = (SimpleSymbol) simpleSymbol102.readResolve();
        new SimpleSymbol("ShowFilterBar");
        Lit357 = (SimpleSymbol) simpleSymbol103.readResolve();
        int[] iArr29 = new int[2];
        iArr29[0] = -5138;
        Lit356 = IntNum.make(iArr29);
        new SimpleSymbol("ItemTextColor");
        Lit355 = (SimpleSymbol) simpleSymbol104.readResolve();
        int[] iArr30 = new int[2];
        iArr30[0] = -769226;
        Lit354 = IntNum.make(iArr30);
        new SimpleSymbol("ItemBackgroundColor");
        Lit353 = (SimpleSymbol) simpleSymbol105.readResolve();
        new SimpleSymbol("ElementsFromString");
        Lit352 = (SimpleSymbol) simpleSymbol106.readResolve();
        new FString("com.google.appinventor.components.runtime.ListPicker");
        Lit351 = fString154;
        new SimpleSymbol("Go_btn$Click");
        Lit350 = (SimpleSymbol) simpleSymbol107.readResolve();
        new SimpleSymbol("ShowAlert");
        Lit348 = (SimpleSymbol) simpleSymbol108.readResolve();
        new SimpleSymbol("Selection");
        Lit345 = (SimpleSymbol) simpleSymbol109.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit344 = fString155;
        int[] iArr31 = new int[2];
        iArr31[0] = -5138;
        Lit343 = IntNum.make(iArr31);
        int[] iArr32 = new int[2];
        iArr32[0] = -769226;
        Lit342 = IntNum.make(iArr32);
        new SimpleSymbol("Go_btn");
        Lit341 = (SimpleSymbol) simpleSymbol110.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit340 = fString156;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit339 = fString157;
        new SimpleSymbol("Space1");
        Lit337 = (SimpleSymbol) simpleSymbol111.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit336 = fString158;
        new SimpleSymbol("list_viewer_button$Click");
        Lit335 = (SimpleSymbol) simpleSymbol112.readResolve();
        new SimpleSymbol("Open");
        Lit334 = (SimpleSymbol) simpleSymbol113.readResolve();
        new SimpleSymbol("List_Picker1");
        Lit333 = (SimpleSymbol) simpleSymbol114.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit332 = fString159;
        int[] iArr33 = new int[2];
        iArr33[0] = -5138;
        Lit331 = IntNum.make(iArr33);
        new SimpleSymbol("Shape");
        Lit330 = (SimpleSymbol) simpleSymbol115.readResolve();
        int[] iArr34 = new int[2];
        iArr34[0] = -769226;
        Lit329 = IntNum.make(iArr34);
        new SimpleSymbol("list_viewer_button");
        Lit328 = (SimpleSymbol) simpleSymbol116.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit327 = fString160;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit326 = fString161;
        new SimpleSymbol("Space6");
        Lit324 = (SimpleSymbol) simpleSymbol117.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit323 = fString162;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit322 = fString163;
        int[] iArr35 = new int[2];
        iArr35[0] = -769226;
        Lit321 = IntNum.make(iArr35);
        new SimpleSymbol("chose_country_tag");
        Lit319 = (SimpleSymbol) simpleSymbol118.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit318 = fString164;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit317 = fString165;
        int[] iArr36 = new int[2];
        iArr36[0] = -5138;
        Lit316 = IntNum.make(iArr36);
        new SimpleSymbol("Vertical_Arrangement1");
        Lit315 = (SimpleSymbol) simpleSymbol119.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit314 = fString166;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit313 = fString167;
        new SimpleSymbol("Space7");
        Lit312 = (SimpleSymbol) simpleSymbol120.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit311 = fString168;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit310 = fString169;
        new SimpleSymbol("Picture");
        Lit309 = (SimpleSymbol) simpleSymbol121.readResolve();
        new SimpleSymbol("Image2");
        Lit306 = (SimpleSymbol) simpleSymbol122.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit305 = fString170;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit304 = fString171;
        int[] iArr37 = new int[2];
        iArr37[0] = -1;
        Lit303 = IntNum.make(iArr37);
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit302 = fString172;
        new SimpleSymbol("Label4$Click");
        Lit301 = (SimpleSymbol) simpleSymbol123.readResolve();
        new SimpleSymbol("Test_albel_copy");
        Lit299 = (SimpleSymbol) simpleSymbol124.readResolve();
        new SimpleSymbol("Recovered_label_copy");
        Lit297 = (SimpleSymbol) simpleSymbol125.readResolve();
        new SimpleSymbol("Deaths_label_copy");
        Lit295 = (SimpleSymbol) simpleSymbol126.readResolve();
        new SimpleSymbol("Cases_Label_copy");
        Lit293 = (SimpleSymbol) simpleSymbol127.readResolve();
        new SimpleSymbol("GetStringInArray");
        Lit291 = (SimpleSymbol) simpleSymbol128.readResolve();
        new SimpleSymbol("Label8");
        Lit290 = (SimpleSymbol) simpleSymbol129.readResolve();
        new SimpleSymbol("OpenJSONArray");
        Lit288 = (SimpleSymbol) simpleSymbol130.readResolve();
        new SimpleSymbol("JSONTools2");
        Lit287 = (SimpleSymbol) simpleSymbol131.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit285 = fString173;
        int[] iArr38 = new int[2];
        iArr38[0] = -5138;
        Lit284 = IntNum.make(iArr38);
        new SimpleSymbol("TextColor");
        Lit283 = (SimpleSymbol) simpleSymbol132.readResolve();
        new SimpleSymbol("Clickable");
        Lit281 = (SimpleSymbol) simpleSymbol133.readResolve();
        new SimpleSymbol("Label4");
        Lit280 = (SimpleSymbol) simpleSymbol134.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit279 = fString174;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit278 = fString175;
        int[] iArr39 = new int[2];
        iArr39[0] = -769226;
        Lit277 = IntNum.make(iArr39);
        new SimpleSymbol("Horizontal_Arrangement3");
        Lit276 = (SimpleSymbol) simpleSymbol135.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit275 = fString176;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit274 = fString177;
        new SimpleSymbol("Space5");
        Lit272 = (SimpleSymbol) simpleSymbol136.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit271 = fString178;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit270 = fString179;
        new SimpleSymbol("Label3");
        Lit269 = (SimpleSymbol) simpleSymbol137.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit268 = fString180;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit267 = fString181;
        new SimpleSymbol("Space4");
        Lit265 = (SimpleSymbol) simpleSymbol138.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit264 = fString182;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit263 = fString183;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit260 = fString184;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit259 = fString185;
        new SimpleSymbol("Horizontal_Arrangement2");
        Lit258 = (SimpleSymbol) simpleSymbol139.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit257 = fString186;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit256 = fString187;
        new SimpleSymbol("isCard");
        Lit255 = (SimpleSymbol) simpleSymbol140.readResolve();
        int[] iArr40 = new int[2];
        iArr40[0] = -5138;
        Lit254 = IntNum.make(iArr40);
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit253 = fString188;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit252 = fString189;
        int[] iArr41 = new int[2];
        iArr41[0] = -5138;
        Lit250 = IntNum.make(iArr41);
        new SimpleSymbol("Fetching_Data_Tag");
        Lit249 = (SimpleSymbol) simpleSymbol141.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit248 = fString190;
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit247 = fString191;
        new SimpleSymbol("Space2");
        Lit245 = (SimpleSymbol) simpleSymbol142.readResolve();
        new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit244 = fString192;
        new FString("com.google.appinventor.components.runtime.ProgressBar");
        Lit243 = fString193;
        int[] iArr42 = new int[2];
        iArr42[0] = -769226;
        Lit242 = IntNum.make(iArr42);
        new SimpleSymbol("Color");
        Lit241 = (SimpleSymbol) simpleSymbol143.readResolve();
        new SimpleSymbol("Custom_Progress1");
        Lit240 = (SimpleSymbol) simpleSymbol144.readResolve();
        new FString("com.google.appinventor.components.runtime.ProgressBar");
        Lit239 = fString194;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit238 = fString195;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit235 = fString196;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit234 = fString197;
        new SimpleSymbol("Test_albel");
        Lit233 = (SimpleSymbol) simpleSymbol145.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit232 = fString198;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit231 = fString199;
        new SimpleSymbol("Tests_tag");
        Lit230 = (SimpleSymbol) simpleSymbol146.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit229 = fString200;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit228 = fString201;
        int[] iArr43 = new int[2];
        iArr43[0] = -5138;
        Lit226 = IntNum.make(iArr43);
        new SimpleSymbol("Test_Cards");
        Lit225 = (SimpleSymbol) simpleSymbol147.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit224 = fString202;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit223 = fString203;
        new SimpleSymbol("Label7");
        Lit222 = (SimpleSymbol) simpleSymbol148.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit221 = fString204;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit220 = fString205;
        new SimpleSymbol("Recovered_label");
        Lit219 = (SimpleSymbol) simpleSymbol149.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit218 = fString206;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit217 = fString207;
        new SimpleSymbol("Recovered_TAg");
        Lit216 = (SimpleSymbol) simpleSymbol150.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit215 = fString208;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit214 = fString209;
        int[] iArr44 = new int[2];
        iArr44[0] = -5138;
        Lit212 = IntNum.make(iArr44);
        new SimpleSymbol("Recovered_CArd");
        Lit211 = (SimpleSymbol) simpleSymbol151.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit210 = fString210;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit209 = fString211;
        new SimpleSymbol("Label6");
        Lit208 = (SimpleSymbol) simpleSymbol152.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit207 = fString212;
        new SimpleSymbol("deaths_description_btn$Click");
        Lit206 = (SimpleSymbol) simpleSymbol153.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit205 = fString213;
        int[] iArr45 = new int[2];
        iArr45[0] = -769226;
        Lit204 = IntNum.make(iArr45);
        new SimpleSymbol("deaths_description_btn");
        Lit203 = (SimpleSymbol) simpleSymbol154.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit202 = fString214;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit201 = fString215;
        new SimpleSymbol("Deaths_label");
        Lit200 = (SimpleSymbol) simpleSymbol155.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit199 = fString216;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit198 = fString217;
        new SimpleSymbol("Deaths_tag");
        Lit197 = (SimpleSymbol) simpleSymbol156.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit196 = fString218;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit195 = fString219;
        int[] iArr46 = new int[2];
        iArr46[0] = -5138;
        Lit193 = IntNum.make(iArr46);
        new SimpleSymbol("Deaths_Card");
        Lit192 = (SimpleSymbol) simpleSymbol157.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit191 = fString220;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit190 = fString221;
        new SimpleSymbol("Label5");
        Lit189 = (SimpleSymbol) simpleSymbol158.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit188 = fString222;
        new SimpleSymbol("Click");
        Lit187 = (SimpleSymbol) simpleSymbol159.readResolve();
        new SimpleSymbol("cases_description_btn$Click");
        Lit186 = (SimpleSymbol) simpleSymbol160.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit185 = fString223;
        new SimpleSymbol("FontTypeface");
        Lit183 = (SimpleSymbol) simpleSymbol161.readResolve();
        int[] iArr47 = new int[2];
        iArr47[0] = -769226;
        Lit182 = IntNum.make(iArr47);
        new SimpleSymbol("cases_description_btn");
        Lit181 = (SimpleSymbol) simpleSymbol162.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit180 = fString224;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit179 = fString225;
        new SimpleSymbol("Cases_Label");
        Lit178 = (SimpleSymbol) simpleSymbol163.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit177 = fString226;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit176 = fString227;
        new SimpleSymbol("Cases_Tag");
        Lit174 = (SimpleSymbol) simpleSymbol164.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit173 = fString228;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit172 = fString229;
        int[] iArr48 = new int[2];
        iArr48[0] = -5138;
        Lit170 = IntNum.make(iArr48);
        new SimpleSymbol("Cases_Card");
        Lit169 = (SimpleSymbol) simpleSymbol165.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit168 = fString230;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit167 = fString231;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit165 = fString232;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit164 = fString233;
        new SimpleSymbol("total_cases_label");
        Lit163 = (SimpleSymbol) simpleSymbol166.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit162 = fString234;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit161 = fString235;
        new SimpleSymbol("total_cases_tag");
        Lit160 = (SimpleSymbol) simpleSymbol167.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit159 = fString236;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit158 = fString237;
        int[] iArr49 = new int[2];
        iArr49[0] = -5138;
        Lit156 = IntNum.make(iArr49);
        new SimpleSymbol("Total_Cases_Card");
        Lit155 = (SimpleSymbol) simpleSymbol168.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit154 = fString238;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit153 = fString239;
        new SimpleSymbol("recovered_cases_label");
        Lit152 = (SimpleSymbol) simpleSymbol169.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit151 = fString240;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit150 = fString241;
        new SimpleSymbol("Recovered_cases_tag");
        Lit149 = (SimpleSymbol) simpleSymbol170.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit148 = fString242;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit147 = fString243;
        int[] iArr50 = new int[2];
        iArr50[0] = -5138;
        Lit145 = IntNum.make(iArr50);
        new SimpleSymbol("Recovered_Cases_CArd");
        Lit144 = (SimpleSymbol) simpleSymbol171.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit143 = fString244;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit142 = fString245;
        new SimpleSymbol("critical_cases_label");
        Lit141 = (SimpleSymbol) simpleSymbol172.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit140 = fString246;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit139 = fString247;
        new SimpleSymbol("Critical_cases_tag");
        Lit138 = (SimpleSymbol) simpleSymbol173.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit137 = fString248;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit136 = fString249;
        int[] iArr51 = new int[2];
        iArr51[0] = -5138;
        Lit134 = IntNum.make(iArr51);
        new SimpleSymbol("Critical_Cases_Card");
        Lit133 = (SimpleSymbol) simpleSymbol174.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit132 = fString250;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit131 = fString251;
        new SimpleSymbol("active_cases_label");
        Lit130 = (SimpleSymbol) simpleSymbol175.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit129 = fString252;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit128 = fString253;
        new SimpleSymbol("Active_cases_tag");
        Lit127 = (SimpleSymbol) simpleSymbol176.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit126 = fString254;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit125 = fString255;
        int[] iArr52 = new int[2];
        iArr52[0] = -5138;
        Lit123 = IntNum.make(iArr52);
        new SimpleSymbol("Active_Cases_Card");
        Lit122 = (SimpleSymbol) simpleSymbol177.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit121 = fString256;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit120 = fString257;
        new SimpleSymbol("new_cases_label");
        Lit119 = (SimpleSymbol) simpleSymbol178.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit118 = fString258;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit117 = fString259;
        new SimpleSymbol("New_cases_tag");
        Lit116 = (SimpleSymbol) simpleSymbol179.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit115 = fString260;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit114 = fString261;
        int[] iArr53 = new int[2];
        iArr53[0] = -5138;
        Lit112 = IntNum.make(iArr53);
        new SimpleSymbol("New_Cases_Card");
        Lit111 = (SimpleSymbol) simpleSymbol180.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit110 = fString262;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit109 = fString263;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit107 = fString264;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit106 = fString265;
        new SimpleSymbol("Total_deaths_label");
        Lit105 = (SimpleSymbol) simpleSymbol181.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit104 = fString266;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit103 = fString267;
        new SimpleSymbol("Total_Deaths_Tag");
        Lit102 = (SimpleSymbol) simpleSymbol182.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit101 = fString268;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit100 = fString269;
        int[] iArr54 = new int[2];
        iArr54[0] = -5138;
        Lit98 = IntNum.make(iArr54);
        new SimpleSymbol("total_deaths_card");
        Lit97 = (SimpleSymbol) simpleSymbol183.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit96 = fString270;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit95 = fString271;
        new SimpleSymbol("Label2");
        Lit93 = (SimpleSymbol) simpleSymbol184.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit92 = fString272;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit91 = fString273;
        new SimpleSymbol("TextAlignment");
        Lit89 = (SimpleSymbol) simpleSymbol185.readResolve();
        new SimpleSymbol("Text");
        Lit88 = (SimpleSymbol) simpleSymbol186.readResolve();
        new SimpleSymbol("FontSize");
        Lit86 = (SimpleSymbol) simpleSymbol187.readResolve();
        new SimpleSymbol("FontBold");
        Lit85 = (SimpleSymbol) simpleSymbol188.readResolve();
        new SimpleSymbol("New_Deaths_tag");
        Lit84 = (SimpleSymbol) simpleSymbol189.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit83 = fString274;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit82 = fString275;
        new SimpleSymbol("UseRoundCard");
        Lit81 = (SimpleSymbol) simpleSymbol190.readResolve();
        int[] iArr55 = new int[2];
        iArr55[0] = -5138;
        Lit79 = IntNum.make(iArr55);
        new SimpleSymbol("BackgroundColor");
        Lit78 = (SimpleSymbol) simpleSymbol191.readResolve();
        new SimpleSymbol("new_deaths_card");
        Lit77 = (SimpleSymbol) simpleSymbol192.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit76 = fString276;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit75 = fString277;
        new SimpleSymbol("Width");
        Lit74 = (SimpleSymbol) simpleSymbol193.readResolve();
        new SimpleSymbol("Height");
        Lit72 = (SimpleSymbol) simpleSymbol194.readResolve();
        new SimpleSymbol("AlignVertical");
        Lit71 = (SimpleSymbol) simpleSymbol195.readResolve();
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit70 = fString278;
        new SimpleSymbol("BackPressed");
        Lit69 = (SimpleSymbol) simpleSymbol196.readResolve();
        new SimpleSymbol("Screen1$BackPressed");
        Lit68 = (SimpleSymbol) simpleSymbol197.readResolve();
        new SimpleSymbol("Deaths_Description_card");
        Lit66 = (SimpleSymbol) simpleSymbol198.readResolve();
        new SimpleSymbol("Cases_Discription_Arrangement");
        Lit64 = (SimpleSymbol) simpleSymbol199.readResolve();
        new SimpleSymbol("Horizontal_Arrangement1");
        Lit63 = (SimpleSymbol) simpleSymbol200.readResolve();
        new SimpleSymbol("Rsults_Arrangement");
        Lit61 = (SimpleSymbol) simpleSymbol201.readResolve();
        new SimpleSymbol("Vertical_Arrangement2");
        Lit59 = (SimpleSymbol) simpleSymbol202.readResolve();
        new SimpleSymbol("Choose_country_arrangement");
        Lit57 = (SimpleSymbol) simpleSymbol203.readResolve();
        new SimpleSymbol("Initialize");
        Lit56 = (SimpleSymbol) simpleSymbol204.readResolve();
        new SimpleSymbol("Screen1$Initialize");
        Lit55 = (SimpleSymbol) simpleSymbol205.readResolve();
        new SimpleSymbol("Image1_copy");
        Lit53 = (SimpleSymbol) simpleSymbol206.readResolve();
        new SimpleSymbol("Image1");
        Lit51 = (SimpleSymbol) simpleSymbol207.readResolve();
        new SimpleSymbol("LoadImageAsync");
        Lit50 = (SimpleSymbol) simpleSymbol208.readResolve();
        new SimpleSymbol("Image_Utilities1");
        Lit49 = (SimpleSymbol) simpleSymbol209.readResolve();
        new SimpleSymbol("Web3");
        Lit48 = (SimpleSymbol) simpleSymbol210.readResolve();
        new SimpleSymbol("TitleVisible");
        Lit47 = (SimpleSymbol) simpleSymbol211.readResolve();
        new SimpleSymbol("Title");
        Lit46 = (SimpleSymbol) simpleSymbol212.readResolve();
        new SimpleSymbol("Scrollable");
        Lit45 = (SimpleSymbol) simpleSymbol213.readResolve();
        new SimpleSymbol("ReceiveSharedText");
        Lit44 = (SimpleSymbol) simpleSymbol214.readResolve();
        int[] iArr56 = new int[2];
        iArr56[0] = -769226;
        Lit43 = IntNum.make(iArr56);
        new SimpleSymbol("PrimaryColorDark");
        Lit42 = (SimpleSymbol) simpleSymbol215.readResolve();
        int[] iArr57 = new int[2];
        iArr57[0] = -769226;
        Lit41 = IntNum.make(iArr57);
        new SimpleSymbol("PrimaryColor");
        Lit40 = (SimpleSymbol) simpleSymbol216.readResolve();
        new SimpleSymbol("AppName");
        Lit39 = (SimpleSymbol) simpleSymbol217.readResolve();
        new SimpleSymbol("AppId");
        Lit38 = (SimpleSymbol) simpleSymbol218.readResolve();
        new SimpleSymbol("AlignHorizontal");
        Lit36 = (SimpleSymbol) simpleSymbol219.readResolve();
        int[] iArr58 = new int[2];
        iArr58[0] = -769226;
        Lit34 = IntNum.make(iArr58);
        new SimpleSymbol("AccentColor");
        Lit33 = (SimpleSymbol) simpleSymbol220.readResolve();
        new SimpleSymbol("g$forward");
        Lit31 = (SimpleSymbol) simpleSymbol221.readResolve();
        new SimpleSymbol("Get");
        Lit26 = (SimpleSymbol) simpleSymbol222.readResolve();
        new SimpleSymbol("list");
        Lit25 = (SimpleSymbol) simpleSymbol223.readResolve();
        new SimpleSymbol("RequestHeaders");
        Lit21 = (SimpleSymbol) simpleSymbol224.readResolve();
        new SimpleSymbol("Url");
        Lit18 = (SimpleSymbol) simpleSymbol225.readResolve();
        new SimpleSymbol("Web1");
        Lit17 = (SimpleSymbol) simpleSymbol226.readResolve();
        new SimpleSymbol("p$web");
        Lit16 = (SimpleSymbol) simpleSymbol227.readResolve();
        new SimpleSymbol("ShowCustomDialog");
        Lit14 = (SimpleSymbol) simpleSymbol228.readResolve();
        new SimpleSymbol("CreateCustomDialog");
        Lit12 = (SimpleSymbol) simpleSymbol229.readResolve();
        new SimpleSymbol("fetching_data_notifier");
        Lit11 = (SimpleSymbol) simpleSymbol230.readResolve();
        new SimpleSymbol("Visible");
        Lit9 = (SimpleSymbol) simpleSymbol231.readResolve();
        new SimpleSymbol("Loading_Data__Arrangement");
        Lit8 = (SimpleSymbol) simpleSymbol232.readResolve();
        new SimpleSymbol("p$dataNotification");
        Lit7 = (SimpleSymbol) simpleSymbol233.readResolve();
        new SimpleSymbol("g$api");
        Lit6 = (SimpleSymbol) simpleSymbol234.readResolve();
        new SimpleSymbol("g$Json");
        Lit5 = (SimpleSymbol) simpleSymbol235.readResolve();
        new SimpleSymbol("g$country");
        Lit4 = (SimpleSymbol) simpleSymbol236.readResolve();
        new SimpleSymbol("g$Url");
        Lit3 = (SimpleSymbol) simpleSymbol237.readResolve();
        new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol238.readResolve();
        new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol239.readResolve();
        new SimpleSymbol("Screen1");
        Lit0 = (SimpleSymbol) simpleSymbol240.readResolve();
    }

    public Screen3() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleMethod moduleMethod29;
        ModuleMethod moduleMethod30;
        ModuleMethod moduleMethod31;
        ModuleMethod moduleMethod32;
        ModuleMethod moduleMethod33;
        ModuleMethod moduleMethod34;
        ModuleMethod moduleMethod35;
        ModuleMethod moduleMethod36;
        ModuleMethod moduleMethod37;
        ModuleMethod moduleMethod38;
        ModuleMethod moduleMethod39;
        ModuleMethod moduleMethod40;
        ModuleMethod moduleMethod41;
        ModuleMethod moduleMethod42;
        ModuleMethod moduleMethod43;
        ModuleMethod moduleMethod44;
        ModuleMethod moduleMethod45;
        ModuleMethod moduleMethod46;
        ModuleMethod moduleMethod47;
        ModuleMethod moduleMethod48;
        ModuleMethod moduleMethod49;
        ModuleMethod moduleMethod50;
        ModuleMethod moduleMethod51;
        ModuleMethod moduleMethod52;
        ModuleMethod moduleMethod53;
        ModuleMethod moduleMethod54;
        ModuleMethod moduleMethod55;
        ModuleMethod moduleMethod56;
        ModuleMethod moduleMethod57;
        ModuleMethod moduleMethod58;
        ModuleMethod moduleMethod59;
        ModuleMethod moduleMethod60;
        ModuleMethod moduleMethod61;
        ModuleMethod moduleMethod62;
        ModuleMethod moduleMethod63;
        ModuleMethod moduleMethod64;
        ModuleMethod moduleMethod65;
        ModuleMethod moduleMethod66;
        ModuleMethod moduleMethod67;
        ModuleMethod moduleMethod68;
        ModuleMethod moduleMethod69;
        ModuleMethod moduleMethod70;
        ModuleMethod moduleMethod71;
        ModuleMethod moduleMethod72;
        ModuleMethod moduleMethod73;
        ModuleMethod moduleMethod74;
        ModuleMethod moduleMethod75;
        ModuleMethod moduleMethod76;
        ModuleMethod moduleMethod77;
        ModuleMethod moduleMethod78;
        ModuleMethod moduleMethod79;
        ModuleMethod moduleMethod80;
        ModuleMethod moduleMethod81;
        ModuleMethod moduleMethod82;
        ModuleMethod moduleMethod83;
        ModuleMethod moduleMethod84;
        ModuleMethod moduleMethod85;
        ModuleMethod moduleMethod86;
        ModuleMethod moduleMethod87;
        ModuleMethod moduleMethod88;
        ModuleMethod moduleMethod89;
        ModuleMethod moduleMethod90;
        ModuleMethod moduleMethod91;
        ModuleMethod moduleMethod92;
        ModuleMethod moduleMethod93;
        ModuleMethod moduleMethod94;
        ModuleMethod moduleMethod95;
        ModuleMethod moduleMethod96;
        ModuleMethod moduleMethod97;
        ModuleMethod moduleMethod98;
        ModuleMethod moduleMethod99;
        ModuleMethod moduleMethod100;
        ModuleMethod moduleMethod101;
        ModuleMethod moduleMethod102;
        ModuleMethod moduleMethod103;
        ModuleMethod moduleMethod104;
        ModuleMethod moduleMethod105;
        ModuleMethod moduleMethod106;
        ModuleMethod moduleMethod107;
        ModuleMethod moduleMethod108;
        ModuleMethod moduleMethod109;
        ModuleMethod moduleMethod110;
        ModuleMethod moduleMethod111;
        ModuleMethod moduleMethod112;
        ModuleMethod moduleMethod113;
        ModuleMethod moduleMethod114;
        ModuleMethod moduleMethod115;
        ModuleMethod moduleMethod116;
        ModuleMethod moduleMethod117;
        ModuleMethod moduleMethod118;
        ModuleMethod moduleMethod119;
        ModuleMethod moduleMethod120;
        ModuleMethod moduleMethod121;
        ModuleMethod moduleMethod122;
        ModuleMethod moduleMethod123;
        ModuleMethod moduleMethod124;
        ModuleMethod moduleMethod125;
        ModuleMethod moduleMethod126;
        ModuleMethod moduleMethod127;
        ModuleMethod moduleMethod128;
        ModuleMethod moduleMethod129;
        ModuleMethod moduleMethod130;
        ModuleMethod moduleMethod131;
        ModuleMethod moduleMethod132;
        ModuleMethod moduleMethod133;
        ModuleMethod moduleMethod134;
        ModuleMethod moduleMethod135;
        ModuleMethod moduleMethod136;
        ModuleMethod moduleMethod137;
        ModuleMethod moduleMethod138;
        ModuleMethod moduleMethod139;
        ModuleMethod moduleMethod140;
        ModuleMethod moduleMethod141;
        ModuleMethod moduleMethod142;
        ModuleMethod moduleMethod143;
        ModuleMethod moduleMethod144;
        ModuleMethod moduleMethod145;
        ModuleMethod moduleMethod146;
        ModuleMethod moduleMethod147;
        ModuleMethod moduleMethod148;
        ModuleMethod moduleMethod149;
        ModuleMethod moduleMethod150;
        ModuleMethod moduleMethod151;
        ModuleMethod moduleMethod152;
        ModuleMethod moduleMethod153;
        ModuleMethod moduleMethod154;
        ModuleMethod moduleMethod155;
        ModuleMethod moduleMethod156;
        ModuleMethod moduleMethod157;
        ModuleMethod moduleMethod158;
        ModuleMethod moduleMethod159;
        ModuleMethod moduleMethod160;
        ModuleMethod moduleMethod161;
        ModuleMethod moduleMethod162;
        ModuleMethod moduleMethod163;
        ModuleMethod moduleMethod164;
        ModuleMethod moduleMethod165;
        ModuleMethod moduleMethod166;
        ModuleMethod moduleMethod167;
        ModuleMethod moduleMethod168;
        ModuleMethod moduleMethod169;
        ModuleMethod moduleMethod170;
        ModuleMethod moduleMethod171;
        ModuleMethod moduleMethod172;
        ModuleMethod moduleMethod173;
        ModuleMethod moduleMethod174;
        ModuleMethod moduleMethod175;
        ModuleMethod moduleMethod176;
        ModuleMethod moduleMethod177;
        ModuleMethod moduleMethod178;
        ModuleMethod moduleMethod179;
        ModuleMethod moduleMethod180;
        ModuleMethod moduleMethod181;
        ModuleMethod moduleMethod182;
        ModuleMethod moduleMethod183;
        ModuleMethod moduleMethod184;
        ModuleMethod moduleMethod185;
        ModuleMethod moduleMethod186;
        ModuleMethod moduleMethod187;
        ModuleMethod moduleMethod188;
        ModuleMethod moduleMethod189;
        ModuleMethod moduleMethod190;
        ModuleMethod moduleMethod191;
        ModuleMethod moduleMethod192;
        ModuleMethod moduleMethod193;
        ModuleMethod moduleMethod194;
        ModuleMethod moduleMethod195;
        ModuleMethod moduleMethod196;
        ModuleMethod moduleMethod197;
        ModuleMethod moduleMethod198;
        ModuleMethod moduleMethod199;
        ModuleMethod moduleMethod200;
        ModuleMethod moduleMethod201;
        ModuleMethod moduleMethod202;
        ModuleMethod moduleMethod203;
        ModuleMethod moduleMethod204;
        ModuleMethod moduleMethod205;
        ModuleMethod moduleMethod206;
        ModuleMethod moduleMethod207;
        ModuleMethod moduleMethod208;
        ModuleMethod moduleMethod209;
        ModuleMethod moduleMethod210;
        ModuleMethod moduleMethod211;
        ModuleMethod moduleMethod212;
        ModuleMethod moduleMethod213;
        ModuleMethod moduleMethod214;
        ModuleMethod moduleMethod215;
        ModuleMethod moduleMethod216;
        ModuleMethod moduleMethod217;
        ModuleMethod moduleMethod218;
        ModuleMethod moduleMethod219;
        ModuleMethod moduleMethod220;
        ModuleMethod moduleMethod221;
        ModuleMethod moduleMethod222;
        ModuleMethod moduleMethod223;
        ModuleMethod moduleMethod224;
        ModuleMethod moduleMethod225;
        ModuleMethod moduleMethod226;
        ModuleMethod moduleMethod227;
        ModuleMethod moduleMethod228;
        ModuleMethod moduleMethod229;
        ModuleMethod moduleMethod230;
        ModuleMethod moduleMethod231;
        ModuleMethod moduleMethod232;
        ModuleMethod moduleMethod233;
        ModuleMethod moduleMethod234;
        ModuleMethod moduleMethod235;
        ModuleMethod moduleMethod236;
        ModuleMethod moduleMethod237;
        ModuleMethod moduleMethod238;
        ModuleMethod moduleMethod239;
        ModuleMethod moduleMethod240;
        ModuleMethod moduleMethod241;
        ModuleMethod moduleMethod242;
        ModuleMethod moduleMethod243;
        ModuleMethod moduleMethod244;
        ModuleMethod moduleMethod245;
        ModuleMethod moduleMethod246;
        ModuleMethod moduleMethod247;
        ModuleMethod moduleMethod248;
        ModuleMethod moduleMethod249;
        ModuleMethod moduleMethod250;
        ModuleMethod moduleMethod251;
        ModuleMethod moduleMethod252;
        ModuleMethod moduleMethod253;
        ModuleMethod moduleMethod254;
        ModuleMethod moduleMethod255;
        ModuleMethod moduleMethod256;
        ModuleMethod moduleMethod257;
        ModuleMethod moduleMethod258;
        ModuleMethod moduleMethod259;
        ModuleMethod moduleMethod260;
        ModuleMethod moduleMethod261;
        ModuleMethod moduleMethod262;
        ModuleMethod moduleMethod263;
        ModuleMethod moduleMethod264;
        ModuleMethod moduleMethod265;
        ModuleMethod moduleMethod266;
        ModuleMethod moduleMethod267;
        ModuleMethod moduleMethod268;
        ModuleMethod moduleMethod269;
        ModuleMethod moduleMethod270;
        ModuleMethod moduleMethod271;
        ModuleMethod moduleMethod272;
        ModuleMethod moduleMethod273;
        ModuleMethod moduleMethod274;
        ModuleMethod moduleMethod275;
        ModuleMethod moduleMethod276;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod277 = moduleMethod;
        new frame();
        frame frame3 = frame2;
        frame3.$main = this;
        frame frame4 = frame3;
        new ModuleMethod(frame4, 1, Lit710, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod277;
        new ModuleMethod(frame4, 2, Lit711, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod2;
        new ModuleMethod(frame4, 3, Lit712, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod3;
        new ModuleMethod(frame4, 4, Lit713, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod4;
        new ModuleMethod(frame4, 6, Lit714, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod5;
        new ModuleMethod(frame4, 7, Lit715, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod6;
        new ModuleMethod(frame4, 8, Lit716, 8194);
        this.add$Mnto$Mnevents = moduleMethod7;
        new ModuleMethod(frame4, 9, Lit717, 16388);
        this.add$Mnto$Mncomponents = moduleMethod8;
        new ModuleMethod(frame4, 10, Lit718, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod9;
        new ModuleMethod(frame4, 11, Lit719, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod10;
        new ModuleMethod(frame4, 12, Lit720, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod11;
        new ModuleMethod(frame4, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod12;
        new ModuleMethod(frame4, 14, Lit721, 16388);
        this.dispatchEvent = moduleMethod13;
        new ModuleMethod(frame4, 15, Lit722, 16388);
        this.dispatchGenericEvent = moduleMethod14;
        new ModuleMethod(frame4, 16, Lit723, 8194);
        this.lookup$Mnhandler = moduleMethod15;
        new ModuleMethod(frame4, 17, (Object) null, 0);
        ModuleMethod moduleMethod278 = moduleMethod16;
        moduleMethod278.setProperty("source-location", "/tmp/runtime7522387041397852836.scm:615");
        lambda$Fn1 = moduleMethod278;
        new ModuleMethod(frame4, 18, "$define", 0);
        this.$define = moduleMethod17;
        new ModuleMethod(frame4, 19, (Object) null, 0);
        lambda$Fn2 = moduleMethod18;
        new ModuleMethod(frame4, 20, (Object) null, 0);
        lambda$Fn3 = moduleMethod19;
        new ModuleMethod(frame4, 21, (Object) null, 0);
        lambda$Fn4 = moduleMethod20;
        new ModuleMethod(frame4, 22, (Object) null, 0);
        lambda$Fn5 = moduleMethod21;
        new ModuleMethod(frame4, 23, (Object) null, 0);
        lambda$Fn6 = moduleMethod22;
        new ModuleMethod(frame4, 24, (Object) null, 0);
        lambda$Fn8 = moduleMethod23;
        new ModuleMethod(frame4, 25, (Object) null, 0);
        lambda$Fn7 = moduleMethod24;
        new ModuleMethod(frame4, 26, (Object) null, 0);
        lambda$Fn9 = moduleMethod25;
        new ModuleMethod(frame4, 27, (Object) null, 0);
        lambda$Fn11 = moduleMethod26;
        new ModuleMethod(frame4, 28, (Object) null, 0);
        lambda$Fn10 = moduleMethod27;
        new ModuleMethod(frame4, 29, (Object) null, 0);
        lambda$Fn12 = moduleMethod28;
        new ModuleMethod(frame4, 30, (Object) null, 0);
        lambda$Fn13 = moduleMethod29;
        new ModuleMethod(frame4, 31, Lit55, 0);
        this.Screen1$Initialize = moduleMethod30;
        new ModuleMethod(frame4, 32, (Object) null, 0);
        lambda$Fn14 = moduleMethod31;
        new ModuleMethod(frame4, 33, (Object) null, 0);
        lambda$Fn15 = moduleMethod32;
        new ModuleMethod(frame4, 34, Lit68, 0);
        this.Screen1$BackPressed = moduleMethod33;
        new ModuleMethod(frame4, 35, (Object) null, 0);
        lambda$Fn16 = moduleMethod34;
        new ModuleMethod(frame4, 36, (Object) null, 0);
        lambda$Fn17 = moduleMethod35;
        new ModuleMethod(frame4, 37, (Object) null, 0);
        lambda$Fn18 = moduleMethod36;
        new ModuleMethod(frame4, 38, (Object) null, 0);
        lambda$Fn19 = moduleMethod37;
        new ModuleMethod(frame4, 39, (Object) null, 0);
        lambda$Fn20 = moduleMethod38;
        new ModuleMethod(frame4, 40, (Object) null, 0);
        lambda$Fn21 = moduleMethod39;
        new ModuleMethod(frame4, 41, (Object) null, 0);
        lambda$Fn22 = moduleMethod40;
        new ModuleMethod(frame4, 42, (Object) null, 0);
        lambda$Fn23 = moduleMethod41;
        new ModuleMethod(frame4, 43, (Object) null, 0);
        lambda$Fn24 = moduleMethod42;
        new ModuleMethod(frame4, 44, (Object) null, 0);
        lambda$Fn25 = moduleMethod43;
        new ModuleMethod(frame4, 45, (Object) null, 0);
        lambda$Fn26 = moduleMethod44;
        new ModuleMethod(frame4, 46, (Object) null, 0);
        lambda$Fn27 = moduleMethod45;
        new ModuleMethod(frame4, 47, (Object) null, 0);
        lambda$Fn28 = moduleMethod46;
        new ModuleMethod(frame4, 48, (Object) null, 0);
        lambda$Fn29 = moduleMethod47;
        new ModuleMethod(frame4, 49, (Object) null, 0);
        lambda$Fn30 = moduleMethod48;
        new ModuleMethod(frame4, 50, (Object) null, 0);
        lambda$Fn31 = moduleMethod49;
        new ModuleMethod(frame4, 51, (Object) null, 0);
        lambda$Fn32 = moduleMethod50;
        new ModuleMethod(frame4, 52, (Object) null, 0);
        lambda$Fn33 = moduleMethod51;
        new ModuleMethod(frame4, 53, (Object) null, 0);
        lambda$Fn34 = moduleMethod52;
        new ModuleMethod(frame4, 54, (Object) null, 0);
        lambda$Fn35 = moduleMethod53;
        new ModuleMethod(frame4, 55, (Object) null, 0);
        lambda$Fn36 = moduleMethod54;
        new ModuleMethod(frame4, 56, (Object) null, 0);
        lambda$Fn37 = moduleMethod55;
        new ModuleMethod(frame4, 57, (Object) null, 0);
        lambda$Fn38 = moduleMethod56;
        new ModuleMethod(frame4, 58, (Object) null, 0);
        lambda$Fn39 = moduleMethod57;
        new ModuleMethod(frame4, 59, (Object) null, 0);
        lambda$Fn40 = moduleMethod58;
        new ModuleMethod(frame4, 60, (Object) null, 0);
        lambda$Fn41 = moduleMethod59;
        new ModuleMethod(frame4, 61, (Object) null, 0);
        lambda$Fn42 = moduleMethod60;
        new ModuleMethod(frame4, 62, (Object) null, 0);
        lambda$Fn43 = moduleMethod61;
        new ModuleMethod(frame4, 63, (Object) null, 0);
        lambda$Fn44 = moduleMethod62;
        new ModuleMethod(frame4, 64, (Object) null, 0);
        lambda$Fn45 = moduleMethod63;
        new ModuleMethod(frame4, 65, (Object) null, 0);
        lambda$Fn46 = moduleMethod64;
        new ModuleMethod(frame4, 66, (Object) null, 0);
        lambda$Fn47 = moduleMethod65;
        new ModuleMethod(frame4, 67, (Object) null, 0);
        lambda$Fn48 = moduleMethod66;
        new ModuleMethod(frame4, 68, (Object) null, 0);
        lambda$Fn49 = moduleMethod67;
        new ModuleMethod(frame4, 69, (Object) null, 0);
        lambda$Fn50 = moduleMethod68;
        new ModuleMethod(frame4, 70, (Object) null, 0);
        lambda$Fn51 = moduleMethod69;
        new ModuleMethod(frame4, 71, (Object) null, 0);
        lambda$Fn52 = moduleMethod70;
        new ModuleMethod(frame4, 72, (Object) null, 0);
        lambda$Fn53 = moduleMethod71;
        new ModuleMethod(frame4, 73, (Object) null, 0);
        lambda$Fn54 = moduleMethod72;
        new ModuleMethod(frame4, 74, (Object) null, 0);
        lambda$Fn55 = moduleMethod73;
        new ModuleMethod(frame4, 75, (Object) null, 0);
        lambda$Fn56 = moduleMethod74;
        new ModuleMethod(frame4, 76, (Object) null, 0);
        lambda$Fn57 = moduleMethod75;
        new ModuleMethod(frame4, 77, (Object) null, 0);
        lambda$Fn58 = moduleMethod76;
        new ModuleMethod(frame4, 78, (Object) null, 0);
        lambda$Fn59 = moduleMethod77;
        new ModuleMethod(frame4, 79, (Object) null, 0);
        lambda$Fn60 = moduleMethod78;
        new ModuleMethod(frame4, 80, (Object) null, 0);
        lambda$Fn61 = moduleMethod79;
        new ModuleMethod(frame4, 81, (Object) null, 0);
        lambda$Fn62 = moduleMethod80;
        new ModuleMethod(frame4, 82, (Object) null, 0);
        lambda$Fn63 = moduleMethod81;
        new ModuleMethod(frame4, 83, (Object) null, 0);
        lambda$Fn64 = moduleMethod82;
        new ModuleMethod(frame4, 84, (Object) null, 0);
        lambda$Fn65 = moduleMethod83;
        new ModuleMethod(frame4, 85, (Object) null, 0);
        lambda$Fn66 = moduleMethod84;
        new ModuleMethod(frame4, 86, (Object) null, 0);
        lambda$Fn67 = moduleMethod85;
        new ModuleMethod(frame4, 87, (Object) null, 0);
        lambda$Fn68 = moduleMethod86;
        new ModuleMethod(frame4, 88, (Object) null, 0);
        lambda$Fn69 = moduleMethod87;
        new ModuleMethod(frame4, 89, (Object) null, 0);
        lambda$Fn70 = moduleMethod88;
        new ModuleMethod(frame4, 90, (Object) null, 0);
        lambda$Fn71 = moduleMethod89;
        new ModuleMethod(frame4, 91, Lit186, 0);
        this.cases_description_btn$Click = moduleMethod90;
        new ModuleMethod(frame4, 92, (Object) null, 0);
        lambda$Fn72 = moduleMethod91;
        new ModuleMethod(frame4, 93, (Object) null, 0);
        lambda$Fn73 = moduleMethod92;
        new ModuleMethod(frame4, 94, (Object) null, 0);
        lambda$Fn74 = moduleMethod93;
        new ModuleMethod(frame4, 95, (Object) null, 0);
        lambda$Fn75 = moduleMethod94;
        new ModuleMethod(frame4, 96, (Object) null, 0);
        lambda$Fn76 = moduleMethod95;
        new ModuleMethod(frame4, 97, (Object) null, 0);
        lambda$Fn77 = moduleMethod96;
        new ModuleMethod(frame4, 98, (Object) null, 0);
        lambda$Fn78 = moduleMethod97;
        new ModuleMethod(frame4, 99, (Object) null, 0);
        lambda$Fn79 = moduleMethod98;
        new ModuleMethod(frame4, 100, Lit206, 0);
        this.deaths_description_btn$Click = moduleMethod99;
        new ModuleMethod(frame4, 101, (Object) null, 0);
        lambda$Fn80 = moduleMethod100;
        new ModuleMethod(frame4, 102, (Object) null, 0);
        lambda$Fn81 = moduleMethod101;
        new ModuleMethod(frame4, 103, (Object) null, 0);
        lambda$Fn82 = moduleMethod102;
        new ModuleMethod(frame4, 104, (Object) null, 0);
        lambda$Fn83 = moduleMethod103;
        new ModuleMethod(frame4, 105, (Object) null, 0);
        lambda$Fn84 = moduleMethod104;
        new ModuleMethod(frame4, 106, (Object) null, 0);
        lambda$Fn85 = moduleMethod105;
        new ModuleMethod(frame4, 107, (Object) null, 0);
        lambda$Fn86 = moduleMethod106;
        new ModuleMethod(frame4, 108, (Object) null, 0);
        lambda$Fn87 = moduleMethod107;
        new ModuleMethod(frame4, 109, (Object) null, 0);
        lambda$Fn88 = moduleMethod108;
        new ModuleMethod(frame4, 110, (Object) null, 0);
        lambda$Fn89 = moduleMethod109;
        new ModuleMethod(frame4, 111, (Object) null, 0);
        lambda$Fn90 = moduleMethod110;
        new ModuleMethod(frame4, 112, (Object) null, 0);
        lambda$Fn91 = moduleMethod111;
        new ModuleMethod(frame4, 113, (Object) null, 0);
        lambda$Fn92 = moduleMethod112;
        new ModuleMethod(frame4, 114, (Object) null, 0);
        lambda$Fn93 = moduleMethod113;
        new ModuleMethod(frame4, 115, (Object) null, 0);
        lambda$Fn94 = moduleMethod114;
        new ModuleMethod(frame4, 116, (Object) null, 0);
        lambda$Fn95 = moduleMethod115;
        new ModuleMethod(frame4, 117, (Object) null, 0);
        lambda$Fn96 = moduleMethod116;
        new ModuleMethod(frame4, 118, (Object) null, 0);
        lambda$Fn97 = moduleMethod117;
        new ModuleMethod(frame4, 119, (Object) null, 0);
        lambda$Fn98 = moduleMethod118;
        new ModuleMethod(frame4, 120, (Object) null, 0);
        lambda$Fn99 = moduleMethod119;
        new ModuleMethod(frame4, 121, (Object) null, 0);
        lambda$Fn100 = moduleMethod120;
        new ModuleMethod(frame4, 122, (Object) null, 0);
        lambda$Fn101 = moduleMethod121;
        new ModuleMethod(frame4, 123, (Object) null, 0);
        lambda$Fn102 = moduleMethod122;
        new ModuleMethod(frame4, 124, (Object) null, 0);
        lambda$Fn103 = moduleMethod123;
        new ModuleMethod(frame4, ErrorLogHelper.MAX_PROPERTY_ITEM_LENGTH, (Object) null, 0);
        lambda$Fn104 = moduleMethod124;
        new ModuleMethod(frame4, 126, (Object) null, 0);
        lambda$Fn105 = moduleMethod125;
        new ModuleMethod(frame4, 127, (Object) null, 0);
        lambda$Fn106 = moduleMethod126;
        new ModuleMethod(frame4, 128, (Object) null, 0);
        lambda$Fn107 = moduleMethod127;
        new ModuleMethod(frame4, 129, (Object) null, 0);
        lambda$Fn108 = moduleMethod128;
        new ModuleMethod(frame4, 130, (Object) null, 0);
        lambda$Fn109 = moduleMethod129;
        new ModuleMethod(frame4, 131, (Object) null, 0);
        lambda$Fn110 = moduleMethod130;
        new ModuleMethod(frame4, 132, (Object) null, 0);
        lambda$Fn111 = moduleMethod131;
        new ModuleMethod(frame4, 133, (Object) null, 0);
        lambda$Fn112 = moduleMethod132;
        new ModuleMethod(frame4, 134, (Object) null, 0);
        lambda$Fn113 = moduleMethod133;
        new ModuleMethod(frame4, 135, (Object) null, 0);
        lambda$Fn114 = moduleMethod134;
        new ModuleMethod(frame4, 136, (Object) null, 0);
        lambda$Fn115 = moduleMethod135;
        new ModuleMethod(frame4, 137, Lit301, 0);
        this.Label4$Click = moduleMethod136;
        new ModuleMethod(frame4, 138, (Object) null, 0);
        lambda$Fn116 = moduleMethod137;
        new ModuleMethod(frame4, 139, (Object) null, 0);
        lambda$Fn117 = moduleMethod138;
        new ModuleMethod(frame4, 140, (Object) null, 0);
        lambda$Fn118 = moduleMethod139;
        new ModuleMethod(frame4, 141, (Object) null, 0);
        lambda$Fn119 = moduleMethod140;
        new ModuleMethod(frame4, 142, (Object) null, 0);
        lambda$Fn120 = moduleMethod141;
        new ModuleMethod(frame4, 143, (Object) null, 0);
        lambda$Fn121 = moduleMethod142;
        new ModuleMethod(frame4, 144, (Object) null, 0);
        lambda$Fn122 = moduleMethod143;
        new ModuleMethod(frame4, 145, (Object) null, 0);
        lambda$Fn123 = moduleMethod144;
        new ModuleMethod(frame4, 146, (Object) null, 0);
        lambda$Fn124 = moduleMethod145;
        new ModuleMethod(frame4, 147, (Object) null, 0);
        lambda$Fn125 = moduleMethod146;
        new ModuleMethod(frame4, 148, (Object) null, 0);
        lambda$Fn126 = moduleMethod147;
        new ModuleMethod(frame4, 149, (Object) null, 0);
        lambda$Fn127 = moduleMethod148;
        new ModuleMethod(frame4, 150, Lit335, 0);
        this.list_viewer_button$Click = moduleMethod149;
        new ModuleMethod(frame4, 151, (Object) null, 0);
        lambda$Fn128 = moduleMethod150;
        new ModuleMethod(frame4, 152, (Object) null, 0);
        lambda$Fn129 = moduleMethod151;
        new ModuleMethod(frame4, 153, (Object) null, 0);
        lambda$Fn130 = moduleMethod152;
        new ModuleMethod(frame4, 154, (Object) null, 0);
        lambda$Fn131 = moduleMethod153;
        new ModuleMethod(frame4, 155, Lit350, 0);
        this.Go_btn$Click = moduleMethod154;
        new ModuleMethod(frame4, 156, (Object) null, 0);
        lambda$Fn132 = moduleMethod155;
        new ModuleMethod(frame4, 157, (Object) null, 0);
        lambda$Fn133 = moduleMethod156;
        new ModuleMethod(frame4, 158, Lit364, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.List_Picker1$AfterPicking = moduleMethod157;
        new ModuleMethod(frame4, 159, (Object) null, 0);
        lambda$Fn134 = moduleMethod158;
        new ModuleMethod(frame4, ComponentConstants.TEXTBOX_PREFERRED_WIDTH, (Object) null, 0);
        lambda$Fn135 = moduleMethod159;
        new ModuleMethod(frame4, 161, (Object) null, 0);
        lambda$Fn136 = moduleMethod160;
        new ModuleMethod(frame4, 162, (Object) null, 0);
        lambda$Fn137 = moduleMethod161;
        new ModuleMethod(frame4, 163, (Object) null, 0);
        lambda$Fn138 = moduleMethod162;
        new ModuleMethod(frame4, 164, (Object) null, 0);
        lambda$Fn139 = moduleMethod163;
        new ModuleMethod(frame4, 165, (Object) null, 0);
        lambda$Fn140 = moduleMethod164;
        new ModuleMethod(frame4, 166, (Object) null, 0);
        lambda$Fn141 = moduleMethod165;
        new ModuleMethod(frame4, 167, (Object) null, 0);
        lambda$Fn142 = moduleMethod166;
        new ModuleMethod(frame4, 168, (Object) null, 0);
        lambda$Fn143 = moduleMethod167;
        new ModuleMethod(frame4, 169, (Object) null, 0);
        lambda$Fn144 = moduleMethod168;
        new ModuleMethod(frame4, 170, (Object) null, 0);
        lambda$Fn145 = moduleMethod169;
        new ModuleMethod(frame4, 171, (Object) null, 0);
        lambda$Fn146 = moduleMethod170;
        new ModuleMethod(frame4, 172, (Object) null, 0);
        lambda$Fn147 = moduleMethod171;
        new ModuleMethod(frame4, 173, Lit415, 0);
        this.cases_description_btn_copy$Click = moduleMethod172;
        new ModuleMethod(frame4, 174, (Object) null, 0);
        lambda$Fn148 = moduleMethod173;
        new ModuleMethod(frame4, 175, (Object) null, 0);
        lambda$Fn149 = moduleMethod174;
        new ModuleMethod(frame4, 176, (Object) null, 0);
        lambda$Fn150 = moduleMethod175;
        new ModuleMethod(frame4, 177, (Object) null, 0);
        lambda$Fn151 = moduleMethod176;
        new ModuleMethod(frame4, 178, (Object) null, 0);
        lambda$Fn152 = moduleMethod177;
        new ModuleMethod(frame4, 179, (Object) null, 0);
        lambda$Fn153 = moduleMethod178;
        new ModuleMethod(frame4, 180, (Object) null, 0);
        lambda$Fn154 = moduleMethod179;
        new ModuleMethod(frame4, 181, (Object) null, 0);
        lambda$Fn155 = moduleMethod180;
        new ModuleMethod(frame4, 182, Lit444, 0);
        this.deaths_description_btn_copy$Click = moduleMethod181;
        new ModuleMethod(frame4, 183, (Object) null, 0);
        lambda$Fn156 = moduleMethod182;
        new ModuleMethod(frame4, 184, (Object) null, 0);
        lambda$Fn157 = moduleMethod183;
        new ModuleMethod(frame4, 185, (Object) null, 0);
        lambda$Fn158 = moduleMethod184;
        new ModuleMethod(frame4, 186, (Object) null, 0);
        lambda$Fn159 = moduleMethod185;
        new ModuleMethod(frame4, 187, (Object) null, 0);
        lambda$Fn160 = moduleMethod186;
        new ModuleMethod(frame4, 188, (Object) null, 0);
        lambda$Fn161 = moduleMethod187;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_DIALOG_FLAG, (Object) null, 0);
        lambda$Fn162 = moduleMethod188;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SEEK, (Object) null, 0);
        lambda$Fn163 = moduleMethod189;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PLAY, (Object) null, 0);
        lambda$Fn164 = moduleMethod190;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PAUSE, (Object) null, 0);
        lambda$Fn165 = moduleMethod191;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_STOP, (Object) null, 0);
        lambda$Fn166 = moduleMethod192;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SOURCE, (Object) null, 0);
        lambda$Fn167 = moduleMethod193;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_FULLSCREEN, (Object) null, 0);
        lambda$Fn168 = moduleMethod194;
        new ModuleMethod(frame4, FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_DURATION, (Object) null, 0);
        lambda$Fn169 = moduleMethod195;
        new ModuleMethod(frame4, 197, Lit489, 0);
        this.Button1_copy$Click = moduleMethod196;
        new ModuleMethod(frame4, 198, (Object) null, 0);
        lambda$Fn170 = moduleMethod197;
        new ModuleMethod(frame4, 199, (Object) null, 0);
        lambda$Fn171 = moduleMethod198;
        new ModuleMethod(frame4, 200, (Object) null, 0);
        lambda$Fn172 = moduleMethod199;
        new ModuleMethod(frame4, 201, (Object) null, 0);
        lambda$Fn173 = moduleMethod200;
        new ModuleMethod(frame4, 202, Lit508, 0);
        this.Button1$Click = moduleMethod201;
        new ModuleMethod(frame4, HttpStatus.SC_NON_AUTHORITATIVE_INFORMATION, (Object) null, 0);
        lambda$Fn174 = moduleMethod202;
        new ModuleMethod(frame4, HttpStatus.SC_NO_CONTENT, (Object) null, 0);
        lambda$Fn175 = moduleMethod203;
        new ModuleMethod(frame4, HttpStatus.SC_RESET_CONTENT, (Object) null, 0);
        lambda$Fn176 = moduleMethod204;
        new ModuleMethod(frame4, HttpStatus.SC_PARTIAL_CONTENT, (Object) null, 0);
        lambda$Fn177 = moduleMethod205;
        new ModuleMethod(frame4, HttpStatus.SC_MULTI_STATUS, (Object) null, 0);
        lambda$Fn178 = moduleMethod206;
        new ModuleMethod(frame4, 208, (Object) null, 0);
        lambda$Fn179 = moduleMethod207;
        new ModuleMethod(frame4, 209, (Object) null, 0);
        lambda$Fn180 = moduleMethod208;
        new ModuleMethod(frame4, 210, (Object) null, 0);
        lambda$Fn181 = moduleMethod209;
        new ModuleMethod(frame4, 211, Lit524, 0);
        this.Button2$Click = moduleMethod210;
        new ModuleMethod(frame4, 212, (Object) null, 0);
        lambda$Fn182 = moduleMethod211;
        new ModuleMethod(frame4, 213, (Object) null, 0);
        lambda$Fn183 = moduleMethod212;
        new ModuleMethod(frame4, 214, (Object) null, 0);
        lambda$Fn184 = moduleMethod213;
        new ModuleMethod(frame4, 215, (Object) null, 0);
        lambda$Fn185 = moduleMethod214;
        new ModuleMethod(frame4, 216, (Object) null, 0);
        lambda$Fn186 = moduleMethod215;
        new ModuleMethod(frame4, 217, (Object) null, 0);
        lambda$Fn187 = moduleMethod216;
        new ModuleMethod(frame4, 218, (Object) null, 0);
        lambda$Fn188 = moduleMethod217;
        new ModuleMethod(frame4, 219, (Object) null, 0);
        lambda$Fn189 = moduleMethod218;
        new ModuleMethod(frame4, 220, (Object) null, 0);
        lambda$Fn190 = moduleMethod219;
        new ModuleMethod(frame4, 221, (Object) null, 0);
        lambda$Fn191 = moduleMethod220;
        new ModuleMethod(frame4, 222, (Object) null, 0);
        lambda$Fn192 = moduleMethod221;
        new ModuleMethod(frame4, 223, (Object) null, 0);
        lambda$Fn193 = moduleMethod222;
        new ModuleMethod(frame4, 224, (Object) null, 0);
        lambda$Fn194 = moduleMethod223;
        new ModuleMethod(frame4, 225, (Object) null, 0);
        lambda$Fn195 = moduleMethod224;
        new ModuleMethod(frame4, 226, (Object) null, 0);
        lambda$Fn196 = moduleMethod225;
        new ModuleMethod(frame4, YaVersion.YOUNG_ANDROID_VERSION, (Object) null, 0);
        lambda$Fn197 = moduleMethod226;
        new ModuleMethod(frame4, 228, (Object) null, 0);
        lambda$Fn198 = moduleMethod227;
        new ModuleMethod(frame4, 229, (Object) null, 0);
        lambda$Fn199 = moduleMethod228;
        new ModuleMethod(frame4, 230, (Object) null, 0);
        lambda$Fn200 = moduleMethod229;
        new ModuleMethod(frame4, 231, (Object) null, 0);
        lambda$Fn201 = moduleMethod230;
        new ModuleMethod(frame4, 232, (Object) null, 0);
        lambda$Fn202 = moduleMethod231;
        new ModuleMethod(frame4, 233, (Object) null, 0);
        lambda$Fn203 = moduleMethod232;
        new ModuleMethod(frame4, 234, (Object) null, 0);
        lambda$Fn204 = moduleMethod233;
        new ModuleMethod(frame4, 235, (Object) null, 0);
        lambda$Fn205 = moduleMethod234;
        new ModuleMethod(frame4, 236, (Object) null, 0);
        lambda$Fn206 = moduleMethod235;
        new ModuleMethod(frame4, 237, (Object) null, 0);
        lambda$Fn207 = moduleMethod236;
        new ModuleMethod(frame4, 238, (Object) null, 0);
        lambda$Fn208 = moduleMethod237;
        new ModuleMethod(frame4, 239, (Object) null, 0);
        lambda$Fn209 = moduleMethod238;
        new ModuleMethod(frame4, 240, (Object) null, 0);
        lambda$Fn210 = moduleMethod239;
        new ModuleMethod(frame4, LispEscapeFormat.ESCAPE_NORMAL, (Object) null, 0);
        lambda$Fn211 = moduleMethod240;
        new ModuleMethod(frame4, LispEscapeFormat.ESCAPE_ALL, (Object) null, 0);
        lambda$Fn212 = moduleMethod241;
        new ModuleMethod(frame4, 243, (Object) null, 0);
        lambda$Fn213 = moduleMethod242;
        new ModuleMethod(frame4, 244, (Object) null, 0);
        lambda$Fn214 = moduleMethod243;
        new ModuleMethod(frame4, 245, (Object) null, 0);
        lambda$Fn215 = moduleMethod244;
        new ModuleMethod(frame4, 246, (Object) null, 0);
        lambda$Fn216 = moduleMethod245;
        new ModuleMethod(frame4, 247, (Object) null, 0);
        lambda$Fn217 = moduleMethod246;
        new ModuleMethod(frame4, ComponentConstants.LISTVIEW_PREFERRED_WIDTH, (Object) null, 0);
        lambda$Fn218 = moduleMethod247;
        new ModuleMethod(frame4, 249, (Object) null, 0);
        lambda$Fn219 = moduleMethod248;
        new ModuleMethod(frame4, ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION, (Object) null, 0);
        lambda$Fn220 = moduleMethod249;
        new ModuleMethod(frame4, Telnet.WILL, (Object) null, 0);
        lambda$Fn221 = moduleMethod250;
        new ModuleMethod(frame4, Telnet.WONT, (Object) null, 0);
        lambda$Fn222 = moduleMethod251;
        new ModuleMethod(frame4, Telnet.f261DO, (Object) null, 0);
        lambda$Fn223 = moduleMethod252;
        new ModuleMethod(frame4, Telnet.DONT, (Object) null, 0);
        lambda$Fn224 = moduleMethod253;
        new ModuleMethod(frame4, 255, (Object) null, 0);
        lambda$Fn225 = moduleMethod254;
        new ModuleMethod(frame4, 256, (Object) null, 0);
        lambda$Fn226 = moduleMethod255;
        new ModuleMethod(frame4, InputDeviceCompat.SOURCE_KEYBOARD, (Object) null, 0);
        lambda$Fn227 = moduleMethod256;
        new ModuleMethod(frame4, 258, (Object) null, 0);
        lambda$Fn228 = moduleMethod257;
        new ModuleMethod(frame4, 259, (Object) null, 0);
        lambda$Fn229 = moduleMethod258;
        new ModuleMethod(frame4, 260, (Object) null, 0);
        lambda$Fn230 = moduleMethod259;
        new ModuleMethod(frame4, 261, (Object) null, 0);
        lambda$Fn231 = moduleMethod260;
        new ModuleMethod(frame4, 262, (Object) null, 0);
        lambda$Fn232 = moduleMethod261;
        new ModuleMethod(frame4, 263, (Object) null, 0);
        lambda$Fn233 = moduleMethod262;
        new ModuleMethod(frame4, 264, (Object) null, 0);
        lambda$Fn234 = moduleMethod263;
        new ModuleMethod(frame4, 265, (Object) null, 0);
        lambda$Fn235 = moduleMethod264;
        new ModuleMethod(frame4, 266, (Object) null, 0);
        lambda$Fn236 = moduleMethod265;
        new ModuleMethod(frame4, 267, (Object) null, 0);
        lambda$Fn237 = moduleMethod266;
        new ModuleMethod(frame4, 268, (Object) null, 0);
        lambda$Fn238 = moduleMethod267;
        new ModuleMethod(frame4, 269, (Object) null, 0);
        lambda$Fn239 = moduleMethod268;
        new ModuleMethod(frame4, 270, Lit683, 16388);
        this.Web1$GotText = moduleMethod269;
        new ModuleMethod(frame4, 271, (Object) null, 0);
        lambda$Fn240 = moduleMethod270;
        new ModuleMethod(frame4, 272, (Object) null, 0);
        lambda$Fn241 = moduleMethod271;
        new ModuleMethod(frame4, 273, (Object) null, 0);
        lambda$Fn242 = moduleMethod272;
        new ModuleMethod(frame4, 274, (Object) null, 0);
        lambda$Fn243 = moduleMethod273;
        new ModuleMethod(frame4, 275, Lit701, 16388);
        this.Web3$GotText = moduleMethod274;
        new ModuleMethod(frame4, 276, (Object) null, 0);
        lambda$Fn244 = moduleMethod275;
        new ModuleMethod(frame4, 277, (Object) null, 0);
        lambda$Fn245 = moduleMethod276;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        String obj;
        Object obj2;
        Consumer $result = $ctx.consumer;
        C1241runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
        Object[] objArr = new Object[2];
        objArr[0] = misc.symbol$To$String(Lit0);
        Object[] objArr2 = objArr;
        objArr2[1] = "-global-vars";
        FString stringAppend = strings.stringAppend(objArr2);
        FString fString = stringAppend;
        if (stringAppend == null) {
            obj = null;
        } else {
            obj = fString.toString();
        }
        this.global$Mnvar$Mnenvironment = Environment.make(obj);
        Screen1 = null;
        this.form$Mnname$Mnsymbol = Lit0;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        C1241runtime.$instance.run();
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit3, "https://covid-193.p.rapidapi.com/statistics?country="), $result);
        } else {
            addToGlobalVars(Lit3, lambda$Fn2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit4, ""), $result);
        } else {
            addToGlobalVars(Lit4, lambda$Fn3);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit5, ""), $result);
        } else {
            addToGlobalVars(Lit5, lambda$Fn4);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit6, "119ffa988fmsha4cf9ab3fb95e90p16f31ajsnffe1562d3d64"), $result);
        } else {
            addToGlobalVars(Lit6, lambda$Fn5);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit7, lambda$Fn6), $result);
        } else {
            addToGlobalVars(Lit7, lambda$Fn7);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit16, lambda$Fn9), $result);
        } else {
            addToGlobalVars(Lit16, lambda$Fn10);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit31, Lit32), $result);
        } else {
            addToGlobalVars(Lit31, lambda$Fn12);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit33, Lit34, Lit35);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit36, Lit37, Lit35);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit38, "6193580781600768", Lit20);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit39, "COVID-19", Lit20);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit40, Lit41, Lit35);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit42, Lit43, Lit35);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit44, AlgorithmIdentifiers.NONE, Lit20);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit45, Boolean.TRUE, Lit10);
            Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit46, "Screen1", Lit20);
            Values.writeValues(C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit47, Boolean.FALSE, Lit10), $result);
        } else {
            new Promise(lambda$Fn13);
            addToFormDoAfterCreation(obj2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment = C1241runtime.addToCurrentFormEnvironment(Lit55, this.Screen1$Initialize);
        } else {
            addToFormEnvironment(Lit55, this.Screen1$Initialize);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Screen1", "Initialize");
        } else {
            addToEvents(Lit0, Lit56);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment2 = C1241runtime.addToCurrentFormEnvironment(Lit68, this.Screen1$BackPressed);
        } else {
            addToFormEnvironment(Lit68, this.Screen1$BackPressed);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Screen1", "BackPressed");
        } else {
            addToEvents(Lit0, Lit69);
        }
        this.Deaths_Description_card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit70, Lit66, lambda$Fn16), $result);
        } else {
            addToComponents(Lit0, Lit75, Lit66, lambda$Fn17);
        }
        this.new_deaths_card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit66, Lit76, Lit77, lambda$Fn18), $result);
        } else {
            addToComponents(Lit66, Lit82, Lit77, lambda$Fn19);
        }
        this.New_Deaths_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit77, Lit83, Lit84, lambda$Fn20), $result);
        } else {
            addToComponents(Lit77, Lit91, Lit84, lambda$Fn21);
        }
        this.Label2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit77, Lit92, Lit93, lambda$Fn22), $result);
        } else {
            addToComponents(Lit77, Lit95, Lit93, lambda$Fn23);
        }
        this.total_deaths_card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit66, Lit96, Lit97, lambda$Fn24), $result);
        } else {
            addToComponents(Lit66, Lit100, Lit97, lambda$Fn25);
        }
        this.Total_Deaths_Tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit97, Lit101, Lit102, lambda$Fn26), $result);
        } else {
            addToComponents(Lit97, Lit103, Lit102, lambda$Fn27);
        }
        this.Total_deaths_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit97, Lit104, Lit105, lambda$Fn28), $result);
        } else {
            addToComponents(Lit97, Lit106, Lit105, lambda$Fn29);
        }
        this.Cases_Discription_Arrangement = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit107, Lit64, lambda$Fn30), $result);
        } else {
            addToComponents(Lit0, Lit109, Lit64, lambda$Fn31);
        }
        this.New_Cases_Card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit64, Lit110, Lit111, lambda$Fn32), $result);
        } else {
            addToComponents(Lit64, Lit114, Lit111, lambda$Fn33);
        }
        this.New_cases_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit111, Lit115, Lit116, lambda$Fn34), $result);
        } else {
            addToComponents(Lit111, Lit117, Lit116, lambda$Fn35);
        }
        this.new_cases_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit111, Lit118, Lit119, lambda$Fn36), $result);
        } else {
            addToComponents(Lit111, Lit120, Lit119, lambda$Fn37);
        }
        this.Active_Cases_Card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit64, Lit121, Lit122, lambda$Fn38), $result);
        } else {
            addToComponents(Lit64, Lit125, Lit122, lambda$Fn39);
        }
        this.Active_cases_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit122, Lit126, Lit127, lambda$Fn40), $result);
        } else {
            addToComponents(Lit122, Lit128, Lit127, lambda$Fn41);
        }
        this.active_cases_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit122, Lit129, Lit130, lambda$Fn42), $result);
        } else {
            addToComponents(Lit122, Lit131, Lit130, lambda$Fn43);
        }
        this.Critical_Cases_Card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit64, Lit132, Lit133, lambda$Fn44), $result);
        } else {
            addToComponents(Lit64, Lit136, Lit133, lambda$Fn45);
        }
        this.Critical_cases_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit133, Lit137, Lit138, lambda$Fn46), $result);
        } else {
            addToComponents(Lit133, Lit139, Lit138, lambda$Fn47);
        }
        this.critical_cases_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit133, Lit140, Lit141, lambda$Fn48), $result);
        } else {
            addToComponents(Lit133, Lit142, Lit141, lambda$Fn49);
        }
        this.Recovered_Cases_CArd = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit64, Lit143, Lit144, lambda$Fn50), $result);
        } else {
            addToComponents(Lit64, Lit147, Lit144, lambda$Fn51);
        }
        this.Recovered_cases_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit144, Lit148, Lit149, lambda$Fn52), $result);
        } else {
            addToComponents(Lit144, Lit150, Lit149, lambda$Fn53);
        }
        this.recovered_cases_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit144, Lit151, Lit152, lambda$Fn54), $result);
        } else {
            addToComponents(Lit144, Lit153, Lit152, lambda$Fn55);
        }
        this.Total_Cases_Card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit64, Lit154, Lit155, lambda$Fn56), $result);
        } else {
            addToComponents(Lit64, Lit158, Lit155, lambda$Fn57);
        }
        this.total_cases_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit155, Lit159, Lit160, lambda$Fn58), $result);
        } else {
            addToComponents(Lit155, Lit161, Lit160, lambda$Fn59);
        }
        this.total_cases_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit155, Lit162, Lit163, lambda$Fn60), $result);
        } else {
            addToComponents(Lit155, Lit164, Lit163, lambda$Fn61);
        }
        this.Rsults_Arrangement = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit165, Lit61, lambda$Fn62), $result);
        } else {
            addToComponents(Lit0, Lit167, Lit61, lambda$Fn63);
        }
        this.Cases_Card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit61, Lit168, Lit169, lambda$Fn64), $result);
        } else {
            addToComponents(Lit61, Lit172, Lit169, lambda$Fn65);
        }
        this.Cases_Tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit169, Lit173, Lit174, lambda$Fn66), $result);
        } else {
            addToComponents(Lit169, Lit176, Lit174, lambda$Fn67);
        }
        this.Cases_Label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit169, Lit177, Lit178, lambda$Fn68), $result);
        } else {
            addToComponents(Lit169, Lit179, Lit178, lambda$Fn69);
        }
        this.cases_description_btn = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit169, Lit180, Lit181, lambda$Fn70), $result);
        } else {
            addToComponents(Lit169, Lit185, Lit181, lambda$Fn71);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment3 = C1241runtime.addToCurrentFormEnvironment(Lit186, this.cases_description_btn$Click);
        } else {
            addToFormEnvironment(Lit186, this.cases_description_btn$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "cases_description_btn", "Click");
        } else {
            addToEvents(Lit181, Lit187);
        }
        this.Label5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit61, Lit188, Lit189, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit61, Lit190, Lit189, Boolean.FALSE);
        }
        this.Deaths_Card = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit61, Lit191, Lit192, lambda$Fn72), $result);
        } else {
            addToComponents(Lit61, Lit195, Lit192, lambda$Fn73);
        }
        this.Deaths_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit192, Lit196, Lit197, lambda$Fn74), $result);
        } else {
            addToComponents(Lit192, Lit198, Lit197, lambda$Fn75);
        }
        this.Deaths_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit192, Lit199, Lit200, lambda$Fn76), $result);
        } else {
            addToComponents(Lit192, Lit201, Lit200, lambda$Fn77);
        }
        this.deaths_description_btn = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit192, Lit202, Lit203, lambda$Fn78), $result);
        } else {
            addToComponents(Lit192, Lit205, Lit203, lambda$Fn79);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment4 = C1241runtime.addToCurrentFormEnvironment(Lit206, this.deaths_description_btn$Click);
        } else {
            addToFormEnvironment(Lit206, this.deaths_description_btn$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "deaths_description_btn", "Click");
        } else {
            addToEvents(Lit203, Lit187);
        }
        this.Label6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit61, Lit207, Lit208, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit61, Lit209, Lit208, Boolean.FALSE);
        }
        this.Recovered_CArd = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit61, Lit210, Lit211, lambda$Fn80), $result);
        } else {
            addToComponents(Lit61, Lit214, Lit211, lambda$Fn81);
        }
        this.Recovered_TAg = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit211, Lit215, Lit216, lambda$Fn82), $result);
        } else {
            addToComponents(Lit211, Lit217, Lit216, lambda$Fn83);
        }
        this.Recovered_label = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit211, Lit218, Lit219, lambda$Fn84), $result);
        } else {
            addToComponents(Lit211, Lit220, Lit219, lambda$Fn85);
        }
        this.Label7 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit61, Lit221, Lit222, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit61, Lit223, Lit222, Boolean.FALSE);
        }
        this.Test_Cards = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit61, Lit224, Lit225, lambda$Fn86), $result);
        } else {
            addToComponents(Lit61, Lit228, Lit225, lambda$Fn87);
        }
        this.Tests_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit225, Lit229, Lit230, lambda$Fn88), $result);
        } else {
            addToComponents(Lit225, Lit231, Lit230, lambda$Fn89);
        }
        this.Test_albel = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit225, Lit232, Lit233, lambda$Fn90), $result);
        } else {
            addToComponents(Lit225, Lit234, Lit233, lambda$Fn91);
        }
        this.Loading_Data__Arrangement = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit235, Lit8, lambda$Fn92), $result);
        } else {
            addToComponents(Lit0, Lit238, Lit8, lambda$Fn93);
        }
        this.Custom_Progress1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit8, Lit239, Lit240, lambda$Fn94), $result);
        } else {
            addToComponents(Lit8, Lit243, Lit240, lambda$Fn95);
        }
        this.Space2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit8, Lit244, Lit245, lambda$Fn96), $result);
        } else {
            addToComponents(Lit8, Lit247, Lit245, lambda$Fn97);
        }
        this.Fetching_Data_Tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit8, Lit248, Lit249, lambda$Fn98), $result);
        } else {
            addToComponents(Lit8, Lit252, Lit249, lambda$Fn99);
        }
        this.Horizontal_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit253, Lit63, lambda$Fn100), $result);
        } else {
            addToComponents(Lit0, Lit256, Lit63, lambda$Fn101);
        }
        this.Horizontal_Arrangement2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit63, Lit257, Lit258, lambda$Fn102), $result);
        } else {
            addToComponents(Lit63, Lit259, Lit258, lambda$Fn103);
        }
        this.Image1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit258, Lit260, Lit51, lambda$Fn104), $result);
        } else {
            addToComponents(Lit258, Lit263, Lit51, lambda$Fn105);
        }
        this.Space4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit63, Lit264, Lit265, lambda$Fn106), $result);
        } else {
            addToComponents(Lit63, Lit267, Lit265, lambda$Fn107);
        }
        this.Label3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit63, Lit268, Lit269, lambda$Fn108), $result);
        } else {
            addToComponents(Lit63, Lit270, Lit269, lambda$Fn109);
        }
        this.Space5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit63, Lit271, Lit272, lambda$Fn110), $result);
        } else {
            addToComponents(Lit63, Lit274, Lit272, lambda$Fn111);
        }
        this.Horizontal_Arrangement3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit63, Lit275, Lit276, lambda$Fn112), $result);
        } else {
            addToComponents(Lit63, Lit278, Lit276, lambda$Fn113);
        }
        this.Label4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit276, Lit279, Lit280, lambda$Fn114), $result);
        } else {
            addToComponents(Lit276, Lit285, Lit280, lambda$Fn115);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment5 = C1241runtime.addToCurrentFormEnvironment(Lit301, this.Label4$Click);
        } else {
            addToFormEnvironment(Lit301, this.Label4$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Label4", "Click");
        } else {
            addToEvents(Lit280, Lit187);
        }
        this.Choose_country_arrangement = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit302, Lit57, lambda$Fn116), $result);
        } else {
            addToComponents(Lit0, Lit304, Lit57, lambda$Fn117);
        }
        this.Image2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit57, Lit305, Lit306, lambda$Fn118), $result);
        } else {
            addToComponents(Lit57, Lit310, Lit306, lambda$Fn119);
        }
        this.Space7 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit57, Lit311, Lit312, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit57, Lit313, Lit312, Boolean.FALSE);
        }
        this.Vertical_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit57, Lit314, Lit315, lambda$Fn120), $result);
        } else {
            addToComponents(Lit57, Lit317, Lit315, lambda$Fn121);
        }
        this.chose_country_tag = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit315, Lit318, Lit319, lambda$Fn122), $result);
        } else {
            addToComponents(Lit315, Lit322, Lit319, lambda$Fn123);
        }
        this.Space6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit315, Lit323, Lit324, lambda$Fn124), $result);
        } else {
            addToComponents(Lit315, Lit326, Lit324, lambda$Fn125);
        }
        this.list_viewer_button = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit315, Lit327, Lit328, lambda$Fn126), $result);
        } else {
            addToComponents(Lit315, Lit332, Lit328, lambda$Fn127);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment6 = C1241runtime.addToCurrentFormEnvironment(Lit335, this.list_viewer_button$Click);
        } else {
            addToFormEnvironment(Lit335, this.list_viewer_button$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "list_viewer_button", "Click");
        } else {
            addToEvents(Lit328, Lit187);
        }
        this.Space1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit315, Lit336, Lit337, lambda$Fn128), $result);
        } else {
            addToComponents(Lit315, Lit339, Lit337, lambda$Fn129);
        }
        this.Go_btn = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit315, Lit340, Lit341, lambda$Fn130), $result);
        } else {
            addToComponents(Lit315, Lit344, Lit341, lambda$Fn131);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment7 = C1241runtime.addToCurrentFormEnvironment(Lit350, this.Go_btn$Click);
        } else {
            addToFormEnvironment(Lit350, this.Go_btn$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Go_btn", "Click");
        } else {
            addToEvents(Lit341, Lit187);
        }
        this.List_Picker1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit57, Lit351, Lit333, lambda$Fn132), $result);
        } else {
            addToComponents(Lit57, Lit362, Lit333, lambda$Fn133);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment8 = C1241runtime.addToCurrentFormEnvironment(Lit364, this.List_Picker1$AfterPicking);
        } else {
            addToFormEnvironment(Lit364, this.List_Picker1$AfterPicking);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "List_Picker1", "AfterPicking");
        } else {
            addToEvents(Lit333, Lit365);
        }
        this.Vertical_Arrangement2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit366, Lit59, lambda$Fn134), $result);
        } else {
            addToComponents(Lit0, Lit368, Lit59, lambda$Fn135);
        }
        this.Label8 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit59, Lit369, Lit290, lambda$Fn136), $result);
        } else {
            addToComponents(Lit59, Lit371, Lit290, lambda$Fn137);
        }
        this.Label10 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit59, Lit372, Lit373, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit59, Lit374, Lit373, Boolean.FALSE);
        }
        this.Rsults_Arrangement_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit59, Lit375, Lit376, lambda$Fn138), $result);
        } else {
            addToComponents(Lit59, Lit378, Lit376, lambda$Fn139);
        }
        this.Cases_Card_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit376, Lit379, Lit380, lambda$Fn140), $result);
        } else {
            addToComponents(Lit376, Lit383, Lit380, lambda$Fn141);
        }
        this.Cases_Tag_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit380, Lit384, Lit385, lambda$Fn142), $result);
        } else {
            addToComponents(Lit380, Lit386, Lit385, lambda$Fn143);
        }
        this.Cases_Label_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit380, Lit387, Lit293, lambda$Fn144), $result);
        } else {
            addToComponents(Lit380, Lit388, Lit293, lambda$Fn145);
        }
        this.cases_description_btn_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit380, Lit389, Lit390, lambda$Fn146), $result);
        } else {
            addToComponents(Lit380, Lit392, Lit390, lambda$Fn147);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment9 = C1241runtime.addToCurrentFormEnvironment(Lit415, this.cases_description_btn_copy$Click);
        } else {
            addToFormEnvironment(Lit415, this.cases_description_btn_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "cases_description_btn_copy", "Click");
        } else {
            addToEvents(Lit390, Lit187);
        }
        this.Label5_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit376, Lit416, Lit417, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit376, Lit418, Lit417, Boolean.FALSE);
        }
        this.Deaths_Card_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit376, Lit419, Lit420, lambda$Fn148), $result);
        } else {
            addToComponents(Lit376, Lit423, Lit420, lambda$Fn149);
        }
        this.Deaths_tag_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit420, Lit424, Lit425, lambda$Fn150), $result);
        } else {
            addToComponents(Lit420, Lit426, Lit425, lambda$Fn151);
        }
        this.Deaths_label_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit420, Lit427, Lit295, lambda$Fn152), $result);
        } else {
            addToComponents(Lit420, Lit428, Lit295, lambda$Fn153);
        }
        this.deaths_description_btn_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit420, Lit429, Lit430, lambda$Fn154), $result);
        } else {
            addToComponents(Lit420, Lit432, Lit430, lambda$Fn155);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment10 = C1241runtime.addToCurrentFormEnvironment(Lit444, this.deaths_description_btn_copy$Click);
        } else {
            addToFormEnvironment(Lit444, this.deaths_description_btn_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "deaths_description_btn_copy", "Click");
        } else {
            addToEvents(Lit430, Lit187);
        }
        this.Label6_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit376, Lit445, Lit446, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit376, Lit447, Lit446, Boolean.FALSE);
        }
        this.Recovered_CArd_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit376, Lit448, Lit449, lambda$Fn156), $result);
        } else {
            addToComponents(Lit376, Lit452, Lit449, lambda$Fn157);
        }
        this.Recovered_TAg_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit449, Lit453, Lit454, lambda$Fn158), $result);
        } else {
            addToComponents(Lit449, Lit455, Lit454, lambda$Fn159);
        }
        this.Recovered_label_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit449, Lit456, Lit297, lambda$Fn160), $result);
        } else {
            addToComponents(Lit449, Lit457, Lit297, lambda$Fn161);
        }
        this.Label7_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit376, Lit458, Lit459, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit376, Lit460, Lit459, Boolean.FALSE);
        }
        this.Test_Cards_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit376, Lit461, Lit462, lambda$Fn162), $result);
        } else {
            addToComponents(Lit376, Lit465, Lit462, lambda$Fn163);
        }
        this.Tests_tag_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit462, Lit466, Lit467, lambda$Fn164), $result);
        } else {
            addToComponents(Lit462, Lit468, Lit467, lambda$Fn165);
        }
        this.Test_albel_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit462, Lit469, Lit299, lambda$Fn166), $result);
        } else {
            addToComponents(Lit462, Lit470, Lit299, lambda$Fn167);
        }
        this.Horizontal_Arrangement4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit59, Lit471, Lit472, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit59, Lit473, Lit472, Boolean.FALSE);
        }
        this.Button1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit472, Lit474, Lit475, lambda$Fn168), $result);
        } else {
            addToComponents(Lit472, Lit477, Lit475, lambda$Fn169);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment11 = C1241runtime.addToCurrentFormEnvironment(Lit489, this.Button1_copy$Click);
        } else {
            addToFormEnvironment(Lit489, this.Button1_copy$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button1_copy", "Click");
        } else {
            addToEvents(Lit475, Lit187);
        }
        this.Space8 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit472, Lit490, Lit491, lambda$Fn170), $result);
        } else {
            addToComponents(Lit472, Lit493, Lit491, lambda$Fn171);
        }
        this.Button1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit472, Lit494, Lit495, lambda$Fn172), $result);
        } else {
            addToComponents(Lit472, Lit497, Lit495, lambda$Fn173);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment12 = C1241runtime.addToCurrentFormEnvironment(Lit508, this.Button1$Click);
        } else {
            addToFormEnvironment(Lit508, this.Button1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button1", "Click");
        } else {
            addToEvents(Lit495, Lit187);
        }
        this.Vertical_Arrangement3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit509, Lit393, lambda$Fn174), $result);
        } else {
            addToComponents(Lit0, Lit511, Lit393, lambda$Fn175);
        }
        this.Horizontal_Arrangement5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit512, Lit513, lambda$Fn176), $result);
        } else {
            addToComponents(Lit393, Lit514, Lit513, lambda$Fn177);
        }
        this.Label11 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit513, Lit515, Lit397, lambda$Fn178), $result);
        } else {
            addToComponents(Lit513, Lit517, Lit397, lambda$Fn179);
        }
        this.Button2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit513, Lit518, Lit519, lambda$Fn180), $result);
        } else {
            addToComponents(Lit513, Lit522, Lit519, lambda$Fn181);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment13 = C1241runtime.addToCurrentFormEnvironment(Lit524, this.Button2$Click);
        } else {
            addToFormEnvironment(Lit524, this.Button2$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button2", "Click");
        } else {
            addToEvents(Lit519, Lit187);
        }
        this.Label12 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit525, Lit526, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit527, Lit526, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit528, Lit529, lambda$Fn182), $result);
        } else {
            addToComponents(Lit393, Lit532, Lit529, lambda$Fn183);
        }
        this.Cases_Tag_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit529, Lit533, Lit534, lambda$Fn184), $result);
        } else {
            addToComponents(Lit529, Lit535, Lit534, lambda$Fn185);
        }
        this.Cases_Label_copy_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit529, Lit536, Lit399, lambda$Fn186), $result);
        } else {
            addToComponents(Lit529, Lit537, Lit399, lambda$Fn187);
        }
        this.Label13 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit538, Lit539, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit540, Lit539, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit541, Lit542, lambda$Fn188), $result);
        } else {
            addToComponents(Lit393, Lit545, Lit542, lambda$Fn189);
        }
        this.Cases_Tag_copy_copy1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit542, Lit546, Lit547, lambda$Fn190), $result);
        } else {
            addToComponents(Lit542, Lit548, Lit547, lambda$Fn191);
        }
        this.Cases_Label_copy_copy1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit542, Lit549, Lit401, lambda$Fn192), $result);
        } else {
            addToComponents(Lit542, Lit550, Lit401, lambda$Fn193);
        }
        this.Label14 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit551, Lit552, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit553, Lit552, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit554, Lit555, lambda$Fn194), $result);
        } else {
            addToComponents(Lit393, Lit558, Lit555, lambda$Fn195);
        }
        this.Cases_Tag_copy_copy2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit555, Lit559, Lit560, lambda$Fn196), $result);
        } else {
            addToComponents(Lit555, Lit561, Lit560, lambda$Fn197);
        }
        this.Cases_Label_copy_copy2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit555, Lit562, Lit403, lambda$Fn198), $result);
        } else {
            addToComponents(Lit555, Lit563, Lit403, lambda$Fn199);
        }
        this.Label15 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit564, Lit565, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit566, Lit565, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy2_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit567, Lit568, lambda$Fn200), $result);
        } else {
            addToComponents(Lit393, Lit571, Lit568, lambda$Fn201);
        }
        this.Cases_Tag_copy_copy2_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit568, Lit572, Lit573, lambda$Fn202), $result);
        } else {
            addToComponents(Lit568, Lit574, Lit573, lambda$Fn203);
        }
        this.Cases_Label_copy_copy2_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit568, Lit575, Lit405, lambda$Fn204), $result);
        } else {
            addToComponents(Lit568, Lit576, Lit405, lambda$Fn205);
        }
        this.Label16 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit577, Lit578, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit579, Lit578, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy2_copy1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit580, Lit581, lambda$Fn206), $result);
        } else {
            addToComponents(Lit393, Lit584, Lit581, lambda$Fn207);
        }
        this.Cases_Tag_copy_copy2_copy1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit581, Lit585, Lit586, lambda$Fn208), $result);
        } else {
            addToComponents(Lit581, Lit587, Lit586, lambda$Fn209);
        }
        this.Cases_Label_copy_copy2_copy1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit581, Lit588, Lit407, lambda$Fn210), $result);
        } else {
            addToComponents(Lit581, Lit589, Lit407, lambda$Fn211);
        }
        this.Label17 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit590, Lit591, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit592, Lit591, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy2_copy2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit593, Lit594, lambda$Fn212), $result);
        } else {
            addToComponents(Lit393, Lit597, Lit594, lambda$Fn213);
        }
        this.Cases_Tag_copy_copy2_copy2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit594, Lit598, Lit599, lambda$Fn214), $result);
        } else {
            addToComponents(Lit594, Lit600, Lit599, lambda$Fn215);
        }
        this.Cases_Label_copy_copy2_copy2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit594, Lit601, Lit409, lambda$Fn216), $result);
        } else {
            addToComponents(Lit594, Lit602, Lit409, lambda$Fn217);
        }
        this.Label18 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit603, Lit604, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit605, Lit604, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy2_copy3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit606, Lit607, lambda$Fn218), $result);
        } else {
            addToComponents(Lit393, Lit610, Lit607, lambda$Fn219);
        }
        this.Cases_Tag_copy_copy2_copy3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit607, Lit611, Lit612, lambda$Fn220), $result);
        } else {
            addToComponents(Lit607, Lit613, Lit612, lambda$Fn221);
        }
        this.Cases_Label_copy_copy2_copy3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit607, Lit614, Lit411, lambda$Fn222), $result);
        } else {
            addToComponents(Lit607, Lit615, Lit411, lambda$Fn223);
        }
        this.Label19 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit616, Lit617, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit393, Lit618, Lit617, Boolean.FALSE);
        }
        this.Cases_Card_copy_copy2_copy4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit393, Lit619, Lit620, lambda$Fn224), $result);
        } else {
            addToComponents(Lit393, Lit623, Lit620, lambda$Fn225);
        }
        this.Cases_Tag_copy_copy2_copy4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit620, Lit624, Lit625, lambda$Fn226), $result);
        } else {
            addToComponents(Lit620, Lit626, Lit625, lambda$Fn227);
        }
        this.Cases_Label_copy_copy2_copy4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit620, Lit627, Lit413, lambda$Fn228), $result);
        } else {
            addToComponents(Lit620, Lit628, Lit413, lambda$Fn229);
        }
        this.Horizontal_Arrangement1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit629, Lit630, lambda$Fn230), $result);
        } else {
            addToComponents(Lit0, Lit632, Lit630, lambda$Fn231);
        }
        this.Horizontal_Arrangement2_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit630, Lit633, Lit634, lambda$Fn232), $result);
        } else {
            addToComponents(Lit630, Lit635, Lit634, lambda$Fn233);
        }
        this.Image1_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit634, Lit636, Lit53, lambda$Fn234), $result);
        } else {
            addToComponents(Lit634, Lit639, Lit53, lambda$Fn235);
        }
        this.Space4_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit630, Lit640, Lit641, lambda$Fn236), $result);
        } else {
            addToComponents(Lit630, Lit643, Lit641, lambda$Fn237);
        }
        this.Label3_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit630, Lit644, Lit645, lambda$Fn238), $result);
        } else {
            addToComponents(Lit630, Lit647, Lit645, lambda$Fn239);
        }
        this.Web1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit648, Lit17, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit649, Lit17, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment14 = C1241runtime.addToCurrentFormEnvironment(Lit683, this.Web1$GotText);
        } else {
            addToFormEnvironment(Lit683, this.Web1$GotText);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Web1", "GotText");
        } else {
            addToEvents(Lit17, Lit684);
        }
        this.fetching_data_notifier = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit685, Lit11, lambda$Fn240), $result);
        } else {
            addToComponents(Lit0, Lit687, Lit11, lambda$Fn241);
        }
        this.JSONTools1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit688, Lit654, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit689, Lit654, Boolean.FALSE);
        }
        this.Image_Utilities1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit690, Lit49, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit691, Lit49, Boolean.FALSE);
        }
        this.JsonUtils1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit692, Lit693, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit694, Lit693, Boolean.FALSE);
        }
        this.Web2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit695, Lit696, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit697, Lit696, Boolean.FALSE);
        }
        this.Web3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit698, Lit48, lambda$Fn242), $result);
        } else {
            addToComponents(Lit0, Lit699, Lit48, lambda$Fn243);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment15 = C1241runtime.addToCurrentFormEnvironment(Lit701, this.Web3$GotText);
        } else {
            addToFormEnvironment(Lit701, this.Web3$GotText);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Web3", "GotText");
        } else {
            addToEvents(Lit48, Lit684);
        }
        this.JSONTools2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit702, Lit287, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit703, Lit287, Boolean.FALSE);
        }
        this.Notifier1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit704, Lit394, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit705, Lit394, Boolean.FALSE);
        }
        this.Snackbar1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit706, Lit479, lambda$Fn244), $result);
        } else {
            addToComponents(Lit0, Lit709, Lit479, lambda$Fn245);
        }
        C1241runtime.initRuntime();
    }

    static String lambda3() {
        return "https://covid-193.p.rapidapi.com/statistics?country=";
    }

    static String lambda4() {
        return "";
    }

    static String lambda5() {
        return "";
    }

    static String lambda6() {
        return "119ffa988fmsha4cf9ab3fb95e90p16f31ajsnffe1562d3d64";
    }

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen3$frame */
    /* compiled from: Screen3.yail */
    public class frame extends ModuleBody {
        Screen3 $main;

        public frame() {
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return Screen3.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return Screen3.lambda3();
                case 20:
                    return Screen3.lambda4();
                case 21:
                    return Screen3.lambda5();
                case 22:
                    return Screen3.lambda6();
                case 23:
                    return Screen3.lambda7();
                case 24:
                    return Screen3.lambda9();
                case 25:
                    return Screen3.lambda8();
                case 26:
                    return Screen3.lambda10();
                case 27:
                    return Screen3.lambda12();
                case 28:
                    return Screen3.lambda11();
                case 29:
                    return Screen3.lambda13();
                case 30:
                    return Screen3.lambda14();
                case 31:
                    return this.$main.Screen1$Initialize();
                case 32:
                    return Screen3.lambda15();
                case 33:
                    return Screen3.lambda16();
                case 34:
                    return this.$main.Screen1$BackPressed();
                case 35:
                    return Screen3.lambda17();
                case 36:
                    return Screen3.lambda18();
                case 37:
                    return Screen3.lambda19();
                case 38:
                    return Screen3.lambda20();
                case 39:
                    return Screen3.lambda21();
                case 40:
                    return Screen3.lambda22();
                case 41:
                    return Screen3.lambda23();
                case 42:
                    return Screen3.lambda24();
                case 43:
                    return Screen3.lambda25();
                case 44:
                    return Screen3.lambda26();
                case 45:
                    return Screen3.lambda27();
                case 46:
                    return Screen3.lambda28();
                case 47:
                    return Screen3.lambda29();
                case 48:
                    return Screen3.lambda30();
                case 49:
                    return Screen3.lambda31();
                case 50:
                    return Screen3.lambda32();
                case 51:
                    return Screen3.lambda33();
                case 52:
                    return Screen3.lambda34();
                case 53:
                    return Screen3.lambda35();
                case 54:
                    return Screen3.lambda36();
                case 55:
                    return Screen3.lambda37();
                case 56:
                    return Screen3.lambda38();
                case 57:
                    return Screen3.lambda39();
                case 58:
                    return Screen3.lambda40();
                case 59:
                    return Screen3.lambda41();
                case 60:
                    return Screen3.lambda42();
                case 61:
                    return Screen3.lambda43();
                case 62:
                    return Screen3.lambda44();
                case 63:
                    return Screen3.lambda45();
                case 64:
                    return Screen3.lambda46();
                case 65:
                    return Screen3.lambda47();
                case 66:
                    return Screen3.lambda48();
                case 67:
                    return Screen3.lambda49();
                case 68:
                    return Screen3.lambda50();
                case 69:
                    return Screen3.lambda51();
                case 70:
                    return Screen3.lambda52();
                case 71:
                    return Screen3.lambda53();
                case 72:
                    return Screen3.lambda54();
                case 73:
                    return Screen3.lambda55();
                case 74:
                    return Screen3.lambda56();
                case 75:
                    return Screen3.lambda57();
                case 76:
                    return Screen3.lambda58();
                case 77:
                    return Screen3.lambda59();
                case 78:
                    return Screen3.lambda60();
                case 79:
                    return Screen3.lambda61();
                case 80:
                    return Screen3.lambda62();
                case 81:
                    return Screen3.lambda63();
                case 82:
                    return Screen3.lambda64();
                case 83:
                    return Screen3.lambda65();
                case 84:
                    return Screen3.lambda66();
                case 85:
                    return Screen3.lambda67();
                case 86:
                    return Screen3.lambda68();
                case 87:
                    return Screen3.lambda69();
                case 88:
                    return Screen3.lambda70();
                case 89:
                    return Screen3.lambda71();
                case 90:
                    return Screen3.lambda72();
                case 91:
                    return this.$main.cases_description_btn$Click();
                case 92:
                    return Screen3.lambda73();
                case 93:
                    return Screen3.lambda74();
                case 94:
                    return Screen3.lambda75();
                case 95:
                    return Screen3.lambda76();
                case 96:
                    return Screen3.lambda77();
                case 97:
                    return Screen3.lambda78();
                case 98:
                    return Screen3.lambda79();
                case 99:
                    return Screen3.lambda80();
                case 100:
                    return this.$main.deaths_description_btn$Click();
                case 101:
                    return Screen3.lambda81();
                case 102:
                    return Screen3.lambda82();
                case 103:
                    return Screen3.lambda83();
                case 104:
                    return Screen3.lambda84();
                case 105:
                    return Screen3.lambda85();
                case 106:
                    return Screen3.lambda86();
                case 107:
                    return Screen3.lambda87();
                case 108:
                    return Screen3.lambda88();
                case 109:
                    return Screen3.lambda89();
                case 110:
                    return Screen3.lambda90();
                case 111:
                    return Screen3.lambda91();
                case 112:
                    return Screen3.lambda92();
                case 113:
                    return Screen3.lambda93();
                case 114:
                    return Screen3.lambda94();
                case 115:
                    return Screen3.lambda95();
                case 116:
                    return Screen3.lambda96();
                case 117:
                    return Screen3.lambda97();
                case 118:
                    return Screen3.lambda98();
                case 119:
                    return Screen3.lambda99();
                case 120:
                    return Screen3.lambda100();
                case 121:
                    return Screen3.lambda101();
                case 122:
                    return Screen3.lambda102();
                case 123:
                    return Screen3.lambda103();
                case 124:
                    return Screen3.lambda104();
                case ErrorLogHelper.MAX_PROPERTY_ITEM_LENGTH /*125*/:
                    return Screen3.lambda105();
                case 126:
                    return Screen3.lambda106();
                case 127:
                    return Screen3.lambda107();
                case 128:
                    return Screen3.lambda108();
                case 129:
                    return Screen3.lambda109();
                case 130:
                    return Screen3.lambda110();
                case 131:
                    return Screen3.lambda111();
                case 132:
                    return Screen3.lambda112();
                case 133:
                    return Screen3.lambda113();
                case 134:
                    return Screen3.lambda114();
                case 135:
                    return Screen3.lambda115();
                case 136:
                    return Screen3.lambda116();
                case 137:
                    return this.$main.Label4$Click();
                case 138:
                    return Screen3.lambda117();
                case 139:
                    return Screen3.lambda118();
                case 140:
                    return Screen3.lambda119();
                case 141:
                    return Screen3.lambda120();
                case 142:
                    return Screen3.lambda121();
                case 143:
                    return Screen3.lambda122();
                case 144:
                    return Screen3.lambda123();
                case 145:
                    return Screen3.lambda124();
                case 146:
                    return Screen3.lambda125();
                case 147:
                    return Screen3.lambda126();
                case 148:
                    return Screen3.lambda127();
                case 149:
                    return Screen3.lambda128();
                case 150:
                    return this.$main.list_viewer_button$Click();
                case 151:
                    return Screen3.lambda129();
                case 152:
                    return Screen3.lambda130();
                case 153:
                    return Screen3.lambda131();
                case 154:
                    return Screen3.lambda132();
                case 155:
                    return this.$main.Go_btn$Click();
                case 156:
                    return Screen3.lambda133();
                case 157:
                    return Screen3.lambda134();
                case 159:
                    return Screen3.lambda135();
                case ComponentConstants.TEXTBOX_PREFERRED_WIDTH:
                    return Screen3.lambda136();
                case 161:
                    return Screen3.lambda137();
                case 162:
                    return Screen3.lambda138();
                case 163:
                    return Screen3.lambda139();
                case 164:
                    return Screen3.lambda140();
                case 165:
                    return Screen3.lambda141();
                case 166:
                    return Screen3.lambda142();
                case 167:
                    return Screen3.lambda143();
                case 168:
                    return Screen3.lambda144();
                case 169:
                    return Screen3.lambda145();
                case 170:
                    return Screen3.lambda146();
                case 171:
                    return Screen3.lambda147();
                case 172:
                    return Screen3.lambda148();
                case 173:
                    return this.$main.cases_description_btn_copy$Click();
                case 174:
                    return Screen3.lambda149();
                case 175:
                    return Screen3.lambda150();
                case 176:
                    return Screen3.lambda151();
                case 177:
                    return Screen3.lambda152();
                case 178:
                    return Screen3.lambda153();
                case 179:
                    return Screen3.lambda154();
                case 180:
                    return Screen3.lambda155();
                case 181:
                    return Screen3.lambda156();
                case 182:
                    return this.$main.deaths_description_btn_copy$Click();
                case 183:
                    return Screen3.lambda157();
                case 184:
                    return Screen3.lambda158();
                case 185:
                    return Screen3.lambda159();
                case 186:
                    return Screen3.lambda160();
                case 187:
                    return Screen3.lambda161();
                case 188:
                    return Screen3.lambda162();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_DIALOG_FLAG:
                    return Screen3.lambda163();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SEEK:
                    return Screen3.lambda164();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PLAY:
                    return Screen3.lambda165();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PAUSE:
                    return Screen3.lambda166();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_STOP:
                    return Screen3.lambda167();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SOURCE:
                    return Screen3.lambda168();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_FULLSCREEN:
                    return Screen3.lambda169();
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_DURATION:
                    return Screen3.lambda170();
                case 197:
                    return this.$main.Button1_copy$Click();
                case 198:
                    return Screen3.lambda171();
                case 199:
                    return Screen3.lambda172();
                case 200:
                    return Screen3.lambda173();
                case 201:
                    return Screen3.lambda174();
                case 202:
                    return this.$main.Button1$Click();
                case HttpStatus.SC_NON_AUTHORITATIVE_INFORMATION /*203*/:
                    return Screen3.lambda175();
                case HttpStatus.SC_NO_CONTENT /*204*/:
                    return Screen3.lambda176();
                case HttpStatus.SC_RESET_CONTENT /*205*/:
                    return Screen3.lambda177();
                case HttpStatus.SC_PARTIAL_CONTENT /*206*/:
                    return Screen3.lambda178();
                case HttpStatus.SC_MULTI_STATUS /*207*/:
                    return Screen3.lambda179();
                case 208:
                    return Screen3.lambda180();
                case 209:
                    return Screen3.lambda181();
                case 210:
                    return Screen3.lambda182();
                case 211:
                    return this.$main.Button2$Click();
                case 212:
                    return Screen3.lambda183();
                case 213:
                    return Screen3.lambda184();
                case 214:
                    return Screen3.lambda185();
                case 215:
                    return Screen3.lambda186();
                case 216:
                    return Screen3.lambda187();
                case 217:
                    return Screen3.lambda188();
                case 218:
                    return Screen3.lambda189();
                case 219:
                    return Screen3.lambda190();
                case 220:
                    return Screen3.lambda191();
                case 221:
                    return Screen3.lambda192();
                case 222:
                    return Screen3.lambda193();
                case 223:
                    return Screen3.lambda194();
                case 224:
                    return Screen3.lambda195();
                case 225:
                    return Screen3.lambda196();
                case 226:
                    return Screen3.lambda197();
                case YaVersion.YOUNG_ANDROID_VERSION:
                    return Screen3.lambda198();
                case 228:
                    return Screen3.lambda199();
                case 229:
                    return Screen3.lambda200();
                case 230:
                    return Screen3.lambda201();
                case 231:
                    return Screen3.lambda202();
                case 232:
                    return Screen3.lambda203();
                case 233:
                    return Screen3.lambda204();
                case 234:
                    return Screen3.lambda205();
                case 235:
                    return Screen3.lambda206();
                case 236:
                    return Screen3.lambda207();
                case 237:
                    return Screen3.lambda208();
                case 238:
                    return Screen3.lambda209();
                case 239:
                    return Screen3.lambda210();
                case 240:
                    return Screen3.lambda211();
                case LispEscapeFormat.ESCAPE_NORMAL:
                    return Screen3.lambda212();
                case LispEscapeFormat.ESCAPE_ALL:
                    return Screen3.lambda213();
                case 243:
                    return Screen3.lambda214();
                case 244:
                    return Screen3.lambda215();
                case 245:
                    return Screen3.lambda216();
                case 246:
                    return Screen3.lambda217();
                case 247:
                    return Screen3.lambda218();
                case ComponentConstants.LISTVIEW_PREFERRED_WIDTH:
                    return Screen3.lambda219();
                case 249:
                    return Screen3.lambda220();
                case ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION:
                    return Screen3.lambda221();
                case Telnet.WILL:
                    return Screen3.lambda222();
                case Telnet.WONT:
                    return Screen3.lambda223();
                case Telnet.f261DO:
                    return Screen3.lambda224();
                case Telnet.DONT:
                    return Screen3.lambda225();
                case 255:
                    return Screen3.lambda226();
                case 256:
                    return Screen3.lambda227();
                case InputDeviceCompat.SOURCE_KEYBOARD:
                    return Screen3.lambda228();
                case 258:
                    return Screen3.lambda229();
                case 259:
                    return Screen3.lambda230();
                case 260:
                    return Screen3.lambda231();
                case 261:
                    return Screen3.lambda232();
                case 262:
                    return Screen3.lambda233();
                case 263:
                    return Screen3.lambda234();
                case 264:
                    return Screen3.lambda235();
                case 265:
                    return Screen3.lambda236();
                case 266:
                    return Screen3.lambda237();
                case 267:
                    return Screen3.lambda238();
                case 268:
                    return Screen3.lambda239();
                case 269:
                    return Screen3.lambda240();
                case 271:
                    return Screen3.lambda241();
                case 272:
                    return Screen3.lambda242();
                case 273:
                    return Screen3.lambda243();
                case 274:
                    return Screen3.lambda244();
                case 276:
                    return Screen3.lambda245();
                case 277:
                    return Screen3.lambda246();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 20:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 23:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 24:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 30:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 31:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 32:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 33:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 34:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 35:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 36:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 37:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 38:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 39:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 40:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 41:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 42:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 43:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 44:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 45:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 46:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 47:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 48:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 49:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 50:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 51:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 52:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 53:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 54:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 55:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 56:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 57:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 58:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 59:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 60:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 61:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 62:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 63:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 64:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 65:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 66:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 67:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 68:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 69:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 70:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 71:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 72:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 73:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 74:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 75:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 76:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 77:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 78:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 79:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 80:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 81:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 82:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 83:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 84:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 85:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 86:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 87:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 88:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 89:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 90:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 91:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 92:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 93:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 94:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 95:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 96:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 97:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 98:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 99:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 100:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 101:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 102:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 103:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 104:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 105:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 106:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 107:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 108:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 109:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 110:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 111:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 112:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 113:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 114:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 115:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 116:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 117:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 118:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 119:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 120:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 121:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 122:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 123:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 124:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case ErrorLogHelper.MAX_PROPERTY_ITEM_LENGTH /*125*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 126:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 127:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 128:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 129:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 130:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 131:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 132:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 133:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 134:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 135:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 136:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 137:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 138:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 139:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 140:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 141:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 142:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 143:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 144:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 145:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 146:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 147:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 148:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 149:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 150:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 151:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 152:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 153:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 154:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 155:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 156:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 157:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 159:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case ComponentConstants.TEXTBOX_PREFERRED_WIDTH:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 161:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 162:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 163:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 164:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 165:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 166:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 167:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 168:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 169:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 170:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 171:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 172:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 173:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 174:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 175:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 176:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 177:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 178:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 179:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 180:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 181:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 182:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 183:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 184:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 185:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 186:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 187:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 188:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_DIALOG_FLAG:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SEEK:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PLAY:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PAUSE:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_STOP:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_SOURCE:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_FULLSCREEN:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_DURATION:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 197:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 198:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 199:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 200:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 201:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 202:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_NON_AUTHORITATIVE_INFORMATION /*203*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_NO_CONTENT /*204*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_RESET_CONTENT /*205*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_PARTIAL_CONTENT /*206*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case HttpStatus.SC_MULTI_STATUS /*207*/:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 208:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 209:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 210:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 211:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 212:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 213:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 214:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 215:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 216:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 217:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 218:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 219:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 220:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 221:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 222:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 223:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 224:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 225:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 226:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case YaVersion.YOUNG_ANDROID_VERSION:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 228:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 229:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 230:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 231:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 232:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 233:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 234:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 235:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 236:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 237:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 238:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 239:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 240:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case LispEscapeFormat.ESCAPE_NORMAL:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case LispEscapeFormat.ESCAPE_ALL:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 243:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 244:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 245:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 246:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 247:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case ComponentConstants.LISTVIEW_PREFERRED_WIDTH:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 249:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case Telnet.WILL:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case Telnet.WONT:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case Telnet.f261DO:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case Telnet.DONT:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 255:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 256:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case InputDeviceCompat.SOURCE_KEYBOARD:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 258:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 259:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 260:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 261:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 262:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 263:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 264:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 265:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 266:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 267:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 268:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 269:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 271:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 272:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 273:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 274:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 276:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 277:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Screen3)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 158:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Screen3)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof Screen3)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 270:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 275:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            Throwable th;
            Throwable th2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th3 = th2;
                        new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw th3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th4 = th;
                        new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw th4;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                case 158:
                    return this.$main.List_Picker1$AfterPicking(obj2);
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            Throwable th6;
            Throwable th7;
            Throwable th8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    Throwable th9 = th8;
                                    new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw th9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                Throwable th10 = th7;
                                new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw th10;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            Throwable th11 = th6;
                            new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw th11;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        Throwable th12 = th5;
                        new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw th12;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    Throwable th13 = th4;
                                    new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw th13;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                Throwable th14 = th3;
                                new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw th14;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            Throwable th15 = th2;
                            new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw th15;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        Throwable th16 = th;
                        new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw th16;
                    }
                case 270:
                    return this.$main.Web1$GotText(obj5, obj6, obj7, obj8);
                case 275:
                    return this.$main.Web3$GotText(obj5, obj6, obj7, obj8);
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th4 = th3;
                        new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw th4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th2;
                        new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw th5;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        Throwable th6 = th;
                        new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw th6;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }
    }

    static Object lambda7() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit9, Boolean.TRUE, Lit10);
        SimpleSymbol simpleSymbol = Lit11;
        SimpleSymbol simpleSymbol2 = Lit12;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit8));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.FALSE);
        Object callComponentMethod = C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit13);
        return C1241runtime.callComponentMethod(Lit11, Lit14, LList.Empty, LList.Empty);
    }

    static Procedure lambda8() {
        return lambda$Fn8;
    }

    static Object lambda9() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit9, Boolean.TRUE, Lit10);
        SimpleSymbol simpleSymbol = Lit11;
        SimpleSymbol simpleSymbol2 = Lit12;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit8));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.FALSE);
        Object callComponentMethod = C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit15);
        return C1241runtime.callComponentMethod(Lit11, Lit14, LList.Empty, LList.Empty);
    }

    static Object lambda10() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit17, Lit18, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit19, "join"), Lit20);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit17, Lit21, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.list2(C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.list2("x-rapidapi-host", "covid-193.p.rapidapi.com"), Lit22, "make a list"), C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.list2("x-rapidapi-key", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit23, "make a list")), Lit24, "make a list"), Lit25);
        return C1241runtime.callComponentMethod(Lit17, Lit26, LList.Empty, LList.Empty);
    }

    static Procedure lambda11() {
        return lambda$Fn11;
    }

    static Object lambda12() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit17, Lit18, C1241runtime.callYailPrimitive(strings.string$Mnappend, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, C1241runtime.$Stthe$Mnnull$Mnvalue$St), C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit4, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit27, "join"), Lit20);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit17, Lit21, C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.list2(C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.list2("x-rapidapi-host", "covid-193.p.rapidapi.com"), Lit28, "make a list"), C1241runtime.callYailPrimitive(C1241runtime.make$Mnyail$Mnlist, LList.list2("x-rapidapi-key", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit6, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit29, "make a list")), Lit30, "make a list"), Lit25);
        return C1241runtime.callComponentMethod(Lit17, Lit26, LList.Empty, LList.Empty);
    }

    static IntNum lambda13() {
        return Lit32;
    }

    static Object lambda14() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit33, Lit34, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit38, "6193580781600768", Lit20);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit39, "COVID-19", Lit20);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit40, Lit41, Lit35);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit42, Lit43, Lit35);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit44, AlgorithmIdentifiers.NONE, Lit20);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit45, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit46, "Screen1", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit47, Boolean.FALSE, Lit10);
    }

    public Object Screen1$Initialize() {
        C1241runtime.setThisForm();
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit48, Lit26, LList.Empty, LList.Empty);
        Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit49, Lit50, LList.list2(C1241runtime.lookupInCurrentFormEnvironment(Lit51), "virus-scan.png"), Lit52);
        return C1241runtime.callComponentMethod(Lit49, Lit50, LList.list2(C1241runtime.lookupInCurrentFormEnvironment(Lit53), "updatedgreen.png"), Lit54);
    }

    public Object Screen1$BackPressed() {
        Object obj;
        C1241runtime.setThisForm();
        Object[] objArr = new Object[2];
        objArr[0] = lambda$Fn14;
        Object[] objArr2 = objArr;
        objArr2[1] = lambda$Fn15;
        if (C1241runtime.processOrDelayed$V(objArr2) != Boolean.FALSE) {
            Object callYailPrimitive = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("home"), Lit60, "open another screen");
        }
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.get$Mnproperty.apply2(Lit61, Lit9), Boolean.TRUE), Lit62, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit9, Boolean.TRUE, Lit10);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.FALSE, Lit10);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit9, Boolean.TRUE, Lit10);
        }
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.get$Mnproperty.apply2(Lit64, Lit9), Boolean.TRUE), Lit65, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.TRUE, Lit10);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit9, Boolean.FALSE, Lit10);
        }
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.get$Mnproperty.apply2(Lit66, Lit9), Boolean.TRUE), Lit67, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.TRUE, Lit10);
            obj = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit9, Boolean.FALSE, Lit10);
        } else {
            obj = Values.empty;
        }
        return obj;
    }

    static Object lambda15() {
        return C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.get$Mnproperty.apply2(Lit57, Lit9), Boolean.TRUE), Lit58, "=");
    }

    static Object lambda16() {
        return C1241runtime.get$Mnproperty.apply2(Lit59, Lit9);
    }

    static Object lambda17() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda18() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda19() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit78, Lit79, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit72, Lit80, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda20() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit78, Lit79, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit72, Lit80, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit77, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda21() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit88, "New:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit89, Lit90, Lit35);
    }

    static Object lambda22() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit88, "New:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit89, Lit90, Lit35);
    }

    static Object lambda23() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit89, Lit90, Lit35);
    }

    static Object lambda24() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit89, Lit90, Lit35);
    }

    static Object lambda25() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit78, Lit98, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit72, Lit99, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda26() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit78, Lit98, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit72, Lit99, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit97, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda27() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit88, "Total:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit89, Lit90, Lit35);
    }

    static Object lambda28() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit88, "Total:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit102, Lit89, Lit90, Lit35);
    }

    static Object lambda29() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit89, Lit90, Lit35);
    }

    static Object lambda30() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit89, Lit90, Lit35);
    }

    static Object lambda31() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit78, Lit108, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda32() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit78, Lit108, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda33() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit78, Lit112, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit72, Lit113, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda34() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit78, Lit112, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit72, Lit113, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit111, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda35() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit88, "New:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit89, Lit90, Lit35);
    }

    static Object lambda36() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit88, "New:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit89, Lit90, Lit35);
    }

    static Object lambda37() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit89, Lit90, Lit35);
    }

    static Object lambda38() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit89, Lit90, Lit35);
    }

    static Object lambda39() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit78, Lit123, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit72, Lit124, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda40() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit78, Lit123, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit72, Lit124, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit122, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda41() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit88, "Active:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit89, Lit90, Lit35);
    }

    static Object lambda42() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit88, "Active:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit127, Lit89, Lit90, Lit35);
    }

    static Object lambda43() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit89, Lit90, Lit35);
    }

    static Object lambda44() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit89, Lit90, Lit35);
    }

    static Object lambda45() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit78, Lit134, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit72, Lit135, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda46() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit78, Lit134, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit72, Lit135, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit133, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda47() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit88, "Critical:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit89, Lit90, Lit35);
    }

    static Object lambda48() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit88, "Critical:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit138, Lit89, Lit90, Lit35);
    }

    static Object lambda49() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit89, Lit90, Lit35);
    }

    static Object lambda50() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit89, Lit90, Lit35);
    }

    static Object lambda51() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit78, Lit145, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit72, Lit146, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda52() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit78, Lit145, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit72, Lit146, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit144, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda53() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit89, Lit90, Lit35);
    }

    static Object lambda54() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit149, Lit89, Lit90, Lit35);
    }

    static Object lambda55() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit89, Lit90, Lit35);
    }

    static Object lambda56() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit89, Lit90, Lit35);
    }

    static Object lambda57() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit78, Lit156, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit72, Lit157, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda58() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit78, Lit156, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit72, Lit157, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit155, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda59() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit88, "Total:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit89, Lit90, Lit35);
    }

    static Object lambda60() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit88, "Total:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit160, Lit89, Lit90, Lit35);
    }

    static Object lambda61() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit89, Lit90, Lit35);
    }

    static Object lambda62() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit86, Lit94, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit89, Lit90, Lit35);
    }

    static Object lambda63() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit36, Lit32, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit78, Lit166, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda64() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit36, Lit32, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit78, Lit166, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda65() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit78, Lit170, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit72, Lit171, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda66() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit78, Lit170, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit72, Lit171, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit169, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda67() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit88, "Cases:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit89, Lit90, Lit35);
    }

    static Object lambda68() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit88, "Cases:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit174, Lit89, Lit90, Lit35);
    }

    static Object lambda69() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit89, Lit90, Lit35);
    }

    static Object lambda70() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit89, Lit90, Lit35);
    }

    static Object lambda71() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit78, Lit182, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit88, "fullscreen", Lit20);
    }

    static Object lambda72() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit78, Lit182, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit181, Lit88, "fullscreen", Lit20);
    }

    public Object cases_description_btn$Click() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.FALSE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit64, Lit9, Boolean.TRUE, Lit10);
    }

    static Object lambda73() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit78, Lit193, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit72, Lit194, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda74() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit78, Lit193, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit72, Lit194, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit192, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda75() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit88, "Deaths:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit89, Lit90, Lit35);
    }

    static Object lambda76() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit88, "Deaths:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit197, Lit89, Lit90, Lit35);
    }

    static Object lambda77() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit89, Lit90, Lit35);
    }

    static Object lambda78() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit89, Lit90, Lit35);
    }

    static Object lambda79() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit78, Lit204, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit88, "fullscreen", Lit20);
    }

    static Object lambda80() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit78, Lit204, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit203, Lit88, "fullscreen", Lit20);
    }

    public Object deaths_description_btn$Click() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit66, Lit9, Boolean.TRUE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda81() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit78, Lit212, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit72, Lit213, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda82() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit78, Lit212, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit72, Lit213, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit211, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda83() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit89, Lit90, Lit35);
    }

    static Object lambda84() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit216, Lit89, Lit90, Lit35);
    }

    static Object lambda85() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit89, Lit90, Lit35);
    }

    static Object lambda86() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit89, Lit90, Lit35);
    }

    static Object lambda87() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit78, Lit226, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit72, Lit227, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda88() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit78, Lit226, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit72, Lit227, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit225, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda89() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit88, "Tests:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit89, Lit90, Lit35);
    }

    static Object lambda90() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit88, "Tests:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit230, Lit89, Lit90, Lit35);
    }

    static Object lambda91() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit89, Lit90, Lit35);
    }

    static Object lambda92() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit89, Lit90, Lit35);
    }

    static Object lambda93() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit72, Lit236, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit74, Lit237, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda94() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit72, Lit236, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit74, Lit237, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit8, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda95() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit241, Lit242, Lit35);
    }

    static Object lambda96() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit240, Lit241, Lit242, Lit35);
    }

    static Object lambda97() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit245, Lit72, Lit246, Lit35);
    }

    static Object lambda98() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit245, Lit72, Lit246, Lit35);
    }

    static Object lambda100() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit78, Lit250, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit86, Lit251, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit88, "Fetching Data", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit89, Lit90, Lit35);
    }

    static Object lambda99() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit78, Lit250, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit86, Lit251, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit88, "Fetching Data", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit249, Lit89, Lit90, Lit35);
    }

    static Object lambda101() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit78, Lit254, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit81, Boolean.TRUE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit255, Boolean.TRUE, Lit10);
    }

    static Object lambda102() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit78, Lit254, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit81, Boolean.TRUE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit255, Boolean.TRUE, Lit10);
    }

    static Object lambda103() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit258, Lit36, Lit37, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit258, Lit71, Lit32, Lit35);
    }

    static Object lambda104() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit258, Lit36, Lit37, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit258, Lit71, Lit32, Lit35);
    }

    static Object lambda105() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit51, Lit72, Lit261, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit51, Lit74, Lit262, Lit35);
    }

    static Object lambda106() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit51, Lit72, Lit261, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit51, Lit74, Lit262, Lit35);
    }

    static Object lambda107() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit74, Lit266, Lit35);
    }

    static Object lambda108() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit265, Lit74, Lit266, Lit35);
    }

    static Object lambda109() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit269, Lit88, "COV-AID TRACKER", Lit20);
    }

    static Object lambda110() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit269, Lit88, "COV-AID TRACKER", Lit20);
    }

    static Object lambda111() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit272, Lit74, Lit273, Lit35);
    }

    static Object lambda112() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit272, Lit74, Lit273, Lit35);
    }

    static Object lambda113() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit78, Lit277, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit81, Boolean.TRUE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit255, Boolean.TRUE, Lit10);
    }

    static Object lambda114() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit78, Lit277, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit81, Boolean.TRUE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit276, Lit255, Boolean.TRUE, Lit10);
    }

    static Object lambda115() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit281, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit86, Lit282, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit88, "View India", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit283, Lit284, Lit35);
    }

    static Object lambda116() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit281, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit86, Lit282, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit88, "View India", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit283, Lit284, Lit35);
    }

    public Object Label4$Click() {
        Object addGlobalVarToCurrentFormEnvironment;
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnequal$Qu, LList.list2(C1241runtime.get$Mnproperty.apply2(Lit280, Lit88), "View World"), Lit286, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit88, "View India", Lit20);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit9, Boolean.TRUE, Lit10);
            addGlobalVarToCurrentFormEnvironment = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit9, Boolean.FALSE, Lit10);
        } else {
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit280, Lit88, "View World", Lit20);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit9, Boolean.FALSE, Lit10);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit9, Boolean.TRUE, Lit10);
            Object callComponentMethod = C1241runtime.callComponentMethod(Lit287, Lit288, LList.list1("statewise"), Lit289);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("state", Lit32), Lit292), Lit20);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("active", Lit32), Lit294), Lit20);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deaths", Lit32), Lit296), Lit20);
            Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("recovered", Lit32), Lit298), Lit20);
            Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("lastupdatedtime", Lit32), Lit300), Lit20);
            addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit31, Lit32);
        }
        return addGlobalVarToCurrentFormEnvironment;
    }

    static Object lambda117() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit78, Lit303, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit72, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit74, Lit73, Lit35);
    }

    static Object lambda118() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit78, Lit303, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit72, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit74, Lit73, Lit35);
    }

    static Object lambda119() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit306, Lit72, Lit307, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit306, Lit74, Lit308, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit306, Lit309, "COV-AID_LOGO.png", Lit20);
    }

    static Object lambda120() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit306, Lit72, Lit307, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit306, Lit74, Lit308, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit306, Lit309, "COV-AID_LOGO.png", Lit20);
    }

    static Object lambda121() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit315, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit315, Lit71, Lit32, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit315, Lit78, Lit316, Lit35);
    }

    static Object lambda122() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit315, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit315, Lit71, Lit32, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit315, Lit78, Lit316, Lit35);
    }

    static Object lambda123() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit86, Lit320, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit88, "Choose Country", Lit20);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit89, Lit90, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit283, Lit321, Lit35);
    }

    static Object lambda124() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit86, Lit320, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit88, "Choose Country", Lit20);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit89, Lit90, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit319, Lit283, Lit321, Lit35);
    }

    static Object lambda125() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit72, Lit325, Lit35);
    }

    static Object lambda126() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit324, Lit72, Lit325, Lit35);
    }

    static Object lambda127() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit78, Lit329, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit330, Lit90, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit88, "Choose Country", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit283, Lit331, Lit35);
    }

    static Object lambda128() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit78, Lit329, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit330, Lit90, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit88, "Choose Country", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit328, Lit283, Lit331, Lit35);
    }

    public Object list_viewer_button$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit333, Lit334, LList.Empty, LList.Empty);
    }

    static Object lambda129() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit337, Lit72, Lit338, Lit35);
    }

    static Object lambda130() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit337, Lit72, Lit338, Lit35);
    }

    static Object lambda131() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit78, Lit342, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit183, Lit184, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit88, "send", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit283, Lit343, Lit35);
    }

    static Object lambda132() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit78, Lit342, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit183, Lit184, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit88, "send", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit341, Lit283, Lit343, Lit35);
    }

    public Object Go_btn$Click() {
        Object callComponentMethod;
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(C1241runtime.yail$Mnnot, LList.list1(C1241runtime.callYailPrimitive(C1241runtime.string$Mnempty$Qu, LList.list1(C1241runtime.get$Mnproperty.apply2(Lit333, Lit345)), Lit346, "is text empty?")), Lit347, "not") != Boolean.FALSE) {
            Object addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit4, C1241runtime.get$Mnproperty.apply2(Lit333, Lit345));
            Object apply1 = Scheme.applyToArgs.apply1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit16, C1241runtime.$Stthe$Mnnull$Mnvalue$St));
            callComponentMethod = Scheme.applyToArgs.apply1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit7, C1241runtime.$Stthe$Mnnull$Mnvalue$St));
        } else {
            callComponentMethod = C1241runtime.callComponentMethod(Lit11, Lit348, LList.list1("Choose a Country"), Lit349);
        }
        return callComponentMethod;
    }

    static Object lambda133() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit352, "Afghanistan,Africa,Albania,Algeria,All,Andorra,Angola,Anguilla,Antigua-and-Barbuda,Argentina,Armenia,Aruba,Asia,Australia,Austria,Azerbaijan,Bahamas,Bahrain,Bangladesh,Barbados,Belarus,Belgium,Belize,Benin,Bermuda,Bhutan,Bolivia,Bosnia-and-Herzegovina,Botswana,Brazil,British-Virgin-Islands,Brukina-Faso,Brunei,Bulgaria,Burundi,Cabo-Verde,Cambodia,Cameroon,Canada,CAR,Caribbean-Netherlands,Cayman-Islands,Chad,Channel-Islands,Chile,China,Colombia,Congo,Costa-Rica,Croatia,Cuba,Curaçao,Cyprus,Czechia,Denmark,Diamond-Princess,Diamond-Princess-,Dijbouti,Dominica,Dominican-Republic,DRC,Ecuador,Egypt,El-Salvador,Equatorial-Guinea,Eritrea,Estonia,Eswatini,Ethiopia,Europe,Faeroe-Islands,Falkland-Islands,Fiji,Finland,France,French-Guiana,French-Polynesia,Gabon,Gambia,Georgia,Germany,Ghana,Gibraltar,Greece,Greenland,Grenada,Guadeloupe,Guam,Guatemala,Guinea,Guinea-Bissau,Guyana,Haiti,Honduras,Hong-Kong,Hungary,Iceland,India,Indonesia,Iran,Iraq,Ireland,Isle-of-Man,Israel,Italy,Ivory-Coast,Jamaica,Japan,Jordan,Kazakhstan,Kenya,Kuwait,Kyrgyzstan,Laos,Latvia,Lebanon,Liberia,Libya,Liechtenstein,Lithuania,Luxembourg,Macao,Madagascar,Malawi,Malaysia,Maldives,Mali,Malta,Martinique,Mauritania,Mauritius,Mayotte,Mexico,Moldova,Monaco,Mongolia,Montenegro,Montserrat,Morocco,Mozambique,MS-Zaandam,MS-Zaandam-,Myanmar,Namibia,Nepal,Netherlands,New-Caledonia,New-Zealand,Nicaragua,Niger,Nigeria,North-America,North-Macedonia,Norway,Oceania,Oman,Pakistan,Palestine,Panama,Papua-New-Guinea,Paraguay,Peru,Philippines,Poland,Portugal,Puerto-Rico,Qatar,Romania,Russia,Rwanda,Réunion,S-Korea,Saint-Kitts-and-Nevis,Saint-Lucia,Saint-Martin,Saint-Pierre-Miquelon,San-Marino,Sao-Tome-and-Principe,Saudi-Arabia,Senegal,Serbia,Seychelles,Sierra-Leone,Singapore,Sint-Maarten,Slovakia,Slovenia,Somalia,South-Africa,South-America,South-Sudan,Spain,Sri-Lanka,St-Barth,St-Vincent-Grenadines,Sudan,Suriname,Sweden,Switzerland,Syria,Taiwan,Tanzania,Thailand,Timor-Leste,Togo,Trinidad-and-Tobago,Tunisia,Turkey,Turks-and-Caicos,UAE,Uganda,UK,Ukraine,Uruguay,US-Virgin-Islands,USA,Uzbekistan,Vatican-City,Venezuela,Vietnam,Western-Sahara,Yemen,Zambia,Zimbabwe", Lit20);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit353, Lit354, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit355, Lit356, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit357, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit358, Lit359, Lit35);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit88, "Choose Country", Lit20);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit360, Lit361, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda134() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit352, "Afghanistan,Africa,Albania,Algeria,All,Andorra,Angola,Anguilla,Antigua-and-Barbuda,Argentina,Armenia,Aruba,Asia,Australia,Austria,Azerbaijan,Bahamas,Bahrain,Bangladesh,Barbados,Belarus,Belgium,Belize,Benin,Bermuda,Bhutan,Bolivia,Bosnia-and-Herzegovina,Botswana,Brazil,British-Virgin-Islands,Brukina-Faso,Brunei,Bulgaria,Burundi,Cabo-Verde,Cambodia,Cameroon,Canada,CAR,Caribbean-Netherlands,Cayman-Islands,Chad,Channel-Islands,Chile,China,Colombia,Congo,Costa-Rica,Croatia,Cuba,Curaçao,Cyprus,Czechia,Denmark,Diamond-Princess,Diamond-Princess-,Dijbouti,Dominica,Dominican-Republic,DRC,Ecuador,Egypt,El-Salvador,Equatorial-Guinea,Eritrea,Estonia,Eswatini,Ethiopia,Europe,Faeroe-Islands,Falkland-Islands,Fiji,Finland,France,French-Guiana,French-Polynesia,Gabon,Gambia,Georgia,Germany,Ghana,Gibraltar,Greece,Greenland,Grenada,Guadeloupe,Guam,Guatemala,Guinea,Guinea-Bissau,Guyana,Haiti,Honduras,Hong-Kong,Hungary,Iceland,India,Indonesia,Iran,Iraq,Ireland,Isle-of-Man,Israel,Italy,Ivory-Coast,Jamaica,Japan,Jordan,Kazakhstan,Kenya,Kuwait,Kyrgyzstan,Laos,Latvia,Lebanon,Liberia,Libya,Liechtenstein,Lithuania,Luxembourg,Macao,Madagascar,Malawi,Malaysia,Maldives,Mali,Malta,Martinique,Mauritania,Mauritius,Mayotte,Mexico,Moldova,Monaco,Mongolia,Montenegro,Montserrat,Morocco,Mozambique,MS-Zaandam,MS-Zaandam-,Myanmar,Namibia,Nepal,Netherlands,New-Caledonia,New-Zealand,Nicaragua,Niger,Nigeria,North-America,North-Macedonia,Norway,Oceania,Oman,Pakistan,Palestine,Panama,Papua-New-Guinea,Paraguay,Peru,Philippines,Poland,Portugal,Puerto-Rico,Qatar,Romania,Russia,Rwanda,Réunion,S-Korea,Saint-Kitts-and-Nevis,Saint-Lucia,Saint-Martin,Saint-Pierre-Miquelon,San-Marino,Sao-Tome-and-Principe,Saudi-Arabia,Senegal,Serbia,Seychelles,Sierra-Leone,Singapore,Sint-Maarten,Slovakia,Slovenia,Somalia,South-Africa,South-America,South-Sudan,Spain,Sri-Lanka,St-Barth,St-Vincent-Grenadines,Sudan,Suriname,Sweden,Switzerland,Syria,Taiwan,Tanzania,Thailand,Timor-Leste,Togo,Trinidad-and-Tobago,Tunisia,Turkey,Turks-and-Caicos,UAE,Uganda,UK,Ukraine,Uruguay,US-Virgin-Islands,USA,Uzbekistan,Vatican-City,Venezuela,Vietnam,Western-Sahara,Yemen,Zambia,Zimbabwe", Lit20);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit353, Lit354, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit355, Lit356, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit357, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit358, Lit359, Lit35);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit88, "Choose Country", Lit20);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit360, Lit361, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit333, Lit9, Boolean.FALSE, Lit10);
    }

    public Object List_Picker1$AfterPicking(Object $selection) {
        Object obj;
        Object $selection2 = C1241runtime.sanitizeComponentData($selection);
        C1241runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit328;
        SimpleSymbol simpleSymbol2 = Lit88;
        if ($selection2 instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit363);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj = $selection2;
        }
        return C1241runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, obj, Lit20);
    }

    static Object lambda135() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit78, Lit367, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda136() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit78, Lit367, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit59, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda137() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit88, "STATE", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit283, Lit370, Lit35);
    }

    static Object lambda138() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit88, "STATE", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit283, Lit370, Lit35);
    }

    static Object lambda139() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit36, Lit32, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit78, Lit377, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit72, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit74, Lit73, Lit35);
    }

    static Object lambda140() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit36, Lit32, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit78, Lit377, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit72, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit376, Lit74, Lit73, Lit35);
    }

    static Object lambda141() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit78, Lit381, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit72, Lit382, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda142() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit78, Lit381, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit72, Lit382, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit380, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda143() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit88, "Cases:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit89, Lit90, Lit35);
    }

    static Object lambda144() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit88, "Cases:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit385, Lit89, Lit90, Lit35);
    }

    static Object lambda145() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit89, Lit90, Lit35);
    }

    static Object lambda146() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit89, Lit90, Lit35);
    }

    static Object lambda147() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit78, Lit391, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit88, "fullscreen", Lit20);
    }

    static Object lambda148() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit78, Lit391, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit390, Lit88, "fullscreen", Lit20);
    }

    public Object cases_description_btn_copy$Click() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit9, Boolean.TRUE, Lit10);
        SimpleSymbol simpleSymbol = Lit394;
        SimpleSymbol simpleSymbol2 = Lit12;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit393));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.FALSE);
        Object callComponentMethod = C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit395);
        Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit287, Lit288, LList.list1("statewise"), Lit396);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("state", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit398), Lit20);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("active", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit400), Lit20);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("confirmed", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit402), Lit20);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deaths", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit404), Lit20);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deltaconfirmed", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit406), Lit20);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deltadeaths", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit408), Lit20);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("recovered", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit410), Lit20);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deltarecovered", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit412), Lit20);
        Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("lastupdatedtime", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit414), Lit20);
        return C1241runtime.callComponentMethod(Lit394, Lit14, LList.Empty, LList.Empty);
    }

    static Object lambda149() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit78, Lit421, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit72, Lit422, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda150() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit78, Lit421, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit72, Lit422, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit420, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda151() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit88, "Deaths:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit89, Lit90, Lit35);
    }

    static Object lambda152() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit88, "Deaths:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit425, Lit89, Lit90, Lit35);
    }

    static Object lambda153() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit89, Lit90, Lit35);
    }

    static Object lambda154() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit89, Lit90, Lit35);
    }

    static Object lambda155() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit78, Lit431, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit88, "fullscreen", Lit20);
    }

    static Object lambda156() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit78, Lit431, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit430, Lit88, "fullscreen", Lit20);
    }

    public Object deaths_description_btn_copy$Click() {
        C1241runtime.setThisForm();
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit9, Boolean.TRUE, Lit10);
        SimpleSymbol simpleSymbol = Lit394;
        SimpleSymbol simpleSymbol2 = Lit12;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit393));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.FALSE);
        Object callComponentMethod = C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit433);
        Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit287, Lit288, LList.list1("statewise"), Lit434);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("state", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit435), Lit20);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("active", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit436), Lit20);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("confirmed", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit437), Lit20);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deaths", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit438), Lit20);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deltaconfirmed", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit439), Lit20);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deltadeaths", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit440), Lit20);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("recovered", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit441), Lit20);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deltarecovered", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit442), Lit20);
        Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("lastupdatedtime", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit443), Lit20);
        return C1241runtime.callComponentMethod(Lit394, Lit14, LList.Empty, LList.Empty);
    }

    static Object lambda157() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit78, Lit450, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit72, Lit451, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda158() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit78, Lit450, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit72, Lit451, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit449, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda159() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit89, Lit90, Lit35);
    }

    static Object lambda160() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit454, Lit89, Lit90, Lit35);
    }

    static Object lambda161() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit89, Lit90, Lit35);
    }

    static Object lambda162() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit89, Lit90, Lit35);
    }

    static Object lambda163() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit78, Lit463, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit72, Lit464, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda164() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit78, Lit463, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit72, Lit464, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit462, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda165() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit88, "Updated On:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit89, Lit90, Lit35);
    }

    static Object lambda166() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit88, "Updated On:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit467, Lit89, Lit90, Lit35);
    }

    static Object lambda167() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit89, Lit90, Lit35);
    }

    static Object lambda168() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit89, Lit90, Lit35);
    }

    static Object lambda169() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit78, Lit476, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit88, "navigate_before", Lit20);
    }

    static Object lambda170() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit78, Lit476, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit475, Lit88, "navigate_before", Lit20);
    }

    public Object Button1_copy$Click() {
        Object andCoerceProperty$Ex;
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(Scheme.numGEq, LList.list2(Lit32, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit478, ">=") != Boolean.FALSE) {
            andCoerceProperty$Ex = C1241runtime.callComponentMethod(Lit479, Lit480, LList.list1("End Of Indian States and Union Territories."), Lit481);
        } else {
            Object addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit31, C1241runtime.callYailPrimitive(AddOp.$Mn, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit90), Lit482, "-"));
            Object callComponentMethod = C1241runtime.callComponentMethod(Lit287, Lit288, LList.list1("statewise"), Lit483);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("state", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit484), Lit20);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("active", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit485), Lit20);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deaths", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit486), Lit20);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("recovered", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit487), Lit20);
            andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("lastupdatedtime", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit488), Lit20);
        }
        return andCoerceProperty$Ex;
    }

    static Object lambda171() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit491, Lit74, Lit492, Lit35);
    }

    static Object lambda172() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit491, Lit74, Lit492, Lit35);
    }

    static Object lambda173() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit78, Lit496, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit88, "navigate_next", Lit20);
    }

    static Object lambda174() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit78, Lit496, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit183, Lit184, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit495, Lit88, "navigate_next", Lit20);
    }

    public Object Button1$Click() {
        Object andCoerceProperty$Ex;
        C1241runtime.setThisForm();
        if (C1241runtime.callYailPrimitive(Scheme.numLEq, LList.list2(Lit498, C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit499, "<=") != Boolean.FALSE) {
            andCoerceProperty$Ex = C1241runtime.callComponentMethod(Lit479, Lit480, LList.list1("End Of Indian States and Union Territories."), Lit500);
        } else {
            Object addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(Lit31, C1241runtime.callYailPrimitive(AddOp.$Pl, LList.list2(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St), Lit90), Lit501, Marker.ANY_NON_NULL_MARKER));
            Object callComponentMethod = C1241runtime.callComponentMethod(Lit287, Lit288, LList.list1("statewise"), Lit502);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit290, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("state", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit503), Lit20);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit293, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("active", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit504), Lit20);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit295, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("deaths", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit505), Lit20);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit297, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("recovered", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit506), Lit20);
            andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit299, Lit88, C1241runtime.callComponentMethod(Lit287, Lit291, LList.list2("lastupdatedtime", C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit31, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit507), Lit20);
        }
        return andCoerceProperty$Ex;
    }

    static Object lambda175() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit78, Lit510, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda176() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit78, Lit510, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit72, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit393, Lit9, Boolean.FALSE, Lit10);
    }

    static Object lambda177() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit513, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit513, Lit71, Lit32, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit513, Lit74, Lit73, Lit35);
    }

    static Object lambda178() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit513, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit513, Lit71, Lit32, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit513, Lit74, Lit73, Lit35);
    }

    static Object lambda179() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit88, "State", Lit20);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit89, Lit90, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit283, Lit516, Lit35);
    }

    static Object lambda180() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit88, "State", Lit20);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit89, Lit90, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit397, Lit283, Lit516, Lit35);
    }

    static Object lambda181() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit78, Lit520, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit183, Lit184, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit88, "close", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit283, Lit521, Lit35);
    }

    static Object lambda182() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit78, Lit520, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit86, Lit87, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit183, Lit184, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit88, "close", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit519, Lit283, Lit521, Lit35);
    }

    public Object Button2$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit394, Lit523, LList.Empty, LList.Empty);
    }

    static Object lambda183() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit78, Lit530, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit72, Lit531, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda184() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit78, Lit530, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit72, Lit531, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit529, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda185() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit88, "Active:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit89, Lit90, Lit35);
    }

    static Object lambda186() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit88, "Active:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit534, Lit89, Lit90, Lit35);
    }

    static Object lambda187() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit89, Lit90, Lit35);
    }

    static Object lambda188() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit399, Lit89, Lit90, Lit35);
    }

    static Object lambda189() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit78, Lit543, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit72, Lit544, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda190() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit78, Lit543, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit72, Lit544, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit542, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda191() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit88, "Confirmed:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit89, Lit90, Lit35);
    }

    static Object lambda192() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit88, "Confirmed:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit547, Lit89, Lit90, Lit35);
    }

    static Object lambda193() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit89, Lit90, Lit35);
    }

    static Object lambda194() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit401, Lit89, Lit90, Lit35);
    }

    static Object lambda195() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit78, Lit556, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit72, Lit557, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda196() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit78, Lit556, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit72, Lit557, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit555, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda197() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit88, "Deaths:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit89, Lit90, Lit35);
    }

    static Object lambda198() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit88, "Deaths:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit560, Lit89, Lit90, Lit35);
    }

    static Object lambda199() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit89, Lit90, Lit35);
    }

    static Object lambda200() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit403, Lit89, Lit90, Lit35);
    }

    static Object lambda201() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit78, Lit569, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit72, Lit570, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda202() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit78, Lit569, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit72, Lit570, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit568, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda203() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit88, "Confirmed (New):", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit89, Lit90, Lit35);
    }

    static Object lambda204() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit88, "Confirmed (New):", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit573, Lit89, Lit90, Lit35);
    }

    static Object lambda205() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit89, Lit90, Lit35);
    }

    static Object lambda206() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit405, Lit89, Lit90, Lit35);
    }

    static Object lambda207() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit78, Lit582, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit72, Lit583, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda208() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit78, Lit582, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit72, Lit583, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit581, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda209() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit88, "Deaths (New):", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit89, Lit90, Lit35);
    }

    static Object lambda210() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit88, "Deaths (New):", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit586, Lit89, Lit90, Lit35);
    }

    static Object lambda211() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit89, Lit90, Lit35);
    }

    static Object lambda212() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit407, Lit89, Lit90, Lit35);
    }

    static Object lambda213() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit78, Lit595, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit72, Lit596, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda214() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit78, Lit595, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit72, Lit596, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit594, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda215() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit89, Lit90, Lit35);
    }

    static Object lambda216() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit88, "Recovered:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit599, Lit89, Lit90, Lit35);
    }

    static Object lambda217() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit89, Lit90, Lit35);
    }

    static Object lambda218() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit409, Lit89, Lit90, Lit35);
    }

    static Object lambda219() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit78, Lit608, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit72, Lit609, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda220() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit78, Lit608, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit72, Lit609, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit607, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda221() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit88, "Recovered (New):", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit89, Lit90, Lit35);
    }

    static Object lambda222() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit88, "Recovered (New):", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit612, Lit89, Lit90, Lit35);
    }

    static Object lambda223() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit89, Lit90, Lit35);
    }

    static Object lambda224() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit411, Lit89, Lit90, Lit35);
    }

    static Object lambda225() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit78, Lit621, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit72, Lit622, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda226() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit78, Lit621, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit72, Lit622, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit74, Lit73, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit620, Lit81, Boolean.TRUE, Lit10);
    }

    static Object lambda227() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit88, "Last Updated:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit89, Lit90, Lit35);
    }

    static Object lambda228() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit85, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit88, "Last Updated:", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit625, Lit89, Lit90, Lit35);
    }

    static Object lambda229() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit89, Lit90, Lit35);
    }

    static Object lambda230() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit86, Lit175, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit88, "0", Lit20);
        return C1241runtime.setAndCoerceProperty$Ex(Lit413, Lit89, Lit90, Lit35);
    }

    static Object lambda231() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit78, Lit631, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit81, Boolean.TRUE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit255, Boolean.TRUE, Lit10);
    }

    static Object lambda232() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit36, Lit37, Lit35);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit71, Lit32, Lit35);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit78, Lit631, Lit35);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit74, Lit73, Lit35);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit81, Boolean.TRUE, Lit10);
        return C1241runtime.setAndCoerceProperty$Ex(Lit630, Lit255, Boolean.TRUE, Lit10);
    }

    static Object lambda233() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit634, Lit36, Lit37, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit634, Lit71, Lit32, Lit35);
    }

    static Object lambda234() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit634, Lit36, Lit37, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit634, Lit71, Lit32, Lit35);
    }

    static Object lambda235() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit72, Lit637, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit74, Lit638, Lit35);
    }

    static Object lambda236() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit72, Lit637, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit53, Lit74, Lit638, Lit35);
    }

    static Object lambda237() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit641, Lit74, Lit642, Lit35);
    }

    static Object lambda238() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit641, Lit74, Lit642, Lit35);
    }

    static Object lambda239() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit645, Lit86, Lit646, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit645, Lit88, "Real Time Updated Statistics", Lit20);
    }

    static Object lambda240() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit645, Lit86, Lit646, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit645, Lit88, "Real Time Updated Statistics", Lit20);
    }

    public Object Web1$GotText(Object $url, Object $responseCode, Object $responseType, Object $responseContent) {
        Object obj;
        Object obj2;
        Object obj3;
        Object sanitizeComponentData = C1241runtime.sanitizeComponentData($url);
        Object sanitizeComponentData2 = C1241runtime.sanitizeComponentData($responseCode);
        Object sanitizeComponentData3 = C1241runtime.sanitizeComponentData($responseType);
        Object $responseContent2 = C1241runtime.sanitizeComponentData($responseContent);
        Object $responseCode2 = sanitizeComponentData2;
        C1241runtime.setThisForm();
        ModuleMethod moduleMethod = C1241runtime.yail$Mnequal$Qu;
        if ($responseCode2 instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit650);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj = $responseCode2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod, LList.list2(obj, Lit651), Lit652, "=") != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit61, Lit9, Boolean.TRUE, Lit10);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit57, Lit9, Boolean.FALSE, Lit10);
            Object callComponentMethod = C1241runtime.callComponentMethod(Lit11, Lit523, LList.Empty, LList.Empty);
            SimpleSymbol simpleSymbol = Lit5;
            if ($responseContent2 instanceof Package) {
                Object[] objArr4 = new Object[3];
                objArr4[0] = "The variable ";
                Object[] objArr5 = objArr4;
                objArr5[1] = C1241runtime.getDisplayRepresentation(Lit653);
                Object[] objArr6 = objArr5;
                objArr6[2] = " is not bound in the current context";
                obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
            } else {
                obj3 = $responseContent2;
            }
            Object addGlobalVarToCurrentFormEnvironment = C1241runtime.addGlobalVarToCurrentFormEnvironment(simpleSymbol, obj3);
            Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit5, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit656);
            Object callComponentMethod3 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("response"), Lit658)), Lit659);
            Object callComponentMethod4 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("cases"), Lit660)), Lit661);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit178, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("total"), Lit662), Lit20);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit219, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("recovered"), Lit663), Lit20);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit119, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("new"), Lit664), Lit20);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit130, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("active"), Lit665), Lit20);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit141, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("critical"), Lit666), Lit20);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit152, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("recovered"), Lit667), Lit20);
            Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit163, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("total"), Lit668), Lit20);
            Object callComponentMethod5 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit5, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit669);
            Object callComponentMethod6 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("response"), Lit670)), Lit671);
            Object callComponentMethod7 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("deaths"), Lit672)), Lit673);
            Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit200, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("total"), Lit674), Lit20);
            Object andCoerceProperty$Ex11 = C1241runtime.setAndCoerceProperty$Ex(Lit93, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("new"), Lit675), Lit20);
            Object andCoerceProperty$Ex12 = C1241runtime.setAndCoerceProperty$Ex(Lit105, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("total"), Lit676), Lit20);
            Object callComponentMethod8 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.lookupGlobalVarInCurrentFormEnvironment(Lit5, C1241runtime.$Stthe$Mnnull$Mnvalue$St)), Lit677);
            Object callComponentMethod9 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("response"), Lit678)), Lit679);
            Object callComponentMethod10 = C1241runtime.callComponentMethod(Lit654, Lit655, LList.list1(C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("tests"), Lit680)), Lit681);
            Object andCoerceProperty$Ex13 = C1241runtime.setAndCoerceProperty$Ex(Lit233, Lit88, C1241runtime.callComponentMethod(Lit654, Lit657, LList.list1("total"), Lit682), Lit20);
            obj2 = C1241runtime.setAndCoerceProperty$Ex(Lit63, Lit9, Boolean.FALSE, Lit10);
        } else {
            obj2 = Values.empty;
        }
        return obj2;
    }

    static Object lambda241() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit11, Lit78, Lit686, Lit35);
    }

    static Object lambda242() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit11, Lit78, Lit686, Lit35);
    }

    static Object lambda243() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit18, "https://api.covid19india.org/data.json", Lit20);
    }

    static Object lambda244() {
        return C1241runtime.setAndCoerceProperty$Ex(Lit48, Lit18, "https://api.covid19india.org/data.json", Lit20);
    }

    public Object Web3$GotText(Object $url, Object $responseCode, Object $responseType, Object $responseContent) {
        Object obj;
        Object sanitizeComponentData = C1241runtime.sanitizeComponentData($url);
        Object sanitizeComponentData2 = C1241runtime.sanitizeComponentData($responseCode);
        Object sanitizeComponentData3 = C1241runtime.sanitizeComponentData($responseType);
        Object $responseContent2 = C1241runtime.sanitizeComponentData($responseContent);
        C1241runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit287;
        SimpleSymbol simpleSymbol2 = Lit655;
        if ($responseContent2 instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit653);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj = $responseContent2;
        }
        return C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, LList.list1(obj), Lit700);
    }

    static Object lambda245() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit479, Lit78, Lit707, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit479, Lit283, Lit708, Lit35);
    }

    static Object lambda246() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit479, Lit78, Lit707, Lit35);
        return C1241runtime.setAndCoerceProperty$Ex(Lit479, Lit283, Lit708, Lit35);
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.form$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name = symbol;
        Object default$Mnvalue = obj;
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & true;
        if (!x ? !x : !this.form$Mnenvironment.isBound(name)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = C1271lists.cons(C1271lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = C1271lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = C1271lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = C1271lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        Object obj = error;
        RetValManager.sendError(obj == null ? null : obj.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        objArr2[0] = "any$";
        Object[] objArr3 = objArr2;
        objArr3[1] = getSimpleName(componentObject);
        Object[] objArr4 = objArr3;
        objArr4[2] = "$";
        Object[] objArr5 = objArr4;
        objArr5[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr5)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1271lists.cons(component2, C1271lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object componentName, Object obj) {
        Object eventName = obj;
        Object obj2 = componentName;
        String obj3 = obj2 == null ? null : obj2.toString();
        Object obj4 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj3, obj4 == null ? null : obj4.toString())));
    }

    public void $define() {
        Object obj;
        Throwable th;
        Object obj2;
        Throwable th2;
        Object obj3;
        Throwable th3;
        Object obj4;
        Throwable th4;
        Object obj5;
        Throwable th5;
        Object obj6;
        Throwable th6;
        Object obj7;
        Throwable th7;
        Object obj8;
        Throwable th8;
        Throwable th9;
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception e) {
            Exception exception = e;
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        Screen1 = this;
        addToFormEnvironment(Lit0, this);
        Object obj9 = this.events$Mnto$Mnregister;
        while (true) {
            Object obj10 = obj9;
            if (obj10 == LList.Empty) {
                break;
            }
            Object obj11 = obj10;
            Object obj12 = obj11;
            try {
                Pair arg0 = (Pair) obj11;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = C1271lists.car.apply1(event$Mninfo);
                String obj13 = apply1 == null ? null : apply1.toString();
                Object apply12 = C1271lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj13, apply12 == null ? null : apply12.toString());
                obj9 = arg0.getCdr();
            } catch (ClassCastException e2) {
                ClassCastException classCastException = e2;
                Throwable th10 = th9;
                new WrongType(classCastException, "arg0", -2, obj12);
                throw th10;
            }
        }
        try {
            LList components = C1271lists.reverse(this.components$Mnto$Mncreate);
            addToGlobalVars(Lit2, lambda$Fn1);
            LList event$Mninfo2 = components;
            while (event$Mninfo2 != LList.Empty) {
                Object obj14 = event$Mninfo2;
                obj6 = obj14;
                Pair arg02 = (Pair) obj14;
                Object component$Mninfo = arg02.getCar();
                Object apply13 = C1271lists.caddr.apply1(component$Mninfo);
                Object apply14 = C1271lists.cadddr.apply1(component$Mninfo);
                Object component$Mntype = C1271lists.cadr.apply1(component$Mninfo);
                Object apply15 = C1271lists.car.apply1(component$Mninfo);
                obj7 = apply15;
                Object component$Mnname = apply13;
                Object component$Mnobject = Invoke.make.apply2(component$Mntype, lookupInFormEnvironment((Symbol) apply15));
                Object apply3 = SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
                Object obj15 = component$Mnname;
                obj8 = obj15;
                addToFormEnvironment((Symbol) obj15, component$Mnobject);
                event$Mninfo2 = arg02.getCdr();
            }
            LList reverse = C1271lists.reverse(this.global$Mnvars$Mnto$Mncreate);
            while (reverse != LList.Empty) {
                Object obj16 = reverse;
                obj4 = obj16;
                Pair arg03 = (Pair) obj16;
                Object var$Mnval = arg03.getCar();
                Object apply16 = C1271lists.car.apply1(var$Mnval);
                obj5 = apply16;
                addToGlobalVarEnvironment((Symbol) apply16, Scheme.applyToArgs.apply1(C1271lists.cadr.apply1(var$Mnval)));
                reverse = arg03.getCdr();
            }
            Object reverse2 = C1271lists.reverse(this.form$Mndo$Mnafter$Mncreation);
            while (reverse2 != LList.Empty) {
                Object obj17 = reverse2;
                obj3 = obj17;
                Pair arg04 = (Pair) obj17;
                Object force = misc.force(arg04.getCar());
                reverse2 = arg04.getCdr();
            }
            LList component$Mndescriptors = components;
            LList lList = component$Mndescriptors;
            while (lList != LList.Empty) {
                Object obj18 = lList;
                obj2 = obj18;
                Pair arg05 = (Pair) obj18;
                Object component$Mninfo2 = arg05.getCar();
                Object apply17 = C1271lists.caddr.apply1(component$Mninfo2);
                Object init$Mnthunk = C1271lists.cadddr.apply1(component$Mninfo2);
                if (init$Mnthunk != Boolean.FALSE) {
                    Object apply18 = Scheme.applyToArgs.apply1(init$Mnthunk);
                }
                lList = arg05.getCdr();
            }
            LList lList2 = component$Mndescriptors;
            while (lList2 != LList.Empty) {
                Object obj19 = lList2;
                obj = obj19;
                Pair arg06 = (Pair) obj19;
                Object component$Mninfo3 = arg06.getCar();
                Object component$Mnname2 = C1271lists.caddr.apply1(component$Mninfo3);
                Object apply19 = C1271lists.cadddr.apply1(component$Mninfo3);
                callInitialize(SlotGet.field.apply2(this, component$Mnname2));
                lList2 = arg06.getCdr();
            }
        } catch (ClassCastException e3) {
            ClassCastException classCastException2 = e3;
            Throwable th11 = th;
            new WrongType(classCastException2, "arg0", -2, obj);
            throw th11;
        } catch (ClassCastException e4) {
            ClassCastException classCastException3 = e4;
            Throwable th12 = th2;
            new WrongType(classCastException3, "arg0", -2, obj2);
            throw th12;
        } catch (ClassCastException e5) {
            ClassCastException classCastException4 = e5;
            Throwable th13 = th3;
            new WrongType(classCastException4, "arg0", -2, obj3);
            throw th13;
        } catch (ClassCastException e6) {
            ClassCastException classCastException5 = e6;
            Throwable th14 = th5;
            new WrongType(classCastException5, "add-to-global-var-environment", 0, obj5);
            throw th14;
        } catch (ClassCastException e7) {
            ClassCastException classCastException6 = e7;
            Throwable th15 = th4;
            new WrongType(classCastException6, "arg0", -2, obj4);
            throw th15;
        } catch (ClassCastException e8) {
            ClassCastException classCastException7 = e8;
            Throwable th16 = th8;
            new WrongType(classCastException7, "add-to-form-environment", 0, obj8);
            throw th16;
        } catch (ClassCastException e9) {
            ClassCastException classCastException8 = e9;
            Throwable th17 = th7;
            new WrongType(classCastException8, "lookup-in-form-environment", 0, obj7);
            throw th17;
        } catch (ClassCastException e10) {
            ClassCastException classCastException9 = e10;
            Throwable th18 = th6;
            new WrongType(classCastException9, "arg0", -2, obj6);
            throw th18;
        } catch (YailRuntimeError e11) {
            processException(e11);
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        LList symbols = LList.makeList(argsArray, 0);
        LList lList = symbols;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj = symbols;
        Object obj2 = LList.Empty;
        while (true) {
            Object obj3 = obj2;
            Object obj4 = obj;
            if (obj4 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj3));
                Object obj5 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    Throwable th4 = th;
                    new WrongType(classCastException, "string->symbol", 1, obj5);
                    throw th4;
                }
            } else {
                Object obj6 = obj4;
                Object obj7 = obj6;
                try {
                    Pair arg0 = (Pair) obj6;
                    obj = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj8 = car;
                    try {
                        obj2 = Pair.make(misc.symbol$To$String((Symbol) car), obj3);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th3;
                        new WrongType(classCastException2, "symbol->string", 1, obj8);
                        throw th5;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    Throwable th6 = th2;
                    new WrongType(classCastException3, "arg0", -2, obj7);
                    throw th6;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
