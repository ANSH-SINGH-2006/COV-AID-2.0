package p004io.kodular.anshsingh2006_1.COV_AID_2;

import android.support.p000v4.app.FragmentTransaction;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.MakeroidYoutubePlayer;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1241runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.C1271lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import org.jose4j.jws.AlgorithmIdentifiers;
import p012yt.DeepHost.InApp_PDFViewer.C1691InApp_PDFViewer;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen4 */
/* compiled from: Screen4.yail */
public class Screen4 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final IntNum Lit10;
    static final FString Lit100;
    static final SimpleSymbol Lit101;
    static final FString Lit102;
    static final FString Lit103;
    static final SimpleSymbol Lit104;
    static final FString Lit105;
    static final FString Lit106;
    static final SimpleSymbol Lit107;
    static final FString Lit108;
    static final FString Lit109;
    static final SimpleSymbol Lit11;
    static final SimpleSymbol Lit110;
    static final FString Lit111;
    static final FString Lit112;
    static final SimpleSymbol Lit113;
    static final FString Lit114;
    static final FString Lit115;
    static final SimpleSymbol Lit116;
    static final FString Lit117;
    static final FString Lit118;
    static final SimpleSymbol Lit119;
    static final IntNum Lit12;
    static final FString Lit120;
    static final FString Lit121;
    static final SimpleSymbol Lit122;
    static final FString Lit123;
    static final FString Lit124;
    static final SimpleSymbol Lit125;
    static final FString Lit126;
    static final PairWithPosition Lit127 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 1056855);
    static final SimpleSymbol Lit128;
    static final FString Lit129;
    static final SimpleSymbol Lit13;
    static final SimpleSymbol Lit130;
    static final FString Lit131;
    static final FString Lit132;
    static final SimpleSymbol Lit133;
    static final FString Lit134;
    static final PairWithPosition Lit135 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 1106007);
    static final SimpleSymbol Lit136;
    static final FString Lit137;
    static final SimpleSymbol Lit138;
    static final FString Lit139;
    static final IntNum Lit14;
    static final FString Lit140;
    static final SimpleSymbol Lit141;
    static final FString Lit142;
    static final PairWithPosition Lit143;
    static final SimpleSymbol Lit144;
    static final FString Lit145;
    static final IntNum Lit146;
    static final FString Lit147;
    static final FString Lit148;
    static final SimpleSymbol Lit149;
    static final SimpleSymbol Lit15;
    static final FString Lit150;
    static final FString Lit151;
    static final FString Lit152;
    static final FString Lit153;
    static final FString Lit154;
    static final SimpleSymbol Lit155;
    static final SimpleSymbol Lit156;
    static final SimpleSymbol Lit157;
    static final SimpleSymbol Lit158;
    static final SimpleSymbol Lit159;
    static final SimpleSymbol Lit16;
    static final SimpleSymbol Lit160;
    static final SimpleSymbol Lit161;
    static final SimpleSymbol Lit162;
    static final SimpleSymbol Lit163;
    static final SimpleSymbol Lit164;
    static final SimpleSymbol Lit165;
    static final SimpleSymbol Lit166;
    static final SimpleSymbol Lit167;
    static final SimpleSymbol Lit168;
    static final SimpleSymbol Lit169;
    static final SimpleSymbol Lit17;
    static final SimpleSymbol Lit18;
    static final SimpleSymbol Lit19;
    static final SimpleSymbol Lit2;
    static final SimpleSymbol Lit20;
    static final SimpleSymbol Lit21;
    static final SimpleSymbol Lit22;
    static final PairWithPosition Lit23;
    static final SimpleSymbol Lit24;
    static final SimpleSymbol Lit25;
    static final SimpleSymbol Lit26;
    static final PairWithPosition Lit27 = PairWithPosition.make(Lit169, PairWithPosition.make(Lit7, PairWithPosition.make(Lit5, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94582), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94577), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94566);
    static final SimpleSymbol Lit28;
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final FString Lit31;
    static final SimpleSymbol Lit32;
    static final SimpleSymbol Lit33;
    static final IntNum Lit34 = IntNum.make(3);
    static final SimpleSymbol Lit35;
    static final IntNum Lit36 = IntNum.make(-2);
    static final FString Lit37;
    static final FString Lit38;
    static final SimpleSymbol Lit39;
    static final IntNum Lit4;
    static final IntNum Lit40;
    static final SimpleSymbol Lit41;
    static final FString Lit42;
    static final PairWithPosition Lit43;
    static final SimpleSymbol Lit44;
    static final SimpleSymbol Lit45;
    static final FString Lit46;
    static final SimpleSymbol Lit47;
    static final FString Lit48;
    static final FString Lit49;
    static final SimpleSymbol Lit5;
    static final SimpleSymbol Lit50;
    static final FString Lit51;
    static final SimpleSymbol Lit52;
    static final PairWithPosition Lit53 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 225367);
    static final SimpleSymbol Lit54;
    static final SimpleSymbol Lit55;
    static final FString Lit56;
    static final SimpleSymbol Lit57;
    static final FString Lit58;
    static final FString Lit59;
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final FString Lit61;
    static final PairWithPosition Lit62 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 274519);
    static final SimpleSymbol Lit63;
    static final FString Lit64;
    static final SimpleSymbol Lit65;
    static final FString Lit66;
    static final FString Lit67;
    static final SimpleSymbol Lit68;
    static final FString Lit69;
    static final SimpleSymbol Lit7;
    static final PairWithPosition Lit70 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 323671);
    static final SimpleSymbol Lit71;
    static final FString Lit72;
    static final SimpleSymbol Lit73;
    static final SimpleSymbol Lit74;
    static final SimpleSymbol Lit75;
    static final IntNum Lit76 = IntNum.make(20);
    static final SimpleSymbol Lit77;
    static final IntNum Lit78 = IntNum.make(1);
    static final SimpleSymbol Lit79;
    static final SimpleSymbol Lit8;
    static final IntNum Lit80;
    static final SimpleSymbol Lit81;
    static final FString Lit82;
    static final FString Lit83;
    static final SimpleSymbol Lit84;
    static final SimpleSymbol Lit85;
    static final SimpleSymbol Lit86;
    static final FString Lit87;
    static final FString Lit88;
    static final SimpleSymbol Lit89;
    static final SimpleSymbol Lit9;
    static final FString Lit90;
    static final FString Lit91;
    static final SimpleSymbol Lit92;
    static final FString Lit93;
    static final FString Lit94;
    static final SimpleSymbol Lit95;
    static final FString Lit96;
    static final FString Lit97;
    static final SimpleSymbol Lit98;
    static final FString Lit99;
    public static Screen4 Screen4;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn31 = null;
    static final ModuleMethod lambda$Fn32 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn9 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public Button Button1;
    public final ModuleMethod Button1$Click;
    public HorizontalArrangement Horizontal_Arrangement1;
    public Image Image1;
    public Image Image10;
    public Image Image11;
    public Image Image2;
    public Image Image3;
    public Image Image4;
    public Image Image5;
    public Image Image6;
    public Image Image7;
    public Image Image8;
    public Image Image9;
    public C1691InApp_PDFViewer InApp_PDFViewer1;
    public C1691InApp_PDFViewer InApp_PDFViewer2;
    public C1691InApp_PDFViewer InApp_PDFViewer3;
    public Label Label1;
    public Label Label2;
    public Label Label3;
    public Label Label3_copy;
    public Label Label3_copy1;
    public Label Label3_copy2;
    public Label Label4;
    public Notifier Notifier1;
    public final ModuleMethod Screen4$Initialize;
    public VerticalArrangement Vertical_Arrangement1;
    public MakeroidYoutubePlayer Youtube_Player1;
    public final ModuleMethod Youtube_Player1$Initialized;
    public MakeroidYoutubePlayer Youtube_Player2;
    public final ModuleMethod Youtube_Player2$Initialized;
    public MakeroidYoutubePlayer Youtube_Player3;
    public final ModuleMethod Youtube_Player3$Initialized;
    public MakeroidYoutubePlayer Youtube_Player4;
    public final ModuleMethod Youtube_Player4$Initialized;
    public MakeroidYoutubePlayer Youtube_Player5;
    public final ModuleMethod Youtube_Player5$Initialized;
    public MakeroidYoutubePlayer Youtube_Player6;
    public final ModuleMethod Youtube_Player6$Initialized;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        SimpleSymbol simpleSymbol15;
        FString fString;
        FString fString2;
        FString fString3;
        FString fString4;
        FString fString5;
        SimpleSymbol simpleSymbol16;
        FString fString6;
        FString fString7;
        FString fString8;
        SimpleSymbol simpleSymbol17;
        SimpleSymbol simpleSymbol18;
        FString fString9;
        SimpleSymbol simpleSymbol19;
        FString fString10;
        FString fString11;
        SimpleSymbol simpleSymbol20;
        FString fString12;
        SimpleSymbol simpleSymbol21;
        FString fString13;
        SimpleSymbol simpleSymbol22;
        FString fString14;
        FString fString15;
        SimpleSymbol simpleSymbol23;
        FString fString16;
        SimpleSymbol simpleSymbol24;
        FString fString17;
        SimpleSymbol simpleSymbol25;
        FString fString18;
        FString fString19;
        SimpleSymbol simpleSymbol26;
        FString fString20;
        FString fString21;
        SimpleSymbol simpleSymbol27;
        FString fString22;
        FString fString23;
        SimpleSymbol simpleSymbol28;
        FString fString24;
        FString fString25;
        SimpleSymbol simpleSymbol29;
        FString fString26;
        FString fString27;
        SimpleSymbol simpleSymbol30;
        FString fString28;
        FString fString29;
        SimpleSymbol simpleSymbol31;
        FString fString30;
        FString fString31;
        SimpleSymbol simpleSymbol32;
        FString fString32;
        FString fString33;
        SimpleSymbol simpleSymbol33;
        FString fString34;
        FString fString35;
        SimpleSymbol simpleSymbol34;
        FString fString36;
        FString fString37;
        SimpleSymbol simpleSymbol35;
        FString fString38;
        FString fString39;
        SimpleSymbol simpleSymbol36;
        FString fString40;
        FString fString41;
        SimpleSymbol simpleSymbol37;
        FString fString42;
        FString fString43;
        SimpleSymbol simpleSymbol38;
        SimpleSymbol simpleSymbol39;
        SimpleSymbol simpleSymbol40;
        FString fString44;
        FString fString45;
        SimpleSymbol simpleSymbol41;
        SimpleSymbol simpleSymbol42;
        SimpleSymbol simpleSymbol43;
        SimpleSymbol simpleSymbol44;
        SimpleSymbol simpleSymbol45;
        SimpleSymbol simpleSymbol46;
        FString fString46;
        SimpleSymbol simpleSymbol47;
        FString fString47;
        SimpleSymbol simpleSymbol48;
        FString fString48;
        FString fString49;
        SimpleSymbol simpleSymbol49;
        FString fString50;
        SimpleSymbol simpleSymbol50;
        FString fString51;
        SimpleSymbol simpleSymbol51;
        FString fString52;
        FString fString53;
        SimpleSymbol simpleSymbol52;
        FString fString54;
        SimpleSymbol simpleSymbol53;
        SimpleSymbol simpleSymbol54;
        SimpleSymbol simpleSymbol55;
        FString fString55;
        SimpleSymbol simpleSymbol56;
        FString fString56;
        FString fString57;
        SimpleSymbol simpleSymbol57;
        FString fString58;
        SimpleSymbol simpleSymbol58;
        SimpleSymbol simpleSymbol59;
        SimpleSymbol simpleSymbol60;
        FString fString59;
        SimpleSymbol simpleSymbol61;
        SimpleSymbol simpleSymbol62;
        FString fString60;
        FString fString61;
        SimpleSymbol simpleSymbol63;
        SimpleSymbol simpleSymbol64;
        SimpleSymbol simpleSymbol65;
        FString fString62;
        SimpleSymbol simpleSymbol66;
        SimpleSymbol simpleSymbol67;
        SimpleSymbol simpleSymbol68;
        SimpleSymbol simpleSymbol69;
        SimpleSymbol simpleSymbol70;
        SimpleSymbol simpleSymbol71;
        SimpleSymbol simpleSymbol72;
        SimpleSymbol simpleSymbol73;
        SimpleSymbol simpleSymbol74;
        SimpleSymbol simpleSymbol75;
        SimpleSymbol simpleSymbol76;
        SimpleSymbol simpleSymbol77;
        SimpleSymbol simpleSymbol78;
        SimpleSymbol simpleSymbol79;
        SimpleSymbol simpleSymbol80;
        SimpleSymbol simpleSymbol81;
        SimpleSymbol simpleSymbol82;
        SimpleSymbol simpleSymbol83;
        SimpleSymbol simpleSymbol84;
        SimpleSymbol simpleSymbol85;
        SimpleSymbol simpleSymbol86;
        SimpleSymbol simpleSymbol87;
        SimpleSymbol simpleSymbol88;
        new SimpleSymbol("component");
        Lit169 = (SimpleSymbol) simpleSymbol.readResolve();
        new SimpleSymbol("lookup-handler");
        Lit168 = (SimpleSymbol) simpleSymbol2.readResolve();
        new SimpleSymbol("dispatchGenericEvent");
        Lit167 = (SimpleSymbol) simpleSymbol3.readResolve();
        new SimpleSymbol("dispatchEvent");
        Lit166 = (SimpleSymbol) simpleSymbol4.readResolve();
        new SimpleSymbol("send-error");
        Lit165 = (SimpleSymbol) simpleSymbol5.readResolve();
        new SimpleSymbol("add-to-form-do-after-creation");
        Lit164 = (SimpleSymbol) simpleSymbol6.readResolve();
        new SimpleSymbol("add-to-global-vars");
        Lit163 = (SimpleSymbol) simpleSymbol7.readResolve();
        new SimpleSymbol("add-to-components");
        Lit162 = (SimpleSymbol) simpleSymbol8.readResolve();
        new SimpleSymbol("add-to-events");
        Lit161 = (SimpleSymbol) simpleSymbol9.readResolve();
        new SimpleSymbol("add-to-global-var-environment");
        Lit160 = (SimpleSymbol) simpleSymbol10.readResolve();
        new SimpleSymbol("is-bound-in-form-environment");
        Lit159 = (SimpleSymbol) simpleSymbol11.readResolve();
        new SimpleSymbol("lookup-in-form-environment");
        Lit158 = (SimpleSymbol) simpleSymbol12.readResolve();
        new SimpleSymbol("add-to-form-environment");
        Lit157 = (SimpleSymbol) simpleSymbol13.readResolve();
        new SimpleSymbol("android-log-form");
        Lit156 = (SimpleSymbol) simpleSymbol14.readResolve();
        new SimpleSymbol("get-simple-name");
        Lit155 = (SimpleSymbol) simpleSymbol15.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit154 = fString;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit153 = fString2;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit152 = fString3;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit151 = fString4;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit150 = fString5;
        new SimpleSymbol("InApp_PDFViewer2");
        Lit149 = (SimpleSymbol) simpleSymbol16.readResolve();
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit148 = fString6;
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit147 = fString7;
        int[] iArr = new int[2];
        iArr[0] = -5138;
        Lit146 = IntNum.make(iArr);
        new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit145 = fString8;
        new SimpleSymbol("Youtube_Player6$Initialized");
        Lit144 = (SimpleSymbol) simpleSymbol17.readResolve();
        new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol89 = (SimpleSymbol) simpleSymbol18.readResolve();
        Lit7 = simpleSymbol89;
        Lit143 = PairWithPosition.make(simpleSymbol89, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 1155159);
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit142 = fString9;
        new SimpleSymbol("Youtube_Player6");
        Lit141 = (SimpleSymbol) simpleSymbol19.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit140 = fString10;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit139 = fString11;
        new SimpleSymbol("Label3_copy2");
        Lit138 = (SimpleSymbol) simpleSymbol20.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit137 = fString12;
        new SimpleSymbol("Youtube_Player5$Initialized");
        Lit136 = (SimpleSymbol) simpleSymbol21.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit134 = fString13;
        new SimpleSymbol("Youtube_Player5");
        Lit133 = (SimpleSymbol) simpleSymbol22.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit132 = fString14;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit131 = fString15;
        new SimpleSymbol("Label3_copy1");
        Lit130 = (SimpleSymbol) simpleSymbol23.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit129 = fString16;
        new SimpleSymbol("Youtube_Player4$Initialized");
        Lit128 = (SimpleSymbol) simpleSymbol24.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit126 = fString17;
        new SimpleSymbol("Youtube_Player4");
        Lit125 = (SimpleSymbol) simpleSymbol25.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit124 = fString18;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit123 = fString19;
        new SimpleSymbol("Label3_copy");
        Lit122 = (SimpleSymbol) simpleSymbol26.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit121 = fString20;
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit120 = fString21;
        new SimpleSymbol("InApp_PDFViewer1");
        Lit119 = (SimpleSymbol) simpleSymbol27.readResolve();
        new FString("yt.DeepHost.InApp_PDFViewer.InApp_PDFViewer");
        Lit118 = fString22;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit117 = fString23;
        new SimpleSymbol("Image11");
        Lit116 = (SimpleSymbol) simpleSymbol28.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit115 = fString24;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit114 = fString25;
        new SimpleSymbol("Image10");
        Lit113 = (SimpleSymbol) simpleSymbol29.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit112 = fString26;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit111 = fString27;
        new SimpleSymbol("Image9");
        Lit110 = (SimpleSymbol) simpleSymbol30.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit109 = fString28;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit108 = fString29;
        new SimpleSymbol("Image8");
        Lit107 = (SimpleSymbol) simpleSymbol31.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit106 = fString30;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit105 = fString31;
        new SimpleSymbol("Image7");
        Lit104 = (SimpleSymbol) simpleSymbol32.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit103 = fString32;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit102 = fString33;
        new SimpleSymbol("Image6");
        Lit101 = (SimpleSymbol) simpleSymbol33.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit100 = fString34;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit99 = fString35;
        new SimpleSymbol("Image5");
        Lit98 = (SimpleSymbol) simpleSymbol34.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit97 = fString36;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit96 = fString37;
        new SimpleSymbol("Image4");
        Lit95 = (SimpleSymbol) simpleSymbol35.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit94 = fString38;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit93 = fString39;
        new SimpleSymbol("Image3");
        Lit92 = (SimpleSymbol) simpleSymbol36.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit91 = fString40;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit90 = fString41;
        new SimpleSymbol("Image2");
        Lit89 = (SimpleSymbol) simpleSymbol37.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit88 = fString42;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit87 = fString43;
        new SimpleSymbol("ScalePictureToFit");
        Lit86 = (SimpleSymbol) simpleSymbol38.readResolve();
        new SimpleSymbol("Height");
        Lit85 = (SimpleSymbol) simpleSymbol39.readResolve();
        new SimpleSymbol("Image1");
        Lit84 = (SimpleSymbol) simpleSymbol40.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit83 = fString44;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit82 = fString45;
        new SimpleSymbol("Visible");
        Lit81 = (SimpleSymbol) simpleSymbol41.readResolve();
        int[] iArr2 = new int[2];
        iArr2[0] = -769226;
        Lit80 = IntNum.make(iArr2);
        new SimpleSymbol("TextColor");
        Lit79 = (SimpleSymbol) simpleSymbol42.readResolve();
        new SimpleSymbol("TextAlignment");
        Lit77 = (SimpleSymbol) simpleSymbol43.readResolve();
        new SimpleSymbol("FontSize");
        Lit75 = (SimpleSymbol) simpleSymbol44.readResolve();
        new SimpleSymbol("FontBold");
        Lit74 = (SimpleSymbol) simpleSymbol45.readResolve();
        new SimpleSymbol("Label1");
        Lit73 = (SimpleSymbol) simpleSymbol46.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit72 = fString46;
        new SimpleSymbol("Youtube_Player3$Initialized");
        Lit71 = (SimpleSymbol) simpleSymbol47.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit69 = fString47;
        new SimpleSymbol("Youtube_Player3");
        Lit68 = (SimpleSymbol) simpleSymbol48.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit67 = fString48;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit66 = fString49;
        new SimpleSymbol("Label4");
        Lit65 = (SimpleSymbol) simpleSymbol49.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit64 = fString50;
        new SimpleSymbol("Youtube_Player2$Initialized");
        Lit63 = (SimpleSymbol) simpleSymbol50.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit61 = fString51;
        new SimpleSymbol("Youtube_Player2");
        Lit60 = (SimpleSymbol) simpleSymbol51.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit59 = fString52;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit58 = fString53;
        new SimpleSymbol("Label3");
        Lit57 = (SimpleSymbol) simpleSymbol52.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit56 = fString54;
        new SimpleSymbol("Initialized");
        Lit55 = (SimpleSymbol) simpleSymbol53.readResolve();
        new SimpleSymbol("Youtube_Player1$Initialized");
        Lit54 = (SimpleSymbol) simpleSymbol54.readResolve();
        new SimpleSymbol("Load");
        Lit52 = (SimpleSymbol) simpleSymbol55.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit51 = fString55;
        new SimpleSymbol("Youtube_Player1");
        Lit50 = (SimpleSymbol) simpleSymbol56.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidYoutubePlayer");
        Lit49 = fString56;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit48 = fString57;
        new SimpleSymbol("Label2");
        Lit47 = (SimpleSymbol) simpleSymbol57.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit46 = fString58;
        new SimpleSymbol("Click");
        Lit45 = (SimpleSymbol) simpleSymbol58.readResolve();
        new SimpleSymbol("Button1$Click");
        Lit44 = (SimpleSymbol) simpleSymbol59.readResolve();
        SimpleSymbol simpleSymbol90 = Lit169;
        SimpleSymbol simpleSymbol91 = Lit7;
        new SimpleSymbol("number");
        SimpleSymbol simpleSymbol92 = (SimpleSymbol) simpleSymbol60.readResolve();
        Lit5 = simpleSymbol92;
        Lit43 = PairWithPosition.make(simpleSymbol90, PairWithPosition.make(simpleSymbol91, PairWithPosition.make(simpleSymbol92, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 176337), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 176332), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 176321);
        new FString("com.google.appinventor.components.runtime.Button");
        Lit42 = fString59;
        new SimpleSymbol("Text");
        Lit41 = (SimpleSymbol) simpleSymbol61.readResolve();
        int[] iArr3 = new int[2];
        iArr3[0] = -769226;
        Lit40 = IntNum.make(iArr3);
        new SimpleSymbol("Button1");
        Lit39 = (SimpleSymbol) simpleSymbol62.readResolve();
        new FString("com.google.appinventor.components.runtime.Button");
        Lit38 = fString60;
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit37 = fString61;
        new SimpleSymbol("Width");
        Lit35 = (SimpleSymbol) simpleSymbol63.readResolve();
        new SimpleSymbol("AlignHorizontal");
        Lit33 = (SimpleSymbol) simpleSymbol64.readResolve();
        new SimpleSymbol("Horizontal_Arrangement1");
        Lit32 = (SimpleSymbol) simpleSymbol65.readResolve();
        new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit31 = fString62;
        new SimpleSymbol("Initialize");
        Lit30 = (SimpleSymbol) simpleSymbol66.readResolve();
        new SimpleSymbol("Screen4$Initialize");
        Lit29 = (SimpleSymbol) simpleSymbol67.readResolve();
        new SimpleSymbol("ShowCustomDialog");
        Lit28 = (SimpleSymbol) simpleSymbol68.readResolve();
        new SimpleSymbol("HORIZONTAL");
        Lit26 = (SimpleSymbol) simpleSymbol69.readResolve();
        new SimpleSymbol("PDF_Load_From_Assest");
        Lit25 = (SimpleSymbol) simpleSymbol70.readResolve();
        new SimpleSymbol("InApp_PDFViewer3");
        Lit24 = (SimpleSymbol) simpleSymbol71.readResolve();
        SimpleSymbol simpleSymbol93 = Lit169;
        SimpleSymbol simpleSymbol94 = Lit7;
        SimpleSymbol simpleSymbol95 = Lit7;
        SimpleSymbol simpleSymbol96 = Lit7;
        new SimpleSymbol("boolean");
        SimpleSymbol simpleSymbol97 = (SimpleSymbol) simpleSymbol72.readResolve();
        Lit17 = simpleSymbol97;
        Lit23 = PairWithPosition.make(simpleSymbol93, PairWithPosition.make(simpleSymbol94, PairWithPosition.make(simpleSymbol95, PairWithPosition.make(simpleSymbol96, PairWithPosition.make(simpleSymbol97, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94369), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94364), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94359), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94354), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen4.yail", 94343);
        new SimpleSymbol("Vertical_Arrangement1");
        Lit22 = (SimpleSymbol) simpleSymbol73.readResolve();
        new SimpleSymbol("CreateCustomDialog");
        Lit21 = (SimpleSymbol) simpleSymbol74.readResolve();
        new SimpleSymbol("Notifier1");
        Lit20 = (SimpleSymbol) simpleSymbol75.readResolve();
        new SimpleSymbol("TitleVisible");
        Lit19 = (SimpleSymbol) simpleSymbol76.readResolve();
        new SimpleSymbol("Title");
        Lit18 = (SimpleSymbol) simpleSymbol77.readResolve();
        new SimpleSymbol("Scrollable");
        Lit16 = (SimpleSymbol) simpleSymbol78.readResolve();
        new SimpleSymbol("ReceiveSharedText");
        Lit15 = (SimpleSymbol) simpleSymbol79.readResolve();
        int[] iArr4 = new int[2];
        iArr4[0] = -769226;
        Lit14 = IntNum.make(iArr4);
        new SimpleSymbol("PrimaryColorDark");
        Lit13 = (SimpleSymbol) simpleSymbol80.readResolve();
        int[] iArr5 = new int[2];
        iArr5[0] = -769226;
        Lit12 = IntNum.make(iArr5);
        new SimpleSymbol("PrimaryColor");
        Lit11 = (SimpleSymbol) simpleSymbol81.readResolve();
        int[] iArr6 = new int[2];
        iArr6[0] = -5138;
        Lit10 = IntNum.make(iArr6);
        new SimpleSymbol("BackgroundColor");
        Lit9 = (SimpleSymbol) simpleSymbol82.readResolve();
        new SimpleSymbol("AppName");
        Lit8 = (SimpleSymbol) simpleSymbol83.readResolve();
        new SimpleSymbol("AppId");
        Lit6 = (SimpleSymbol) simpleSymbol84.readResolve();
        int[] iArr7 = new int[2];
        iArr7[0] = -769226;
        Lit4 = IntNum.make(iArr7);
        new SimpleSymbol("AccentColor");
        Lit3 = (SimpleSymbol) simpleSymbol85.readResolve();
        new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol86.readResolve();
        new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol87.readResolve();
        new SimpleSymbol("Screen4");
        Lit0 = (SimpleSymbol) simpleSymbol88.readResolve();
    }

    public Screen4() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleMethod moduleMethod29;
        ModuleMethod moduleMethod30;
        ModuleMethod moduleMethod31;
        ModuleMethod moduleMethod32;
        ModuleMethod moduleMethod33;
        ModuleMethod moduleMethod34;
        ModuleMethod moduleMethod35;
        ModuleMethod moduleMethod36;
        ModuleMethod moduleMethod37;
        ModuleMethod moduleMethod38;
        ModuleMethod moduleMethod39;
        ModuleMethod moduleMethod40;
        ModuleMethod moduleMethod41;
        ModuleMethod moduleMethod42;
        ModuleMethod moduleMethod43;
        ModuleMethod moduleMethod44;
        ModuleMethod moduleMethod45;
        ModuleMethod moduleMethod46;
        ModuleMethod moduleMethod47;
        ModuleMethod moduleMethod48;
        ModuleMethod moduleMethod49;
        ModuleMethod moduleMethod50;
        ModuleMethod moduleMethod51;
        ModuleMethod moduleMethod52;
        ModuleMethod moduleMethod53;
        ModuleMethod moduleMethod54;
        ModuleMethod moduleMethod55;
        ModuleMethod moduleMethod56;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod57 = moduleMethod;
        new frame();
        frame frame3 = frame2;
        frame3.$main = this;
        frame frame4 = frame3;
        new ModuleMethod(frame4, 1, Lit155, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod57;
        new ModuleMethod(frame4, 2, Lit156, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod2;
        new ModuleMethod(frame4, 3, Lit157, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod3;
        new ModuleMethod(frame4, 4, Lit158, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod4;
        new ModuleMethod(frame4, 6, Lit159, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod5;
        new ModuleMethod(frame4, 7, Lit160, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod6;
        new ModuleMethod(frame4, 8, Lit161, 8194);
        this.add$Mnto$Mnevents = moduleMethod7;
        new ModuleMethod(frame4, 9, Lit162, 16388);
        this.add$Mnto$Mncomponents = moduleMethod8;
        new ModuleMethod(frame4, 10, Lit163, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod9;
        new ModuleMethod(frame4, 11, Lit164, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod10;
        new ModuleMethod(frame4, 12, Lit165, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod11;
        new ModuleMethod(frame4, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod12;
        new ModuleMethod(frame4, 14, Lit166, 16388);
        this.dispatchEvent = moduleMethod13;
        new ModuleMethod(frame4, 15, Lit167, 16388);
        this.dispatchGenericEvent = moduleMethod14;
        new ModuleMethod(frame4, 16, Lit168, 8194);
        this.lookup$Mnhandler = moduleMethod15;
        new ModuleMethod(frame4, 17, (Object) null, 0);
        ModuleMethod moduleMethod58 = moduleMethod16;
        moduleMethod58.setProperty("source-location", "/tmp/runtime7522387041397852836.scm:615");
        lambda$Fn1 = moduleMethod58;
        new ModuleMethod(frame4, 18, "$define", 0);
        this.$define = moduleMethod17;
        new ModuleMethod(frame4, 19, (Object) null, 0);
        lambda$Fn2 = moduleMethod18;
        new ModuleMethod(frame4, 20, Lit29, 0);
        this.Screen4$Initialize = moduleMethod19;
        new ModuleMethod(frame4, 21, (Object) null, 0);
        lambda$Fn3 = moduleMethod20;
        new ModuleMethod(frame4, 22, (Object) null, 0);
        lambda$Fn4 = moduleMethod21;
        new ModuleMethod(frame4, 23, (Object) null, 0);
        lambda$Fn5 = moduleMethod22;
        new ModuleMethod(frame4, 24, (Object) null, 0);
        lambda$Fn6 = moduleMethod23;
        new ModuleMethod(frame4, 25, Lit44, 0);
        this.Button1$Click = moduleMethod24;
        new ModuleMethod(frame4, 26, Lit54, 0);
        this.Youtube_Player1$Initialized = moduleMethod25;
        new ModuleMethod(frame4, 27, Lit63, 0);
        this.Youtube_Player2$Initialized = moduleMethod26;
        new ModuleMethod(frame4, 28, Lit71, 0);
        this.Youtube_Player3$Initialized = moduleMethod27;
        new ModuleMethod(frame4, 29, (Object) null, 0);
        lambda$Fn7 = moduleMethod28;
        new ModuleMethod(frame4, 30, (Object) null, 0);
        lambda$Fn8 = moduleMethod29;
        new ModuleMethod(frame4, 31, (Object) null, 0);
        lambda$Fn9 = moduleMethod30;
        new ModuleMethod(frame4, 32, (Object) null, 0);
        lambda$Fn10 = moduleMethod31;
        new ModuleMethod(frame4, 33, (Object) null, 0);
        lambda$Fn11 = moduleMethod32;
        new ModuleMethod(frame4, 34, (Object) null, 0);
        lambda$Fn12 = moduleMethod33;
        new ModuleMethod(frame4, 35, (Object) null, 0);
        lambda$Fn13 = moduleMethod34;
        new ModuleMethod(frame4, 36, (Object) null, 0);
        lambda$Fn14 = moduleMethod35;
        new ModuleMethod(frame4, 37, (Object) null, 0);
        lambda$Fn15 = moduleMethod36;
        new ModuleMethod(frame4, 38, (Object) null, 0);
        lambda$Fn16 = moduleMethod37;
        new ModuleMethod(frame4, 39, (Object) null, 0);
        lambda$Fn17 = moduleMethod38;
        new ModuleMethod(frame4, 40, (Object) null, 0);
        lambda$Fn18 = moduleMethod39;
        new ModuleMethod(frame4, 41, (Object) null, 0);
        lambda$Fn19 = moduleMethod40;
        new ModuleMethod(frame4, 42, (Object) null, 0);
        lambda$Fn20 = moduleMethod41;
        new ModuleMethod(frame4, 43, (Object) null, 0);
        lambda$Fn21 = moduleMethod42;
        new ModuleMethod(frame4, 44, (Object) null, 0);
        lambda$Fn22 = moduleMethod43;
        new ModuleMethod(frame4, 45, (Object) null, 0);
        lambda$Fn23 = moduleMethod44;
        new ModuleMethod(frame4, 46, (Object) null, 0);
        lambda$Fn24 = moduleMethod45;
        new ModuleMethod(frame4, 47, (Object) null, 0);
        lambda$Fn25 = moduleMethod46;
        new ModuleMethod(frame4, 48, (Object) null, 0);
        lambda$Fn26 = moduleMethod47;
        new ModuleMethod(frame4, 49, (Object) null, 0);
        lambda$Fn27 = moduleMethod48;
        new ModuleMethod(frame4, 50, (Object) null, 0);
        lambda$Fn28 = moduleMethod49;
        new ModuleMethod(frame4, 51, (Object) null, 0);
        lambda$Fn29 = moduleMethod50;
        new ModuleMethod(frame4, 52, (Object) null, 0);
        lambda$Fn30 = moduleMethod51;
        new ModuleMethod(frame4, 53, Lit128, 0);
        this.Youtube_Player4$Initialized = moduleMethod52;
        new ModuleMethod(frame4, 54, Lit136, 0);
        this.Youtube_Player5$Initialized = moduleMethod53;
        new ModuleMethod(frame4, 55, Lit144, 0);
        this.Youtube_Player6$Initialized = moduleMethod54;
        new ModuleMethod(frame4, 56, (Object) null, 0);
        lambda$Fn31 = moduleMethod55;
        new ModuleMethod(frame4, 57, (Object) null, 0);
        lambda$Fn32 = moduleMethod56;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        String obj;
        Object obj2;
        Consumer $result = $ctx.consumer;
        C1241runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
        Object[] objArr = new Object[2];
        objArr[0] = misc.symbol$To$String(Lit0);
        Object[] objArr2 = objArr;
        objArr2[1] = "-global-vars";
        FString stringAppend = strings.stringAppend(objArr2);
        FString fString = stringAppend;
        if (stringAppend == null) {
            obj = null;
        } else {
            obj = fString.toString();
        }
        this.global$Mnvar$Mnenvironment = Environment.make(obj);
        Screen4 = null;
        this.form$Mnname$Mnsymbol = Lit0;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        C1241runtime.$instance.run();
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit6, "6193580781600768", Lit7);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "COV_AID_2", Lit7);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit9, Lit10, Lit5);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit13, Lit14, Lit5);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit15, AlgorithmIdentifiers.NONE, Lit7);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit16, Boolean.TRUE, Lit17);
            Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, "Screen4", Lit7);
            Values.writeValues(C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, Boolean.FALSE, Lit17), $result);
        } else {
            new Promise(lambda$Fn2);
            addToFormDoAfterCreation(obj2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment = C1241runtime.addToCurrentFormEnvironment(Lit29, this.Screen4$Initialize);
        } else {
            addToFormEnvironment(Lit29, this.Screen4$Initialize);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Screen4", "Initialize");
        } else {
            addToEvents(Lit0, Lit30);
        }
        this.Horizontal_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit31, Lit32, lambda$Fn3), $result);
        } else {
            addToComponents(Lit0, Lit37, Lit32, lambda$Fn4);
        }
        this.Button1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit32, Lit38, Lit39, lambda$Fn5), $result);
        } else {
            addToComponents(Lit32, Lit42, Lit39, lambda$Fn6);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment2 = C1241runtime.addToCurrentFormEnvironment(Lit44, this.Button1$Click);
        } else {
            addToFormEnvironment(Lit44, this.Button1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Button1", "Click");
        } else {
            addToEvents(Lit39, Lit45);
        }
        this.Label2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit46, Lit47, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit48, Lit47, Boolean.FALSE);
        }
        this.Youtube_Player1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit49, Lit50, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit51, Lit50, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment3 = C1241runtime.addToCurrentFormEnvironment(Lit54, this.Youtube_Player1$Initialized);
        } else {
            addToFormEnvironment(Lit54, this.Youtube_Player1$Initialized);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Youtube_Player1", "Initialized");
        } else {
            addToEvents(Lit50, Lit55);
        }
        this.Label3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit56, Lit57, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit58, Lit57, Boolean.FALSE);
        }
        this.Youtube_Player2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit59, Lit60, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit61, Lit60, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment4 = C1241runtime.addToCurrentFormEnvironment(Lit63, this.Youtube_Player2$Initialized);
        } else {
            addToFormEnvironment(Lit63, this.Youtube_Player2$Initialized);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Youtube_Player2", "Initialized");
        } else {
            addToEvents(Lit60, Lit55);
        }
        this.Label4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit64, Lit65, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit66, Lit65, Boolean.FALSE);
        }
        this.Youtube_Player3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit67, Lit68, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit69, Lit68, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment5 = C1241runtime.addToCurrentFormEnvironment(Lit71, this.Youtube_Player3$Initialized);
        } else {
            addToFormEnvironment(Lit71, this.Youtube_Player3$Initialized);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Youtube_Player3", "Initialized");
        } else {
            addToEvents(Lit68, Lit55);
        }
        this.Label1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit72, Lit73, lambda$Fn7), $result);
        } else {
            addToComponents(Lit0, Lit82, Lit73, lambda$Fn8);
        }
        this.Image1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit83, Lit84, lambda$Fn9), $result);
        } else {
            addToComponents(Lit0, Lit87, Lit84, lambda$Fn10);
        }
        this.Image2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit88, Lit89, lambda$Fn11), $result);
        } else {
            addToComponents(Lit0, Lit90, Lit89, lambda$Fn12);
        }
        this.Image3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit91, Lit92, lambda$Fn13), $result);
        } else {
            addToComponents(Lit0, Lit93, Lit92, lambda$Fn14);
        }
        this.Image4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit94, Lit95, lambda$Fn15), $result);
        } else {
            addToComponents(Lit0, Lit96, Lit95, lambda$Fn16);
        }
        this.Image5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit97, Lit98, lambda$Fn17), $result);
        } else {
            addToComponents(Lit0, Lit99, Lit98, lambda$Fn18);
        }
        this.Image6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit100, Lit101, lambda$Fn19), $result);
        } else {
            addToComponents(Lit0, Lit102, Lit101, lambda$Fn20);
        }
        this.Image7 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit103, Lit104, lambda$Fn21), $result);
        } else {
            addToComponents(Lit0, Lit105, Lit104, lambda$Fn22);
        }
        this.Image8 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit106, Lit107, lambda$Fn23), $result);
        } else {
            addToComponents(Lit0, Lit108, Lit107, lambda$Fn24);
        }
        this.Image9 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit109, Lit110, lambda$Fn25), $result);
        } else {
            addToComponents(Lit0, Lit111, Lit110, lambda$Fn26);
        }
        this.Image10 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit112, Lit113, lambda$Fn27), $result);
        } else {
            addToComponents(Lit0, Lit114, Lit113, lambda$Fn28);
        }
        this.Image11 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit115, Lit116, lambda$Fn29), $result);
        } else {
            addToComponents(Lit0, Lit117, Lit116, lambda$Fn30);
        }
        this.InApp_PDFViewer1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit118, Lit119, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit120, Lit119, Boolean.FALSE);
        }
        this.Label3_copy = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit121, Lit122, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit123, Lit122, Boolean.FALSE);
        }
        this.Youtube_Player4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit124, Lit125, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit126, Lit125, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment6 = C1241runtime.addToCurrentFormEnvironment(Lit128, this.Youtube_Player4$Initialized);
        } else {
            addToFormEnvironment(Lit128, this.Youtube_Player4$Initialized);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Youtube_Player4", "Initialized");
        } else {
            addToEvents(Lit125, Lit55);
        }
        this.Label3_copy1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit129, Lit130, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit131, Lit130, Boolean.FALSE);
        }
        this.Youtube_Player5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit132, Lit133, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit134, Lit133, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment7 = C1241runtime.addToCurrentFormEnvironment(Lit136, this.Youtube_Player5$Initialized);
        } else {
            addToFormEnvironment(Lit136, this.Youtube_Player5$Initialized);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Youtube_Player5", "Initialized");
        } else {
            addToEvents(Lit133, Lit55);
        }
        this.Label3_copy2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit137, Lit138, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit139, Lit138, Boolean.FALSE);
        }
        this.Youtube_Player6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit140, Lit141, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit142, Lit141, Boolean.FALSE);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment8 = C1241runtime.addToCurrentFormEnvironment(Lit144, this.Youtube_Player6$Initialized);
        } else {
            addToFormEnvironment(Lit144, this.Youtube_Player6$Initialized);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Youtube_Player6", "Initialized");
        } else {
            addToEvents(Lit141, Lit55);
        }
        this.Vertical_Arrangement1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit145, Lit22, lambda$Fn31), $result);
        } else {
            addToComponents(Lit0, Lit147, Lit22, lambda$Fn32);
        }
        this.InApp_PDFViewer2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit148, Lit149, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit150, Lit149, Boolean.FALSE);
        }
        this.InApp_PDFViewer3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit151, Lit24, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit152, Lit24, Boolean.FALSE);
        }
        this.Notifier1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit153, Lit20, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit154, Lit20, Boolean.FALSE);
        }
        C1241runtime.initRuntime();
    }

    static Object lambda3() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit6, "6193580781600768", Lit7);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "COV_AID_2", Lit7);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit9, Lit10, Lit5);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit13, Lit14, Lit5);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit15, AlgorithmIdentifiers.NONE, Lit7);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit16, Boolean.TRUE, Lit17);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, "Screen4", Lit7);
        return C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit19, Boolean.FALSE, Lit17);
    }

    public Object Screen4$Initialize() {
        C1241runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit20;
        SimpleSymbol simpleSymbol2 = Lit21;
        Pair list1 = LList.list1(C1241runtime.lookupInCurrentFormEnvironment(Lit22));
        Pair chain4 = LList.chain4(list1, "", "", "", Boolean.TRUE);
        Object callComponentMethod = C1241runtime.callComponentMethod(simpleSymbol, simpleSymbol2, list1, Lit23);
        Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit24, Lit25, LList.list3(C1241runtime.lookupInCurrentFormEnvironment(Lit22), "cov-aid_2.0.pdf", C1241runtime.get$Mnproperty.apply2(Lit24, Lit26)), Lit27);
        return C1241runtime.callComponentMethod(Lit20, Lit28, LList.Empty, LList.Empty);
    }

    static Object lambda4() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit32, Lit33, Lit34, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit32, Lit35, Lit36, Lit5);
    }

    static Object lambda5() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit32, Lit33, Lit34, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit32, Lit35, Lit36, Lit5);
    }

    static Object lambda6() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit9, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit41, "Tap To View Tips", Lit7);
    }

    static Object lambda7() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit9, Lit40, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit39, Lit41, "Tap To View Tips", Lit7);
    }

    public Object Button1$Click() {
        C1241runtime.setThisForm();
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit24, Lit25, LList.list3(C1241runtime.lookupInCurrentFormEnvironment(Lit22), "cov-aid_2.0.pdf", C1241runtime.get$Mnproperty.apply2(Lit24, Lit26)), Lit43);
        return C1241runtime.callComponentMethod(Lit20, Lit28, LList.Empty, LList.Empty);
    }

    public Object Youtube_Player1$Initialized() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit50, Lit52, LList.list1("8dlUqlMDkR4"), Lit53);
    }

    public Object Youtube_Player2$Initialized() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit60, Lit52, LList.list1("i0ZabxXmH4Y"), Lit62);
    }

    public Object Youtube_Player3$Initialized() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit68, Lit52, LList.list1("2etHdW0Xdsk"), Lit70);
    }

    static Object lambda8() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit74, Boolean.TRUE, Lit17);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit75, Lit76, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit41, "Scroll Down To Read Tips", Lit7);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit77, Lit78, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit79, Lit80, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda9() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit74, Boolean.TRUE, Lit17);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit75, Lit76, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit41, "Scroll Down To Read Tips", Lit7);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit77, Lit78, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit79, Lit80, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit73, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda10() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda11() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit84, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda12() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda13() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit89, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda14() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda15() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda16() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda17() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit95, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda18() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda19() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit98, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda20() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda21() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit101, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda22() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda23() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit104, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda24() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda25() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit107, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda26() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda27() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit110, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda28() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda29() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit113, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda30() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit81, Boolean.FALSE, Lit17);
    }

    static Object lambda31() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit85, Lit36, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit35, Lit36, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit86, Boolean.TRUE, Lit17);
        return C1241runtime.setAndCoerceProperty$Ex(Lit116, Lit81, Boolean.FALSE, Lit17);
    }

    public Object Youtube_Player4$Initialized() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit125, Lit52, LList.list1("677pSwGauqs"), Lit127);
    }

    public Object Youtube_Player5$Initialized() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit133, Lit52, LList.list1("yp9p0ieLZZ0"), Lit135);
    }

    public Object Youtube_Player6$Initialized() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit141, Lit52, LList.list1("PhdSdJu_QXI"), Lit143);
    }

    static Object lambda32() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit33, Lit34, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit9, Lit146, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit35, Lit36, Lit5);
    }

    static Object lambda33() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit33, Lit34, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit9, Lit146, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit35, Lit36, Lit5);
    }

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen4$frame */
    /* compiled from: Screen4.yail */
    public class frame extends ModuleBody {
        Screen4 $main;

        public frame() {
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Screen4)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Screen4)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof Screen4)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            Throwable th;
            Throwable th2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th3 = th2;
                        new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw th3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th4 = th;
                        new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw th4;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            Throwable th6;
            Throwable th7;
            Throwable th8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    Throwable th9 = th8;
                                    new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw th9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                Throwable th10 = th7;
                                new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw th10;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            Throwable th11 = th6;
                            new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw th11;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        Throwable th12 = th5;
                        new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw th12;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    Throwable th13 = th4;
                                    new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw th13;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                Throwable th14 = th3;
                                new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw th14;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            Throwable th15 = th2;
                            new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw th15;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        Throwable th16 = th;
                        new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw th16;
                    }
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th4 = th3;
                        new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw th4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th2;
                        new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw th5;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        Throwable th6 = th;
                        new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw th6;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return Screen4.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return Screen4.lambda3();
                case 20:
                    return this.$main.Screen4$Initialize();
                case 21:
                    return Screen4.lambda4();
                case 22:
                    return Screen4.lambda5();
                case 23:
                    return Screen4.lambda6();
                case 24:
                    return Screen4.lambda7();
                case 25:
                    return this.$main.Button1$Click();
                case 26:
                    return this.$main.Youtube_Player1$Initialized();
                case 27:
                    return this.$main.Youtube_Player2$Initialized();
                case 28:
                    return this.$main.Youtube_Player3$Initialized();
                case 29:
                    return Screen4.lambda8();
                case 30:
                    return Screen4.lambda9();
                case 31:
                    return Screen4.lambda10();
                case 32:
                    return Screen4.lambda11();
                case 33:
                    return Screen4.lambda12();
                case 34:
                    return Screen4.lambda13();
                case 35:
                    return Screen4.lambda14();
                case 36:
                    return Screen4.lambda15();
                case 37:
                    return Screen4.lambda16();
                case 38:
                    return Screen4.lambda17();
                case 39:
                    return Screen4.lambda18();
                case 40:
                    return Screen4.lambda19();
                case 41:
                    return Screen4.lambda20();
                case 42:
                    return Screen4.lambda21();
                case 43:
                    return Screen4.lambda22();
                case 44:
                    return Screen4.lambda23();
                case 45:
                    return Screen4.lambda24();
                case 46:
                    return Screen4.lambda25();
                case 47:
                    return Screen4.lambda26();
                case 48:
                    return Screen4.lambda27();
                case 49:
                    return Screen4.lambda28();
                case 50:
                    return Screen4.lambda29();
                case 51:
                    return Screen4.lambda30();
                case 52:
                    return Screen4.lambda31();
                case 53:
                    return this.$main.Youtube_Player4$Initialized();
                case 54:
                    return this.$main.Youtube_Player5$Initialized();
                case 55:
                    return this.$main.Youtube_Player6$Initialized();
                case 56:
                    return Screen4.lambda32();
                case 57:
                    return Screen4.lambda33();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 20:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 23:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 24:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 30:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 31:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 32:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 33:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 34:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 35:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 36:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 37:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 38:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 39:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 40:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 41:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 42:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 43:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 44:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 45:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 46:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 47:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 48:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 49:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 50:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 51:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 52:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 53:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 54:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 55:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 56:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 57:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.form$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name = symbol;
        Object default$Mnvalue = obj;
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & true;
        if (!x ? !x : !this.form$Mnenvironment.isBound(name)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = C1271lists.cons(C1271lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = C1271lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = C1271lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = C1271lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        Object obj = error;
        RetValManager.sendError(obj == null ? null : obj.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        objArr2[0] = "any$";
        Object[] objArr3 = objArr2;
        objArr3[1] = getSimpleName(componentObject);
        Object[] objArr4 = objArr3;
        objArr4[2] = "$";
        Object[] objArr5 = objArr4;
        objArr5[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr5)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1271lists.cons(component2, C1271lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object componentName, Object obj) {
        Object eventName = obj;
        Object obj2 = componentName;
        String obj3 = obj2 == null ? null : obj2.toString();
        Object obj4 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj3, obj4 == null ? null : obj4.toString())));
    }

    public void $define() {
        Object obj;
        Throwable th;
        Object obj2;
        Throwable th2;
        Object obj3;
        Throwable th3;
        Object obj4;
        Throwable th4;
        Object obj5;
        Throwable th5;
        Object obj6;
        Throwable th6;
        Object obj7;
        Throwable th7;
        Object obj8;
        Throwable th8;
        Throwable th9;
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception e) {
            Exception exception = e;
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        Screen4 = this;
        addToFormEnvironment(Lit0, this);
        Object obj9 = this.events$Mnto$Mnregister;
        while (true) {
            Object obj10 = obj9;
            if (obj10 == LList.Empty) {
                break;
            }
            Object obj11 = obj10;
            Object obj12 = obj11;
            try {
                Pair arg0 = (Pair) obj11;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = C1271lists.car.apply1(event$Mninfo);
                String obj13 = apply1 == null ? null : apply1.toString();
                Object apply12 = C1271lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj13, apply12 == null ? null : apply12.toString());
                obj9 = arg0.getCdr();
            } catch (ClassCastException e2) {
                ClassCastException classCastException = e2;
                Throwable th10 = th9;
                new WrongType(classCastException, "arg0", -2, obj12);
                throw th10;
            }
        }
        try {
            LList components = C1271lists.reverse(this.components$Mnto$Mncreate);
            addToGlobalVars(Lit2, lambda$Fn1);
            LList event$Mninfo2 = components;
            while (event$Mninfo2 != LList.Empty) {
                Object obj14 = event$Mninfo2;
                obj6 = obj14;
                Pair arg02 = (Pair) obj14;
                Object component$Mninfo = arg02.getCar();
                Object apply13 = C1271lists.caddr.apply1(component$Mninfo);
                Object apply14 = C1271lists.cadddr.apply1(component$Mninfo);
                Object component$Mntype = C1271lists.cadr.apply1(component$Mninfo);
                Object apply15 = C1271lists.car.apply1(component$Mninfo);
                obj7 = apply15;
                Object component$Mnname = apply13;
                Object component$Mnobject = Invoke.make.apply2(component$Mntype, lookupInFormEnvironment((Symbol) apply15));
                Object apply3 = SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
                Object obj15 = component$Mnname;
                obj8 = obj15;
                addToFormEnvironment((Symbol) obj15, component$Mnobject);
                event$Mninfo2 = arg02.getCdr();
            }
            LList reverse = C1271lists.reverse(this.global$Mnvars$Mnto$Mncreate);
            while (reverse != LList.Empty) {
                Object obj16 = reverse;
                obj4 = obj16;
                Pair arg03 = (Pair) obj16;
                Object var$Mnval = arg03.getCar();
                Object apply16 = C1271lists.car.apply1(var$Mnval);
                obj5 = apply16;
                addToGlobalVarEnvironment((Symbol) apply16, Scheme.applyToArgs.apply1(C1271lists.cadr.apply1(var$Mnval)));
                reverse = arg03.getCdr();
            }
            Object reverse2 = C1271lists.reverse(this.form$Mndo$Mnafter$Mncreation);
            while (reverse2 != LList.Empty) {
                Object obj17 = reverse2;
                obj3 = obj17;
                Pair arg04 = (Pair) obj17;
                Object force = misc.force(arg04.getCar());
                reverse2 = arg04.getCdr();
            }
            LList component$Mndescriptors = components;
            LList lList = component$Mndescriptors;
            while (lList != LList.Empty) {
                Object obj18 = lList;
                obj2 = obj18;
                Pair arg05 = (Pair) obj18;
                Object component$Mninfo2 = arg05.getCar();
                Object apply17 = C1271lists.caddr.apply1(component$Mninfo2);
                Object init$Mnthunk = C1271lists.cadddr.apply1(component$Mninfo2);
                if (init$Mnthunk != Boolean.FALSE) {
                    Object apply18 = Scheme.applyToArgs.apply1(init$Mnthunk);
                }
                lList = arg05.getCdr();
            }
            LList lList2 = component$Mndescriptors;
            while (lList2 != LList.Empty) {
                Object obj19 = lList2;
                obj = obj19;
                Pair arg06 = (Pair) obj19;
                Object component$Mninfo3 = arg06.getCar();
                Object component$Mnname2 = C1271lists.caddr.apply1(component$Mninfo3);
                Object apply19 = C1271lists.cadddr.apply1(component$Mninfo3);
                callInitialize(SlotGet.field.apply2(this, component$Mnname2));
                lList2 = arg06.getCdr();
            }
        } catch (ClassCastException e3) {
            ClassCastException classCastException2 = e3;
            Throwable th11 = th;
            new WrongType(classCastException2, "arg0", -2, obj);
            throw th11;
        } catch (ClassCastException e4) {
            ClassCastException classCastException3 = e4;
            Throwable th12 = th2;
            new WrongType(classCastException3, "arg0", -2, obj2);
            throw th12;
        } catch (ClassCastException e5) {
            ClassCastException classCastException4 = e5;
            Throwable th13 = th3;
            new WrongType(classCastException4, "arg0", -2, obj3);
            throw th13;
        } catch (ClassCastException e6) {
            ClassCastException classCastException5 = e6;
            Throwable th14 = th5;
            new WrongType(classCastException5, "add-to-global-var-environment", 0, obj5);
            throw th14;
        } catch (ClassCastException e7) {
            ClassCastException classCastException6 = e7;
            Throwable th15 = th4;
            new WrongType(classCastException6, "arg0", -2, obj4);
            throw th15;
        } catch (ClassCastException e8) {
            ClassCastException classCastException7 = e8;
            Throwable th16 = th8;
            new WrongType(classCastException7, "add-to-form-environment", 0, obj8);
            throw th16;
        } catch (ClassCastException e9) {
            ClassCastException classCastException8 = e9;
            Throwable th17 = th7;
            new WrongType(classCastException8, "lookup-in-form-environment", 0, obj7);
            throw th17;
        } catch (ClassCastException e10) {
            ClassCastException classCastException9 = e10;
            Throwable th18 = th6;
            new WrongType(classCastException9, "arg0", -2, obj6);
            throw th18;
        } catch (YailRuntimeError e11) {
            processException(e11);
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        LList symbols = LList.makeList(argsArray, 0);
        LList lList = symbols;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj = symbols;
        Object obj2 = LList.Empty;
        while (true) {
            Object obj3 = obj2;
            Object obj4 = obj;
            if (obj4 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj3));
                Object obj5 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    Throwable th4 = th;
                    new WrongType(classCastException, "string->symbol", 1, obj5);
                    throw th4;
                }
            } else {
                Object obj6 = obj4;
                Object obj7 = obj6;
                try {
                    Pair arg0 = (Pair) obj6;
                    obj = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj8 = car;
                    try {
                        obj2 = Pair.make(misc.symbol$To$String((Symbol) car), obj3);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th3;
                        new WrongType(classCastException2, "symbol->string", 1, obj8);
                        throw th5;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    Throwable th6 = th2;
                    new WrongType(classCastException3, "arg0", -2, obj7);
                    throw th6;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
