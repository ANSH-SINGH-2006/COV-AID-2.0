package p004io.kodular.anshsingh2006_1.COV_AID_2;

import android.support.p000v4.app.FragmentTransaction;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.MakeroidFab;
import com.google.appinventor.components.runtime.MakeroidTabLayout;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1241runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.C1271lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import org.jose4j.jws.AlgorithmIdentifiers;

/* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen5 */
/* compiled from: Screen5.yail */
public class Screen5 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final SimpleSymbol Lit100;
    static final IntNum Lit101;
    static final SimpleSymbol Lit102;
    static final SimpleSymbol Lit103;
    static final FString Lit104;
    static final SimpleSymbol Lit105;
    static final SimpleSymbol Lit106;
    static final PairWithPosition Lit107 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 381031);
    static final SimpleSymbol Lit108;
    static final SimpleSymbol Lit109;
    static final SimpleSymbol Lit11;
    static final PairWithPosition Lit110;
    static final SimpleSymbol Lit111;
    static final SimpleSymbol Lit112;
    static final FString Lit113;
    static final FString Lit114;
    static final SimpleSymbol Lit115;
    static final SimpleSymbol Lit116;
    static final SimpleSymbol Lit117;
    static final SimpleSymbol Lit118;
    static final SimpleSymbol Lit119;
    static final IntNum Lit12;
    static final SimpleSymbol Lit120;
    static final SimpleSymbol Lit121;
    static final SimpleSymbol Lit122;
    static final SimpleSymbol Lit123;
    static final SimpleSymbol Lit124;
    static final SimpleSymbol Lit125;
    static final SimpleSymbol Lit126;
    static final SimpleSymbol Lit127;
    static final SimpleSymbol Lit128;
    static final SimpleSymbol Lit129;
    static final SimpleSymbol Lit13;
    static final IntNum Lit14;
    static final SimpleSymbol Lit15;
    static final IntNum Lit16;
    static final SimpleSymbol Lit17;
    static final SimpleSymbol Lit18;
    static final SimpleSymbol Lit19;
    static final SimpleSymbol Lit2;
    static final SimpleSymbol Lit20;
    static final SimpleSymbol Lit21;
    static final SimpleSymbol Lit22;
    static final SimpleSymbol Lit23;
    static final PairWithPosition Lit24 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98403), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98397);
    static final PairWithPosition Lit25 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98512), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98506);
    static final PairWithPosition Lit26 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98616), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98610);
    static final PairWithPosition Lit27 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98724), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98718);
    static final PairWithPosition Lit28 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98828), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98822);
    static final PairWithPosition Lit29 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98932), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 98926);
    static final SimpleSymbol Lit3;
    static final PairWithPosition Lit30 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99039), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99033);
    static final PairWithPosition Lit31 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99146), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99140);
    static final PairWithPosition Lit32 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99258), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99252);
    static final PairWithPosition Lit33 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99362), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99356);
    static final PairWithPosition Lit34 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99480), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99474);
    static final PairWithPosition Lit35 = PairWithPosition.make(Lit9, PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99591), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 99585);
    static final SimpleSymbol Lit36;
    static final SimpleSymbol Lit37;
    static final FString Lit38;
    static final SimpleSymbol Lit39;
    static final IntNum Lit4;
    static final IntNum Lit40;
    static final SimpleSymbol Lit41;
    static final IntNum Lit42;
    static final SimpleSymbol Lit43;
    static final IntNum Lit44;
    static final SimpleSymbol Lit45;
    static final IntNum Lit46;
    static final FString Lit47;
    static final SimpleSymbol Lit48;
    static final PairWithPosition Lit49 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 159843), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 159838);
    static final SimpleSymbol Lit5;
    static final PairWithPosition Lit50 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 159934);
    static final PairWithPosition Lit51 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160059), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160054);
    static final PairWithPosition Lit52 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160151);
    static final PairWithPosition Lit53 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160274), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160269);
    static final PairWithPosition Lit54 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160366);
    static final PairWithPosition Lit55 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160494), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160489);
    static final PairWithPosition Lit56 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160587);
    static final PairWithPosition Lit57 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160715), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160710);
    static final PairWithPosition Lit58 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160807);
    static final PairWithPosition Lit59 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160930), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 160925);
    static final SimpleSymbol Lit6;
    static final PairWithPosition Lit60 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161022);
    static final PairWithPosition Lit61 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161147), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161142);
    static final PairWithPosition Lit62 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161240);
    static final PairWithPosition Lit63 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161369), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161364);
    static final PairWithPosition Lit64 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161462);
    static final PairWithPosition Lit65 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161589), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161584);
    static final PairWithPosition Lit66 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161682);
    static final PairWithPosition Lit67 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161814), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161809);
    static final PairWithPosition Lit68 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 161907);
    static final PairWithPosition Lit69 = PairWithPosition.make(Lit129, PairWithPosition.make(Lit129, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 162039), "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 162034);
    static final IntNum Lit7 = IntNum.make(3);
    static final PairWithPosition Lit70 = PairWithPosition.make(Lit9, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 162132);
    static final SimpleSymbol Lit71;
    static final SimpleSymbol Lit72;
    static final FString Lit73;
    static final SimpleSymbol Lit74;
    static final FString Lit75;
    static final FString Lit76;
    static final SimpleSymbol Lit77;
    static final FString Lit78;
    static final FString Lit79;
    static final SimpleSymbol Lit8;
    static final SimpleSymbol Lit80;
    static final FString Lit81;
    static final FString Lit82;
    static final SimpleSymbol Lit83;
    static final FString Lit84;
    static final FString Lit85;
    static final SimpleSymbol Lit86;
    static final FString Lit87;
    static final FString Lit88;
    static final SimpleSymbol Lit89;
    static final SimpleSymbol Lit9;
    static final FString Lit90;
    static final FString Lit91;
    static final SimpleSymbol Lit92;
    static final SimpleSymbol Lit93;
    static final IntNum Lit94 = IntNum.make(-1040);
    static final SimpleSymbol Lit95;
    static final IntNum Lit96 = IntNum.make(-1080);
    static final SimpleSymbol Lit97;
    static final FString Lit98;
    static final FString Lit99;
    public static Screen5 Screen5;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public MakeroidFab Floating_Action_Button1;
    public final ModuleMethod Floating_Action_Button1$Click;
    public final ModuleMethod Floating_Action_Button1$LongClick;
    public Image Image1;
    public Label Label1;
    public Label Label2;
    public Label Label3;
    public Label Label4;
    public Label Label5;
    public Label Label6;
    public Notifier Notifier1;
    public final ModuleMethod Screen5$Initialize;
    public MakeroidTabLayout Tab_Layout1;
    public final ModuleMethod Tab_Layout1$TabItemSelected;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        SimpleSymbol simpleSymbol15;
        FString fString;
        FString fString2;
        SimpleSymbol simpleSymbol16;
        SimpleSymbol simpleSymbol17;
        SimpleSymbol simpleSymbol18;
        SimpleSymbol simpleSymbol19;
        SimpleSymbol simpleSymbol20;
        SimpleSymbol simpleSymbol21;
        SimpleSymbol simpleSymbol22;
        FString fString3;
        SimpleSymbol simpleSymbol23;
        SimpleSymbol simpleSymbol24;
        SimpleSymbol simpleSymbol25;
        FString fString4;
        FString fString5;
        SimpleSymbol simpleSymbol26;
        SimpleSymbol simpleSymbol27;
        SimpleSymbol simpleSymbol28;
        SimpleSymbol simpleSymbol29;
        FString fString6;
        FString fString7;
        SimpleSymbol simpleSymbol30;
        FString fString8;
        FString fString9;
        SimpleSymbol simpleSymbol31;
        FString fString10;
        FString fString11;
        SimpleSymbol simpleSymbol32;
        FString fString12;
        FString fString13;
        SimpleSymbol simpleSymbol33;
        FString fString14;
        FString fString15;
        SimpleSymbol simpleSymbol34;
        FString fString16;
        FString fString17;
        SimpleSymbol simpleSymbol35;
        FString fString18;
        SimpleSymbol simpleSymbol36;
        SimpleSymbol simpleSymbol37;
        SimpleSymbol simpleSymbol38;
        FString fString19;
        SimpleSymbol simpleSymbol39;
        SimpleSymbol simpleSymbol40;
        SimpleSymbol simpleSymbol41;
        SimpleSymbol simpleSymbol42;
        FString fString20;
        SimpleSymbol simpleSymbol43;
        SimpleSymbol simpleSymbol44;
        SimpleSymbol simpleSymbol45;
        SimpleSymbol simpleSymbol46;
        SimpleSymbol simpleSymbol47;
        SimpleSymbol simpleSymbol48;
        SimpleSymbol simpleSymbol49;
        SimpleSymbol simpleSymbol50;
        SimpleSymbol simpleSymbol51;
        SimpleSymbol simpleSymbol52;
        SimpleSymbol simpleSymbol53;
        SimpleSymbol simpleSymbol54;
        SimpleSymbol simpleSymbol55;
        SimpleSymbol simpleSymbol56;
        SimpleSymbol simpleSymbol57;
        SimpleSymbol simpleSymbol58;
        SimpleSymbol simpleSymbol59;
        SimpleSymbol simpleSymbol60;
        SimpleSymbol simpleSymbol61;
        SimpleSymbol simpleSymbol62;
        new SimpleSymbol("any");
        Lit129 = (SimpleSymbol) simpleSymbol.readResolve();
        new SimpleSymbol("lookup-handler");
        Lit128 = (SimpleSymbol) simpleSymbol2.readResolve();
        new SimpleSymbol("dispatchGenericEvent");
        Lit127 = (SimpleSymbol) simpleSymbol3.readResolve();
        new SimpleSymbol("dispatchEvent");
        Lit126 = (SimpleSymbol) simpleSymbol4.readResolve();
        new SimpleSymbol("send-error");
        Lit125 = (SimpleSymbol) simpleSymbol5.readResolve();
        new SimpleSymbol("add-to-form-do-after-creation");
        Lit124 = (SimpleSymbol) simpleSymbol6.readResolve();
        new SimpleSymbol("add-to-global-vars");
        Lit123 = (SimpleSymbol) simpleSymbol7.readResolve();
        new SimpleSymbol("add-to-components");
        Lit122 = (SimpleSymbol) simpleSymbol8.readResolve();
        new SimpleSymbol("add-to-events");
        Lit121 = (SimpleSymbol) simpleSymbol9.readResolve();
        new SimpleSymbol("add-to-global-var-environment");
        Lit120 = (SimpleSymbol) simpleSymbol10.readResolve();
        new SimpleSymbol("is-bound-in-form-environment");
        Lit119 = (SimpleSymbol) simpleSymbol11.readResolve();
        new SimpleSymbol("lookup-in-form-environment");
        Lit118 = (SimpleSymbol) simpleSymbol12.readResolve();
        new SimpleSymbol("add-to-form-environment");
        Lit117 = (SimpleSymbol) simpleSymbol13.readResolve();
        new SimpleSymbol("android-log-form");
        Lit116 = (SimpleSymbol) simpleSymbol14.readResolve();
        new SimpleSymbol("get-simple-name");
        Lit115 = (SimpleSymbol) simpleSymbol15.readResolve();
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit114 = fString;
        new FString("com.google.appinventor.components.runtime.Notifier");
        Lit113 = fString2;
        new SimpleSymbol("LongClick");
        Lit112 = (SimpleSymbol) simpleSymbol16.readResolve();
        new SimpleSymbol("Floating_Action_Button1$LongClick");
        Lit111 = (SimpleSymbol) simpleSymbol17.readResolve();
        new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol63 = (SimpleSymbol) simpleSymbol18.readResolve();
        Lit9 = simpleSymbol63;
        Lit110 = PairWithPosition.make(simpleSymbol63, LList.Empty, "/tmp/1624039079031_0.8921560322568782-0/youngandroidproject/../src/io/kodular/anshsingh2006_1/COV_AID_2/Screen5.yail", 389223);
        new SimpleSymbol("Click");
        Lit109 = (SimpleSymbol) simpleSymbol19.readResolve();
        new SimpleSymbol("Floating_Action_Button1$Click");
        Lit108 = (SimpleSymbol) simpleSymbol20.readResolve();
        new SimpleSymbol("ShowAlert");
        Lit106 = (SimpleSymbol) simpleSymbol21.readResolve();
        new SimpleSymbol("Notifier1");
        Lit105 = (SimpleSymbol) simpleSymbol22.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidFab");
        Lit104 = fString3;
        new SimpleSymbol("IconName");
        Lit103 = (SimpleSymbol) simpleSymbol23.readResolve();
        new SimpleSymbol("Icon");
        Lit102 = (SimpleSymbol) simpleSymbol24.readResolve();
        int[] iArr = new int[2];
        iArr[0] = -769226;
        Lit101 = IntNum.make(iArr);
        new SimpleSymbol("Floating_Action_Button1");
        Lit100 = (SimpleSymbol) simpleSymbol25.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidFab");
        Lit99 = fString4;
        new FString("com.google.appinventor.components.runtime.Image");
        Lit98 = fString5;
        new SimpleSymbol("Picture");
        Lit97 = (SimpleSymbol) simpleSymbol26.readResolve();
        new SimpleSymbol("Width");
        Lit95 = (SimpleSymbol) simpleSymbol27.readResolve();
        new SimpleSymbol("Height");
        Lit93 = (SimpleSymbol) simpleSymbol28.readResolve();
        new SimpleSymbol("Image1");
        Lit92 = (SimpleSymbol) simpleSymbol29.readResolve();
        new FString("com.google.appinventor.components.runtime.Image");
        Lit91 = fString6;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit90 = fString7;
        new SimpleSymbol("Label5");
        Lit89 = (SimpleSymbol) simpleSymbol30.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit88 = fString8;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit87 = fString9;
        new SimpleSymbol("Label3");
        Lit86 = (SimpleSymbol) simpleSymbol31.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit85 = fString10;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit84 = fString11;
        new SimpleSymbol("Label4");
        Lit83 = (SimpleSymbol) simpleSymbol32.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit82 = fString12;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit81 = fString13;
        new SimpleSymbol("Label6");
        Lit80 = (SimpleSymbol) simpleSymbol33.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit79 = fString14;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit78 = fString15;
        new SimpleSymbol("Label2");
        Lit77 = (SimpleSymbol) simpleSymbol34.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit76 = fString16;
        new FString("com.google.appinventor.components.runtime.Label");
        Lit75 = fString17;
        new SimpleSymbol("Label1");
        Lit74 = (SimpleSymbol) simpleSymbol35.readResolve();
        new FString("com.google.appinventor.components.runtime.Label");
        Lit73 = fString18;
        new SimpleSymbol("TabItemSelected");
        Lit72 = (SimpleSymbol) simpleSymbol36.readResolve();
        new SimpleSymbol("Tab_Layout1$TabItemSelected");
        Lit71 = (SimpleSymbol) simpleSymbol37.readResolve();
        new SimpleSymbol("$tab");
        Lit48 = (SimpleSymbol) simpleSymbol38.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidTabLayout");
        Lit47 = fString19;
        int[] iArr2 = new int[2];
        iArr2[0] = -16777216;
        Lit46 = IntNum.make(iArr2);
        new SimpleSymbol("TabsTextColor");
        Lit45 = (SimpleSymbol) simpleSymbol39.readResolve();
        int[] iArr3 = new int[2];
        iArr3[0] = -769226;
        Lit44 = IntNum.make(iArr3);
        new SimpleSymbol("TabsIndicatorColor");
        Lit43 = (SimpleSymbol) simpleSymbol40.readResolve();
        int[] iArr4 = new int[2];
        iArr4[0] = -1;
        Lit42 = IntNum.make(iArr4);
        new SimpleSymbol("TabsBackgroundColor");
        Lit41 = (SimpleSymbol) simpleSymbol41.readResolve();
        int[] iArr5 = new int[2];
        iArr5[0] = -769226;
        Lit40 = IntNum.make(iArr5);
        new SimpleSymbol("TabsActiveTextColor");
        Lit39 = (SimpleSymbol) simpleSymbol42.readResolve();
        new FString("com.google.appinventor.components.runtime.MakeroidTabLayout");
        Lit38 = fString20;
        new SimpleSymbol("Initialize");
        Lit37 = (SimpleSymbol) simpleSymbol43.readResolve();
        new SimpleSymbol("Screen5$Initialize");
        Lit36 = (SimpleSymbol) simpleSymbol44.readResolve();
        new SimpleSymbol("AddNewTab");
        Lit23 = (SimpleSymbol) simpleSymbol45.readResolve();
        new SimpleSymbol("Tab_Layout1");
        Lit22 = (SimpleSymbol) simpleSymbol46.readResolve();
        new SimpleSymbol("TitleVisible");
        Lit21 = (SimpleSymbol) simpleSymbol47.readResolve();
        new SimpleSymbol("Title");
        Lit20 = (SimpleSymbol) simpleSymbol48.readResolve();
        new SimpleSymbol("boolean");
        Lit19 = (SimpleSymbol) simpleSymbol49.readResolve();
        new SimpleSymbol("Scrollable");
        Lit18 = (SimpleSymbol) simpleSymbol50.readResolve();
        new SimpleSymbol("ReceiveSharedText");
        Lit17 = (SimpleSymbol) simpleSymbol51.readResolve();
        int[] iArr6 = new int[2];
        iArr6[0] = -769226;
        Lit16 = IntNum.make(iArr6);
        new SimpleSymbol("PrimaryColorDark");
        Lit15 = (SimpleSymbol) simpleSymbol52.readResolve();
        int[] iArr7 = new int[2];
        iArr7[0] = -769226;
        Lit14 = IntNum.make(iArr7);
        new SimpleSymbol("PrimaryColor");
        Lit13 = (SimpleSymbol) simpleSymbol53.readResolve();
        int[] iArr8 = new int[2];
        iArr8[0] = -5138;
        Lit12 = IntNum.make(iArr8);
        new SimpleSymbol("BackgroundColor");
        Lit11 = (SimpleSymbol) simpleSymbol54.readResolve();
        new SimpleSymbol("AppName");
        Lit10 = (SimpleSymbol) simpleSymbol55.readResolve();
        new SimpleSymbol("AppId");
        Lit8 = (SimpleSymbol) simpleSymbol56.readResolve();
        new SimpleSymbol("AlignHorizontal");
        Lit6 = (SimpleSymbol) simpleSymbol57.readResolve();
        new SimpleSymbol("number");
        Lit5 = (SimpleSymbol) simpleSymbol58.readResolve();
        int[] iArr9 = new int[2];
        iArr9[0] = -769226;
        Lit4 = IntNum.make(iArr9);
        new SimpleSymbol("AccentColor");
        Lit3 = (SimpleSymbol) simpleSymbol59.readResolve();
        new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol60.readResolve();
        new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol61.readResolve();
        new SimpleSymbol("Screen5");
        Lit0 = (SimpleSymbol) simpleSymbol62.readResolve();
    }

    public Screen5() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod29 = moduleMethod;
        new frame();
        frame frame3 = frame2;
        frame3.$main = this;
        frame frame4 = frame3;
        new ModuleMethod(frame4, 1, Lit115, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod29;
        new ModuleMethod(frame4, 2, Lit116, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod2;
        new ModuleMethod(frame4, 3, Lit117, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod3;
        new ModuleMethod(frame4, 4, Lit118, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod4;
        new ModuleMethod(frame4, 6, Lit119, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod5;
        new ModuleMethod(frame4, 7, Lit120, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod6;
        new ModuleMethod(frame4, 8, Lit121, 8194);
        this.add$Mnto$Mnevents = moduleMethod7;
        new ModuleMethod(frame4, 9, Lit122, 16388);
        this.add$Mnto$Mncomponents = moduleMethod8;
        new ModuleMethod(frame4, 10, Lit123, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod9;
        new ModuleMethod(frame4, 11, Lit124, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod10;
        new ModuleMethod(frame4, 12, Lit125, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod11;
        new ModuleMethod(frame4, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod12;
        new ModuleMethod(frame4, 14, Lit126, 16388);
        this.dispatchEvent = moduleMethod13;
        new ModuleMethod(frame4, 15, Lit127, 16388);
        this.dispatchGenericEvent = moduleMethod14;
        new ModuleMethod(frame4, 16, Lit128, 8194);
        this.lookup$Mnhandler = moduleMethod15;
        new ModuleMethod(frame4, 17, (Object) null, 0);
        ModuleMethod moduleMethod30 = moduleMethod16;
        moduleMethod30.setProperty("source-location", "/tmp/runtime7522387041397852836.scm:615");
        lambda$Fn1 = moduleMethod30;
        new ModuleMethod(frame4, 18, "$define", 0);
        this.$define = moduleMethod17;
        new ModuleMethod(frame4, 19, (Object) null, 0);
        lambda$Fn2 = moduleMethod18;
        new ModuleMethod(frame4, 20, Lit36, 0);
        this.Screen5$Initialize = moduleMethod19;
        new ModuleMethod(frame4, 21, (Object) null, 0);
        lambda$Fn3 = moduleMethod20;
        new ModuleMethod(frame4, 22, (Object) null, 0);
        lambda$Fn4 = moduleMethod21;
        new ModuleMethod(frame4, 23, Lit71, 8194);
        this.Tab_Layout1$TabItemSelected = moduleMethod22;
        new ModuleMethod(frame4, 24, (Object) null, 0);
        lambda$Fn5 = moduleMethod23;
        new ModuleMethod(frame4, 25, (Object) null, 0);
        lambda$Fn6 = moduleMethod24;
        new ModuleMethod(frame4, 26, (Object) null, 0);
        lambda$Fn7 = moduleMethod25;
        new ModuleMethod(frame4, 27, (Object) null, 0);
        lambda$Fn8 = moduleMethod26;
        new ModuleMethod(frame4, 28, Lit108, 0);
        this.Floating_Action_Button1$Click = moduleMethod27;
        new ModuleMethod(frame4, 29, Lit111, 0);
        this.Floating_Action_Button1$LongClick = moduleMethod28;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext $ctx) {
        String obj;
        Object obj2;
        Consumer $result = $ctx.consumer;
        C1241runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
        Object[] objArr = new Object[2];
        objArr[0] = misc.symbol$To$String(Lit0);
        Object[] objArr2 = objArr;
        objArr2[1] = "-global-vars";
        FString stringAppend = strings.stringAppend(objArr2);
        FString fString = stringAppend;
        if (stringAppend == null) {
            obj = null;
        } else {
            obj = fString.toString();
        }
        this.global$Mnvar$Mnenvironment = Environment.make(obj);
        Screen5 = null;
        this.form$Mnname$Mnsymbol = Lit0;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        C1241runtime.$instance.run();
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
            Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit6, Lit7, Lit5);
            Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "6193580781600768", Lit9);
            Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit10, "COV_AID_2", Lit9);
            Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
            Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit13, Lit14, Lit5);
            Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit15, Lit16, Lit5);
            Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit17, AlgorithmIdentifiers.NONE, Lit9);
            Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, Boolean.TRUE, Lit19);
            Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit20, "Screen5", Lit9);
            Values.writeValues(C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, Boolean.FALSE, Lit19), $result);
        } else {
            new Promise(lambda$Fn2);
            addToFormDoAfterCreation(obj2);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment = C1241runtime.addToCurrentFormEnvironment(Lit36, this.Screen5$Initialize);
        } else {
            addToFormEnvironment(Lit36, this.Screen5$Initialize);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Screen5", "Initialize");
        } else {
            addToEvents(Lit0, Lit37);
        }
        this.Tab_Layout1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit38, Lit22, lambda$Fn3), $result);
        } else {
            addToComponents(Lit0, Lit47, Lit22, lambda$Fn4);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment2 = C1241runtime.addToCurrentFormEnvironment(Lit71, this.Tab_Layout1$TabItemSelected);
        } else {
            addToFormEnvironment(Lit71, this.Tab_Layout1$TabItemSelected);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Tab_Layout1", "TabItemSelected");
        } else {
            addToEvents(Lit22, Lit72);
        }
        this.Label1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit73, Lit74, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit75, Lit74, Boolean.FALSE);
        }
        this.Label2 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit76, Lit77, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit78, Lit77, Boolean.FALSE);
        }
        this.Label6 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit79, Lit80, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit81, Lit80, Boolean.FALSE);
        }
        this.Label4 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit82, Lit83, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit84, Lit83, Boolean.FALSE);
        }
        this.Label3 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit85, Lit86, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit87, Lit86, Boolean.FALSE);
        }
        this.Label5 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit88, Lit89, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit90, Lit89, Boolean.FALSE);
        }
        this.Image1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit91, Lit92, lambda$Fn5), $result);
        } else {
            addToComponents(Lit0, Lit98, Lit92, lambda$Fn6);
        }
        this.Floating_Action_Button1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit99, Lit100, lambda$Fn7), $result);
        } else {
            addToComponents(Lit0, Lit104, Lit100, lambda$Fn8);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment3 = C1241runtime.addToCurrentFormEnvironment(Lit108, this.Floating_Action_Button1$Click);
        } else {
            addToFormEnvironment(Lit108, this.Floating_Action_Button1$Click);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Floating_Action_Button1", "Click");
        } else {
            addToEvents(Lit100, Lit109);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Object addToCurrentFormEnvironment4 = C1241runtime.addToCurrentFormEnvironment(Lit111, this.Floating_Action_Button1$LongClick);
        } else {
            addToFormEnvironment(Lit111, this.Floating_Action_Button1$LongClick);
        }
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1241runtime.$Stthis$Mnform$St, "Floating_Action_Button1", "LongClick");
        } else {
            addToEvents(Lit100, Lit112);
        }
        this.Notifier1 = null;
        if (C1241runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(C1241runtime.addComponentWithinRepl(Lit0, Lit113, Lit105, Boolean.FALSE), $result);
        } else {
            addToComponents(Lit0, Lit114, Lit105, Boolean.FALSE);
        }
        C1241runtime.initRuntime();
    }

    static Object lambda3() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit6, Lit7, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "6193580781600768", Lit9);
        Object andCoerceProperty$Ex4 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit10, "COV_AID_2", Lit9);
        Object andCoerceProperty$Ex5 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
        Object andCoerceProperty$Ex6 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit13, Lit14, Lit5);
        Object andCoerceProperty$Ex7 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit15, Lit16, Lit5);
        Object andCoerceProperty$Ex8 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit17, AlgorithmIdentifiers.NONE, Lit9);
        Object andCoerceProperty$Ex9 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit18, Boolean.TRUE, Lit19);
        Object andCoerceProperty$Ex10 = C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit20, "Screen5", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit0, Lit21, Boolean.FALSE, Lit19);
    }

    public Object Screen5$Initialize() {
        C1241runtime.setThisForm();
        Object callComponentMethod = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Home", "home.png"), Lit24);
        Object callComponentMethod2 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Oxygen", "oxygen-tank.png"), Lit25);
        Object callComponentMethod3 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Plasma", "plasma.png"), Lit26);
        Object callComponentMethod4 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Beds", "hospital-bed.png"), Lit27);
        Object callComponentMethod5 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Ambulance", "bus.png"), Lit28);
        Object callComponentMethod6 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Medicines", "icu.png"), Lit29);
        Object callComponentMethod7 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Food", "doctor-icon.png"), Lit30);
        Object callComponentMethod8 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Doctor", "ambulance.png"), Lit31);
        Object callComponentMethod9 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Home Nurse", "nurse-icon.png"), Lit32);
        Object callComponentMethod10 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Home ICU", "hicu.png"), Lit33);
        Object callComponentMethod11 = C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Mental Health", "mental-health.png"), Lit34);
        return C1241runtime.callComponentMethod(Lit22, Lit23, LList.list2("Social Groups", "social.png"), Lit35);
    }

    static Object lambda4() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit39, Lit40, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit41, Lit42, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit43, Lit44, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit45, Lit46, Lit5);
    }

    static Object lambda5() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit39, Lit40, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit41, Lit42, Lit5);
        Object andCoerceProperty$Ex3 = C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit43, Lit44, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit22, Lit45, Lit46, Lit5);
    }

    public Object Tab_Layout1$TabItemSelected(Object $tab, Object $position) {
        Object obj;
        Object obj2;
        Object obj3;
        Object obj4;
        Object obj5;
        Object obj6;
        Object obj7;
        Object obj8;
        Object obj9;
        Object obj10;
        Object obj11;
        Object sanitizeComponentData = C1241runtime.sanitizeComponentData($tab);
        Object sanitizeComponentData2 = C1241runtime.sanitizeComponentData($position);
        Object $tab2 = sanitizeComponentData;
        C1241runtime.setThisForm();
        ModuleMethod moduleMethod = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr = new Object[3];
            objArr[0] = "The variable ";
            Object[] objArr2 = objArr;
            objArr2[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr3 = objArr2;
            objArr3[2] = " is not bound in the current context";
            obj = C1241runtime.signalRuntimeError(strings.stringAppend(objArr3), "Unbound Variable");
        } else {
            obj = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod, LList.list2(obj, "Oxygen"), Lit49, "=") != Boolean.FALSE) {
            Object callYailPrimitive = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("oxygen"), Lit50, "open another screen");
        }
        ModuleMethod moduleMethod2 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr4 = new Object[3];
            objArr4[0] = "The variable ";
            Object[] objArr5 = objArr4;
            objArr5[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr6 = objArr5;
            objArr6[2] = " is not bound in the current context";
            obj2 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr6), "Unbound Variable");
        } else {
            obj2 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod2, LList.list2(obj2, "Plasma"), Lit51, "=") != Boolean.FALSE) {
            Object callYailPrimitive2 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen6"), Lit52, "open another screen");
        }
        ModuleMethod moduleMethod3 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr7 = new Object[3];
            objArr7[0] = "The variable ";
            Object[] objArr8 = objArr7;
            objArr8[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr9 = objArr8;
            objArr9[2] = " is not bound in the current context";
            obj3 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr9), "Unbound Variable");
        } else {
            obj3 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod3, LList.list2(obj3, "Beds"), Lit53, "=") != Boolean.FALSE) {
            Object callYailPrimitive3 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen7"), Lit54, "open another screen");
        }
        ModuleMethod moduleMethod4 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr10 = new Object[3];
            objArr10[0] = "The variable ";
            Object[] objArr11 = objArr10;
            objArr11[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr12 = objArr11;
            objArr12[2] = " is not bound in the current context";
            obj4 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr12), "Unbound Variable");
        } else {
            obj4 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod4, LList.list2(obj4, "Ambulance"), Lit55, "=") != Boolean.FALSE) {
            Object callYailPrimitive4 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen15"), Lit56, "open another screen");
        }
        ModuleMethod moduleMethod5 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr13 = new Object[3];
            objArr13[0] = "The variable ";
            Object[] objArr14 = objArr13;
            objArr14[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr15 = objArr14;
            objArr15[2] = " is not bound in the current context";
            obj5 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr15), "Unbound Variable");
        } else {
            obj5 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod5, LList.list2(obj5, "Medicines"), Lit57, "=") != Boolean.FALSE) {
            Object callYailPrimitive5 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen8"), Lit58, "open another screen");
        }
        ModuleMethod moduleMethod6 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr16 = new Object[3];
            objArr16[0] = "The variable ";
            Object[] objArr17 = objArr16;
            objArr17[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr18 = objArr17;
            objArr18[2] = " is not bound in the current context";
            obj6 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr18), "Unbound Variable");
        } else {
            obj6 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod6, LList.list2(obj6, "Food"), Lit59, "=") != Boolean.FALSE) {
            Object callYailPrimitive6 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen9"), Lit60, "open another screen");
        }
        ModuleMethod moduleMethod7 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr19 = new Object[3];
            objArr19[0] = "The variable ";
            Object[] objArr20 = objArr19;
            objArr20[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr21 = objArr20;
            objArr21[2] = " is not bound in the current context";
            obj7 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr21), "Unbound Variable");
        } else {
            obj7 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod7, LList.list2(obj7, "Doctor"), Lit61, "=") != Boolean.FALSE) {
            Object callYailPrimitive7 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen10"), Lit62, "open another screen");
        }
        ModuleMethod moduleMethod8 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr22 = new Object[3];
            objArr22[0] = "The variable ";
            Object[] objArr23 = objArr22;
            objArr23[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr24 = objArr23;
            objArr24[2] = " is not bound in the current context";
            obj8 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr24), "Unbound Variable");
        } else {
            obj8 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod8, LList.list2(obj8, "Home Nurse"), Lit63, "=") != Boolean.FALSE) {
            Object callYailPrimitive8 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen11"), Lit64, "open another screen");
        }
        ModuleMethod moduleMethod9 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr25 = new Object[3];
            objArr25[0] = "The variable ";
            Object[] objArr26 = objArr25;
            objArr26[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr27 = objArr26;
            objArr27[2] = " is not bound in the current context";
            obj9 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr27), "Unbound Variable");
        } else {
            obj9 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod9, LList.list2(obj9, "Home ICU"), Lit65, "=") != Boolean.FALSE) {
            Object callYailPrimitive9 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen12"), Lit66, "open another screen");
        }
        ModuleMethod moduleMethod10 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr28 = new Object[3];
            objArr28[0] = "The variable ";
            Object[] objArr29 = objArr28;
            objArr29[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr30 = objArr29;
            objArr30[2] = " is not bound in the current context";
            obj10 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr30), "Unbound Variable");
        } else {
            obj10 = $tab2;
        }
        if (C1241runtime.callYailPrimitive(moduleMethod10, LList.list2(obj10, "Mental Health"), Lit67, "=") != Boolean.FALSE) {
            Object callYailPrimitive10 = C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen13"), Lit68, "open another screen");
        }
        ModuleMethod moduleMethod11 = C1241runtime.yail$Mnequal$Qu;
        if ($tab2 instanceof Package) {
            Object[] objArr31 = new Object[3];
            objArr31[0] = "The variable ";
            Object[] objArr32 = objArr31;
            objArr32[1] = C1241runtime.getDisplayRepresentation(Lit48);
            Object[] objArr33 = objArr32;
            objArr33[2] = " is not bound in the current context";
            obj11 = C1241runtime.signalRuntimeError(strings.stringAppend(objArr33), "Unbound Variable");
        } else {
            obj11 = $tab2;
        }
        return C1241runtime.callYailPrimitive(moduleMethod11, LList.list2(obj11, "Social Groups"), Lit69, "=") != Boolean.FALSE ? C1241runtime.callYailPrimitive(C1241runtime.open$Mnanother$Mnscreen, LList.list1("Screen14"), Lit70, "open another screen") : Values.empty;
    }

    static Object lambda6() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit93, Lit94, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit95, Lit96, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit97, "cov-aid_orange.jpeg", Lit9);
    }

    static Object lambda7() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit93, Lit94, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit95, Lit96, Lit5);
        return C1241runtime.setAndCoerceProperty$Ex(Lit92, Lit97, "cov-aid_orange.jpeg", Lit9);
    }

    static Object lambda8() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit100, Lit11, Lit101, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit100, Lit102, "updated.png", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit100, Lit103, "", Lit9);
    }

    static Object lambda9() {
        Object andCoerceProperty$Ex = C1241runtime.setAndCoerceProperty$Ex(Lit100, Lit11, Lit101, Lit5);
        Object andCoerceProperty$Ex2 = C1241runtime.setAndCoerceProperty$Ex(Lit100, Lit102, "updated.png", Lit9);
        return C1241runtime.setAndCoerceProperty$Ex(Lit100, Lit103, "", Lit9);
    }

    public Object Floating_Action_Button1$Click() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit105, Lit106, LList.list1("Real-Time Updated Statistics"), Lit107);
    }

    public Object Floating_Action_Button1$LongClick() {
        C1241runtime.setThisForm();
        return C1241runtime.callComponentMethod(Lit105, Lit106, LList.list1("Real-Time Updated Statistics"), Lit110);
    }

    /* renamed from: io.kodular.anshsingh2006_1.COV_AID_2.Screen5$frame */
    /* compiled from: Screen5.yail */
    public class frame extends ModuleBody {
        Screen5 $main;

        public frame() {
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Screen5)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                case 23:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Screen5)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof Screen5)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            Throwable th;
            Throwable th2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th3 = th2;
                        new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw th3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th4 = th;
                        new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw th4;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            Throwable th4;
            Throwable th5;
            Throwable th6;
            Throwable th7;
            Throwable th8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    Throwable th9 = th8;
                                    new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw th9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                Throwable th10 = th7;
                                new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw th10;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            Throwable th11 = th6;
                            new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw th11;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        Throwable th12 = th5;
                        new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw th12;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    Throwable th13 = th4;
                                    new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw th13;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                Throwable th14 = th3;
                                new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw th14;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            Throwable th15 = th2;
                            new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw th15;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        Throwable th16 = th;
                        new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw th16;
                    }
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            Throwable th;
            Throwable th2;
            Throwable th3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        Throwable th4 = th3;
                        new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw th4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th2;
                        new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw th5;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        Throwable th6 = th;
                        new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw th6;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                case 23:
                    return this.$main.Tab_Layout1$TabItemSelected(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return Screen5.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return Screen5.lambda3();
                case 20:
                    return this.$main.Screen5$Initialize();
                case 21:
                    return Screen5.lambda4();
                case 22:
                    return Screen5.lambda5();
                case 24:
                    return Screen5.lambda6();
                case 25:
                    return Screen5.lambda7();
                case 26:
                    return Screen5.lambda8();
                case 27:
                    return Screen5.lambda9();
                case 28:
                    return this.$main.Floating_Action_Button1$Click();
                case 29:
                    return this.$main.Floating_Action_Button1$LongClick();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 20:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 24:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f243pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.form$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name = symbol;
        Object default$Mnvalue = obj;
        boolean x = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & true;
        if (!x ? !x : !this.form$Mnenvironment.isBound(name)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol name) {
        return this.form$Mnenvironment.isBound(name);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr2 = objArr;
        objArr2[1] = name;
        Object[] objArr3 = objArr2;
        objArr3[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr4 = objArr3;
        objArr4[3] = object;
        androidLogForm(Format.formatToString(0, objArr4));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object component$Mnname, Object event$Mnname) {
        this.events$Mnto$Mnregister = C1271lists.cons(C1271lists.cons(component$Mnname, event$Mnname), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object container$Mnname, Object component$Mntype, Object component$Mnname, Object init$Mnthunk) {
        this.components$Mnto$Mncreate = C1271lists.cons(LList.list4(container$Mnname, component$Mntype, component$Mnname, init$Mnthunk), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object var, Object val$Mnthunk) {
        this.global$Mnvars$Mnto$Mncreate = C1271lists.cons(LList.list2(var, val$Mnthunk), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object thunk) {
        this.form$Mndo$Mnafter$Mncreation = C1271lists.cons(thunk, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object error) {
        Object obj = error;
        RetValManager.sendError(obj == null ? null : obj.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        objArr2[0] = "any$";
        Object[] objArr3 = objArr2;
        objArr3[1] = getSimpleName(componentObject);
        Object[] objArr4 = objArr3;
        objArr4[2] = "$";
        Object[] objArr5 = objArr4;
        objArr5[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr5)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1271lists.cons(component2, C1271lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object componentName, Object obj) {
        Object eventName = obj;
        Object obj2 = componentName;
        String obj3 = obj2 == null ? null : obj2.toString();
        Object obj4 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj3, obj4 == null ? null : obj4.toString())));
    }

    public void $define() {
        Object obj;
        Throwable th;
        Object obj2;
        Throwable th2;
        Object obj3;
        Throwable th3;
        Object obj4;
        Throwable th4;
        Object obj5;
        Throwable th5;
        Object obj6;
        Throwable th6;
        Object obj7;
        Throwable th7;
        Object obj8;
        Throwable th8;
        Throwable th9;
        Language.setDefaults(Scheme.getInstance());
        try {
            run();
        } catch (Exception e) {
            Exception exception = e;
            androidLogForm(exception.getMessage());
            processException(exception);
        }
        Screen5 = this;
        addToFormEnvironment(Lit0, this);
        Object obj9 = this.events$Mnto$Mnregister;
        while (true) {
            Object obj10 = obj9;
            if (obj10 == LList.Empty) {
                break;
            }
            Object obj11 = obj10;
            Object obj12 = obj11;
            try {
                Pair arg0 = (Pair) obj11;
                Object event$Mninfo = arg0.getCar();
                Object apply1 = C1271lists.car.apply1(event$Mninfo);
                String obj13 = apply1 == null ? null : apply1.toString();
                Object apply12 = C1271lists.cdr.apply1(event$Mninfo);
                EventDispatcher.registerEventForDelegation(this, obj13, apply12 == null ? null : apply12.toString());
                obj9 = arg0.getCdr();
            } catch (ClassCastException e2) {
                ClassCastException classCastException = e2;
                Throwable th10 = th9;
                new WrongType(classCastException, "arg0", -2, obj12);
                throw th10;
            }
        }
        try {
            LList components = C1271lists.reverse(this.components$Mnto$Mncreate);
            addToGlobalVars(Lit2, lambda$Fn1);
            LList event$Mninfo2 = components;
            while (event$Mninfo2 != LList.Empty) {
                Object obj14 = event$Mninfo2;
                obj6 = obj14;
                Pair arg02 = (Pair) obj14;
                Object component$Mninfo = arg02.getCar();
                Object apply13 = C1271lists.caddr.apply1(component$Mninfo);
                Object apply14 = C1271lists.cadddr.apply1(component$Mninfo);
                Object component$Mntype = C1271lists.cadr.apply1(component$Mninfo);
                Object apply15 = C1271lists.car.apply1(component$Mninfo);
                obj7 = apply15;
                Object component$Mnname = apply13;
                Object component$Mnobject = Invoke.make.apply2(component$Mntype, lookupInFormEnvironment((Symbol) apply15));
                Object apply3 = SlotSet.set$Mnfield$Ex.apply3(this, component$Mnname, component$Mnobject);
                Object obj15 = component$Mnname;
                obj8 = obj15;
                addToFormEnvironment((Symbol) obj15, component$Mnobject);
                event$Mninfo2 = arg02.getCdr();
            }
            LList reverse = C1271lists.reverse(this.global$Mnvars$Mnto$Mncreate);
            while (reverse != LList.Empty) {
                Object obj16 = reverse;
                obj4 = obj16;
                Pair arg03 = (Pair) obj16;
                Object var$Mnval = arg03.getCar();
                Object apply16 = C1271lists.car.apply1(var$Mnval);
                obj5 = apply16;
                addToGlobalVarEnvironment((Symbol) apply16, Scheme.applyToArgs.apply1(C1271lists.cadr.apply1(var$Mnval)));
                reverse = arg03.getCdr();
            }
            Object reverse2 = C1271lists.reverse(this.form$Mndo$Mnafter$Mncreation);
            while (reverse2 != LList.Empty) {
                Object obj17 = reverse2;
                obj3 = obj17;
                Pair arg04 = (Pair) obj17;
                Object force = misc.force(arg04.getCar());
                reverse2 = arg04.getCdr();
            }
            LList component$Mndescriptors = components;
            LList lList = component$Mndescriptors;
            while (lList != LList.Empty) {
                Object obj18 = lList;
                obj2 = obj18;
                Pair arg05 = (Pair) obj18;
                Object component$Mninfo2 = arg05.getCar();
                Object apply17 = C1271lists.caddr.apply1(component$Mninfo2);
                Object init$Mnthunk = C1271lists.cadddr.apply1(component$Mninfo2);
                if (init$Mnthunk != Boolean.FALSE) {
                    Object apply18 = Scheme.applyToArgs.apply1(init$Mnthunk);
                }
                lList = arg05.getCdr();
            }
            LList lList2 = component$Mndescriptors;
            while (lList2 != LList.Empty) {
                Object obj19 = lList2;
                obj = obj19;
                Pair arg06 = (Pair) obj19;
                Object component$Mninfo3 = arg06.getCar();
                Object component$Mnname2 = C1271lists.caddr.apply1(component$Mninfo3);
                Object apply19 = C1271lists.cadddr.apply1(component$Mninfo3);
                callInitialize(SlotGet.field.apply2(this, component$Mnname2));
                lList2 = arg06.getCdr();
            }
        } catch (ClassCastException e3) {
            ClassCastException classCastException2 = e3;
            Throwable th11 = th;
            new WrongType(classCastException2, "arg0", -2, obj);
            throw th11;
        } catch (ClassCastException e4) {
            ClassCastException classCastException3 = e4;
            Throwable th12 = th2;
            new WrongType(classCastException3, "arg0", -2, obj2);
            throw th12;
        } catch (ClassCastException e5) {
            ClassCastException classCastException4 = e5;
            Throwable th13 = th3;
            new WrongType(classCastException4, "arg0", -2, obj3);
            throw th13;
        } catch (ClassCastException e6) {
            ClassCastException classCastException5 = e6;
            Throwable th14 = th5;
            new WrongType(classCastException5, "add-to-global-var-environment", 0, obj5);
            throw th14;
        } catch (ClassCastException e7) {
            ClassCastException classCastException6 = e7;
            Throwable th15 = th4;
            new WrongType(classCastException6, "arg0", -2, obj4);
            throw th15;
        } catch (ClassCastException e8) {
            ClassCastException classCastException7 = e8;
            Throwable th16 = th8;
            new WrongType(classCastException7, "add-to-form-environment", 0, obj8);
            throw th16;
        } catch (ClassCastException e9) {
            ClassCastException classCastException8 = e9;
            Throwable th17 = th7;
            new WrongType(classCastException8, "lookup-in-form-environment", 0, obj7);
            throw th17;
        } catch (ClassCastException e10) {
            ClassCastException classCastException9 = e10;
            Throwable th18 = th6;
            new WrongType(classCastException9, "arg0", -2, obj6);
            throw th18;
        } catch (YailRuntimeError e11) {
            processException(e11);
        }
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] argsArray) {
        Throwable th;
        Throwable th2;
        Throwable th3;
        LList symbols = LList.makeList(argsArray, 0);
        LList lList = symbols;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj = symbols;
        Object obj2 = LList.Empty;
        while (true) {
            Object obj3 = obj2;
            Object obj4 = obj;
            if (obj4 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj3));
                Object obj5 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    Throwable th4 = th;
                    new WrongType(classCastException, "string->symbol", 1, obj5);
                    throw th4;
                }
            } else {
                Object obj6 = obj4;
                Object obj7 = obj6;
                try {
                    Pair arg0 = (Pair) obj6;
                    obj = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj8 = car;
                    try {
                        obj2 = Pair.make(misc.symbol$To$String((Symbol) car), obj3);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        Throwable th5 = th3;
                        new WrongType(classCastException2, "symbol->string", 1, obj8);
                        throw th5;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    Throwable th6 = th2;
                    new WrongType(classCastException3, "arg0", -2, obj7);
                    throw th6;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
